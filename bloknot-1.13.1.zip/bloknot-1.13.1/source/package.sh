#!/bin/sh
# Сборка архива поставки: ./package.sh  →  dist/tetrad-<версия>.zip
set -e
cd "$(dirname "$0")"
VERSION=$(node -p "require('./package.json').version")
NAME="bloknot-$VERSION"
node build.cjs
rm -rf "dist/$NAME" "dist/$NAME.zip"
mkdir -p "dist/$NAME/upload/data" "dist/$NAME/source"
# приложение (без данных)
cp -r app/index.php app/api.php app/cron.php app/favicon.ico app/.htaccess app/.user.ini app/lib app/assets "dist/$NAME/upload/"
cp app/data/.htaccess app/data/index.html "dist/$NAME/upload/data/"
# исходники и тесты
cp -r src tests build.cjs package.json package.sh "dist/$NAME/source/"
cp README.md LICENSE THIRD-PARTY-LICENSES.md "dist/$NAME/"
# приложение для Windows (собирается на GitHub, см. windows-app/README.md)
mkdir -p "dist/$NAME/windows-app"
cp -r desktop/. "dist/$NAME/windows-app/"
rm -rf "dist/$NAME/windows-app/node_modules" "dist/$NAME/windows-app/src-tauri/target" "dist/$NAME/windows-app/src-tauri/gen"
(cd dist && python3 - "$NAME" <<'PY'
import os, sys, zipfile
name = sys.argv[1]
with zipfile.ZipFile(name + '.zip', 'w', zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(name):
        dirs.sort()
        for f in sorted(files):
            p = os.path.join(root, f)
            z.write(p, p)
PY
)
echo "Готово: dist/$NAME.zip"
