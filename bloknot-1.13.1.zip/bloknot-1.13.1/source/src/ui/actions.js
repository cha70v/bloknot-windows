// Действия со страницами, общие для боковой панели, меню страницы и редактора
import { api } from '../api.js';
import { state, upsertPage, loadTree, descendants, toggleExpanded, removePageLocal } from '../store.js';
import { toast, confirmDialog } from './modal.js';
import { pickPageDialog } from './pagepicker.js';
import { pageTitle, downloadUrl } from '../util.js';

export function navigate(hash) {
  if (location.hash !== hash) location.hash = hash;
  else window.dispatchEvent(new HashChangeEvent('hashchange'));
}

export function openPage(id) {
  navigate(`#/p/${id}`);
}

export async function createPage(parentId = null, { open = true, title = '' } = {}) {
  try {
    const p = await api('page.create', { parent_id: parentId, title });
    upsertPage(p);
    if (parentId) toggleExpanded(parentId, true);
    if (open) navigate(`#/p/${p.id}?new=1`);
    return p;
  } catch (e) {
    toast(`Не удалось создать страницу: ${e.message}`, 'error');
    return null;
  }
}

export async function trashPage(id) {
  const p = state.pages.get(id);
  const affected = [id, ...descendants(id)];
  const n = affected.length - 1;
  try {
    await api('page.trash', { id });
    removePageLocal(id);
    toast(n ? `«${pageTitle(p)}» и вложенные (${n}) в корзине` : `«${pageTitle(p)}» в корзине`, 'info', {
      duration: 6000,
      action: {
        label: 'Отменить',
        onClick: async () => {
          await api('page.restore', { id });
          await loadTree();
        },
      },
    });
    if (affected.includes(state.currentId)) navigate(p && p.parent_id ? `#/p/${p.parent_id}` : '#/');
    return true;
  } catch (e) {
    toast(`Не удалось удалить: ${e.message}`, 'error');
    return false;
  }
}

export async function duplicatePage(id) {
  try {
    const p = await api('page.duplicate', { id });
    await loadTree();
    toast('Страница скопирована');
    openPage(p.id);
  } catch (e) {
    toast(`Не удалось скопировать: ${e.message}`, 'error');
  }
}

export async function movePageDialog(id) {
  const exclude = new Set([id, ...descendants(id)]);
  const res = await pickPageDialog({ title: `Переместить «${pageTitle(state.pages.get(id))}»`, exclude, allowRoot: true });
  if (!res) return;
  try {
    await api('page.move', { id, parent_id: res.id });
    if (res.id) toggleExpanded(res.id, true);
    await loadTree();
    toast('Страница перемещена');
  } catch (e) {
    toast(e.message, 'error');
  }
}

export function exportPage(id, children = true) {
  downloadUrl(`api.php?a=export.md&id=${id}&children=${children ? 1 : 0}`);
}

export async function purgePage(id, title) {
  const ok = await confirmDialog({
    title: 'Удалить навсегда?',
    text: `Страница «${title}» и все вложенные страницы будут удалены без возможности восстановления.`,
    confirm: 'Удалить навсегда',
    danger: true,
  });
  if (!ok) return false;
  await api('page.purge', { id });
  return true;
}

export async function toggleFavorite(id, on) {
  const p = state.pages.get(id);
  if (on === undefined) on = !(p && p.favorite_at);
  try {
    const res = await api('page.favorite', { id, on });
    upsertPage(res);
    toast(on ? 'Добавлено в избранное' : 'Убрано из избранного');
  } catch (e) {
    toast(e.message, 'error');
  }
}
