<?php
/** Изображения: загрузка, проверка, выдача с проверкой прав, очистка неиспользуемых. */

function allowed_image_types()
{
    return array(
        IMAGETYPE_JPEG => 'image/jpeg',
        IMAGETYPE_PNG => 'image/png',
        IMAGETYPE_GIF => 'image/gif',
        IMAGETYPE_WEBP => 'image/webp',
    );
}

function file_storage_path($id)
{
    return uploads_dir() . '/' . substr($id, 0, 2) . '/' . $id;
}

function upload_limit_bytes()
{
    $toBytes = function ($v) {
        $v = trim((string) $v);
        if ($v === '' || $v === '-1') return PHP_INT_MAX;
        $n = (float) $v;
        $u = strtolower(substr($v, -1));
        if ($u === 'g') $n *= 1024 * 1024 * 1024;
        elseif ($u === 'm') $n *= 1024 * 1024;
        elseif ($u === 'k') $n *= 1024;
        return (int) $n;
    };
    $limit = min($toBytes(ini_get('upload_max_filesize')), $toBytes(ini_get('post_max_size')));
    if ($limit <= 0) $limit = PHP_INT_MAX;
    return (int) min($limit, MAX_IMAGE_BYTES);
}

/** Проверяет файл на диске и возвращает [mime, width, height]. Бросает HttpError, если это не изображение. */
function validate_image_file($path, $size)
{
    if ($size <= 0) throw new HttpError(422, 'Пустой файл');
    if ($size > MAX_IMAGE_BYTES) throw new HttpError(413, 'Изображение больше 15 МБ');
    $info = @getimagesize($path);
    $types = allowed_image_types();
    if (!$info || !isset($types[$info[2]])) {
        throw new HttpError(415, 'Поддерживаются только изображения JPEG, PNG, GIF и WebP');
    }
    $mime = $types[$info[2]];
    if (function_exists('finfo_open')) {
        $f = finfo_open(FILEINFO_MIME_TYPE);
        $real = $f ? finfo_file($f, $path) : false;
        if ($f) finfo_close($f);
        if ($real && $real !== $mime) {
            throw new HttpError(415, 'Содержимое файла не соответствует типу изображения');
        }
    }
    // защита от «полиглотов»: изображение не должно содержать исполняемый код
    $head = file_get_contents($path, false, null, 0, min($size, 2 * 1024 * 1024));
    if (preg_match('/<\?php|<script[\s>]|<html[\s>]/i', $head)) {
        throw new HttpError(415, 'Файл содержит подозрительный код и отклонён');
    }
    return array($mime, (int) $info[0], (int) $info[1]);
}

function store_image($uid, $tmpPath, $size, $originalName, $pageId, $isUploaded)
{
    list($mime, $w, $h) = validate_image_file($tmpPath, $size);
    if ($pageId) {
        $pageId = (int) $pageId;
        if (!q_val('SELECT id FROM pages WHERE id = ? AND owner_id = ?', array($pageId, $uid))) $pageId = null;
    } else {
        $pageId = null;
    }
    $id = random_token(16);
    $dest = file_storage_path($id);
    if (!is_dir(dirname($dest)) && !@mkdir(dirname($dest), 0750, true)) {
        throw new HttpError(500, 'Не удалось создать каталог для файлов. Проверьте права на папку data.');
    }
    $ok = $isUploaded ? move_uploaded_file($tmpPath, $dest) : rename($tmpPath, $dest);
    if (!$ok && !$isUploaded) $ok = copy($tmpPath, $dest);
    if (!$ok) throw new HttpError(500, 'Не удалось сохранить файл');
    @chmod($dest, 0640);
    $name = t_substr(preg_replace('/[^\p{L}\p{N}\s._()-]+/u', '_', basename((string) $originalName)), 0, 120);
    q('INSERT INTO files(id, owner_id, page_id, mime, size, width, height, original_name, created_at) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)',
        array($id, $uid, $pageId, $mime, $size, $w, $h, $name, now_ms()));
    return array('id' => $id, 'mime' => $mime, 'size' => $size, 'width' => $w, 'height' => $h, 'name' => $name);
}

function file_upload($uid)
{
    if (empty($_FILES['file'])) {
        if (!empty($_SERVER['CONTENT_LENGTH']) && (int) $_SERVER['CONTENT_LENGTH'] > upload_limit_bytes()) {
            throw new HttpError(413, 'Файл больше допустимого хостингом размера (' . round(upload_limit_bytes() / 1048576, 1) . ' МБ)');
        }
        throw new HttpError(422, 'Файл не получен');
    }
    $f = $_FILES['file'];
    if (is_array($f['error'])) throw new HttpError(422, 'Загружайте по одному файлу');
    if ($f['error'] === UPLOAD_ERR_INI_SIZE || $f['error'] === UPLOAD_ERR_FORM_SIZE) {
        throw new HttpError(413, 'Файл больше допустимого хостингом размера (' . round(upload_limit_bytes() / 1048576, 1) . ' МБ)');
    }
    if ($f['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name'])) {
        throw new HttpError(422, 'Ошибка загрузки файла (код ' . (int) $f['error'] . ')');
    }
    return store_image($uid, $f['tmp_name'], (int) $f['size'], $f['name'], isset($_POST['page_id']) ? $_POST['page_id'] : null, true);
}

function is_public_ip($ip)
{
    return (bool) filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE);
}

/** Скачивает изображение по ссылке на свой сервер (с защитой от обращений во внутреннюю сеть). */
function file_fetch_url($uid, $url, $pageId)
{
    $url = trim((string) $url);
    for ($hop = 0; $hop < 4; $hop++) {
        $parts = parse_url($url);
        if (!$parts || empty($parts['host']) || !in_array(strtolower(isset($parts['scheme']) ? $parts['scheme'] : ''), array('http', 'https'), true)) {
            throw new HttpError(422, 'Укажите ссылку, начинающуюся с http:// или https://');
        }
        $host = $parts['host'];
        $ips = filter_var($host, FILTER_VALIDATE_IP) ? array($host) : @gethostbynamel($host);
        if (!$ips) throw new HttpError(422, 'Не удалось найти сервер ' . $host);
        foreach ($ips as $ip) {
            if (!is_public_ip($ip)) throw new HttpError(422, 'Ссылки на внутреннюю сеть запрещены');
        }
        $tmpDir = TETRAD_DATA . '/tmp';
        if (!is_dir($tmpDir)) @mkdir($tmpDir, 0750, true);
        $tmp = $tmpDir . '/fetch-' . random_token(8);
        $res = http_download($url, $tmp, $ips[0]);
        if ($res['redirect']) {
            @unlink($tmp);
            $url = absolutize_url($url, $res['redirect']);
            continue;
        }
        if ($res['status'] < 200 || $res['status'] >= 300) {
            @unlink($tmp);
            throw new HttpError(422, 'Сервер вернул ошибку ' . $res['status']);
        }
        $name = basename(isset($parts['path']) ? $parts['path'] : 'image') ?: 'image';
        try {
            return store_image($uid, $tmp, filesize($tmp), $name, $pageId, false);
        } finally {
            @unlink($tmp);
        }
    }
    throw new HttpError(422, 'Слишком много перенаправлений');
}

function absolutize_url($base, $loc)
{
    if (preg_match('#^https?://#i', $loc)) return $loc;
    $b = parse_url($base);
    $origin = $b['scheme'] . '://' . $b['host'] . (isset($b['port']) ? ':' . $b['port'] : '');
    if (str_starts_with($loc, '//')) return $b['scheme'] . ':' . $loc;
    if (str_starts_with($loc, '/')) return $origin . $loc;
    $dir = isset($b['path']) ? preg_replace('#/[^/]*$#', '/', $b['path']) : '/';
    return $origin . $dir . $loc;
}

function http_download($url, $dest, $pinnedIp)
{
    $max = MAX_IMAGE_BYTES;
    if (function_exists('curl_init')) {
        $fh = fopen($dest, 'wb');
        $ch = curl_init($url);
        $parts = parse_url($url);
        $port = isset($parts['port']) ? $parts['port'] : (strtolower($parts['scheme']) === 'https' ? 443 : 80);
        $written = 0;
        curl_setopt_array($ch, array(
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_USERAGENT => 'Tetrad/' . TETRAD_VERSION,
            CURLOPT_RESOLVE => array($parts['host'] . ':' . $port . ':' . $pinnedIp),
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_HEADER => false,
            CURLOPT_WRITEFUNCTION => function ($ch, $data) use ($fh, &$written, $max) {
                $written += strlen($data);
                if ($written > $max) return 0;
                return fwrite($fh, $data);
            },
        ));
        $ok = curl_exec($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $redirect = curl_getinfo($ch, CURLINFO_REDIRECT_URL);
        $err = curl_error($ch);
        curl_close($ch);
        fclose($fh);
        if ($written > $max) throw new HttpError(413, 'Изображение больше 15 МБ');
        if (!$ok && !$redirect) throw new HttpError(422, 'Не удалось скачать изображение: ' . $err);
        return array('status' => $status, 'redirect' => ($status >= 300 && $status < 400) ? $redirect : null);
    }
    if (!ini_get('allow_url_fopen')) throw new HttpError(422, 'Хостинг не разрешает скачивать файлы по ссылке. Сохраните изображение и загрузите его с устройства.');
    $ctx = stream_context_create(array('http' => array('follow_location' => 0, 'timeout' => 25, 'user_agent' => 'Tetrad/' . TETRAD_VERSION, 'ignore_errors' => true)));
    $in = @fopen($url, 'rb', false, $ctx);
    if (!$in) throw new HttpError(422, 'Не удалось скачать изображение');
    $meta = stream_get_meta_data($in);
    $status = 0;
    $redirect = null;
    foreach ($meta['wrapper_data'] as $h) {
        if (preg_match('#^HTTP/\S+\s+(\d+)#', $h, $m)) $status = (int) $m[1];
        if (stripos($h, 'Location:') === 0) $redirect = trim(substr($h, 9));
    }
    if ($status >= 300 && $status < 400 && $redirect) {
        fclose($in);
        return array('status' => $status, 'redirect' => $redirect);
    }
    $out = fopen($dest, 'wb');
    $n = stream_copy_to_stream($in, $out, $max + 1);
    fclose($in);
    fclose($out);
    if ($n > $max) throw new HttpError(413, 'Изображение больше 15 МБ');
    return array('status' => $status, 'redirect' => null);
}

function file_serve($uid, $id)
{
    if (!preg_match('/^[a-f0-9]{32}$/', (string) $id)) throw new HttpError(404, 'Файл не найден');
    $f = q_one('SELECT * FROM files WHERE id = ? AND owner_id = ?', array($id, $uid));
    $path = file_storage_path($id);
    if ($f && !is_file($path)) file_restore_duplicate($id);
    if (!$f || !is_file($path)) throw new HttpError(404, 'Файл не найден');
    $etag = '"' . $id . '"';
    header('Cache-Control: private, max-age=31536000, immutable');
    header('ETag: ' . $etag);
    if (isset($_SERVER['HTTP_IF_NONE_MATCH']) && trim($_SERVER['HTTP_IF_NONE_MATCH']) === $etag) {
        http_response_code(304);
        exit;
    }
    $ext = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp');
    $name = pathinfo($f['original_name'] ?: 'image', PATHINFO_FILENAME) . '.' . (isset($ext[$f['mime']]) ? $ext[$f['mime']] : 'bin');
    header('Content-Type: ' . $f['mime']);
    header('Content-Length: ' . filesize($path));
    header("Content-Security-Policy: default-src 'none'; sandbox");
    header('Content-Disposition: ' . (!empty($_GET['dl']) ? 'attachment' : 'inline') . "; filename*=UTF-8''" . rawurlencode($name));
    readfile($path);
    exit;
}

/**
 * В резервной копии одинаковые изображения хранятся один раз, а список копий лежит в uploads/_duplicates.json.
 * Если архив распаковали вручную (по FTP), недостающая копия создаётся при первом обращении.
 */
function file_restore_duplicate($id)
{
    $map = uploads_dir() . '/_duplicates.json';
    if (!is_file($map)) return false;
    $dups = json_decode((string) file_get_contents($map), true);
    $rel = substr($id, 0, 2) . '/' . $id;
    if (!is_array($dups) || !isset($dups[$rel]) || !preg_match('#^[a-f0-9]{2}/[a-f0-9]{32}$#', (string) $dups[$rel])) return false;
    $src = uploads_dir() . '/' . $dups[$rel];
    $dst = file_storage_path($id);
    if (!is_file($src)) return false;
    if (!is_dir(dirname($dst))) @mkdir(dirname($dst), 0750, true);
    return @copy($src, $dst);
}

/** Ссылается ли хоть одна страница или версия на файл. */
function file_is_referenced($id)
{
    $like = '%' . $id . '%';
    if (q_val('SELECT 1 FROM pages WHERE content LIKE ? OR cover = ? LIMIT 1', array($like, 'file:' . $id))) return true;
    if (q_val('SELECT 1 FROM revisions WHERE content LIKE ? LIMIT 1', array($like))) return true;
    return false;
}

function files_delete_if_unreferenced($uid, $ids)
{
    $n = 0;
    foreach ($ids as $id) {
        if (!file_is_referenced($id)) {
            @unlink(file_storage_path($id));
            q('DELETE FROM files WHERE id = ? AND owner_id = ?', array($id, $uid));
            $n++;
        }
    }
    return $n;
}

/** Удаляет файлы, на которые больше нигде нет ссылок (старше суток — чтобы не задеть только что загруженные). */
function files_cleanup($uid)
{
    $ids = q('SELECT id FROM files WHERE owner_id = ? AND created_at < ?', array($uid, now_ms() - 86400000))->fetchAll(PDO::FETCH_COLUMN);
    $before = (int) q_val('SELECT COALESCE(SUM(size),0) FROM files WHERE owner_id = ?', array($uid));
    $n = files_delete_if_unreferenced($uid, $ids);
    $after = (int) q_val('SELECT COALESCE(SUM(size),0) FROM files WHERE owner_id = ?', array($uid));
    return array('deleted' => $n, 'freed' => $before - $after);
}

function storage_stats($uid)
{
    $files = q_one('SELECT COUNT(*) AS n, COALESCE(SUM(size),0) AS bytes FROM files WHERE owner_id = ?', array($uid));
    return array(
        'pages' => (int) q_val('SELECT COUNT(*) FROM pages WHERE owner_id = ? AND deleted_at IS NULL', array($uid)),
        'trash' => (int) q_val('SELECT COUNT(*) FROM pages WHERE owner_id = ? AND deleted_at IS NOT NULL', array($uid)),
        'files' => (int) $files['n'],
        'files_bytes' => (int) $files['bytes'],
        'db_bytes' => is_file(db_path()) ? filesize(db_path()) : 0,
        'upload_limit' => upload_limit_bytes(),
        'disk_free' => function_exists('disk_free_space') ? @disk_free_space(TETRAD_DATA) : null,
    );
}
