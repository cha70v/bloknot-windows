// Обращение к серверу
import { emitter } from './util.js';

export const apiEvents = emitter();
let csrf = '';

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.status = status;
    this.data = data || {};
  }
  get offline() {
    return this.status === 0;
  }
}

export function setCsrf(t) {
  csrf = t || '';
}

export async function api(action, data, { method, keepalive = false, query = {} } = {}) {
  const params = new URLSearchParams(Object.assign({ a: action }, query));
  const m = method || (data === undefined ? 'GET' : 'POST');
  const init = { method: m, credentials: 'same-origin', headers: {}, keepalive, cache: 'no-store' };
  if (m === 'POST') {
    init.headers['X-CSRF-Token'] = csrf;
    if (data instanceof FormData) init.body = data;
    else {
      init.headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(data || {});
    }
  }
  let res;
  try {
    res = await fetch(`api.php?${params}`, init);
  } catch (e) {
    throw new ApiError('Нет связи с сервером', 0);
  }
  let body = null;
  const text = await res.text();
  try {
    body = text ? JSON.parse(text) : null;
  } catch (e) {
    body = null;
  }
  if (!res.ok) {
    const msg = (body && body.error) || (res.status >= 500 ? `Ошибка сервера (${res.status})` : `Ошибка ${res.status}`);
    const err = new ApiError(msg, res.status, body);
    if (res.status === 401 && body && body.auth) apiEvents.emit('auth-required');
    if (res.status === 403 && body && body.csrf) apiEvents.emit('csrf-expired');
    throw err;
  }
  return body;
}

/** Загрузка файла с прогрессом */
export function upload(action, formData, onProgress) {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `api.php?a=${encodeURIComponent(action)}`);
    xhr.setRequestHeader('X-CSRF-Token', csrf);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
    };
    xhr.onload = () => {
      let body = null;
      try {
        body = JSON.parse(xhr.responseText);
      } catch (e) {
        body = null;
      }
      if (xhr.status >= 200 && xhr.status < 300 && body) resolve(body);
      else {
        let msg = (body && body.error) || `Ошибка ${xhr.status}`;
        if (xhr.status === 413) msg = (body && body.error) || 'Файл больше лимита хостинга';
        if (xhr.status === 401) apiEvents.emit('auth-required');
        reject(new ApiError(msg, xhr.status, body));
      }
    };
    xhr.onerror = () => reject(new ApiError('Нет связи с сервером', 0));
    xhr.send(formData);
  });
}

export function fileUrl(id) {
  return `api.php?a=file&id=${encodeURIComponent(id)}`;
}
