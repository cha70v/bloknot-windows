// ИИ-помощник: команда над выделенным текстом через сервер Блокнота (GigaChat или другое подключение)
import { el } from '../util.js';
import { icon } from '../icons.js';
import { api } from '../api.js';
import { positionPopup, viewportBox } from '../ui/menu.js';
import { toast } from '../ui/modal.js';
import { markdownToBlocks, blocksToText } from './convert.js';
import { getRange } from './caret.js';
import { state } from '../store.js';

const QUICK = [
  ['Исправить ошибки', 'Исправь орфографические, пунктуационные и грамматические ошибки. Больше ничего не меняй.'],
  ['Улучшить текст', 'Сделай текст яснее и лучше по стилю, сохранив смысл и тон.'],
  ['Сократить', 'Сократи текст примерно вдвое, сохранив главное.'],
  ['Подробнее', 'Раскрой текст подробнее, добавь пояснения и детали по теме.'],
  ['На английский', 'Переведи на английский язык.'],
  ['На русский', 'Переведи на русский язык.'],
  ['Списком', 'Оформи содержание в виде маркированного списка тезисов.'],
  ['Объяснить', 'Объясни простыми словами, о чём этот текст.'],
];

// для пустой строки: написать новый текст
const QUICK_NEW = [
  ['Продолжить текст', 'Продолжи текст страницы по смыслу: напиши следующий абзац.'],
  ['Составить план', 'Составь краткий план по теме страницы в виде списка.'],
  ['Предложить идеи', 'Предложи 5 идей по теме страницы списком.'],
  ['Подвести итог', 'Кратко подведи итог написанного на странице.'],
];

export class AiPanel {
  constructor(editor) {
    this.editor = editor;
    this.pop = null;
    this.seq = 0;
  }

  /** Открывает панель для всего текста блока (из меню блока). */
  openForBlock(id) {
    const host = this.editor.editableOf(id);
    if (!host) return;
    const r = document.createRange();
    r.selectNodeContents(host);
    this.editor.clearSelection && this.editor.clearSelection();
    this.open(r);
  }

  /** Несколько выделенных строк: команда выполняется над всеми сразу. */
  openForBlocks(ids) {
    const ed = this.editor;
    const list = ids.map((id) => ed.block(id)).filter((b) => b && b.html !== undefined && ed.editableOf(b.id));
    if (!list.length) return;
    if (list.length === 1) return this.openForBlock(list[0].id);
    const first = ed.editableOf(list[0].id);
    const last = ed.editableOf(list[list.length - 1].id);
    const r = document.createRange();
    r.setStart(first, 0);
    r.setEnd(last, last.childNodes.length);
    const text = blocksToText(list, ed.convertCtx());
    if (!text.trim()) return;
    ed.clearSelection && ed.clearSelection();
    this.close();
    this.lastKb = null;
    this.ctx = { mode: 'blocks', blockIds: list.map((b) => b.id), range: r, host: last, blockId: list[0].id, text, rect: r.getBoundingClientRect() };
    this.build();
  }

  /** Пустая строка: ответ ИИ сразу пишется в эту строку. */
  openForEmpty(id) {
    const ed = this.editor;
    const host = ed.editableOf(id);
    const b = ed.block(id);
    if (!host || !b) return;
    ed.clearSelection && ed.clearSelection();
    const r = document.createRange();
    r.selectNodeContents(host);
    r.collapse(true);
    this.close();
    this.lastKb = null;
    this.ctx = { mode: 'write', range: r, host, blockId: id, text: '', rect: host.getBoundingClientRect(), context: this.pageContext(id) };
    this.build();
  }

  /** Текст страницы до строки (для «продолжи», «подведи итог»): последние ~4000 символов. */
  pageContext(id) {
    const ed = this.editor;
    const i = ed.index(id);
    const parts = [];
    for (const x of ed.blocks.slice(0, i)) {
      const t = ed.editableOf(x.id);
      const txt = t ? t.textContent : '';
      if (txt && txt.trim()) parts.push(txt.trim());
    }
    const all = parts.join('\n');
    return all.length > 4000 ? all.slice(-4000) : all;
  }

  /** Открывает панель для текущего выделения (или переданного диапазона). */
  open(given) {
    const r = given || getRange();
    if (!r || r.collapsed) return;
    const host = (r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement).closest('[contenteditable="true"]');
    const b = host ? this.editor.blockFromNode(host) : null;
    if (!host || !b) return;
    const text = r.toString();
    if (!text.trim()) return;
    this.lastKb = null;
    this.ctx = { mode: 'edit', range: r.cloneRange(), host, blockId: b.id, text, rect: r.getBoundingClientRect() };
    this.close();
    this.build();
  }

  build() {
    const sheet = matchMedia('(max-width: 640px), (pointer: coarse)').matches;
    // телефон: полноэкранное окно над клавиатурой — клавиатура его не перекрывает
    this.pop = el('div', { class: `ai-pop${sheet ? ' is-sheet' : ''}`, role: 'dialog', 'aria-modal': sheet ? 'true' : 'false', 'aria-label': 'ИИ-помощник' });
    const write = this.ctx.mode === 'write';
    this.input = el('textarea', { class: 'ai-input', rows: '1', placeholder: write ? 'Что написать? Например: «план поездки на выходные»' : 'Что сделать с текстом?', 'aria-label': 'Команда для ИИ', maxlength: '2000' });
    const send = el('button', { type: 'button', class: 'ai-send', title: 'Выполнить (Enter)', 'aria-label': 'Выполнить' }, icon('arrowUp', 16));
    send.addEventListener('click', () => this.run(this.input.value));
    this.input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
        e.preventDefault();
        this.run(this.input.value);
      } else if (e.key === 'Escape') {
        e.preventDefault();
        this.close(true);
      }
    });
    this.input.addEventListener('input', () => this.autosize());
    this.body = el('div', { class: 'ai-body' });
    const chips = el('div', { class: 'ai-chips' }, ...(write ? (this.ctx.context ? QUICK_NEW : []) : QUICK).map(([label, cmd]) => {
      const c = el('button', { type: 'button', class: 'ai-chip' }, label);
      c.addEventListener('click', () => {
        this.input.value = label;
        this.run(cmd, label);
      });
      return c;
    }));
    this.chips = chips;
    const close = el('button', { type: 'button', class: 'icon-btn ai-close', 'aria-label': 'Закрыть', title: 'Закрыть (Esc)' }, icon('x', 16));
    close.addEventListener('click', () => this.close(true));
    const head = el('div', { class: 'ai-head' }, el('span', { class: 'ai-badge' }, icon('sparkle', 15), 'ИИ'), el('span', { class: 'ai-sel' }, write ? 'Ответ появится в этой строке' : this.ctx.mode === 'blocks' ? `Выделено строк: ${this.ctx.blockIds.length}` : `Выделено: ${this.ctx.text.length.toLocaleString('ru')} симв.`), close);
    const parts = [head];
    if (sheet) {
      // текст страницы закрыт окном — показываем, с чем работает ИИ
      const src = write ? 'Ответ появится в выбранной пустой строке.' : this.ctx.text.trim();
      parts.push(el('div', { class: `ai-source${write ? ' is-note' : ''}` }, src.length > 1200 ? src.slice(0, 1200) + '…' : src));
    }
    parts.push(el('div', { class: 'ai-row' }, this.input, send), chips, this.body);
    this.pop.append(...parts);
    this.pop.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        this.close(true);
      }
    });
    document.body.append(this.pop);
    this.showMark();
    this.place();
    this.input.focus({ preventScroll: true });
    this.onDown = (e) => {
      if (this.pop && !this.pop.contains(e.target) && !e.target.closest('.fmt-bar')) this.close();
    };
    setTimeout(() => document.addEventListener('pointerdown', this.onDown, true), 0);
    // Esc закрывает панель, даже если фокус ушёл из неё (например, после нажатия быстрой команды)
    this.onKey = (e) => {
      if (e.key === 'Escape' && this.pop && !e.defaultPrevented) {
        e.preventDefault();
        this.close(true);
      }
    };
    document.addEventListener('keydown', this.onKey);
    this.onScroll = () => this.place();
    window.addEventListener('resize', this.onScroll);
    window.addEventListener('scroll', this.onScroll, true);
    if (window.visualViewport) {
      window.visualViewport.addEventListener('resize', this.onScroll);
      window.visualViewport.addEventListener('scroll', this.onScroll);
    }
  }

  /** Подсветка обрабатываемого текста, пока открыта панель (фокус уходит в поле команды, а текст остаётся выделенным). */
  showMark() {
    this.hideMark();
    if (this.ctx.mode === 'write' || this.ctx.mode === 'blocks') {
      for (const id of this.ctx.blockIds || [this.ctx.blockId]) {
        const n = this.editor.nodes.get(id);
        if (n) n.classList.add('is-ai-target');
      }
      this.markMode = 'line';
      return;
    }
    const r = this.ctx.range;
    if (window.CSS && CSS.highlights && typeof Highlight === 'function') {
      CSS.highlights.set('ai-target', new Highlight(r));
      this.markMode = 'hl';
      return;
    }
    // запасной вариант для старых браузеров: полупрозрачные прямоугольники поверх текста
    this.markMode = 'box';
    this.markLayer = el('div', { class: 'ai-mark-layer', 'aria-hidden': 'true' });
    document.body.append(this.markLayer);
    this.drawBoxes();
  }

  drawBoxes() {
    if (this.markMode !== 'box' || !this.markLayer) return;
    this.markLayer.textContent = '';
    for (const rc of this.ctx.range.getClientRects()) {
      if (!rc.width) continue;
      this.markLayer.append(el('div', { class: 'ai-mark', style: `left:${rc.left}px;top:${rc.top}px;width:${rc.width}px;height:${rc.height}px` }));
    }
  }

  hideMark() {
    if (this.markMode === 'hl' && window.CSS && CSS.highlights) CSS.highlights.delete('ai-target');
    if (this.markMode === 'line') document.querySelectorAll('.is-ai-target').forEach((n) => n.classList.remove('is-ai-target', 'is-ai-busy'));
    if (this.markLayer) this.markLayer.remove();
    this.markLayer = null;
    this.markMode = null;
  }

  place() {
    this.drawBoxes();
    if (!this.pop) return;
    if (this.pop.classList.contains('is-sheet')) {
      // телефон: окно занимает всю видимую часть экрана над клавиатурой
      const box = viewportBox();
      this.pop.style.top = `${Math.round(box.top + box.shift)}px`;
      this.pop.style.height = `${Math.round(box.bottom - box.top)}px`;
      return;
    }
    const host = this.ctx.host;
    const rect = !host.isConnected ? this.ctx.rect : this.ctx.mode === 'write' || this.ctx.mode === 'blocks' ? host.getBoundingClientRect() : this.ctx.range.getBoundingClientRect();
    positionPopup(this.pop, rect.width || rect.height ? rect : this.ctx.rect, 'bottom-start', 10);
  }

  autosize() {
    this.input.style.height = 'auto';
    this.input.style.height = `${Math.min(140, this.input.scrollHeight)}px`;
  }

  close(restore = false) {
    if (!this.pop) return;
    this.seq++;
    document.removeEventListener('pointerdown', this.onDown, true);
    document.removeEventListener('keydown', this.onKey);
    window.removeEventListener('resize', this.onScroll);
    window.removeEventListener('scroll', this.onScroll, true);
    if (window.visualViewport) {
      window.visualViewport.removeEventListener('resize', this.onScroll);
      window.visualViewport.removeEventListener('scroll', this.onScroll);
    }
    this.pop.remove();
    this.pop = null;
    if (this.padded) {
      this.padded.style.paddingBottom = '';
      this.padded = null;
    }
    this.hideMark();
    if (restore && this.ctx && this.ctx.host.isConnected) {
      this.ctx.host.focus({ preventScroll: true });
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(this.ctx.range);
    }
  }

  async run(instruction, label) {
    instruction = (instruction || '').trim();
    if (!instruction) {
      this.input.focus();
      return;
    }
    this.lastCmd = [instruction, label];
    const my = ++this.seq;
    this.body.textContent = '';
    this.chips.hidden = true;
    this.body.append(el('div', { class: 'ai-loading' }, el('span', { class: 'ai-spinner' }), 'ИИ думает…'));
    this.place();
    const page = state.pages.get(state.currentId);
    const write = this.ctx.mode === 'write';
    const line = write ? this.editor.nodes.get(this.ctx.blockId) : null;
    if (line) line.classList.add('is-ai-busy');
    try {
      const res = await api('ai.run', { instruction, text: this.ctx.text, context: write ? this.ctx.context : '', title: page ? page.title || '' : '' });
      if (my !== this.seq || !this.pop) return;
      if (write) {
        // пустая строка: ответ сразу вставляется в неё
        this.result = res.text;
        this.apply('fill');
        toast(`Текст от ИИ вставлен${res.truncated ? ' (ответ обрезан по длине)' : ''}`, 'info', { action: { label: 'Отменить', onClick: () => this.editor.undo() } });
        return;
      }
      this.showResult(res);
    } catch (e) {
      if (line) line.classList.remove('is-ai-busy');
      if (my !== this.seq || !this.pop) return;
      this.showError(e);
    }
  }

  showResult(res) {
    this.body.textContent = '';
    this.result = res.text;
    const out = el('div', { class: 'ai-result', tabindex: '0' });
    out.textContent = res.text;
    const btn = (label, ic, fn, primary) => {
      const b = el('button', { type: 'button', class: `btn btn-small${primary ? ' btn-primary' : ''}${label ? '' : ' ai-icon-btn'}`, title: label || 'Копировать', 'aria-label': label || 'Копировать' }, ic ? icon(ic, 14) : null, label || null);
      b.addEventListener('click', fn);
      return b;
    };
    const actions = el(
      'div',
      { class: 'ai-actions' },
      btn('Заменить выделенное', 'check', () => this.apply('replace'), true),
      btn('Вставить ниже', 'plus', () => this.apply('below')),
      btn('', 'copy', async () => {
        try {
          await navigator.clipboard.writeText(res.text);
          toast('Скопировано');
        } catch (e) {
          toast('Не удалось скопировать', 'error');
        }
      }),
      btn('Ещё раз', 'refresh', () => this.run(this.lastCmd[0], this.lastCmd[1])),
    );
    const meta = el('div', { class: 'ai-meta' }, `${res.provider ? res.provider + ' · ' : ''}${res.model || ''}${res.ms ? ` · ${(res.ms / 1000).toFixed(1)} с` : ''}${res.truncated ? ' · ответ обрезан по длине' : ''}`);
    this.body.append(out, actions, meta);
    this.place();
    actions.querySelector('.btn-primary').focus({ preventScroll: true });
  }

  showError(e) {
    this.body.textContent = '';
    this.chips.hidden = false;
    const box = el('div', { class: 'ai-error' }, el('span', null, e.message || 'Не удалось выполнить запрос'));
    if (e.data && e.data.ai_setup) {
      const b = el('button', { type: 'button', class: 'btn btn-small btn-primary' }, 'Открыть настройки ИИ');
      b.addEventListener('click', () => {
        this.close();
        window.dispatchEvent(new CustomEvent('tetrad:settings', { detail: 'ai' }));
      });
      box.append(b);
    }
    this.body.append(box);
    this.place();
  }

  /** Вставка результата: вместо выделенного фрагмента или новыми блоками ниже. */
  apply(mode) {
    const ed = this.editor;
    const { host, range, blockId } = this.ctx;
    const text = this.result || '';
    const b = ed.block(blockId);
    if (!b || !host.isConnected) {
      toast('Блок изменился — скопируйте результат и вставьте вручную', 'error');
      return;
    }
    this.close();
    if (this.ctx.mode === 'blocks') {
      const ids = this.ctx.blockIds.filter((id) => ed.block(id));
      if (!ids.length) return;
      const blocks = markdownToBlocks(text);
      if (!blocks.length) return;
      const base = ed.block(ids[0]).indent || 0;
      if (base) blocks.forEach((x) => (x.indent = Math.min(8, (x.indent || 0) + base)));
      ed.checkpoint();
      if (mode === 'replace') {
        const at = ed.index(ids[0]);
        for (const id of ids.slice().reverse()) ed.removeAt(ed.index(id));
        ed.insertBlocksAt(at, blocks);
      } else {
        const li = ed.index(ids[ids.length - 1]);
        ed.insertBlocksAt(ed.isClosed(li) ? ed.subtreeEnd(li) : li + 1, blocks);
      }
      ed.changed();
      const lastB = blocks[blocks.length - 1];
      if (lastB.html !== undefined) ed.focusBlock(lastB.id, 'end');
      return;
    }
    if (mode === 'fill') {
      const blocks = markdownToBlocks(text);
      if (!blocks.length) return;
      host.focus({ preventScroll: true });
      if (blocks.length === 1 && blocks[0].type === 'p') {
        // одна строка — остаётся тип строки (заголовок, пункт списка…)
        const sel = window.getSelection();
        const r = document.createRange();
        r.selectNodeContents(host);
        sel.removeAllRanges();
        sel.addRange(r);
        ed.checkpoint();
        document.execCommand('insertHTML', false, blocks[0].html || '');
        return;
      }
      ed.pasteBlocks(b, host, blocks);
      return;
    }
    const isMain = host.classList.contains('blk-text');
    if (mode === 'below' || !isMain) {
      if (mode === 'replace') {
        // подпись или ячейка таблицы — только текст
        host.focus({ preventScroll: true });
        const sel = window.getSelection();
        sel.removeAllRanges();
        sel.addRange(range);
        document.execCommand('insertText', false, text.replace(/\s*\n\s*/g, ' '));
        return;
      }
      const blocks = markdownToBlocks(text);
      if (!blocks.length) return;
      const base = b.indent || 0;
      if (base) blocks.forEach((x) => (x.indent = Math.min(8, (x.indent || 0) + base)));
      ed.checkpoint();
      const i = ed.index(b.id);
      const at = ed.isClosed(i) ? ed.subtreeEnd(i) : i + 1;
      ed.insertBlocksAt(at, blocks);
      ed.changed();
      const last = blocks[blocks.length - 1];
      if (last.html !== undefined) ed.focusBlock(last.id, 'end');
      return;
    }
    host.focus({ preventScroll: true });
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
    if (!/\n/.test(text)) {
      document.execCommand('insertText', false, text);
      return;
    }
    const blocks = markdownToBlocks(text);
    if (blocks.length === 1 && blocks[0].type === 'p') {
      document.execCommand('insertHTML', false, blocks[0].html || '');
      return;
    }
    // несколько абзацев: удаляем выделенное и вставляем блоки на место каретки, как при вставке из буфера
    document.execCommand('delete');
    host.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
    ed.pasteBlocks(b, host, blocks);
  }
}
