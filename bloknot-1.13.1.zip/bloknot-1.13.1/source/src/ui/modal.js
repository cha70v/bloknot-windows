// Диалоги, уведомления и выбор эмодзи
import { el } from '../util.js';
import { icon } from '../icons.js';
import { positionPopup, isSheetMode } from './menu.js';

let toastHost = null;

export function toast(message, type = 'info', opts = {}) {
  if (!toastHost) {
    toastHost = el('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' });
    document.body.append(toastHost);
  }
  // одинаковые уведомления не копятся стопкой — новое заменяет прежнее
  for (const old of Array.from(toastHost.children)) {
    if (old.dataset.msg === message) old.remove();
  }
  const t = el('div', { class: `toast toast-${type}`, 'data-msg': message }, el('span', { class: 'toast-text' }, message));
  if (opts.action) {
    const b = el('button', { type: 'button', class: 'toast-action' }, opts.action.label);
    b.addEventListener('click', () => {
      opts.action.onClick();
      t.remove();
    });
    t.append(b);
  }
  const close = el('button', { type: 'button', class: 'toast-close', 'aria-label': 'Закрыть' }, icon('x', 14));
  close.addEventListener('click', () => t.remove());
  t.append(close);
  toastHost.append(t);
  const ms = opts.duration || (type === 'error' ? 7000 : 2600);
  if (ms !== Infinity) setTimeout(() => t.remove(), ms);
  return t;
}

/** Модальное окно. content — узел или функция (close) => узел. */
export function modal({ title, content, className = '', onClose, wide = false, dismissable = true }) {
  const prev = document.activeElement;
  const backdrop = el('div', { class: 'modal-backdrop' });
  const box = el('div', { class: `modal ${wide ? 'is-wide' : ''} ${className}`, role: 'dialog', 'aria-modal': 'true', 'aria-label': title || '' });
  const close = () => {
    backdrop.remove();
    document.removeEventListener('keydown', onKey, true);
    if (prev && prev.focus && document.contains(prev)) prev.focus({ preventScroll: true });
    onClose && onClose();
  };
  const onKey = (e) => {
    if (e.key === 'Escape' && dismissable) {
      e.preventDefault();
      e.stopPropagation();
      close();
    }
    if (e.key === 'Tab') {
      const f = Array.from(box.querySelectorAll('button, input, select, textarea, a[href], [tabindex]:not([tabindex="-1"])')).filter((x) => !x.disabled && x.offsetParent);
      if (!f.length) return;
      const first = f[0];
      const last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
  };
  if (title) {
    const head = el('div', { class: 'modal-head' }, el('h2', { class: 'modal-title' }, title));
    if (dismissable) {
      const x = el('button', { type: 'button', class: 'icon-btn modal-x', 'aria-label': 'Закрыть' }, icon('x'));
      x.addEventListener('click', close);
      head.append(x);
    }
    box.append(head);
  }
  const body = el('div', { class: 'modal-body' });
  body.append(typeof content === 'function' ? content(close) : content);
  box.append(body);
  backdrop.append(box);
  if (dismissable) {
    backdrop.addEventListener('pointerdown', (e) => {
      if (e.target === backdrop) close();
    });
  }
  document.body.append(backdrop);
  document.addEventListener('keydown', onKey, true);
  // фокус ставится сразу, чтобы символы, набранные сразу после открытия, не попали на страницу
  const focusAuto = () => {
    const auto = box.querySelector('[autofocus], input, textarea, select, .btn-primary');
    const t = auto || box;
    if (t.focus) t.focus({ preventScroll: true });
  };
  focusAuto();
  setTimeout(() => {
    if (!box.contains(document.activeElement)) focusAuto();
  }, 0);
  return { close, box, body };
}

export function confirmDialog({ title, text, confirm = 'Подтвердить', cancel = 'Отмена', danger = false }) {
  return new Promise((resolve) => {
    let done = false;
    const m = modal({
      title,
      content: (close) => {
        const ok = el('button', { type: 'button', class: `btn ${danger ? 'btn-danger' : 'btn-primary'}` }, confirm);
        const no = el('button', { type: 'button', class: 'btn' }, cancel);
        ok.addEventListener('click', () => {
          done = true;
          resolve(true);
          close();
        });
        no.addEventListener('click', () => close());
        return el('div', null, text ? el('p', { class: 'modal-text' }, text) : null, el('div', { class: 'modal-actions' }, no, ok));
      },
      onClose: () => {
        if (!done) resolve(false);
      },
    });
    setTimeout(() => m.box.querySelector(danger ? '.btn' : '.btn-primary').focus(), 0);
  });
}

export function promptDialog({ title, label, value = '', placeholder = '', confirm = 'Готово', allowEmpty = false, type = 'text' }) {
  return new Promise((resolve) => {
    let done = false;
    modal({
      title,
      content: (close) => {
        const input = el('input', { type, class: 'input', value, placeholder, autofocus: true, spellcheck: 'false' });
        const ok = el('button', { type: 'submit', class: 'btn btn-primary' }, confirm);
        const no = el('button', { type: 'button', class: 'btn' }, 'Отмена');
        const form = el('form', { class: 'prompt-form' }, label ? el('label', { class: 'field-label' }, label) : null, input, el('div', { class: 'modal-actions' }, no, ok));
        form.addEventListener('submit', (e) => {
          e.preventDefault();
          const v = input.value.trim();
          if (!v && !allowEmpty) {
            input.focus();
            return;
          }
          done = true;
          resolve(v);
          close();
        });
        no.addEventListener('click', () => close());
        setTimeout(() => input.select(), 0);
        return form;
      },
      onClose: () => {
        if (!done) resolve(allowEmpty ? null : null);
      },
    });
  });
}

// ---------- выбор эмодзи ----------
const EMOJI = {
  'Частые': '📄 📝 📌 📎 📚 📖 📘 📙 📗 📕 📓 📔 🗂️ 📁 🗃️ 🗒️ 📅 🗓️ ✅ ☑️ ⭐ 🌟 💡 🔥 ⚡ 🎯 🚀 🧭 🔖 🏷️ 🔑 🔒',
  'Работа': '💼 🧑‍💻 💻 🖥️ ⌨️ 🖱️ 📊 📈 📉 🧮 🧾 📋 📐 📏 ✏️ ✒️ 🖊️ 🖋️ 🖌️ 🎨 🧪 🔬 🛠️ 🔧 ⚙️ 🧩 🗄️ 📬 📮 ☎️ 📞 🗣️',
  'Жизнь': '🏠 🏡 🛋️ 🍳 🥗 🍎 ☕ 🍵 🧘 🏃 🚴 ⚽ 🎾 🏋️ 🧳 ✈️ 🚗 🚆 🗺️ 🏖️ ⛰️ 🌲 🌿 🌸 🌻 🐱 🐶 👶 ❤️ 💰 🛒 🎁 🎉',
  'Учёба': '🎓 🏫 📝 🧠 🔤 🔢 🌍 🗿 🏛️ ⚗️ 🧬 🔭 🎼 🎹 🎸 🎬 📷 🎧 📺 🎮 ♟️ 🧶 ✂️ 🧵',
  'Символы': '❗ ❓ ⚠️ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ ➕ ➖ ✖️ ➗ ♻️ ✳️ ❇️ 🔺 🔻 💠 🔷 🔶 🆕 🆗',
};

export function pickEmoji(anchor, onPick, { allowRemove = true } = {}) {
  const pop = el('div', { class: `emoji-pop ${isSheetMode() ? 'is-sheet' : ''}`, role: 'dialog', 'aria-label': 'Выбор значка' });
  const input = el('input', { class: 'input emoji-input', placeholder: 'Свой значок: вставьте эмодзи', maxlength: '8' });
  const head = el('div', { class: 'emoji-head' }, input);
  if (allowRemove) {
    const rm = el('button', { type: 'button', class: 'btn btn-small' }, 'Убрать');
    rm.addEventListener('click', () => {
      done('');
    });
    head.append(rm);
  }
  pop.append(head);
  const grid = el('div', { class: 'emoji-grid' });
  for (const [group, list] of Object.entries(EMOJI)) {
    grid.append(el('div', { class: 'emoji-group' }, group));
    for (const e of list.split(' ')) {
      const b = el('button', { type: 'button', class: 'emoji-btn', title: e }, e);
      b.addEventListener('click', () => done(e));
      grid.append(b);
    }
  }
  pop.append(grid);
  const backdrop = isSheetMode() ? el('div', { class: 'sheet-backdrop' }) : null;
  function cleanup() {
    pop.remove();
    if (backdrop) backdrop.remove();
    document.removeEventListener('pointerdown', outside, true);
    document.removeEventListener('keydown', key, true);
  }
  function done(v) {
    cleanup();
    onPick(v);
  }
  function outside(e) {
    if (!pop.contains(e.target)) cleanup();
  }
  function key(e) {
    if (e.key === 'Escape') {
      e.stopPropagation();
      cleanup();
    }
  }
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && input.value.trim()) {
      e.preventDefault();
      done(Array.from(input.value.trim()).slice(0, 4).join(''));
    }
  });
  if (backdrop) document.body.append(backdrop);
  document.body.append(pop);
  if (!isSheetMode()) positionPopup(pop, anchor.getBoundingClientRect(), 'bottom-start');
  setTimeout(() => document.addEventListener('pointerdown', outside, true), 0);
  document.addEventListener('keydown', key, true);
  const first = grid.querySelector('.emoji-btn');
  if (first) first.focus();
}
