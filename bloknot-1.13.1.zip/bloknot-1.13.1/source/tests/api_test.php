<?php
/**
 * Интеграционные тесты серверной части Тетради.
 * Запуск: php tests/api_test.php
 * Тест копирует приложение во временную папку, поднимает встроенный сервер PHP и проходит сценарии через HTTP.
 */

$ROOT = dirname(__DIR__);
$APP = is_dir($ROOT . '/app') ? $ROOT . '/app' : dirname($ROOT) . '/upload'; // в архиве поставки — ../upload
$TMP = sys_get_temp_dir() . '/tetrad-test-' . bin2hex(random_bytes(3));
$PORT = 18000 + random_int(0, 999);
$BASE = "http://127.0.0.1:$PORT";

$passed = 0;
$failed = 0;
function ok($cond, $name)
{
    global $passed, $failed;
    if ($cond) { $passed++; echo "  ✓ $name\n"; }
    else { $failed++; echo "  ✕ $name\n"; }
    return $cond;
}
function section($t) { echo "\n$t\n"; }

function copy_dir($src, $dst)
{
    @mkdir($dst, 0777, true);
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($src, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::SELF_FIRST);
    foreach ($it as $f) {
        $target = $dst . '/' . substr($f->getPathname(), strlen($src) + 1);
        if ($f->isDir()) @mkdir($target, 0777, true);
        else copy($f->getPathname(), $target);
    }
}

$server = null;
function start_server()
{
    global $server, $TMP, $PORT;
    $sendmail = dirname(__DIR__) . '/tests/support/fake-sendmail.sh ' . $TMP . '-mail';
    $cmd = sprintf('exec php -d sendmail_path=%s -S 127.0.0.1:%d -t %s %s/router.php', escapeshellarg($sendmail), $PORT, escapeshellarg($TMP), escapeshellarg($TMP));
    $server = proc_open($cmd, array(0 => array('pipe', 'r'), 1 => array('file', $TMP . '-server.log', 'a'), 2 => array('file', $TMP . '-server.log', 'a')), $pipes);
    for ($i = 0; $i < 50; $i++) {
        usleep(100000);
        if (@fsockopen('127.0.0.1', $PORT)) return;
    }
    die("Сервер не запустился\n");
}
function stop_server()
{
    global $server;
    if ($server) { proc_terminate($server); proc_close($server); $server = null; }
}

class Client
{
    public $jar;
    public $csrf = '';
    public function __construct() { $this->jar = tempnam(sys_get_temp_dir(), 'jar'); }
    public function req($method, $path, $data = null, $opts = array())
    {
        global $BASE;
        $ch = curl_init($BASE . $path);
        $headers = array();
        if ($this->csrf && empty($opts['no_csrf'])) $headers[] = 'X-CSRF-Token: ' . $this->csrf;
        if (!empty($opts['headers'])) $headers = array_merge($headers, $opts['headers']);
        curl_setopt_array($ch, array(
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_COOKIEJAR => $this->jar,
            CURLOPT_COOKIEFILE => $this->jar,
            CURLOPT_HEADER => true,
            CURLOPT_FOLLOWLOCATION => false,
        ));
        if ($data !== null) {
            if (!empty($opts['multipart']) || !empty($opts['form'])) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            } else {
                $headers[] = 'Content-Type: application/json';
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $resp = curl_exec($ch);
        $status = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $hsize = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        curl_close($ch);
        $head = substr($resp, 0, $hsize);
        $body = substr($resp, $hsize);
        return array('status' => $status, 'headers' => $head, 'body' => $body, 'json' => json_decode($body, true));
    }
    public function api($action, $data = null, $method = null, $opts = array())
    {
        $q = is_array($action) ? http_build_query($action) : 'a=' . $action;
        return $this->req($method ?: ($data === null ? 'GET' : 'POST'), '/api.php?' . $q, $data, $opts);
    }
    public function login($email, $pwd)
    {
        $s = $this->api('auth.status');
        $this->csrf = $s['json']['csrf'];
        $r = $this->api('auth.login', array('email' => $email, 'password' => $pwd));
        if ($r['status'] === 200) $this->csrf = $r['json']['csrf'];
        return $r;
    }
}

function make_png($w = 40, $h = 30)
{
    $im = imagecreatetruecolor($w, $h);
    imagefill($im, 0, 0, imagecolorallocate($im, 40, 120, 200));
    ob_start();
    imagepng($im);
    return ob_get_clean();
}

// ------------------------------------------------------------------
copy_dir($APP, $TMP);
copy($ROOT . '/tests/router.php', $TMP . '/router.php');
start_server();
register_shutdown_function(function () use ($TMP) { stop_server(); });

$EMAIL = 'denis@example.com';
$PWD = 'Очень-секретный-пароль-1';

section('Сборка');
$css = preg_replace(array('#/\*.*?\*/#s', '/"[^"]*"/'), array('', '""'), file_get_contents(dirname(__DIR__) . '/src/styles.css'));
$depth = 0; $neg = false;
foreach (str_split($css) as $ch) { if ($ch === '{') $depth++; elseif ($ch === '}') { $depth--; if ($depth < 0) { $neg = true; $depth = 0; } } }
ok($depth === 0 && !$neg, 'В стилях нет лишних или потерянных фигурных скобок (иначе браузер молча выбрасывает правила)');

section('Установка');
$c = new Client();
$r = $c->req('GET', '/');
ok($r['status'] === 200 && str_contains($r['body'], 'Установка Блокнота'), 'Мастер установки открывается');
preg_match('/name="csrf" value="([^"]+)"/', $r['body'], $m);
$csrf = $m[1];
ok(is_file("$TMP/data/setup-code.txt"), 'Создан файл с кодом установки');
preg_match('/([A-Z0-9]{4}-[A-Z0-9]{4})/', file_get_contents("$TMP/data/setup-code.txt"), $m);
$code = $m[1];
$r = $c->req('POST', '/', http_build_query(array('csrf' => $csrf, 'code' => 'AAAA-BBBB', 'email' => $EMAIL, 'password' => $PWD, 'password2' => $PWD)), array('form' => true));
ok($r['status'] === 200 && str_contains($r['body'], 'Неверный код'), 'Неверный код установки отклоняется');
$r = $c->req('GET', '/data/setup-code.txt');
ok($r['status'] === 403, 'Файл с кодом недоступен из браузера');
$r = $c->req('POST', '/', http_build_query(array('csrf' => $csrf, 'code' => strtolower($code), 'name' => 'Денис', 'email' => $EMAIL, 'password' => $PWD, 'password2' => $PWD)), array('form' => true));
ok($r['status'] === 302, 'Установка с верным кодом завершается');
ok(is_file("$TMP/data/config.php") && !is_file("$TMP/data/setup-code.txt"), 'Конфигурация создана, код удалён');
$r = $c->req('GET', '/');
ok(str_contains($r['body'], 'assets/app.js') && str_contains($r['headers'], "Content-Security-Policy: default-src 'self'"), 'После установки открывается приложение с CSP');
$r = $c->req('POST', '/', http_build_query(array('csrf' => $csrf, 'code' => $code, 'email' => 'evil@x.com', 'password' => 'xxxxxxxx', 'password2' => 'xxxxxxxx')), array('form' => true));
$pdo = new PDO('sqlite:' . glob("$TMP/data/*.sqlite")[0]);
ok((int) $pdo->query('select count(*) from users')->fetchColumn() === 1 && !str_contains($r['body'], 'Установка Блокнота'), 'Повторная установка невозможна');
$pdo = null;

section('Переход на HTTPS');
$h = new Client();
$r = $h->req('GET', '/?__probe=https');
ok($r['status'] === 200 && trim($r['body']) === 'bloknot-https-ok', 'Служебная проверка HTTPS отвечает');
$r = $h->req('GET', '/');
ok($r['status'] === 200, 'Локальный адрес (127.0.0.1) не перенаправляется');
$r = $h->req('GET', '/', null, array('headers' => array('Host: notes.invalid-domain.example')));
ok($r['status'] === 200, 'Без работающего сертификата перенаправления нет (сайт не блокируется)');
file_put_contents("$TMP/data/https-check.json", json_encode(array('notes.example.com' => array('ok' => true, 'at' => time()))));
$r = $h->req('GET', '/?x=1', null, array('headers' => array('Host: notes.example.com')));
ok($r['status'] === 301 && str_contains($r['headers'], 'Location: https://notes.example.com/?x=1&_https=1'), 'При рабочем сертификате — перенаправление 301 на https');
$r = $h->req('GET', '/?x=1&_https=1', null, array('headers' => array('Host: notes.example.com')));
ok($r['status'] === 200, 'Защита от зацикливания, если прокси скрывает HTTPS');
$r = $h->req('GET', '/?x=1&_https=1', null, array('headers' => array('Host: notes.example.com', 'X-Forwarded-Proto: https')));
ok($r['status'] === 302 && str_contains($r['headers'], 'Location: /?x=1'), 'На HTTPS служебный параметр убирается');
$r = $h->req('GET', '/', null, array('headers' => array('Host: notes.example.com', 'X-Forwarded-Proto: https')));
ok($r['status'] === 200 && str_contains($r['headers'], 'Strict-Transport-Security'), 'На HTTPS страница отдаётся с HSTS');
touch("$TMP/data/NO-HTTPS-REDIRECT");
$r = $h->req('GET', '/', null, array('headers' => array('Host: notes.example.com')));
ok($r['status'] === 200, 'Файл NO-HTTPS-REDIRECT отключает перенаправление');
unlink("$TMP/data/NO-HTTPS-REDIRECT");
unlink("$TMP/data/https-check.json");

section('Авторизация и доступ');
$anon = new Client();
$r = $anon->api('tree');
ok($r['status'] === 401, 'Без входа дерево страниц недоступно (401)');
$r = $anon->req('GET', '/data/');
ok($r['status'] === 403, 'Каталог data закрыт');
$r = $anon->req('GET', '/lib/bootstrap.php');
ok($r['status'] === 403, 'Каталог lib закрыт');
$r = $anon->login($EMAIL, 'wrong-password');
ok($r['status'] === 401, 'Неверный пароль отклоняется');
$u = new Client();
$r = $u->login(strtoupper($EMAIL), $PWD);
ok($r['status'] === 200, 'Вход по почте (без учёта регистра) и паролю');
ok(str_contains($r['headers'], 'HttpOnly') && stripos($r['headers'], 'SameSite=Lax') !== false, 'Cookie сессии HttpOnly + SameSite');
$csrfSaved = $u->csrf;
$u->csrf = 'bad';
$r = $u->api('page.create', array('title' => 'x'));
ok($r['status'] === 403, 'POST без верного CSRF-токена отклоняется');
$u->csrf = $csrfSaved;

section('Страницы');
$r = $u->api('tree');
ok($r['status'] === 200 && count($r['json']['pages']) === 1 && $r['json']['pages'][0]['title'] === 'Добро пожаловать', 'Есть приветственная страница');
$r = $u->api('page.create', array('title' => 'Проект «Тетрадь»', 'icon' => '📘'));
$p1 = $r['json'];
ok($r['status'] === 200 && $p1['id'] > 0 && $p1['version'] === 1, 'Создание страницы');
$content = array('v' => 1, 'blocks' => array(
    array('id' => 'a1', 'type' => 'h1', 'html' => 'Привет, мир'),
    array('id' => 'a2', 'type' => 'p', 'html' => 'Обычный <b>жирный</b> и <i>курсив</i> текст про ЁЖИКОВ'),
    array('id' => 'a3', 'type' => 'ul', 'html' => 'пункт списка'),
    array('id' => 'a4', 'type' => 'todo', 'html' => 'задача', 'checked' => true),
    array('id' => 'a5', 'type' => 'code', 'text' => "echo 'hi';", 'lang' => 'php'),
));
$r = $u->api('page.save', array('id' => $p1['id'], 'base_version' => 1, 'title' => 'Проект «Тетрадь»', 'content' => $content));
ok($r['status'] === 200 && $r['json']['version'] === 2, 'Сохранение увеличивает версию');
$r = $u->api(array('a' => 'page.get', 'id' => $p1['id']));
ok($r['json']['content']['blocks'][1]['html'] === $content['blocks'][1]['html'] && $r['json']['last_opened_at'] > 0, 'Содержимое читается без искажений, отмечено открытие');

section('Конфликты');
$content2 = $content;
$content2['blocks'][0]['html'] = 'Правка со второго устройства';
$r = $u->api('page.save', array('id' => $p1['id'], 'base_version' => 2, 'content' => $content2));
ok($r['json']['version'] === 3, 'Устройство Б сохраняет версию 3');
$content3 = $content;
$content3['blocks'][0]['html'] = 'Правка с первого устройства по старой версии';
$r = $u->api('page.save', array('id' => $p1['id'], 'base_version' => 2, 'content' => $content3));
ok($r['status'] === 409 && $r['json']['server']['version'] === 3, 'Сохранение поверх более новой версии отклоняется (409) с копией серверной версии');
$r = $u->api(array('a' => 'page.get', 'id' => $p1['id']));
ok($r['json']['content']['blocks'][0]['html'] === 'Правка со второго устройства', 'Более новая версия не перезаписана');
$r = $u->api(array('a' => 'page.revisions', 'id' => $p1['id']));
$conflictRev = null;
foreach ($r['json'] as $rev) if ($rev['reason'] === 'conflict') $conflictRev = $rev;
ok($conflictRev !== null, 'Отклонённая версия сохранена в истории');
$r = $u->api(array('a' => 'revision.get', 'id' => $conflictRev['id']));
ok($r['json']['content']['blocks'][0]['html'] === 'Правка с первого устройства по старой версии', 'Отклонённое содержимое можно восстановить из истории');
$r = $u->api('page.save', array('id' => $p1['id'], 'base_version' => 2, 'content' => $content3, 'force' => true));
ok($r['status'] === 200 && $r['json']['version'] === 4, 'Принудительное сохранение «оставить мою версию»');
$r = $u->api(array('a' => 'poll', 'page' => $p1['id']));
ok($r['json']['page']['version'] === 4 && isset($r['json']['tree_stamp']), 'Опрос изменений возвращает актуальную версию');

section('Изображения');
$png = make_png();
file_put_contents("$TMP-img.png", $png);
$r = $u->api('file.upload', array('file' => new CURLFile("$TMP-img.png", 'image/png', 'фото.png'), 'page_id' => $p1['id']), 'POST', array('multipart' => true));
ok($r['status'] === 200 && strlen($r['json']['id']) === 32 && $r['json']['width'] === 40, 'Загрузка PNG');
$fileId = $r['json']['id'];
file_put_contents("$TMP-evil.jpg", "<?php system(\$_GET['c']); ?>");
$r = $u->api('file.upload', array('file' => new CURLFile("$TMP-evil.jpg", 'image/jpeg', 'evil.jpg')), 'POST', array('multipart' => true));
ok($r['status'] === 415, 'PHP-скрипт под видом JPEG отклоняется');
file_put_contents("$TMP-poly.png", $png . "<?php echo 1; ?>");
$r = $u->api('file.upload', array('file' => new CURLFile("$TMP-poly.png", 'image/png', 'poly.png')), 'POST', array('multipart' => true));
ok($r['status'] === 415, 'PNG со встроенным PHP-кодом отклоняется');
file_put_contents("$TMP-x.svg", '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
$r = $u->api('file.upload', array('file' => new CURLFile("$TMP-x.svg", 'image/svg+xml', 'x.svg')), 'POST', array('multipart' => true));
ok($r['status'] === 415, 'SVG (риск XSS) не принимается');
$r = $u->api(array('a' => 'file', 'id' => $fileId));
ok($r['status'] === 200 && $r['body'] === $png && str_contains($r['headers'], 'Content-Type: image/png') && str_contains($r['headers'], 'sandbox'), 'Файл отдаётся владельцу с правильным типом и песочницей');
$r = $anon->api(array('a' => 'file', 'id' => $fileId));
ok($r['status'] === 401, 'Посторонний не может скачать вложение');
$r = $anon->req('GET', '/data/uploads/' . substr($fileId, 0, 2) . '/' . $fileId);
ok($r['status'] === 403, 'Прямой доступ к файлу в data/uploads закрыт');
$r = $u->api('file.fetch', array('url' => 'http://127.0.0.1:' . $PORT . '/assets/icon-180.png'));
ok($r['status'] === 422, 'Загрузка по ссылке во внутреннюю сеть запрещена (SSRF)');

section('Иерархия');
$r = $u->api('page.create', array('title' => 'Вложенная', 'parent_id' => $p1['id']));
$child = $r['json'];
ok($child['parent_id'] === $p1['id'], 'Создание вложенной страницы');
$r = $u->api('page.create', array('title' => 'Внучка', 'parent_id' => $child['id']));
$grand = $r['json'];
$r = $u->api('page.move', array('id' => $p1['id'], 'parent_id' => $grand['id']));
ok($r['status'] === 422, 'Нельзя переместить страницу внутрь собственного потомка');
$r = $u->api('page.move', array('id' => $grand['id'], 'parent_id' => null));
ok($r['status'] === 200 && $r['json']['parent_id'] === null, 'Перемещение в корень');
$r = $u->api('page.move', array('id' => $grand['id'], 'parent_id' => $p1['id'], 'before_id' => $child['id']));
$tree = $u->api('tree')['json']['pages'];
$kids = array_values(array_filter($tree, function ($p) use ($p1) { return $p['parent_id'] === $p1['id']; }));
usort($kids, function ($a, $b) { return $a['position'] <=> $b['position']; });
ok($kids[0]['id'] === $grand['id'] && $kids[1]['id'] === $child['id'], 'Изменение порядка (перед указанной страницей)');
$r = $u->api('page.duplicate', array('id' => $p1['id']));
$dup = $r['json'];
ok($r['status'] === 200 && str_contains($dup['title'], '(копия)'), 'Дублирование страницы с вложенными');
$tree = $u->api('tree')['json']['pages'];
$dupKids = array_filter($tree, function ($p) use ($dup) { return $p['parent_id'] === $dup['id']; });
ok(count($dupKids) === 2, 'Вложенные страницы скопированы');

section('Избранное');
$r = $u->api('page.favorite', array('id' => $p1['id'], 'on' => true));
ok($r['status'] === 200 && $r['json']['favorite_at'] > 0, 'Добавление в избранное');
$fav = array_values(array_filter($u->api('tree')['json']['pages'], function ($p) use ($p1) { return $p['id'] === $p1['id']; }));
ok($fav && $fav[0]['favorite_at'] > 0, 'Дерево страниц отдаёт отметку избранного');
$r = $u->api('page.favorite', array('id' => $p1['id'], 'on' => false));
ok($r['status'] === 200 && $r['json']['favorite_at'] === null, 'Удаление из избранного');
$u->api('page.favorite', array('id' => $p1['id'], 'on' => true));

section('Поиск и недавние');
$r = $u->api(array('a' => 'search', 'q' => 'ёжиков'));
ok(count($r['json']) >= 1 && $r['json'][0]['id'] === $p1['id'] || count(array_filter($r['json'], function ($x) use ($p1) { return $x['id'] === $p1['id']; })) === 1, 'Поиск по тексту без учёта регистра (кириллица)');
$r = $u->api(array('a' => 'search', 'q' => 'ПРОЕКТ'));
ok($r['json'][0]['title_hit'] === true, 'Совпадения в названии — первыми');
$r = $u->api(array('a' => 'search', 'q' => '100%_'));
ok($r['status'] === 200 && count($r['json']) === 0, 'Спецсимволы в поиске экранируются');
$r = $u->api('recent');
ok($r['json'][0]['id'] === $p1['id'], 'Недавно открытые');

section('Корзина');
$r = $u->api('page.trash', array('id' => $p1['id']));
ok($r['json']['trashed'] === 3, 'Страница с потомками перемещена в корзину');
$tree = $u->api('tree')['json']['pages'];
ok(!array_filter($tree, function ($p) use ($p1) { return $p['id'] === $p1['id']; }), 'Удалённая страница скрыта из дерева');
$r = $u->api(array('a' => 'page.get', 'id' => $p1['id']));
ok($r['status'] === 410, 'Открытие страницы из корзины → 410');
$r = $u->api('page.save', array('id' => $p1['id'], 'base_version' => 4, 'content' => $content));
ok($r['status'] === 410, 'Сохранение в удалённую страницу запрещено');
$r = $u->api('trash');
ok(count($r['json']) === 1 && $r['json'][0]['children_count'] === 2, 'Корзина показывает корень удаления');
$r = $u->api('page.restore', array('id' => $p1['id']));
$tree = $u->api('tree')['json']['pages'];
ok(count(array_filter($tree, function ($p) use ($p1, $child, $grand) { return in_array($p['id'], array($p1['id'], $child['id'], $grand['id']), true); })) === 3, 'Восстановление вместе с потомками');
// окончательное удаление и очистка файлов
$r = $u->api('page.create', array('title' => 'Временная'));
$tmpPage = $r['json'];
$r = $u->api('file.upload', array('file' => new CURLFile("$TMP-img.png", 'image/png', 'tmp.png'), 'page_id' => $tmpPage['id']), 'POST', array('multipart' => true));
$tmpFile = $r['json']['id'];
$u->api('page.save', array('id' => $tmpPage['id'], 'base_version' => 1, 'content' => array('blocks' => array(array('id' => 'i', 'type' => 'image', 'file' => $tmpFile)))));
$r = $u->api('page.purge', array('id' => $tmpPage['id']));
ok($r['status'] === 422, 'Окончательное удаление только из корзины');
$u->api('page.trash', array('id' => $tmpPage['id']));
$r = $u->api('page.purge', array('id' => $tmpPage['id']));
ok($r['status'] === 200 && !is_file("$TMP/data/uploads/" . substr($tmpFile, 0, 2) . "/$tmpFile"), 'Окончательное удаление стирает страницу и её неиспользуемые файлы');

section('Экспорт');
$r = $u->api(array('a' => 'export.md', 'id' => $p1['id']));
file_put_contents("$TMP-export.zip", $r['body']);
$z = new ZipArchive();
ok($r['status'] === 200 && $z->open("$TMP-export.zip") === true, 'Экспорт страницы в ZIP');
$names = array();
for ($i = 0; $i < $z->numFiles; $i++) $names[] = $z->getNameIndex($i);
$mainMd = $z->getFromName('Проект «Тетрадь».md');
ok($mainMd !== false && str_contains($mainMd, '# Правка с первого') && str_contains($mainMd, '**жирный**') && str_contains($mainMd, '- [x] задача') && str_contains($mainMd, "```php"), 'Markdown: заголовки, форматирование, чек-листы, код');
ok(in_array('Проект «Тетрадь»/Вложенная.md', $names, true), 'Вложенные страницы экспортируются в папку');
$z->close();

section('Резервное копирование и восстановление');
// то же изображение ещё раз (как при повторном импорте) — в архиве должно храниться один раз
$r = $u->api('file.upload', array('file' => new CURLFile("$TMP-img.png", 'image/png', 'копия.png'), 'page_id' => $p1['id']), 'POST', array('multipart' => true));
$dupId = $r['json']['id'];
$r = $u->api('backup');
file_put_contents("$TMP-backup.zip", $r['body']);
$z = new ZipArchive();
$zo = $z->open("$TMP-backup.zip");
$bn = array();
if ($zo === true) { for ($i = 0; $i < $z->numFiles; $i++) $bn[] = $z->getNameIndex($i); $z->close(); }
ok($zo === true && in_array('manifest.json', $bn, true) && count(preg_grep('#^data/.*\.sqlite$#', $bn)) === 1 && count(preg_grep('#^data/uploads/#', $bn)) >= 1, 'Бэкап содержит базу, файлы и манифест');
$z->open("$TMP-backup.zip");
$man = json_decode($z->getFromName('manifest.json'), true);
$dbName = array_values(preg_grep('#^data/.*\.sqlite$#', $bn))[0];
$dbSt = $z->statName($dbName);
$dbRaw = $z->getFromName($dbName);
$z->close();
ok($dbSt['comp_method'] === ZipArchive::CM_DEFLATE && $dbSt['comp_size'] < $dbSt['size'] / 2 && substr($dbRaw, 0, 15) === 'SQLite format 3', 'База в бэкапе сжата без потерь (' . round($dbSt['size'] / 1024) . ' → ' . round($dbSt['comp_size'] / 1024) . ' КБ)');
ok(isset($man['duplicates']) && count($man['duplicates']) === 1 && count(preg_grep('#^data/uploads/[a-f0-9]{2}/#', $bn)) === count(glob("$TMP/data/uploads/*/*")) - 1 && in_array('data/uploads/_duplicates.json', $bn, true), 'Одинаковые изображения хранятся в архиве один раз');
// распаковка без расширения ZipArchive (встроенный читатель с поддержкой сжатия)
$chk = "$TMP-nozip.php";
file_put_contents($chk, '<?php define("TETRAD_NO_ZIPARCHIVE", 1); class HttpError extends Exception { public function __construct($s, $m) { parent::__construct($m); } }
require ' . var_export(dirname(__DIR__) . '/app/lib/zip.php', true) . ';
try { $n = zip_extract_safe($argv[1], $argv[2]); echo count($n), " ok"; } catch (Exception $e) { echo "ERR ", $e->getMessage(); }');
$out = shell_exec('php ' . escapeshellarg($chk) . ' ' . escapeshellarg("$TMP-backup.zip") . ' ' . escapeshellarg("$TMP-nozip") . ' 2>&1');
ok(str_ends_with(trim((string) $out), ' ok') && md5_file("$TMP-nozip/$dbName") === md5($dbRaw), 'Сжатый архив распаковывается и без ZipArchive: ' . trim((string) $out));
$bad = file_get_contents("$TMP-backup.zip");
file_put_contents("$TMP-bad.zip", substr($bad, 0, 200) . str_repeat("\0", 64) . substr($bad, 264));
$out = shell_exec('php ' . escapeshellarg($chk) . ' ' . escapeshellarg("$TMP-bad.zip") . ' ' . escapeshellarg("$TMP-nozip2") . ' 2>&1');
ok(str_starts_with(trim((string) $out), 'ERR'), 'Повреждённый архив распознаётся, а не восстанавливается молча');
// портим данные, затем восстанавливаем
$u->api('page.trash', array('id' => $p1['id']));
$u->api('trash.empty', array());
$r = $u->api(array('a' => 'search', 'q' => 'ёжиков'));
ok(count($r['json']) === 1, 'Данные изменены после бэкапа (осталась только копия)');
$r = $u->api('backup.restore', array('file' => new CURLFile("$TMP-backup.zip", 'application/zip', 'b.zip')), 'POST', array('multipart' => true));
ok($r['status'] === 200 && $r['json']['ok'], 'Восстановление из архива');
$r = $u->api(array('a' => 'page.get', 'id' => $p1['id']));
ok($r['status'] === 200 && $r['json']['title'] === 'Проект «Тетрадь»', 'После восстановления страница на месте');
$r = $u->api(array('a' => 'file', 'id' => $fileId));
ok($r['status'] === 200 && $r['body'] === $png, 'После восстановления изображение на месте');
$r2 = $u->api(array('a' => 'file', 'id' => $dupId));
ok($r2['status'] === 200 && $r2['body'] === $png, 'После восстановления копия одинакового изображения тоже на месте');
// восстановление кусками (обход лимита загрузки хостинга)
$u->api('page.trash', array('id' => $p1['id']));
$u->api('trash.empty', array());
$data = file_get_contents("$TMP-backup.zip");
$tok = bin2hex(random_bytes(10));
$okChunks = true;
foreach (str_split($data, 7000) as $i => $piece) {
    file_put_contents("$TMP-chunk", $piece);
    $r = $u->api('backup.chunk', array('upload' => $tok, 'offset' => (string) ($i * 7000), 'chunk' => new CURLFile("$TMP-chunk", 'application/octet-stream', 'chunk.bin')), 'POST', array('multipart' => true));
    $okChunks = $okChunks && $r['status'] === 200;
}
$r = $u->api('backup.chunk', array('upload' => $tok, 'offset' => '5', 'chunk' => new CURLFile("$TMP-chunk", 'application/octet-stream', 'chunk.bin')), 'POST', array('multipart' => true));
ok($okChunks && $r['status'] === 409, 'Загрузка архива кусками; кусок не по порядку отклоняется');
$r = $u->api('backup.restore', array('upload' => $tok));
ok($r['status'] === 200 && $r['json']['ok'] && $u->api(array('a' => 'page.get', 'id' => $p1['id']))['status'] === 200, 'Восстановление из архива, загруженного кусками');
// ручная распаковка по FTP: копия изображения появляется сама при первом обращении
$copyRel = array_keys($man['duplicates'])[0];
$copyId = basename($copyRel);
@unlink("$TMP/data/uploads/$copyRel");
file_put_contents("$TMP/data/uploads/_duplicates.json", json_encode($man['duplicates']));
$r2 = $u->api(array('a' => 'file', 'id' => $copyId));
ok(in_array($copyId, array($fileId, $dupId), true) && $r2['status'] === 200 && $r2['body'] === $png && is_file("$TMP/data/uploads/$copyRel"), 'После ручной распаковки по FTP одинаковые изображения восстанавливаются сами');
@unlink("$TMP/data/uploads/_duplicates.json");
$out = shell_exec('cd ' . escapeshellarg($TMP) . ' && php cron.php backup 2>&1');
ok(str_contains($out, 'Резервная копия') && count(glob("$TMP/data/backups/*.zip")) === 1, 'Резервное копирование по расписанию (cron.php)');

section('Бэкап на почту');
function mails($dir) { $f = glob($dir . '/*.eml'); sort($f); return $f; }
function mail_text_part($raw)
{
    if (!preg_match('/Content-Type: text\/plain; charset=UTF-8\r?\nContent-Transfer-Encoding: base64\r?\n\r?\n([A-Za-z0-9+\/=\r\n]+)/', $raw, $m)) return '';
    return base64_decode(preg_replace('/\s+/', '', $m[1]));
}
$st = $u->api('mail.status')['json'];
ok($st['enabled'] === false && $st['recipient'] === $EMAIL && $st['transport'] === 'hosting', 'Статус: выключено (галочка при установке не стояла), получатель — почта входа');
$r = $u->api('mail.save', array('enabled' => true, 'interval_days' => 7));
ok($r['status'] === 200 && $r['json']['enabled'] === true, 'Включение отправки без какой-либо настройки почты');
$u->api('tree'); // первое обращение после включения — копия уходит сразу, в фоне
for ($i = 0; $i < 30 && count(mails("$TMP-mail")) < 1; $i++) usleep(200000);
ok(count(mails("$TMP-mail")) === 1, 'После включения первая копия уходит сама (в фоне)');
$r = $u->api('mail.send', array());
$list = mails("$TMP-mail");
ok($r['status'] === 200 && count($list) === 2, 'Кнопка «Отправить сейчас» — письмо через почту хостинга (mail)');
$raw = $list ? file_get_contents(end($list)) : '';
ok(str_contains($raw, 'To: ' . $EMAIL) && str_contains($raw, 'Subject: =?UTF-8?B?') && str_contains($raw, 'From: =?UTF-8?B?'), 'Заголовки письма: получатель, тема и отправитель в UTF-8');
ok(preg_match('/Content-Type: application\/zip; name="bloknot-backup-[0-9-]+\.zip"/', $raw) === 1, 'Полная резервная копия приложена к письму');
$text = mail_text_part($raw);
ok(preg_match('#(http://127\.0\.0\.1:\d+/api\.php\?a=backup\.dl[^\s]+)#', $text, $mDl) === 1 && preg_match('#(http://[^\s]+a=mail\.confirm[^\s]+)#', $text, $mCf) === 1, 'В письме есть ссылка на копию и ссылка подтверждения');
$dl = new Client();
$r = $dl->req('GET', substr($mDl[1], strlen($BASE)));
ok($r['status'] === 200 && substr($r['body'], 0, 2) === 'PK', 'Ссылка из письма скачивает копию без входа');
$r = $dl->req('GET', preg_replace('/s=[a-f0-9]+/', 's=' . str_repeat('0', 40), substr($mDl[1], strlen($BASE))));
ok($r['status'] === 403, 'Подделанная ссылка не работает');
$r = $dl->req('GET', substr($mCf[1], strlen($BASE)));
ok($r['status'] === 200 && $u->api('mail.status')['json']['confirmed_at'] > 0, 'Ссылка «Письма доходят» подтверждает доставку');
$out = shell_exec('cd ' . escapeshellarg($TMP) . ' && php cron.php mail-backup 2>&1');
ok(str_contains($out, 'не требуется'), 'Без изменений и до срока повторная отправка не выполняется');
// прошла неделя и есть изменения — отправка в фоне при обычном использовании
$pdo = new PDO('sqlite:' . glob("$TMP/data/*.sqlite")[0]);
$pdo->exec("UPDATE meta SET value = '" . (time() - 8 * 86400) . "' WHERE key IN ('mail_last_ok_at', 'mail_last_at')");
$pdo = null;
$pg = $u->api('page.create', array('title' => 'Новая заметка для бэкапа'));
$before = count(mails("$TMP-mail"));
$u->api('poll');
for ($i = 0; $i < 30 && count(mails("$TMP-mail")) <= $before; $i++) usleep(200000);
ok(count(mails("$TMP-mail")) === $before + 1, 'Через неделю после изменений копия уходит сама в фоне');
// большая копия — частями в нескольких письмах; из частей данные восстанавливаются
$bk = glob("$TMP/data/backups/*.zip"); sort($bk); $bsize = filesize(end($bk));
file_put_contents("$TMP-limit.php", '<?php define("MAIL_ATTACH_LIMIT", ' . (intdiv($bsize, 3) + 1) . ');');
$before = count(mails("$TMP-mail"));
$out = shell_exec('cd ' . escapeshellarg($TMP) . ' && php -d auto_prepend_file=' . escapeshellarg("$TMP-limit.php") . ' -d sendmail_path=' . escapeshellarg(dirname(__DIR__) . '/tests/support/fake-sendmail.sh ' . $TMP . '-mail') . ' cron.php mail-backup now 2>&1');
$new = array_slice(mails("$TMP-mail"), $before);
$parts = array();
foreach ($new as $f) {
    $raw = file_get_contents($f);
    if (preg_match('/name="(bloknot-backup-[0-9-]+\.zip\.(\d{3}))"[\s\S]*?\r?\n\r?\n([A-Za-z0-9+\/=\r\n]+)/', $raw, $m)) $parts[$m[2]] = base64_decode(preg_replace('/\s+/', '', $m[3]));
}
ksort($parts);
$joined = implode('', $parts);
ok(str_contains((string) $out, 'отправлена') && count($new) >= 3 && count($parts) === count($new) && array_keys($parts) === array_map(function ($i) { return sprintf('%03d', $i); }, range(1, count($new))), 'Большая копия уходит частями (писем: ' . count($new) . '), в каждом своя часть');
ok(str_contains(mail_text_part(file_get_contents($new[0])), 'Это письмо 1 из') && preg_match('/^Subject: (.+(?:\r?\n[ \t].+)*)/m', file_get_contents($new[1]), $sm) && str_contains(mb_decode_mimeheader(preg_replace('/\s+/', ' ', trim($sm[1]))), 'часть 2 из'), 'В теме и тексте писем указан номер части и как восстановить');
$tok = bin2hex(random_bytes(10));
$off = 0;
foreach ($parts as $piece) {
    file_put_contents("$TMP-chunk", $piece);
    $u->api('backup.chunk', array('upload' => $tok, 'offset' => (string) $off, 'chunk' => new CURLFile("$TMP-chunk", 'application/octet-stream', 'part')), 'POST', array('multipart' => true));
    $off += strlen($piece);
}
$r = $u->api('backup.restore', array('upload' => $tok));
ok(substr($joined, 0, 2) === 'PK' && $r['status'] === 200 && $r['json']['ok'] && $u->api(array('a' => 'page.get', 'id' => $pg['json']['id']))['status'] === 200, 'Данные восстанавливаются из частей, присланных письмами');
// запасной вариант: SMTP своего ящика
$SMTP_PORT = $PORT + 1000;
$smtp = proc_open(sprintf('exec php %s %d %s user@example.com app-pass', escapeshellarg(__DIR__ . '/support/fake_smtp.php'), $SMTP_PORT, escapeshellarg("$TMP-smtp")), array(), $pp);
for ($i = 0; $i < 30 && !@fsockopen('127.0.0.1', $SMTP_PORT); $i++) usleep(100000);
$u->api('mail.save', array('smtp_host' => '127.0.0.1', 'smtp_port' => $SMTP_PORT, 'smtp_secure' => 'none', 'smtp_user' => 'user@example.com', 'smtp_pass' => 'wrong'));
$r = $u->api('mail.send', array());
ok($r['status'] === 502 && str_contains($r['json']['error'], 'пароль приложения'), 'Неверный пароль SMTP — понятная ошибка');
$u->api('mail.save', array('smtp_pass' => 'app-pass'));
$r = $u->api('mail.send', array());
ok($r['status'] === 200 && count(mails("$TMP-smtp")) === 1 && $r['json']['transport'] === 'smtp', 'Отправка через SMTP своего ящика');
$st = $u->api('mail.status')['json'];
ok(!isset($st['smtp_pass']) && $st['smtp_pass_set'] === true, 'Пароль SMTP не возвращается в браузер');
// хостинг перехватывает порт: соединение есть, но сервер молчит → понятная ошибка, а не «нет ответа»
$SILENT_PORT = $PORT + 1500;
$silent = proc_open(sprintf('exec php %s %d', escapeshellarg(__DIR__ . '/support/silent_server.php'), $SILENT_PORT), array(), $sp);
for ($i = 0; $i < 30 && !@fsockopen('127.0.0.1', $SILENT_PORT); $i++) usleep(100000);
$u->api('mail.save', array('smtp_host' => '127.0.0.1', 'smtp_port' => $SILENT_PORT, 'smtp_secure' => 'none', 'smtp_user' => 'user@example.com', 'smtp_pass' => 'app-pass'));
$t0 = microtime(true);
$r = $u->api('mail.send', array());
ok($r['status'] === 502 && str_contains($r['json']['error'], 'Хостинг не пропускает подключения') && str_contains($r['json']['error'], 'перехвачено'), 'Молчащий сервер (перехват хостингом) — понятная ошибка с подсказкой');
// перебор портов: настроенный порт молчит, рабочий найден автоматически и запомнен
$FALLBACK_PORT = 2525;
$smtp2 = proc_open(sprintf('exec php %s %d %s user@example.com app-pass', escapeshellarg(__DIR__ . '/support/fake_smtp.php'), $FALLBACK_PORT, escapeshellarg("$TMP-smtp")), array(), $pp2);
for ($i = 0; $i < 30 && !@fsockopen('127.0.0.1', $FALLBACK_PORT); $i++) usleep(100000);
$before = count(mails("$TMP-smtp"));
$r = $u->api('mail.send', array());
ok($r['status'] === 200 && count(mails("$TMP-smtp")) === $before + 1 && $r['json']['smtp_port'] === $FALLBACK_PORT, 'Если порт закрыт, Блокнот сам находит рабочий (2525) и запоминает его');
// диагностика
$u->api('mail.save', array('smtp_port' => $SMTP_PORT));
$r = $u->api('mail.diagnose');
$d = $r['json'];
ok($r['status'] === 200 && isset($d['probe']['127.0.0.1:' . $SMTP_PORT]) && $d['probe']['127.0.0.1:' . $SMTP_PORT]['state'] === 'ok', 'Диагностика: доступный SMTP-сервер помечен как рабочий');
ok(isset($d['probe']['smtp.gmail.com:465']) && $d['probe']['smtp.gmail.com:465']['state'] !== 'ok' && $d['verdict'] !== 'smtp_external' && $d['advice'] !== '', 'Диагностика: недоступный Gmail распознан, есть рекомендация');
$u->api('mail.save', array('smtp_port' => $SILENT_PORT));
$d = $u->api('mail.diagnose')['json'];
ok($d['probe']['127.0.0.1:' . $SILENT_PORT]['state'] === 'silent', 'Диагностика: перехват соединения хостингом распознан');
proc_terminate($silent);
proc_terminate($smtp2);
$u->api('mail.save', array('smtp_clear' => true));
ok($u->api('mail.status')['json']['transport'] === 'hosting', 'Можно вернуться к отправке через хостинг');
proc_terminate($smtp);

section('ИИ-помощник');
$GC_PORT = $PORT + 1700;
$DS_PORT = $PORT + 1800;
$gcLog = "$TMP-gc.log";
$gc = proc_open(sprintf('exec env FAKE_GC_LOG=%s FAKE_GC_ID=%s php -S 127.0.0.1:%d %s', escapeshellarg($gcLog), basename($TMP), $GC_PORT, escapeshellarg(__DIR__ . '/support/fake_gigachat.php')), array(1 => array('file', '/dev/null', 'w'), 2 => array('file', '/dev/null', 'w')), $gp);
$ds = proc_open(sprintf('exec env FAKE_DS_LOG=%s php -S 127.0.0.1:%d %s', escapeshellarg("$TMP-ds.log"), $DS_PORT, escapeshellarg(__DIR__ . '/support/fake_deepseek.php')), array(1 => array('file', '/dev/null', 'w'), 2 => array('file', '/dev/null', 'w')), $dp);
for ($i = 0; $i < 30 && (!@fsockopen('127.0.0.1', $GC_PORT) || !@fsockopen('127.0.0.1', $DS_PORT)); $i++) usleep(100000);
$st = $u->api('ai.status')['json'];
$gcp = $st['profiles'][0];
ok($st['active'] === 'gigachat' && $gcp['type'] === 'gigachat' && $gcp['builtin'] && !$st['configured'] && $gcp['scope'] === 'GIGACHAT_API_PERS' && str_contains($gcp['oauth_url'], 'ngw.devices.sberbank.ru:9443/api/v2/oauth'), 'По умолчанию есть подключение GigaChat — нужно только ввести ключ');
$r = $u->api('ai.run', array('instruction' => 'Сократи', 'text' => 'текст'));
ok($r['status'] === 412 && !empty($r['json']['ai_setup']), 'Без ключа — понятная ошибка и ссылка на настройки');
$r = $u->api('ai.save', array('id' => 'gigachat', 'key' => 'Basic R29vZEtleUZvckdpZ2FDaGF0MTIzNA==', 'base_url' => "http://127.0.0.1:$GC_PORT/api/v1", 'oauth_url' => "http://127.0.0.1:$GC_PORT/api/v2/oauth"));
ok($r['status'] === 200 && $r['json']['configured'] && $r['json']['profiles'][0]['key_hint'] === '…NA==' && !str_contains($r['body'], 'R29vZEtleUZvckdpZ2FDaGF0'), 'Ключ сохраняется, в браузер уходят только последние символы');
$r = $u->api('ai.test', array('id' => 'gigachat'));
ok($r['status'] === 200 && $r['json']['models'] === array('GigaChat', 'GigaChat-2-Pro', 'GigaChat-2-Max'), 'Проверка: токен получен, список моделей без эмбеддингов');
$lines = array_map('json_decode', file($gcLog, FILE_IGNORE_NEW_LINES));
ok($lines[0]->path === '/api/v2/oauth' && preg_match('/^[0-9a-f-]{36}$/', $lines[0]->rquid) && $lines[0]->raw === 'scope=GIGACHAT_API_PERS' && $lines[0]->auth === 'Basic R29vZEtleUZvckdpZ2FDaGF0MTIzNA==', 'Запрос токена: RqUID, scope и ключ авторизации');
$r = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'привет мир', 'title' => 'Заметка'));
ok($r['status'] === 200 && $r['json']['text'] === 'Гига: ПРИВЕТ МИР' && $r['json']['provider'] === 'GigaChat' && $r['json']['tokens'] === 37, 'Команда над текстом выполняется через GigaChat');
$r = $u->api('ai.run', array('instruction' => 'Напиши приветствие', 'text' => '', 'context' => "Первая строка страницы\nВторая", 'title' => 'Заметка'));
$lines = array_map('json_decode', file($gcLog, FILE_IGNORE_NEW_LINES));
$chat = json_decode(end($lines)->raw, true);
ok($r['status'] === 200 && $r['json']['text'] === 'Ответ: Напиши приветствие (с контекстом)' && str_contains($chat['messages'][1]['content'], "<page>\nПервая строка страницы\nВторая\n</page>") && str_contains($chat['messages'][0]['content'], 'вставится в его заметку'), 'Пустая строка: новый текст по запросу с учётом содержимого страницы');
$u->api('ai.run', array('instruction' => 'Оформи списком', 'text' => 'а и б'));
$lines = array_map('json_decode', file($gcLog, FILE_IGNORE_NEW_LINES));
$oauthCount = count(array_filter($lines, function ($l) { return $l->path === '/api/v2/oauth'; }));
$chat = json_decode(end($lines)->raw, true);
ok($oauthCount === 1 && $chat['model'] === 'GigaChat' && $chat['messages'][0]['role'] === 'system' && str_contains($chat['messages'][1]['content'], "<fragment>\nа и б\n</fragment>") && $chat['temperature'] == 0.7, 'Токен переиспользуется 30 минут; в запросе модель, системная инструкция и фрагмент');
// токен истёк на стороне сервиса — обновляется сам
@unlink(sys_get_temp_dir() . '/fake-gc-token-' . basename($TMP));
$r = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'ещё'));
ok($r['status'] === 200 && $r['json']['text'] === 'Гига: ЕЩЁ', 'Просроченный токен обновляется автоматически');
$r = $u->api('ai.save', array('id' => 'gigachat', 'model' => 'GigaChat-2-Max', 'temperature' => '0,3'));
$r = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'макс'));
$lines = array_map('json_decode', file($gcLog, FILE_IGNORE_NEW_LINES));
$chat = json_decode(end($lines)->raw, true);
ok($r['status'] === 200 && $chat['model'] === 'GigaChat-2-Max' && $chat['temperature'] == 0.3, 'Выбор модели и температуры');
$r = $u->api('ai.save', array('id' => 'gigachat', 'model' => 'GigaChat-Ultra'));
$r = $u->api('ai.run', array('instruction' => 'x', 'text' => 'y'));
ok($r['status'] === 422 && str_contains($r['json']['error'], 'модель'), 'Несуществующая модель — понятная ошибка');
$u->api('ai.save', array('id' => 'gigachat', 'model' => 'GigaChat'));
$r = $u->api('ai.save', array('id' => 'gigachat', 'key' => 'V3JvbmdLZXlXcm9uZ0tleQ=='));
$r = $u->api('ai.test', array('id' => 'gigachat'));
ok($r['status'] === 422 && str_contains($r['json']['error'], 'ключ авторизации'), 'Неверный ключ GigaChat — понятная ошибка');
$u->api('ai.save', array('id' => 'gigachat', 'key' => 'R29vZEtleUZvckdpZ2FDaGF0MTIzNA=='));
// своё подключение (OpenAI-совместимое)
$r = $u->api('ai.save', array('type' => 'openai', 'name' => 'Мой DeepSeek', 'base_url' => "http://127.0.0.1:$DS_PORT", 'model' => 'deepseek-flash', 'key' => 'sk-test-good-key-1234567890', 'temperature' => 1));
$newId = $r['json']['saved_id'] ?? '';
ok($r['status'] === 200 && $r['json']['active'] === $newId && count($r['json']['profiles']) === 2, 'Создание своего подключения: название, адрес, модель, ключ; оно становится активным');
$r = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'ds'));
$dsReq = json_decode(file_get_contents("$TMP-ds.log"), true);
ok($r['status'] === 200 && $r['json']['text'] === 'ИИ: DS' && $r['json']['provider'] === 'Мой DeepSeek' && $dsReq['auth'] === 'Bearer sk-test-good-key-1234567890' && $dsReq['body']['temperature'] == 1, 'Запрос уходит в активное подключение');
$r = $u->api('ai.models', array('id' => $newId));
ok($r['status'] === 200 && in_array('deepseek-v4-pro', $r['json']['models'], true), 'Загрузка списка моделей подключения');
$r = $u->api('ai.activate', array('id' => 'gigachat'));
$r2 = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'снова'));
ok($r['json']['active'] === 'gigachat' && $r2['json']['text'] === 'Гига: СНОВА', 'Переключение между подключениями');
$r = $u->api('ai.delete', array('id' => 'gigachat'));
ok($r['status'] === 422, 'Встроенное подключение GigaChat нельзя удалить');
$r = $u->api('ai.delete', array('id' => $newId));
ok($r['status'] === 200 && count($r['json']['profiles']) === 1 && $r['json']['active'] === 'gigachat', 'Удаление своего подключения');
$r = $u->api('ai.save', array('type' => 'openai', 'name' => '', 'base_url' => 'ftp://x', 'model' => 'm'));
ok($r['status'] === 422, 'Проверка полей нового подключения');
$cfgText = file_get_contents("$TMP/data/config.php");
ok(str_contains($cfgText, 'R29vZEtleUZvckdpZ2FDaGF0MTIzNA==') && str_contains($cfgText, "defined('TETRAD')"), 'Ключи хранятся на сервере в data/config.php');
// сертификат Минцифры
$key = openssl_pkey_new(array('private_key_bits' => 2048));
$cert = openssl_csr_sign(openssl_csr_new(array('commonName' => 'Russian Trusted Root CA (test)'), $key), null, $key, 30);
openssl_x509_export($cert, $pem);
file_put_contents("$TMP-ca.crt", $pem);
$r = $u->api('ai.cert', array('file' => new CURLFile("$TMP-ca.crt", 'application/x-x509-ca-cert', 'russian_trusted_root_ca.cer')), 'POST', array('multipart' => true));
ok($r['status'] === 200 && $r['json']['cert'] === true && is_file("$TMP/data/ai-ca.pem"), 'Загрузка сертификата Минцифры');
file_put_contents("$TMP-bad.crt", 'hello');
$r = $u->api('ai.cert', array('file' => new CURLFile("$TMP-bad.crt", 'text/plain', 'bad.crt')), 'POST', array('multipart' => true));
ok($r['status'] === 422, 'Не сертификат — отклоняется');
$r = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'с сертификатом'));
ok($r['status'] === 200, 'С загруженным сертификатом запросы работают');
$r = $u->api('ai.cert.delete', array());
ok($r['json']['cert'] === false, 'Сертификат можно удалить');
// HTTPS с самоподписанным сертификатом: «Автоматически» — повтор без проверки, «Проверять» — ошибка
if (trim((string) shell_exec('command -v openssl'))) {
    $TLS_PORT = $PORT + 1900;
    shell_exec(sprintf('openssl req -x509 -newkey rsa:2048 -nodes -subj /CN=localhost -days 2 -keyout %s -out %s 2>/dev/null', escapeshellarg("$TMP-tls.key"), escapeshellarg("$TMP-tls.crt")));
    $tls = proc_open(sprintf('exec openssl s_server -quiet -accept %d -cert %s -key %s -www', $TLS_PORT, escapeshellarg("$TMP-tls.crt"), escapeshellarg("$TMP-tls.key")), array(0 => array('pipe', 'r'), 1 => array('file', '/dev/null', 'w'), 2 => array('file', '/dev/null', 'w')), $tp);
    for ($i = 0; $i < 30 && !@fsockopen('127.0.0.1', $TLS_PORT); $i++) usleep(100000);
    $u->api('ai.save', array('id' => 'gigachat', 'oauth_url' => "https://127.0.0.1:$TLS_PORT/api/v2/oauth", 'ssl' => 'verify'));
    $r = $u->api('ai.test', array('id' => 'gigachat'));
    ok($r['status'] === 502 && str_contains($r['json']['error'], 'сертификат'), 'Режим «Проверять сертификат»: недоверенный сертификат — понятная ошибка');
    $u->api('ai.save', array('id' => 'gigachat', 'ssl' => 'auto'));
    $u->api('ai.test', array('id' => 'gigachat'));
    $st = $u->api('ai.status')['json'];
    ok($st['profiles'][0]['insecure'] === true, 'Режим «Автоматически»: при недоверенном сертификате соединение повторяется без проверки и это видно в настройках');
    proc_terminate($tls);
    $u->api('ai.save', array('id' => 'gigachat', 'oauth_url' => "http://127.0.0.1:$GC_PORT/api/v2/oauth"));
}
// старый формат настроек (один ключ DeepSeek) переносится
if (!defined('TETRAD')) define('TETRAD', 1);
$cfg = include "$TMP/data/config.php";
$cfg['ai'] = array('key' => 'sk-test-good-key-1234567890', 'model' => 'deepseek-flash', 'thinking' => false, 'models' => array());
$cfg['ai_base_url'] = "http://127.0.0.1:$DS_PORT";
file_put_contents("$TMP/data/config.php", "<?php\nif (!defined('TETRAD')) { http_response_code(403); exit; }\nreturn " . var_export($cfg, true) . ';');
$st = $u->api('ai.status')['json'];
$r = $u->api('ai.run', array('instruction' => 'Сделай заглавными', 'text' => 'старый'));
ok($st['active'] === 'deepseek' && count($st['profiles']) === 2 && $r['json']['text'] === 'ИИ: СТАРЫЙ', 'Настройки прежней версии (DeepSeek) переносятся в подключение «DeepSeek»');
proc_terminate($gc);
proc_terminate($ds);

section('Перезапуск сервера');
stop_server();
start_server();
$r = $u->api(array('a' => 'page.get', 'id' => $p1['id']));
ok($r['status'] === 200 && $r['json']['version'] >= 4, 'После перезапуска данные и сессия сохраняются');

section('Двухфакторный вход');
function t_b32d($s) { $a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $bits = ''; foreach (str_split(strtoupper($s)) as $c) $bits .= str_pad(decbin(strpos($a, $c)), 5, '0', STR_PAD_LEFT); $o = ''; foreach (str_split($bits, 8) as $b) if (strlen($b) === 8) $o .= chr(bindec($b)); return $o; }
function t_totp($secret, $step) { $h = hash_hmac('sha1', pack('N2', 0, $step), t_b32d($secret), true); $o = ord($h[19]) & 15; $n = ((ord($h[$o]) & 127) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]); return str_pad((string) ($n % 1000000), 6, '0', STR_PAD_LEFT); }
$now = (int) floor(time() / 30);
// RFC 6238, контрольный пример (ключ «12345678901234567890», T=59 с → 94287082, 6 цифр — 287082)
ok(t_totp('GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ', 1) === '287082', 'Проверочная реализация TOTP совпадает с RFC 6238');
$st = $u->api('auth.2fa.status')['json'];
ok($st['enabled'] === false && $st['recovery_left'] === 0, 'По умолчанию двухфакторный вход выключен');
$r = $u->api('auth.2fa.setup', array('password' => 'wrong-password'));
ok($r['status'] === 403, 'Для включения нужен текущий пароль');
$r = $u->api('auth.2fa.setup', array('password' => $PWD));
$secret = $r['json']['secret'] ?? '';
ok($r['status'] === 200 && preg_match('/^[A-Z2-7]{32}$/', $secret) && str_starts_with($r['json']['uri'], 'otpauth://totp/') && str_contains($r['json']['uri'], 'secret=' . $secret), 'Настройка: секрет и ссылка otpauth:// для приложения');
ok(t_totp($secret, $now) !== '' && $u->api('auth.2fa.status')['json']['enabled'] === false, 'До подтверждения кодом двухфакторный вход не включается');
$before2fa = new Client();
$before2fa->login($EMAIL, $PWD);
$r = $u->api('auth.2fa.enable', array('code' => '000000' === t_totp($secret, $now) ? '111111' : '000000'));
ok($r['status'] === 422, 'Неверный код при включении отклоняется');
$r = $u->api('auth.2fa.enable', array('code' => t_totp($secret, $now)));
if (!empty($r['json']['csrf'])) $u->csrf = $r['json']['csrf'];
$rc = $r['json']['recovery_codes'] ?? array();
ok($r['status'] === 200 && count($rc) === 10 && preg_match('/^[a-z0-9]{4}-[a-z0-9]{4}$/', $rc[0]) && $r['json']['status']['enabled'] === true, 'Включение: 10 резервных кодов');
ok($u->api('tree')['status'] === 200 && $before2fa->api('tree')['status'] === 401, 'Текущий сеанс остаётся, другие завершаются');
$dbRow = (new PDO('sqlite:' . glob("$TMP/data/*.sqlite")[0]))->query('SELECT recovery_codes FROM users LIMIT 1')->fetchColumn();
ok(!str_contains($dbRow, $rc[0]), 'Резервные коды хранятся только в виде хэшей');
// вход: после пароля нужен код
$c2 = new Client();
$r = $c2->login($EMAIL, $PWD);
ok($r['status'] === 200 && !empty($r['json']['need_2fa']) && empty($r['json']['user']) && $c2->api('tree')['status'] === 401, 'После правильного пароля требуется код, без него доступа нет');
$r = $c2->api('auth.2fa', array('code' => t_totp($secret, $now)));
ok($r['status'] === 401, 'Уже использованный код повторно не принимается');
$r = $c2->api('auth.2fa', array('code' => t_totp($secret, $now + 1)));
if ($r['status'] === 200) $c2->csrf = $r['json']['csrf'];
ok($r['status'] === 200 && $r['json']['used'] === 'totp' && $c2->api('tree')['status'] === 200, 'Вход с кодом из приложения (допуск ±30 секунд)');
$c3 = new Client();
$c3->login($EMAIL, $PWD);
$r = $c3->api('auth.2fa', array('code' => strtoupper($rc[0])));
ok($r['status'] === 200 && $r['json']['used'] === 'recovery' && $r['json']['recovery_left'] === 9, 'Вход по резервному коду');
$c4 = new Client();
$c4->login($EMAIL, $PWD);
ok($c4->api('auth.2fa', array('code' => $rc[0]))['status'] === 401, 'Резервный код срабатывает только один раз');
$c4->api('auth.2fa', array('code' => $rc[1], 'remember' => true));
$c4->api('auth.logout', array());
$r = $c4->login($EMAIL, $PWD);
ok($r['status'] === 200 && empty($r['json']['need_2fa']) && !empty($r['json']['user']), '«Не спрашивать на этом устройстве»: повторный вход без кода');
$st = $u->api('auth.2fa.status')['json'];
ok($st['trusted_devices'] === 1 && $st['recovery_left'] === 8, 'Статус: доверенные устройства и остаток резервных кодов');
$r = $u->api('auth.2fa.codes', array('code' => $rc[2]));
$rc2 = $r['json']['recovery_codes'] ?? array();
ok($r['status'] === 200 && count($rc2) === 10 && $r['json']['status']['recovery_left'] === 10, 'Новые резервные коды');
$c5 = new Client();
$c5->login($EMAIL, $PWD);
ok($c5->api('auth.2fa', array('code' => $rc[3]))['status'] === 401, 'Старые резервные коды после замены не действуют');
$u->api('auth.2fa.forget', array());
$c4->api('auth.logout', array());
$r = $c4->login($EMAIL, $PWD);
ok(!empty($r['json']['need_2fa']), '«Спрашивать код везде» отменяет доверенные устройства');
$r = $u->api('auth.2fa.disable', array('password' => 'wrong', 'code' => $rc2[0]));
ok($r['status'] === 403 && $u->api('auth.2fa.status')['json']['enabled'] === true, 'Выключение требует пароль');
$c6 = new Client();
$c6->login($EMAIL, $PWD);

$rBad = $c6->api('auth.2fa', array('code' => 'zzzz-zzzz'));
ok($rBad['status'] === 401, 'Неверный резервный код отклоняется');

section('Смена и сброс пароля');
$r = $u->api('auth.password', array('current' => 'wrong', 'password' => 'new-password-123'));
ok($r['status'] === 403, 'Смена пароля требует текущий пароль');
$other = new Client();
$other->login($EMAIL, $PWD);
$r = $u->api('auth.password', array('current' => $PWD, 'password' => 'new-password-123'));
if ($r['status'] === 200) $u->csrf = $r['json']['csrf'];
ok($r['status'] === 200, 'Смена пароля');
ok($u->api('tree')['status'] === 200, 'Текущая сессия остаётся активной');
ok($other->api('tree')['status'] === 401, 'Другие сессии завершаются после смены пароля');
$r = $anon->api('auth.reset', array('password' => 'reset-password-1'));
ok($r['status'] === 403, 'Сброс без файла RESET-PASSWORD невозможен');
touch("$TMP/data/RESET-PASSWORD");
$anon2 = new Client();
$s = $anon2->api('auth.status');
$anon2->csrf = $s['json']['csrf'];
ok($s['json']['reset_available'] === true, 'Файл RESET-PASSWORD включает сброс');
$r = $anon2->api('auth.reset', array('email' => $EMAIL, 'password' => 'reset-password-1'));
ok($r['status'] === 200 && !is_file("$TMP/data/RESET-PASSWORD"), 'Сброс пароля, файл удалён');
$r = $anon2->login($EMAIL, 'reset-password-1');
ok($r['status'] === 200 && empty($r['json']['need_2fa']) && !empty($r['json']['user']), 'Вход с новым паролем: сброс через хостинг снимает и двухфакторный вход (на случай потерянного телефона)');

section('Защита от перебора');
$bf = new Client();
$codes = array();
for ($i = 0; $i < 10; $i++) $codes[] = $bf->login($EMAIL, 'nope' . $i)['status'];
ok(in_array(429, $codes, true), 'После серии неудачных попыток вход блокируется (429)');
ok($bf->login($EMAIL, 'reset-password-1')['status'] === 429, 'Блокировка действует и для верного пароля');

echo "\nИтог: $passed пройдено, $failed с ошибками\n";
stop_server();
exec('rm -rf ' . escapeshellarg($TMP) . ' ' . escapeshellarg($TMP) . '-*');
exit($failed ? 1 : 0);
