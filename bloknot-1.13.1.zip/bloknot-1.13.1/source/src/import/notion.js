// Импорт ZIP-экспорта Notion (HTML или Markdown & CSV). Работает в браузере: архив не загружается на сервер целиком.
import JSZip from 'jszip';
import { api, upload } from '../api.js';
import { htmlToBlocks, markdownToBlocks } from '../editor/convert.js';
import { newBlock } from '../editor/model.js';
import { prepareImage } from '../editor/images.js';
import { escapeHtml } from '../util.js';

const IMAGE_EXT = /\.(png|jpe?g|gif|webp|bmp|heic|avif)$/i;
const PAGE_EXT = /\.(html?|md)$/i;
const ID_SUFFIX = /\s+[0-9a-f]{32}$/i;
const SHORT_ID = /\s+[0-9a-f]{20,}$/i;

function cleanName(name) {
  return name.replace(PAGE_EXT, '').replace(/\.csv$/i, '').replace(ID_SUFFIX, '').replace(SHORT_ID, '').trim() || 'Без названия';
}

function dirname(p) {
  const i = p.lastIndexOf('/');
  return i < 0 ? '' : p.slice(0, i);
}

function stripExt(p) {
  return p.replace(PAGE_EXT, '').replace(/\.csv$/i, '');
}

function joinPath(dir, rel) {
  const parts = (dir ? dir.split('/') : []).concat(rel.split('/'));
  const out = [];
  for (const part of parts) {
    if (!part || part === '.') continue;
    if (part === '..') out.pop();
    else out.push(part);
  }
  return out.join('/');
}

function safeDecode(s) {
  try {
    return decodeURIComponent(s);
  } catch (e) {
    return s;
  }
}

async function collectEntries(zip, prefix, files, depth = 0) {
  const inner = [];
  zip.forEach((path, entry) => {
    if (entry.dir) return;
    if (/__MACOSX\//.test(path) || /\/\._/.test(path) || /\.DS_Store$/.test(path)) return;
    if (/\.zip$/i.test(path) && depth < 2) inner.push(entry);
    else files.set((prefix + path).normalize('NFC'), entry);
  });
  for (const entry of inner) {
    const data = await entry.async('uint8array');
    const z = await JSZip.loadAsync(data);
    await collectEntries(z, prefix, files, depth + 1);
  }
}

function parseCsv(text) {
  const rows = [];
  let row = [];
  let cell = '';
  let q = false;
  text = text.replace(/^﻿/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) {
      if (c === '"') {
        if (text[i + 1] === '"') {
          cell += '"';
          i++;
        } else q = false;
      } else cell += c;
    } else if (c === '"') q = true;
    else if (c === ',') {
      row.push(cell);
      cell = '';
    } else if (c === '\n' || c === '\r') {
      if (c === '\r' && text[i + 1] === '\n') i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = '';
    } else cell += c;
  }
  if (cell || row.length) {
    row.push(cell);
    rows.push(row);
  }
  return rows.filter((r) => r.some((x) => x.trim()));
}

function stripId(name) {
  return name.replace(ID_SUFFIX, '').replace(SHORT_ID, '').trim();
}

function looseKey(k) {
  const d = dirname(k);
  return (d ? d + '/' : '') + stripId(k.split('/').pop());
}

/**
 * @returns {Promise<{pages:number, images:number, warnings:number, rootId:number|null}>}
 */
export async function importNotionZip(file, { container = true, uploadLimit, onProgress = () => {}, onWarning = () => {} }) {
  let warnings = 0;
  const warn = (m) => {
    warnings++;
    onWarning(m);
  };
  onProgress(0, 1, 'Чтение архива…');
  let zip;
  try {
    zip = await JSZip.loadAsync(file);
  } catch (e) {
    throw new Error('Не удалось открыть архив. Убедитесь, что это ZIP-файл экспорта Notion.');
  }
  const files = new Map();
  await collectEntries(zip, '', files);

  // страницы: HTML/MD-файлы и CSV-таблицы баз данных (в экспорте Markdown)
  const pages = new Map(); // key (путь без расширения) -> { key, path, kind, title }
  for (const path of files.keys()) {
    const base = path.split('/').pop();
    if (PAGE_EXT.test(path)) {
      if (/^index\.html?$/i.test(path)) continue;
      const key = stripExt(path);
      if (!pages.has(key) || /\.html?$/i.test(path)) pages.set(key, { key, path, kind: /\.md$/i.test(path) ? 'md' : 'html', title: cleanName(base) });
    } else if (/\.csv$/i.test(path) && !/_all\.csv$/i.test(path)) {
      const key = stripExt(path);
      if (!pages.has(key)) pages.set(key, { key, path, kind: 'csv', title: cleanName(base) });
    }
  }
  if (!pages.size) throw new Error('В архиве не найдено страниц Notion (файлов .html или .md).');

  const addChildLink = (p, href) => {
    if (!href || /^(https?:|mailto:|#|data:)/i.test(href)) return;
    const target = joinPath(dirname(p.path), safeDecode(href.split('#')[0].split('?')[0])).normalize('NFC');
    const key = stripExt(target);
    if (pages.has(key) && key !== p.key) {
      if (!p.childLinks) p.childLinks = [];
      if (!p.childLinks.includes(key)) p.childLinks.push(key);
    }
  };

  // читаем содержимое HTML заранее: нужен порядок вложенных страниц, заголовок и значок
  const parser = new DOMParser();
  let read = 0;
  for (const p of pages.values()) {
    read++;
    if (read % 10 === 0) onProgress(read, pages.size * 3, `Разбор страниц: ${read} из ${pages.size}`);
    const text = await files.get(p.path).async('string');
    p.raw = text;
    if (p.kind === 'html') {
      const doc = parser.parseFromString(text, 'text/html');
      p.doc = doc;
      const t = doc.querySelector('.page-title');
      if (t && t.textContent.trim()) p.title = t.textContent.trim();
      const ic = doc.querySelector('.page-header-icon');
      if (ic && !ic.querySelector('img') && ic.textContent.trim()) p.icon = Array.from(ic.textContent.trim()).slice(0, 4).join('');
      const cover = doc.querySelector('img.page-cover-image');
      if (cover) p.coverSrc = cover.getAttribute('src');
      doc.querySelectorAll('figure.link-to-page a[href], table.collection-content a[href]').forEach((a) => addChildLink(p, a.getAttribute('href')));
    } else if (p.kind === 'md') {
      const m = text.match(/^#\s+(.+)$/m);
      if (m && text.trimStart().startsWith('#')) p.title = m[1].trim();
      // в Markdown-экспорте вложенные страницы — отдельные строки-ссылки на .md/.csv
      for (const line of text.split(/\r?\n/)) {
        const lm = line.match(/^\s*\[[^\]]*\]\(([^)]+\.(?:md|csv))\)\s*$/i);
        if (lm) addChildLink(p, lm[1]);
      }
    }
  }

  // ---------- восстановление вложенности ----------
  // 1) по папкам: Notion кладёт вложенные страницы в папку с именем родителя
  //    (в разных версиях экспорта — «Название id/» или просто «Название/»);
  // 2) по ссылкам на вложенные страницы внутри родителя — если папок нет (экспорт без папок).
  const loose = new Map();
  for (const k of pages.keys()) {
    const lk = looseKey(k);
    if (!loose.has(lk)) loose.set(lk, []);
    loose.get(lk).push(k);
  }
  const folderOwner = (dir) => {
    if (pages.has(dir)) return dir;
    const cands = loose.get(looseKey(dir)) || [];
    if (cands.length === 1) return cands[0];
    if (cands.length > 1) return cands.find((c) => (pages.get(c).childLinks || []).some((t) => t.startsWith(dir + '/'))) || cands[0];
    return null;
  };
  for (const p of pages.values()) {
    p.parent = null;
    let dir = dirname(p.key);
    while (dir) {
      const owner = folderOwner(dir);
      if (owner && owner !== p.key) {
        p.parent = owner;
        break;
      }
      dir = dirname(dir);
    }
  }
  const isAncestor = (a, b) => {
    // является ли a предком b
    let cur = pages.get(b);
    const seen = new Set();
    while (cur && cur.parent && !seen.has(cur.parent)) {
      if (cur.parent === a) return true;
      seen.add(cur.parent);
      cur = pages.get(cur.parent);
    }
    return false;
  };
  for (const p of pages.values()) {
    for (const t of p.childLinks || []) {
      const c = pages.get(t);
      if (!c || c === p || c.parent) continue;
      if (isAncestor(c.key, p.key)) continue;
      c.parent = p.key;
    }
  }
  const nested = Array.from(pages.values()).filter((p) => p.parent).length;
  if (pages.size > 1 && !nested) warn('Не удалось определить вложенность страниц — все страницы импортированы на одном уровне');

  // порядок: дети в порядке упоминания в родителе
  const childrenOf = new Map();
  for (const p of pages.values()) {
    const k = p.parent || '';
    if (!childrenOf.has(k)) childrenOf.set(k, []);
    childrenOf.get(k).push(p);
  }
  for (const [parentKey, list] of childrenOf) {
    const parent = pages.get(parentKey);
    const raw = parent ? safeDecode(parent.raw || '') : '';
    list.sort((a, b) => {
      const an = a.key.split('/').pop();
      const bn = b.key.split('/').pop();
      const ai = raw ? raw.indexOf(an) : -1;
      const bi = raw ? raw.indexOf(bn) : -1;
      if (ai >= 0 && bi >= 0) return ai - bi;
      if (ai >= 0) return -1;
      if (bi >= 0) return 1;
      return a.title.localeCompare(b.title, 'ru');
    });
  }

  // создаём страницы сверху вниз
  let rootId = null;
  if (container) {
    const root = await api('page.create', { title: 'Импорт из Notion', icon: '📥' });
    rootId = root.id;
  }
  const total = pages.size * 3;
  let step = pages.size;
  const created = [];
  const createLevel = async (parentKey, parentId) => {
    for (const p of childrenOf.get(parentKey) || []) {
      const res = await api('page.create', { parent_id: parentId, title: p.title, icon: p.icon || '' });
      p.id = res.id;
      p.version = res.version;
      created.push(p);
      step++;
      onProgress(step, total, `Создание страниц: ${created.length} из ${pages.size}`);
      await createLevel(p.key, p.id);
    }
  };
  await createLevel('', rootId);
  if (!rootId && created.length === 1) rootId = created[0].id;
  else if (!rootId && created.length) rootId = created[0].id;

  const byPath = new Map();
  for (const p of pages.values()) byPath.set(p.path.normalize('NFC'), p);

  const resolveTarget = (fromPath, href) => {
    if (!href || /^(https?:|mailto:|tel:|#|data:)/i.test(href)) return null;
    const clean = safeDecode(href.split('#')[0].split('?')[0]);
    return joinPath(dirname(fromPath), clean).normalize('NFC');
  };

  // переносим содержимое
  let images = 0;
  for (const p of created) {
    step++;
    onProgress(step, total, `Перенос содержимого: «${p.title}»`);
    const pageLink = (href) => {
      const target = resolveTarget(p.path, href);
      if (!target) return null;
      const tp = byPath.get(target) || pages.get(stripExt(target));
      return tp && tp.id ? tp.id : null;
    };
    const opts = {
      notion: true,
      resolveHref: (href) => {
        const id = pageLink(href);
        return id ? `#/p/${id}` : href;
      },
      resolvePageLink: pageLink,
    };
    let blocks = [];
    try {
      if (p.kind === 'html') {
        const doc = p.doc;
        // ссылки на вложения (PDF и т. п.) — переносим как текст с пометкой
        doc.querySelectorAll('a[href]').forEach((a) => {
          const href = a.getAttribute('href');
          const target = resolveTarget(p.path, href);
          if (!target || PAGE_EXT.test(target) || IMAGE_EXT.test(target) || pages.has(stripExt(target))) return;
          if (/\.csv$/i.test(target)) return;
          const name = target.split('/').pop();
          const span = doc.createElement('span');
          span.textContent = `📎 ${name} (файл не перенесён)`;
          a.replaceWith(span);
          warn(`«${p.title}»: вложение «${name}» не перенесено — поддерживаются только изображения`);
        });
        const body = doc.querySelector('.page-body') || doc.querySelector('article') || doc.body;
        const props = doc.querySelector('table.properties');
        if (props && !body.contains(props)) blocks = blocks.concat(htmlToBlocks(props, opts));
        blocks = blocks.concat(htmlToBlocks(body, opts));
      } else if (p.kind === 'md') {
        let md = p.raw;
        if (md.trimStart().startsWith('# ')) md = md.replace(/^\s*#\s+.+\n?/, '');
        blocks = markdownToBlocks(md, opts);
      } else if (p.kind === 'csv') {
        const rows = parseCsv(p.raw);
        if (rows.length) blocks.push(newBlock('table', { rows: rows.map((r) => r.map((c) => escapeHtml(c))) }));
      }
    } catch (e) {
      warn(`«${p.title}»: не удалось разобрать содержимое (${e.message})`);
    }

    // изображения
    for (const b of blocks) {
      if (b.type !== 'image' || !b.src) continue;
      const src = b.src;
      try {
        let res = null;
        if (/^https?:/i.test(src)) {
          res = await api('file.fetch', { url: src, page_id: p.id });
        } else {
          const target = resolveTarget(p.path, src);
          const entry = target && files.get(target);
          if (!entry) throw new Error('файл не найден в архиве');
          const blob = await entry.async('blob');
          const name = target.split('/').pop();
          const type = /\.png$/i.test(name) ? 'image/png' : /\.gif$/i.test(name) ? 'image/gif' : /\.webp$/i.test(name) ? 'image/webp' : 'image/jpeg';
          const f = await prepareImage(new File([blob], name, { type }), uploadLimit);
          const fd = new FormData();
          fd.append('file', f, f.name);
          fd.append('page_id', p.id);
          res = await upload('file.upload', fd);
        }
        b.file = res.id;
        b.w = res.width;
        b.h = res.height;
        delete b.src;
        images++;
      } catch (e) {
        if (/^https?:/i.test(src)) {
          b.type = 'bookmark';
          b.url = src;
          b.title = 'Изображение (не удалось скачать)';
          delete b.src;
        } else {
          b.type = 'p';
          b.html = `🖼 ${escapeHtml(src.split('/').pop())} (изображение не перенесено)`;
          delete b.src;
        }
        warn(`«${p.title}»: изображение не перенесено (${e.message})`);
      }
    }

    // обложка
    let cover = '';
    if (p.coverSrc) {
      try {
        let res;
        if (/^https?:/i.test(p.coverSrc)) res = await api('file.fetch', { url: p.coverSrc, page_id: p.id });
        else {
          const target = resolveTarget(p.path, p.coverSrc);
          const entry = target && files.get(target);
          if (!entry) throw new Error('файл не найден');
          const blob = await entry.async('blob');
          const f = await prepareImage(new File([blob], 'cover.jpg', { type: blob.type || 'image/jpeg' }), uploadLimit);
          const fd = new FormData();
          fd.append('file', f, 'cover.jpg');
          fd.append('page_id', p.id);
          res = await upload('file.upload', fd);
        }
        cover = 'file:' + res.id;
        images++;
      } catch (e) {
        cover = '';
      }
    }

    try {
      await api('page.save', { id: p.id, base_version: p.version, title: p.title, icon: p.icon || '', cover, content: { v: 1, blocks } });
    } catch (e) {
      warn(`«${p.title}»: не удалось сохранить (${e.message})`);
    }
    p.doc = null;
    p.raw = null;
  }
  onProgress(total, total, 'Готово');
  return { pages: created.length, images, warnings, rootId };
}
