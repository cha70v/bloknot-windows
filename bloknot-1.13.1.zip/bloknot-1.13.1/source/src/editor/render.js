// Отрисовка блоков в DOM
import { el, escapeHtml, hostOf } from '../util.js';
import { applyWidths, validWidths } from './table.js';
import { icon } from '../icons.js';
import { PLACEHOLDERS, TEXT_TYPES } from './model.js';
import { highlight, LANGUAGE_OPTIONS, normalizeLang } from './highlight.js';

function editable(tag, cls, html, ro, ph) {
  const node = el(tag, { class: cls, 'data-editable': '1', spellcheck: 'true' });
  if (!ro) node.setAttribute('contenteditable', 'true');
  if (ph) node.setAttribute('data-ph', ph);
  node.innerHTML = html || '';
  return node;
}

export function codeHtml(text, lang) {
  let h = highlight(text || '', lang);
  if (!text || text.endsWith('\n')) h += '<br data-eol="1">';
  return h;
}

/** Создаёт DOM-узел блока. ctx: { ro, fileUrl, getPage } */
export function renderBlock(b, ctx) {
  const ro = ctx.ro;
  const wrap = el('div', { class: `blk blk-${b.type}${b.color ? ` has-color c-${b.color}` : ''}`, 'data-id': b.id });
  if (b.indent) wrap.style.setProperty('--indent', b.indent);
  const gutter = el(
    'div',
    { class: 'blk-gutter', contenteditable: 'false' },
    ro ? null : el('button', { class: 'blk-add', type: 'button', title: 'Добавить блок ниже', 'aria-label': 'Добавить блок ниже', tabindex: '-1', 'data-action': 'add' }, icon('plus', 16)),
    ro ? null : el('button', { class: 'blk-handle', type: 'button', title: 'Перетащите, чтобы переместить. Нажмите — меню блока', 'aria-label': 'Меню блока', tabindex: '-1', 'data-action': 'handle' }, icon('grip', 16)),
  );
  wrap.append(gutter);
  if (TEXT_TYPES.has(b.type) && b.type !== 'toggle') {
    wrap.append(el('button', { class: 'blk-collapse', type: 'button', contenteditable: 'false', tabindex: '-1', 'data-action': 'collapse', 'aria-label': 'Свернуть вложенные' }, icon('chevron', 15)));
  }
  const body = el('div', { class: 'blk-body' });
  wrap.append(body);

  if (TEXT_TYPES.has(b.type)) {
    const tag = b.type === 'h1' || b.type === 'h2' || b.type === 'h3' ? b.type : 'div';
    const text = editable(tag, 'blk-text', b.html, ro, PLACEHOLDERS[b.type]);
    if (b.type === 'ul') body.append(el('span', { class: 'blk-marker blk-bullet', contenteditable: 'false', 'aria-hidden': 'true' }));
    if (b.type === 'ol') body.append(el('span', { class: 'blk-marker blk-num', contenteditable: 'false' }, '1.'));
    if (b.type === 'todo') {
      const cb = el('input', { type: 'checkbox', class: 'blk-check', 'data-action': 'check', 'aria-label': 'Отметить задачу' });
      cb.checked = !!b.checked;
      if (ro) cb.disabled = true;
      body.append(el('span', { class: 'blk-marker', contenteditable: 'false' }, cb));
      wrap.classList.toggle('is-checked', !!b.checked);
    }
    if (b.type === 'toggle') {
      body.append(
        el('button', { class: 'blk-marker blk-toggle-btn', type: 'button', contenteditable: 'false', 'data-action': 'toggle', 'aria-expanded': b.open ? 'true' : 'false', 'aria-label': b.open ? 'Свернуть' : 'Развернуть' }, icon('chevron', 16)),
      );
      wrap.classList.toggle('is-open', !!b.open);
    }
    if (b.type === 'callout') {
      body.append(el('button', { class: 'blk-callout-icon', type: 'button', contenteditable: 'false', 'data-action': 'callout-icon', 'aria-label': 'Сменить значок' }, b.icon || '💡'));
    }
    body.append(text);
    return wrap;
  }

  switch (b.type) {
    case 'code': {
      const lang = normalizeLang(b.lang);
      const select = el('select', { class: 'code-lang', 'data-action': 'code-lang', 'aria-label': 'Язык', disabled: ro });
      for (const [v, label] of LANGUAGE_OPTIONS) select.append(el('option', { value: v, selected: v === lang }, label));
      const code = el('code', { class: 'blk-code', 'data-editable': '1', spellcheck: 'false', 'data-lang': lang });
      if (!ro) {
        code.setAttribute('contenteditable', 'plaintext-only');
        if (code.contentEditable !== 'plaintext-only') code.setAttribute('contenteditable', 'true');
      }
      code.innerHTML = codeHtml(b.text, lang);
      body.append(
        el(
          'div',
          { class: 'code-wrap' },
          el('div', { class: 'code-bar', contenteditable: 'false' }, select, el('button', { class: 'code-copy', type: 'button', 'data-action': 'code-copy', title: 'Скопировать код' }, icon('copy', 15), el('span', null, 'Копировать'))),
          el('pre', null, code),
        ),
      );
      return wrap;
    }
    case 'hr':
      wrap.setAttribute('tabindex', '-1');
      body.append(el('div', { class: 'blk-hr' }, el('hr')));
      return wrap;
    case 'image': {
      wrap.setAttribute('tabindex', '-1');
      const frame = el('div', { class: 'img-frame', style: { width: b.w ? `min(${b.width || 100}%, ${b.w}px)` : `${b.width || 100}%` } });
      const src = b._local || (b.file ? ctx.fileUrl(b.file) : '');
      if (src) {
        const img = el('img', { src, alt: '', draggable: 'false', loading: 'lazy', decoding: 'async' });
        if (b.w && b.h) {
          img.width = b.w;
          img.height = b.h;
        }
        frame.append(img);
      } else {
        frame.append(el('div', { class: 'img-missing' }, icon('image', 22), el('span', null, b.src ? 'Изображение не загружено' : 'Нет изображения')));
      }
      if (b._uploading) frame.append(el('div', { class: 'img-progress' }, el('span', { class: 'img-progress-bar', style: { width: `${b._progress || 0}%` } })));
      if (!ro) frame.append(el('span', { class: 'img-resize img-resize-l', 'data-action': 'img-resize', title: 'Изменить размер' }), el('span', { class: 'img-resize img-resize-r', 'data-action': 'img-resize', title: 'Изменить размер' }));
      const cap = editable('figcaption', 'img-caption', b.caption || '', ro, 'Подпись');
      cap.setAttribute('data-caption', '1');
      cap.removeAttribute('data-editable');
      body.append(el('figure', { class: 'img' }, frame, cap));
      return wrap;
    }
    case 'bookmark': {
      wrap.setAttribute('tabindex', '-1');
      const url = b.url || '';
      body.append(
        el(
          'a',
          { class: 'bookmark', href: url, target: '_blank', rel: 'noopener noreferrer', draggable: 'false' },
          el('span', { class: 'bm-icon' }, icon('link', 18)),
          el('span', { class: 'bm-text' }, el('span', { class: 'bm-title' }, b.title || hostOf(url)), el('span', { class: 'bm-url' }, url)),
        ),
      );
      return wrap;
    }
    case 'page': {
      wrap.setAttribute('tabindex', '-1');
      const p = ctx.getPage(b.pageId);
      const a = el(
        'a',
        { class: `pagelink${p ? '' : ' is-missing'}`, href: `#/p/${b.pageId}`, draggable: 'false', 'data-action': 'open-page' },
        el('span', { class: 'pagelink-icon' }, p && p.icon ? p.icon : icon('page', 18)),
        el('span', { class: 'pagelink-title' }, p ? (p.title && p.title.trim()) || 'Без названия' : 'Страница удалена или недоступна'),
      );
      body.append(a);
      return wrap;
    }
    case 'table': {
      wrap.setAttribute('tabindex', '-1');
      const table = el('table', { class: 'tbl' });
      const rows = b.rows && b.rows.length ? b.rows : [['']];
      const cols = Math.max(1, ...rows.map((r) => r.length));
      rows.forEach((r, ri) => {
        const tr = el('tr');
        for (let ci = 0; ci < cols; ci++) {
          const td = el(ri === 0 && b.header !== false ? 'th' : 'td', { 'data-cell': `${ri}:${ci}` });
          if (!ro) td.setAttribute('contenteditable', 'true');
          td.innerHTML = r[ci] || '';
          tr.append(td);
        }
        table.append(tr);
      });
      applyWidths(table, validWidths(b.widths), cols);
      body.append(el('div', { class: 'tbl-wrap' }, table));
      return wrap;
    }
    default:
      body.append(el('div', { class: 'blk-text' }, escapeHtml(b.type)));
      return wrap;
  }
}
