// Подготовка изображений перед загрузкой: уменьшение очень больших фото (например, с телефона)
const MAX_SIDE = 2560;

function loadImage(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve(img);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Не удалось прочитать изображение'));
    };
    img.src = url;
  });
}

/**
 * Уменьшает изображение, если оно больше 2560 px по длинной стороне или превышает лимит загрузки.
 * GIF не трогаем — иначе пропадёт анимация.
 */
export async function prepareImage(file, limitBytes) {
  const limit = limitBytes || 15 * 1024 * 1024;
  if (file.type === 'image/gif') {
    if (file.size > limit) throw new Error(`GIF больше ${(limit / 1048576).toFixed(0)} МБ`);
    return file;
  }
  let img;
  try {
    img = await loadImage(file);
  } catch (e) {
    return file;
  }
  const side = Math.max(img.naturalWidth, img.naturalHeight);
  if (side <= MAX_SIDE && file.size <= limit && file.size <= 6 * 1024 * 1024) return file;
  let scale = Math.min(1, MAX_SIDE / side);
  const canvas = document.createElement('canvas');
  const type = file.type === 'image/png' && file.size < limit ? 'image/png' : 'image/jpeg';
  for (let attempt = 0; attempt < 4; attempt++) {
    canvas.width = Math.round(img.naturalWidth * scale);
    canvas.height = Math.round(img.naturalHeight * scale);
    const ctx = canvas.getContext('2d');
    if (type === 'image/jpeg') {
      ctx.fillStyle = '#fff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((r) => canvas.toBlob(r, type, 0.86));
    if (blob && blob.size <= limit) {
      const name = (file.name || 'image').replace(/\.\w+$/, '') + (type === 'image/png' ? '.png' : '.jpg');
      return new File([blob], name, { type });
    }
    scale *= 0.7;
  }
  throw new Error('Изображение слишком большое даже после уменьшения');
}
