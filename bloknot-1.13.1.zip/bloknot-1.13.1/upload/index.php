<?php
/** Блокнот — точка входа: мастер установки или оболочка приложения. */

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/auth.php';

enforce_https();
security_headers();

function h($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function asset_url($file)
{
    $path = __DIR__ . '/assets/' . $file;
    return 'assets/' . $file . '?v=' . (is_file($path) ? substr(md5((string) filemtime($path) . TETRAD_VERSION), 0, 10) : TETRAD_VERSION);
}

function setup_requirements()
{
    $dataOk = is_dir(TETRAD_DATA) ? is_writable(TETRAD_DATA) : @mkdir(TETRAD_DATA, 0750, true);
    return array(
        array('PHP 7.4 или новее', PHP_VERSION_ID >= 70400, 'Сейчас установлена версия ' . PHP_VERSION . '. Выберите более новую версию PHP в панели хостинга.'),
        array('Расширение PDO SQLite', extension_loaded('pdo_sqlite'), 'Включите расширение pdo_sqlite в настройках PHP хостинга.'),
        array('Расширение mbstring', extension_loaded('mbstring'), 'Включите расширение mbstring — без него хуже работает поиск по-русски.'),
        array('Папка data доступна для записи', (bool) $dataOk, 'Через FTP-клиент установите на папку data права 755 (или 775).'),
        array('Расширение GD или getimagesize', function_exists('getimagesize'), 'Нужно для проверки загружаемых изображений.'),
        array('Расширение fileinfo (желательно)', extension_loaded('fileinfo'), 'Не обязательно, но повышает надёжность проверки файлов.', true),
        array('Расширение DOM (желательно)', class_exists('DOMDocument'), 'Нужно для качественного экспорта в Markdown.', true),
    );
}

function setup_code()
{
    $file = TETRAD_DATA . '/setup-code.txt';
    if (!is_file($file)) {
        ensure_data_protection(TETRAD_DATA);
        $alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
        $code = '';
        for ($i = 0; $i < 8; $i++) $code .= $alphabet[random_int(0, strlen($alphabet) - 1)];
        @file_put_contents($file, "Код установки Блокнота: " . substr($code, 0, 4) . '-' . substr($code, 4) . "\n\nВведите его на странице установки. Файл удалится автоматически.\n");
    }
    $txt = (string) @file_get_contents($file);
    return preg_match('/([A-Z0-9]{4}-[A-Z0-9]{4})/', $txt, $m) ? $m[1] : null;
}

function run_setup($post)
{
    $errors = array();
    foreach (setup_requirements() as $r) {
        if (!$r[1] && empty($r[3])) $errors[] = $r[0] . ': ' . $r[2];
    }
    if ($errors) return $errors;

    start_session();
    if (empty($post['csrf']) || !hash_equals(csrf_token(), (string) $post['csrf'])) return array('Форма устарела — обновите страницу и попробуйте снова.');

    $code = setup_code();
    $given = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', (string) (isset($post['code']) ? $post['code'] : '')));
    if (!$code || $given !== str_replace('-', '', $code)) return array('Неверный код установки. Его можно найти в файле data/setup-code.txt на хостинге.');

    $email = trim(t_lower((string) (isset($post['email']) ? $post['email'] : '')));
    $name = trim((string) (isset($post['name']) ? $post['name'] : ''));
    $pwd = (string) (isset($post['password']) ? $post['password'] : '');
    $pwd2 = (string) (isset($post['password2']) ? $post['password2'] : '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Укажите корректный адрес почты (он используется как логин).';
    if (strlen($pwd) < 8) $errors[] = 'Пароль должен быть не короче 8 символов.';
    if ($pwd !== $pwd2) $errors[] = 'Пароли не совпадают.';
    if ($errors) return $errors;

    ensure_data_protection(TETRAD_DATA);
    foreach (array('uploads', 'sessions', 'tmp', 'backups') as $d) {
        if (!is_dir(TETRAD_DATA . '/' . $d)) @mkdir(TETRAD_DATA . '/' . $d, 0750, true);
    }
    @file_put_contents(TETRAD_DATA . '/probe', 'tetrad-probe');

    $cfg = array(
        'db_file' => 'tetrad-' . random_token(8) . '.sqlite',
        'secret' => random_token(32),
        'cron_key' => random_token(16),
        'created_at' => gmdate('c'),
        'mail' => array('enabled' => !empty($post['mail_backup']), 'interval_days' => 7),
    );
    write_php_config(config_path() . '.new', $cfg);
    // база создаётся до того, как установка будет считаться завершённой
    $pdo = new PDO('sqlite:' . TETRAD_DATA . '/' . $cfg['db_file'], null, null, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    migrate($pdo);
    $now = now_ms();
    $st = $pdo->prepare('INSERT INTO users(email, name, password_hash, is_admin, created_at, password_changed_at) VALUES(?, ?, ?, 1, ?, ?)');
    $st->execute(array($email, $name, password_hash($pwd, PASSWORD_DEFAULT), $now, $now));
    $uid = (int) $pdo->lastInsertId();

    // приветственная страница
    $welcome = json_encode(array('v' => 1, 'blocks' => welcome_blocks()), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $ms = (int) round(microtime(true) * 1000);
    $st = $pdo->prepare('INSERT INTO pages(owner_id, parent_id, position, title, icon, content, search_text, version, created_at, updated_at) VALUES(?, NULL, 1024, ?, ?, ?, ?, 1, ?, ?)');
    $st->execute(array($uid, 'Добро пожаловать', '👋', $welcome, t_lower('Добро пожаловать'), $ms, $ms));
    $pdo = null;

    rename(config_path() . '.new', config_path());
    @unlink(TETRAD_DATA . '/setup-code.txt');

    session_regenerate_id(true);
    $_SESSION = array('uid' => $uid, 'login_at' => $now, 'csrf' => random_token(24), 'renewed' => time());
    return array();
}

function welcome_blocks()
{
    $id = function () { return substr(bin2hex(random_bytes(6)), 0, 10); };
    return array(
        array('id' => $id(), 'type' => 'p', 'html' => 'Это ваш личный <b>Блокнот</b>. Всё сохраняется на вашем сервере автоматически — через секунду после того, как вы перестанете печатать.'),
        array('id' => $id(), 'type' => 'h2', 'html' => 'С чего начать'),
        array('id' => $id(), 'type' => 'todo', 'html' => 'Наберите <code>/</code> в пустой строке, чтобы выбрать тип блока', 'checked' => false),
        array('id' => $id(), 'type' => 'todo', 'html' => 'Перетащите блок за значок <b>⋮⋮</b> слева от него', 'checked' => false),
        array('id' => $id(), 'type' => 'todo', 'html' => 'Вставьте картинку из буфера обмена или перетащите её сюда', 'checked' => false),
        array('id' => $id(), 'type' => 'todo', 'html' => 'Перенесите страницы из Notion: <b>Настройки → Импорт из Notion</b>', 'checked' => false),
        array('id' => $id(), 'type' => 'h2', 'html' => 'Быстрые клавиши'),
        array('id' => $id(), 'type' => 'ul', 'html' => '<code>Ctrl/⌘ + K</code> — поиск по всем страницам'),
        array('id' => $id(), 'type' => 'ul', 'html' => '<code>#</code>, <code>##</code>, <code>-</code>, <code>1.</code>, <code>[]</code>, <code>&gt;</code> и пробел в начале строки — быстрые заголовки, списки, чек-листы и цитаты'),
        array('id' => $id(), 'type' => 'ul', 'html' => '<code>Tab</code> / <code>Shift + Tab</code> — вложенность'),
        array('id' => $id(), 'type' => 'ul', 'html' => '<code>Esc</code> — выделить блок, затем стрелки, <code>Delete</code>, <code>Ctrl + D</code> для дублирования'),
        array('id' => $id(), 'type' => 'callout', 'icon' => '💡', 'html' => 'Не забывайте про резервные копии: <b>Настройки → Скачать резервную копию</b>.'),
    );
}

// ---------------- Мастер установки ----------------
if (!is_installed()) {
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    header('Cache-Control: no-store');
    $errors = array();
    $post = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : null;
    if ($post !== null) {
        try {
            $errors = run_setup($post);
        } catch (Throwable $e) {
            error_log('[tetrad setup] ' . $e->getMessage());
            @unlink(config_path() . '.new');
            $errors = array('Не удалось завершить установку: ' . $e->getMessage());
        }
        if (!$errors) {
            header('Location: ./');
            exit;
        }
    }
    $reqs = setup_requirements();
    $hasCode = setup_code() !== null;
    start_session();
    $csrf = csrf_token();
    $old = function ($k) use ($post) { return $post && isset($post[$k]) && $k !== 'password' && $k !== 'password2' ? h($post[$k]) : ''; };
    ?><!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<title>Установка Блокнота</title>
<link rel="icon" href="assets/icon-32.png?v=3" type="image/png" sizes="32x32">
<style>
:root{color-scheme:light dark;--bg:#f7f7f5;--card:#fff;--fg:#37352f;--muted:#787774;--line:#e9e9e7;--accent:#2383e2;--bad:#d44c47;--good:#448361}
@media (prefers-color-scheme:dark){:root{--bg:#191919;--card:#202020;--fg:#d4d4d4;--muted:#8f8f8f;--line:#2f2f2f;--accent:#2383e2;--bad:#e0685a;--good:#4dab7a}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.55 ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif}
main{max-width:560px;margin:48px auto;padding:0 16px}
h1{font-size:30px;font-weight:700;margin:0 0 6px}.logo{font-size:44px;line-height:1;margin-bottom:12px}p.lead{color:var(--muted);margin:0 0 28px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;padding:22px;margin-bottom:18px}
h2{font-size:15px;margin:0 0 12px}
ul.req{list-style:none;margin:0;padding:0}ul.req li{display:flex;gap:10px;padding:6px 0;border-top:1px solid var(--line)}ul.req li:first-child{border-top:0}
.ok{color:var(--good)}.bad{color:var(--bad)}.hint{display:block;color:var(--muted);font-size:13px}
label{display:block;font-weight:600;font-size:13px;margin:14px 0 6px}
input{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:6px;background:transparent;color:inherit;font:inherit}
input:focus{outline:2px solid var(--accent);outline-offset:-1px}
label.check{display:flex;gap:8px;align-items:flex-start;font-weight:400;font-size:14px;margin-top:18px}label.check input{width:auto;margin-top:3px}button{margin-top:20px;width:100%;padding:12px;border:0;border-radius:8px;background:var(--accent);color:#fff;font:inherit;font-weight:600;cursor:pointer}
.err{background:color-mix(in srgb,var(--bad) 12%,transparent);border:1px solid color-mix(in srgb,var(--bad) 40%,transparent);color:var(--fg);border-radius:8px;padding:10px 14px;margin-bottom:16px}
code{background:color-mix(in srgb,var(--fg) 8%,transparent);padding:1px 5px;border-radius:4px;font-size:13px}
</style>
</head>
<body>
<main>
<div class="logo">📒</div>
<h1>Установка Блокнота</h1>
<p class="lead">Это займёт минуту. Данные будут храниться только на вашем хостинге.</p>
<?php if ($errors): ?><div class="err"><?php foreach ($errors as $e) echo h($e) . '<br>'; ?></div><?php endif; ?>
<div class="card">
<h2>Проверка хостинга</h2>
<ul class="req">
<?php foreach ($reqs as $r): ?>
<li><span class="<?= $r[1] ? 'ok' : 'bad' ?>"><?= $r[1] ? '✓' : (!empty($r[3]) ? '–' : '✕') ?></span><span><?= h($r[0]) ?><?php if (!$r[1]): ?><span class="hint"><?= h($r[2]) ?></span><?php endif; ?></span></li>
<?php endforeach; ?>
<li><span class="<?= is_https() ? 'ok' : 'bad' ?>"><?= is_https() ? '✓' : '!' ?></span><span>HTTPS<?php if (!is_https()): ?><span class="hint">Сайт открыт без HTTPS. Включите бесплатный сертификат Let’s Encrypt в панели хостинга, иначе пароль передаётся незашифрованным.</span><?php endif; ?></span></li>
</ul>
</div>
<form class="card" method="post" autocomplete="off">
<h2>Учётная запись владельца</h2>
<input type="hidden" name="csrf" value="<?= h($csrf) ?>">
<label for="code">Код установки</label>
<input id="code" name="code" required placeholder="XXXX-XXXX" value="<?= $old('code') ?>">
<span class="hint"><?php if ($hasCode): ?>Откройте через FTP файл <code>data/setup-code.txt</code> — код записан в нём. Так установку не сможет перехватить посторонний.<?php else: ?>Не удалось создать файл с кодом: проверьте права на папку <code>data</code>.<?php endif; ?></span>
<label for="name">Ваше имя</label>
<input id="name" name="name" placeholder="Денис" value="<?= $old('name') ?>">
<label for="email">Почта (логин)</label>
<input id="email" name="email" type="email" required autocomplete="username" value="<?= $old('email') ?>">
<label for="password">Пароль</label>
<input id="password" name="password" type="password" required minlength="8" autocomplete="new-password">
<span class="hint">Не короче 8 символов. Лучше — фраза из нескольких слов.</span>
<label for="password2">Пароль ещё раз</label>
<input id="password2" name="password2" type="password" required minlength="8" autocomplete="new-password">
<label class="check"><input type="checkbox" name="mail_backup" value="1"<?= $post === null || !empty($post['mail_backup']) ? ' checked' : '' ?>> Раз в неделю присылать резервную копию на эту почту</label>
<span class="hint">Ничего настраивать не нужно — письмо отправит хостинг. Изменить можно в настройках.</span>
<button type="submit">Создать Блокнот</button>
</form>
</main>
</body>
</html>
<?php
    exit;
}

// ---------------- Оболочка приложения ----------------
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
header('Cache-Control: no-cache');
$theme = isset($_COOKIE['tetrad_theme']) && in_array($_COOKIE['tetrad_theme'], array('light', 'dark'), true) ? $_COOKIE['tetrad_theme'] : '';
?><!doctype html>
<html lang="ru"<?= $theme ? ' data-theme="' . $theme . '"' : '' ?>>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-content">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#ffffff" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#191919" media="(prefers-color-scheme: dark)">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<title>Блокнот</title>
<link rel="icon" href="assets/icon-32.png?v=3" type="image/png" sizes="32x32">
<link rel="icon" href="assets/icon-16.png?v=3" type="image/png" sizes="16x16">
<link rel="icon" href="assets/icon-48.png?v=3" type="image/png" sizes="48x48">
<link rel="icon" href="assets/icon-192.png?v=3" type="image/png" sizes="192x192">
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png?v=3">
<link rel="manifest" href="assets/manifest.json">
<link rel="stylesheet" href="<?= h(asset_url('app.css')) ?>">
</head>
<body>
<div id="app" aria-live="polite"><div class="boot">Загрузка…</div></div>
<noscript>Для работы Блокнота нужен JavaScript.</noscript>
<script type="module" src="<?= h(asset_url('app.js')) ?>"></script>
</body>
</html>
