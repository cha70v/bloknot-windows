// Состояние приложения: пользователь, дерево страниц, настройки интерфейса
import { api } from './api.js';
import { emitter, store as ls } from './util.js';

export const state = {
  user: null,
  pages: new Map(), // id -> страница (без содержимого)
  treeStamp: null,
  currentId: null,
  sort: ls('sort') || 'manual', // manual | title | updated
  expanded: new Set(ls('expanded') || []),
  uploadLimit: 15 * 1024 * 1024,
};

export const events = emitter();

export async function loadTree() {
  const res = await api('tree');
  state.pages = new Map(res.pages.map((p) => [p.id, p]));
  state.treeStamp = res.tree_stamp;
  events.emit('tree');
  return state.pages;
}

export function upsertPage(p) {
  const old = state.pages.get(p.id) || {};
  const merged = Object.assign({}, old, p);
  delete merged.content;
  state.pages.set(p.id, merged);
  events.emit('tree');
}

export function removePageLocal(id) {
  for (const cid of descendants(id)) state.pages.delete(cid);
  state.pages.delete(id);
  events.emit('tree');
}

export function children(parentId) {
  const list = [];
  for (const p of state.pages.values()) if ((p.parent_id ?? null) === (parentId ?? null)) list.push(p);
  return sortPages(list);
}

export function sortPages(list) {
  const s = state.sort;
  const coll = new Intl.Collator('ru', { sensitivity: 'base', numeric: true });
  if (s === 'title') list.sort((a, b) => coll.compare(a.title || 'яяя', b.title || 'яяя'));
  else if (s === 'updated') list.sort((a, b) => b.updated_at - a.updated_at);
  else list.sort((a, b) => a.position - b.position);
  return list;
}

export function descendants(id) {
  const out = [];
  const stack = [id];
  while (stack.length) {
    const cur = stack.pop();
    for (const p of state.pages.values()) {
      if (p.parent_id === cur) {
        out.push(p.id);
        stack.push(p.id);
      }
    }
  }
  return out;
}

export function ancestors(id) {
  const out = [];
  let p = state.pages.get(id);
  const guard = new Set();
  while (p && p.parent_id && !guard.has(p.parent_id)) {
    guard.add(p.parent_id);
    p = state.pages.get(p.parent_id);
    if (p) out.unshift(p);
  }
  return out;
}

export function setSort(s) {
  state.sort = s;
  ls('sort', s);
  events.emit('tree');
}

export function toggleExpanded(id, force) {
  const on = force === undefined ? !state.expanded.has(id) : force;
  if (on) state.expanded.add(id);
  else state.expanded.delete(id);
  ls('expanded', Array.from(state.expanded));
  events.emit('tree');
}

export function expandTo(id) {
  let changed = false;
  for (const a of ancestors(id)) {
    if (!state.expanded.has(a.id)) {
      state.expanded.add(a.id);
      changed = true;
    }
  }
  if (changed) {
    ls('expanded', Array.from(state.expanded));
    events.emit('tree');
  }
}
