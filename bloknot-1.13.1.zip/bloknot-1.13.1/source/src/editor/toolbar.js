// Плавающая панель форматирования и редактор ссылок
import { el, isMac, normalizeUrl, safeHref, escapeHtml, debounce, hostOf } from '../util.js';
import { icon } from '../icons.js';
import { getRange } from './caret.js';
import { positionPopup, showMenu, viewportBox } from '../ui/menu.js';
import { COLORS } from './model.js';
import { AiPanel } from './ai.js';

const mod = isMac ? '⌘' : 'Ctrl+';

export class InlineToolbar {
  constructor(editor) {
    this.editor = editor;
    this.bar = el('div', { class: 'fmt-bar', role: 'toolbar', 'aria-label': 'Форматирование' });
    const btn = (name, title, fn) => {
      const b = el('button', { type: 'button', class: 'fmt-btn', title, 'aria-label': title, 'data-fmt': name }, icon(name, 17));
      b.addEventListener('pointerdown', (e) => e.preventDefault());
      b.addEventListener('click', (e) => {
        e.preventDefault();
        fn();
      });
      return b;
    };
    this.colorBtn = el('button', { type: 'button', class: 'fmt-btn fmt-color', title: 'Цвет текста и фона', 'aria-label': 'Цвет текста и фона', 'data-fmt': 'color' }, el('span', { class: 'fmt-color-a' }, 'A'), icon('chevronDown', 12));
    this.colorBtn.addEventListener('pointerdown', (e) => e.preventDefault());
    this.colorBtn.addEventListener('click', (e) => {
      e.preventDefault();
      this.openColor();
    });
    this.ai = new AiPanel(editor);
    const aiBtn = el('button', { type: 'button', class: 'fmt-btn fmt-ai', title: 'ИИ-помощник: команда для выделенного текста', 'aria-label': 'ИИ-помощник', 'data-fmt': 'ai' }, icon('sparkle', 15), el('span', null, 'ИИ'));
    aiBtn.addEventListener('pointerdown', (e) => e.preventDefault());
    aiBtn.addEventListener('click', (e) => {
      e.preventDefault();
      this.bar.style.display = 'none';
      this.ai.open();
    });
    this.bar.append(
      aiBtn,
      el('span', { class: 'fmt-sep' }),
      this.colorBtn,
      el('span', { class: 'fmt-sep' }),
      btn('bold', `Жирный (${mod}B)`, () => this.exec('bold')),
      btn('italic', `Курсив (${mod}I)`, () => this.exec('italic')),
      btn('underline', `Подчёркнутый (${mod}U)`, () => this.exec('underline')),
      btn('strike', `Зачёркнутый (${mod}Shift+S)`, () => this.exec('strikeThrough')),
      btn('code', `Код (${mod}E)`, () => this.toggleCode()),
      el('span', { class: 'fmt-sep' }),
      btn('link', `Ссылка (${mod}K)`, () => this.openLink()),
    );
    this.bar.style.display = 'none';
    document.body.append(this.bar);
    this.card = null;
    this.onSel = () => this.update();
    document.addEventListener('selectionchange', this.onSel);
    this.onOver = (e) => {
      const a = e.target.closest && e.target.closest('a[href]');
      if (a && editor.root.contains(a) && a.closest('[contenteditable="true"]')) {
        clearTimeout(this.hoverTimer);
        this.hoverTimer = setTimeout(() => this.showLinkCard(a), 350);
      } else if (!(this.card && this.card.contains(e.target))) {
        clearTimeout(this.hoverTimer);
      }
    };
    editor.root.addEventListener('mouseover', this.onOver);
    this.onScroll = () => this.update();
    window.addEventListener('scroll', this.onScroll, true);
    if (window.visualViewport) window.visualViewport.addEventListener('resize', this.onScroll);
  }

  destroy() {
    this.ai.close();
    document.removeEventListener('selectionchange', this.onSel);
    window.removeEventListener('scroll', this.onScroll, true);
    if (window.visualViewport) window.visualViewport.removeEventListener('resize', this.onScroll);
    this.bar.remove();
    this.hideCard();
    this.closeLink();
  }

  host(node) {
    if (!node) return null;
    const e = node.nodeType === 1 ? node : node.parentElement;
    const h = e && e.closest('[contenteditable="true"]');
    if (!h || !this.editor.root.contains(h) || h.classList.contains('blk-code')) return null;
    return h;
  }

  update() {
    if (this.linkPop || (this.ai && this.ai.pop)) return;
    const r = getRange();
    const h = r ? this.host(r.commonAncestorContainer) : null;
    if (!r || !h || r.collapsed || !r.toString().trim()) {
      this.bar.style.display = 'none';
      const sc = this.editor.root.closest('.scroller');
      if (sc && sc.style.paddingBottom && !(this.ai && this.ai.pop)) sc.style.paddingBottom = '';
      // каретка внутри ссылки — показываем карточку ссылки (удобно на телефоне)
      if (r && r.collapsed && h) {
        const node = r.startContainer.nodeType === 1 ? r.startContainer : r.startContainer.parentElement;
        const a = node && node.closest('a[href]');
        if (a && h.contains(a)) this.showLinkCard(a);
        else if (this.card && !this.card.matches(':hover')) this.hideCard();
      }
      return;
    }
    this.hideCard();
    this.bar.style.display = 'flex';
    for (const [name, cmd] of [['bold', 'bold'], ['italic', 'italic'], ['underline', 'underline'], ['strike', 'strikeThrough']]) {
      let on = false;
      try {
        on = document.queryCommandState(cmd);
      } catch (e) {
        /* ignore */
      }
      this.bar.querySelector(`[data-fmt="${name}"]`).classList.toggle('is-on', on);
    }
    const node = r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement;
    this.bar.querySelector('[data-fmt="code"]').classList.toggle('is-on', !!node.closest('code'));
    this.bar.querySelector('[data-fmt="link"]').classList.toggle('is-on', !!node.closest('a'));
    const cur = this.currentColors(node, h);
    const a = this.colorBtn.querySelector('.fmt-color-a');
    a.className = `fmt-color-a${cur.fg ? ' tc-' + cur.fg : ''}${cur.bg ? ' tc-' + cur.bg + '_background' : ''}`;
    const rect = r.getBoundingClientRect();
    const touch = matchMedia('(pointer: coarse)').matches;
    if (touch) this.placeTouch(rect);
    else positionPopup(this.bar, rect, 'top-start', 8);
  }

  /**
   * Телефон. Над выделением iOS/Android всегда показывают своё системное меню
   * («Скопировать · Вставить · …»), поэтому наша панель встаёт ПОД выделение — ниже ручки выделения.
   * Если над выделением нет места, система сама уносит меню вниз — тогда наша панель встаёт ещё ниже, под ним.
   * Панель не заезжает на ленту действий строки и на клавиатуру: при нехватке места страница прокручивается,
   * а если прокрутить нельзя — панель уходит над выделением (выше системного меню).
   */
  placeTouch(rect) {
    const MENU = 64; // системное меню (≈48 px) с отступами
    const HANDLE = 12; // ручка выделения под текстом
    const box = viewportBox();
    const vTop = box.top;
    const vBottom = box.bottom;
    let limit = vBottom;
    const mb = document.querySelector('.mobilebar.is-visible:not(.is-suppressed):not(.is-floating)');
    if (mb) limit = Math.min(limit, mb.getBoundingClientRect().top, vBottom - mb.offsetHeight);
    const barH = this.bar.offsetHeight;
    const barW = this.bar.offsetWidth;
    // iOS сама выбирает, где показать своё меню — над выделением или под ним, — и сайту не сообщает.
    // Поэтому под выделением всегда оставляем полосу под это меню, а нашу панель ставим ниже неё.
    const below = rect.bottom + HANDLE + MENU;
    let top = below;
    if (below + barH > limit - 6) {
      // выделение у нижнего края (над клавиатурой/лентой) — прокручиваем страницу, чтобы под ним поместилась панель
      const scroller = this.editor.root.closest('.scroller');
      const need = below + barH + 6 - limit;
      if (scroller) {
        const pad = Math.round(window.innerHeight - limit + barH + MENU + 40);
        if (parseFloat(scroller.style.paddingBottom || '0') < pad) scroller.style.paddingBottom = `${pad}px`;
        if (rect.top - need > vTop + box.safeTop + 16) {
          const before = scroller.scrollTop;
          scroller.scrollBy({ top: need, behavior: 'instant' });
          const moved = scroller.scrollTop - before;
          if (moved > 0) {
            rect = { top: rect.top - moved, bottom: rect.bottom - moved, left: rect.left };
            top = rect.bottom + HANDLE + MENU;
          }
        }
      }
      if (top + barH > limit - 6) {
        // прокрутить нельзя — над выделением, выше системного меню
        top = rect.top - barH - MENU - 8;
      }
    }
    top = Math.max(vTop + 8, Math.min(top, limit - barH - 6));
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - barW - 8));
    this.bar.style.left = `${left}px`;
    this.bar.style.top = `${Math.round(top + box.shift)}px`;
  }

  exec(cmd) {
    const r = getRange();
    const h = r ? this.host(r.commonAncestorContainer) : null;
    if (!h) return;
    document.execCommand('styleWithCSS', false, false);
    document.execCommand(cmd, false, null);
    this.update();
  }

  // ---------- цвет фрагмента текста ----------
  currentColors(node, h) {
    const out = {};
    for (let e = node; e && e !== h; e = e.parentElement) {
      if (e.tagName !== 'SPAN') continue;
      for (const c of e.classList) {
        const m = /^tc-([a-z]+?)(_background)?$/.exec(c);
        if (!m) continue;
        if (m[2] && !out.bg) out.bg = m[1];
        if (!m[2] && !out.fg) out.fg = m[1];
      }
    }
    return out;
  }

  openColor() {
    const r = getRange();
    const h = r ? this.host(r.commonAncestorContainer) : null;
    if (!h || r.collapsed) return;
    const saved = r.cloneRange();
    const node = r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement;
    const cur = this.currentColors(node, h);
    const swatch = (c, bg) => () => el('span', { class: `color-swatch${bg ? ' is-bg' : ''} ${c ? 'c-' + c : ''}` }, bg ? '' : 'A');
    const pick = (kind, color) => () => {
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(saved);
      this.applyColor(kind, color);
    };
    const items = [{ header: 'Цвет текста' }, { label: 'Обычный текст', icon: swatch(null, false), checked: !cur.fg, onSelect: pick('fg', null) }];
    for (const [c, name] of COLORS) items.push({ label: `${name} текст`, icon: swatch(c, false), checked: cur.fg === c, onSelect: pick('fg', c) });
    items.push({ separator: true }, { header: 'Цвет фона' }, { label: 'Без фона', icon: swatch(null, true), checked: !cur.bg, onSelect: pick('bg', null) });
    for (const [c, name] of COLORS) items.push({ label: `${name} фон`, icon: swatch(`${c}_background`, true), checked: cur.bg === c, onSelect: pick('bg', c) });
    showMenu({ anchor: this.colorBtn, items, placement: 'bottom-start', className: 'color-menu fmt-color-menu', focusFirst: false, sheetTitle: 'Цвет' });
  }

  /** kind: 'fg' | 'bg'; color: 'red' … или null (убрать). */
  applyColor(kind, color) {
    const r = getRange();
    const h = r ? this.host(r.commonAncestorContainer) : null;
    if (!h || r.collapsed) return;
    this.editor.checkpoint();
    const re = kind === 'bg' ? /^tc-[a-z]+_background$/ : /^tc-[a-z]+$/;
    const hasKind = (e) => e.tagName === 'SPAN' && Array.from(e.classList).some((c) => re.test(c));
    const stripKind = (e) => {
      for (const c of Array.from(e.classList)) if (re.test(c)) e.classList.remove(c);
      if (!e.classList.length) {
        e.removeAttribute('class');
        e.replaceWith(...e.childNodes);
      }
    };
    // выделение внутри уже окрашенного фрагмента — разрезаем его, чтобы цвет сменился только у выделенного
    let anc = r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement;
    while (anc && anc !== h && !hasKind(anc)) anc = anc.parentElement;
    if (anc && anc !== h) {
      const before = document.createRange();
      before.setStart(anc, 0);
      before.setEnd(r.startContainer, r.startOffset);
      const after = document.createRange();
      after.setStart(r.endContainer, r.endOffset);
      after.setEnd(anc, anc.childNodes.length);
      const fa = after.extractContents();
      const fb = before.extractContents();
      if (fb.textContent) {
        const s1 = anc.cloneNode(false);
        s1.append(fb);
        anc.before(s1);
      }
      if (fa.textContent) {
        const s2 = anc.cloneNode(false);
        s2.append(fa);
        anc.after(s2);
      }
      r.selectNodeContents(anc);
    }
    const frag = r.extractContents();
    frag.querySelectorAll('span').forEach((sp) => {
      if (hasKind(sp)) stripKind(sp);
    });
    let first;
    let last;
    if (color) {
      const span = document.createElement('span');
      span.className = kind === 'bg' ? `tc-${color}_background` : `tc-${color}`;
      span.append(frag);
      r.insertNode(span);
      first = last = span;
    } else {
      first = frag.firstChild;
      last = frag.lastChild;
      r.insertNode(frag);
    }
    if (anc && anc !== h && anc.isConnected) {
      if (!anc.textContent) anc.remove();
      else stripKind(anc);
    }
    h.normalize();
    const sel = window.getSelection();
    const nr = document.createRange();
    if (first && first.isConnected && last && last.isConnected) {
      nr.setStartBefore(first);
      nr.setEndAfter(last);
      sel.removeAllRanges();
      sel.addRange(nr);
    }
    h.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'formatFontColor' }));
    this.update();
  }

  toggleCode() {
    const r = getRange();
    const h = r ? this.host(r.commonAncestorContainer) : null;
    if (!h || r.collapsed) return;
    this.editor.checkpoint();
    const node = r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement;
    const existing = node.closest('code');
    if (existing && h.contains(existing)) {
      existing.replaceWith(document.createTextNode(existing.textContent));
    } else {
      const text = r.toString();
      r.deleteContents();
      const c = document.createElement('code');
      c.textContent = text;
      r.insertNode(c);
      const sel = window.getSelection();
      const nr = document.createRange();
      nr.selectNodeContents(c);
      sel.removeAllRanges();
      sel.addRange(nr);
    }
    h.normalize();
    h.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'formatCode' }));
    this.update();
  }

  fixLinks(h) {
    h.querySelectorAll('a[href]').forEach((a) => {
      const href = a.getAttribute('href');
      if (href.startsWith('#/')) {
        a.removeAttribute('target');
        a.removeAttribute('rel');
      } else {
        a.setAttribute('target', '_blank');
        a.setAttribute('rel', 'noopener noreferrer');
      }
    });
  }

  // ---------- карточка ссылки ----------
  showLinkCard(a) {
    if (this.linkPop || (this.card && this.card.dataset.for === a.getAttribute('href') && this.cardAnchor === a)) return;
    this.hideCard();
    const href = a.getAttribute('href');
    const internal = href.startsWith('#/p/');
    let label = href;
    if (internal) {
      const p = this.editor.opts.getPage && this.editor.opts.getPage(Number(href.slice(4)));
      label = p ? `${p.icon ? p.icon + ' ' : ''}${p.title || 'Без названия'}` : 'Страница недоступна';
    }
    const card = el(
      'div',
      { class: 'link-card', 'data-for': href },
      el('span', { class: 'link-card-url', title: href }, internal ? label : hostOf(href) + (href.length > 40 ? '…' : '')),
      el('button', { type: 'button', class: 'link-card-btn', title: 'Открыть' }, icon('open', 16)),
      el('button', { type: 'button', class: 'link-card-btn', title: 'Изменить ссылку' }, icon('link', 16)),
      el('button', { type: 'button', class: 'link-card-btn', title: 'Убрать ссылку' }, icon('x', 16)),
    );
    const [openB, editB, rmB] = card.querySelectorAll('button');
    card.addEventListener('pointerdown', (e) => e.preventDefault());
    openB.addEventListener('click', () => {
      this.hideCard();
      if (internal) this.editor.opts.openPage && this.editor.opts.openPage(Number(href.slice(4)));
      else window.open(href, '_blank', 'noopener,noreferrer');
    });
    editB.addEventListener('click', () => {
      this.hideCard();
      const range = document.createRange();
      range.selectNodeContents(a);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      this.openLink();
    });
    rmB.addEventListener('click', () => {
      this.hideCard();
      const h = this.host(a);
      this.editor.checkpoint();
      a.replaceWith(...Array.from(a.childNodes));
      if (h) {
        h.normalize();
        h.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'formatRemove' }));
      }
    });
    document.body.append(card);
    positionPopup(card, a.getBoundingClientRect(), 'bottom-start', 4);
    this.card = card;
    this.cardAnchor = a;
    card.addEventListener('mouseleave', () => setTimeout(() => {
      if (this.card === card && !card.matches(':hover') && !(this.cardAnchor && this.cardAnchor.matches(':hover'))) this.hideCard();
    }, 400));
    a.addEventListener('mouseleave', () => setTimeout(() => {
      if (this.card === card && !card.matches(':hover') && !a.matches(':hover')) {
        const r = getRange();
        if (!(r && a.contains(r.startContainer))) this.hideCard();
      }
    }, 400), { once: true });
  }

  hideCard() {
    if (this.card) {
      this.card.remove();
      this.card = null;
      this.cardAnchor = null;
    }
  }

  // ---------- поповер ссылки ----------
  openLink() {
    const r = getRange();
    const h = r ? this.host(r.commonAncestorContainer) : null;
    if (!h) return;
    this.closeLink();
    this.bar.style.display = 'none';
    const saved = r.cloneRange();
    const node = r.commonAncestorContainer.nodeType === 1 ? r.commonAncestorContainer : r.commonAncestorContainer.parentElement;
    const existing = node.closest('a');
    const input = el('input', {
      type: 'text', class: 'link-input', placeholder: 'Вставьте ссылку или найдите страницу', value: existing ? existing.getAttribute('href') : '',
      'aria-label': 'Адрес ссылки', autocomplete: 'off', spellcheck: 'false',
    });
    const results = el('div', { class: 'link-results' });
    const pop = el('div', { class: 'link-pop' }, input, results);
    if (existing) {
      const rm = el('button', { type: 'button', class: 'link-remove' }, icon('x', 15), 'Убрать ссылку');
      rm.addEventListener('click', () => this.applyLink(null, saved, h, existing));
      pop.append(rm);
    }
    document.body.append(pop);
    positionPopup(pop, r.getBoundingClientRect(), 'bottom-start', 8);
    this.linkPop = pop;
    let options = [];
    let cursor = -1;
    const renderResults = (list) => {
      options = list;
      results.textContent = '';
      cursor = list.length ? 0 : -1;
      list.forEach((o, i) => {
        const row = el('button', { type: 'button', class: `link-opt${i === 0 ? ' is-active' : ''}` }, o.icon ? el('span', { class: 'link-opt-ic' }, o.icon) : icon(o.kind === 'url' ? 'link' : 'page', 16), el('span', null, o.label));
        row.addEventListener('pointerdown', (e) => e.preventDefault());
        row.addEventListener('click', () => this.applyLink(o.href, saved, h, existing));
        results.append(row);
      });
    };
    const search = debounce(async (q) => {
      const list = [];
      const url = normalizeUrl(q);
      if (q && safeHref(url)) list.push({ kind: 'url', href: url, label: `Ссылка на ${url}` });
      if (q && this.editor.opts.searchPages) {
        try {
          const pages = await this.editor.opts.searchPages(q);
          pages.slice(0, 6).forEach((p) => list.push({ kind: 'page', href: `#/p/${p.id}`, icon: p.icon, label: p.title || 'Без названия' }));
        } catch (e) {
          /* ignore */
        }
      }
      if (this.linkPop === pop) renderResults(list);
    }, 150);
    input.addEventListener('input', () => search(input.value.trim()));
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        this.closeLink();
        restore(saved, h);
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        if (!options.length) return;
        cursor = (cursor + (e.key === 'ArrowDown' ? 1 : -1) + options.length) % options.length;
        Array.from(results.children).forEach((c, i) => c.classList.toggle('is-active', i === cursor));
      } else if (e.key === 'Enter') {
        e.preventDefault();
        const v = input.value.trim();
        if (cursor >= 0 && options[cursor]) this.applyLink(options[cursor].href, saved, h, existing);
        else if (v) this.applyLink(normalizeUrl(v), saved, h, existing);
      }
    });
    this.linkOutside = (e) => {
      if (!pop.contains(e.target)) this.closeLink();
    };
    setTimeout(() => document.addEventListener('pointerdown', this.linkOutside, true), 0);
    input.focus();
    input.select();
    if (input.value) search(input.value);
  }

  closeLink() {
    if (this.linkPop) {
      this.linkPop.remove();
      this.linkPop = null;
      document.removeEventListener('pointerdown', this.linkOutside, true);
    }
  }

  applyLink(href, saved, h, existing) {
    this.closeLink();
    restore(saved, h);
    this.editor.checkpoint();
    if (!href) {
      if (existing) existing.replaceWith(...Array.from(existing.childNodes));
    } else {
      const safe = safeHref(href);
      if (!safe) {
        this.editor.opts.toast && this.editor.opts.toast('Ссылка должна начинаться с http:// или https://', 'error');
        return;
      }
      if (existing) existing.setAttribute('href', safe);
      else if (saved.collapsed) {
        let label = safe;
        if (safe.startsWith('#/p/')) {
          const p = this.editor.opts.getPage && this.editor.opts.getPage(Number(safe.slice(4)));
          label = p ? p.title || 'Без названия' : safe;
        }
        document.execCommand('insertHTML', false, `<a href="${escapeHtml(safe)}">${escapeHtml(label)}</a>`);
      } else document.execCommand('createLink', false, safe);
    }
    this.fixLinks(h);
    h.normalize();
    h.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'formatCreateLink' }));
  }
}

function restore(range, h) {
  h.focus({ preventScroll: true });
  const sel = window.getSelection();
  sel.removeAllRanges();
  sel.addRange(range);
}
