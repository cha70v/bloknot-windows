<?php
/**
 * Блокнот — задачи по расписанию.
 *
 * Из командной строки (cron в панели хостинга):
 *   php /путь/к/сайту/cron.php backup        — резервная копия в data/backups (хранится 7 последних)
 *   php /путь/к/сайту/cron.php backup 14     — хранить 14 последних
 *   php /путь/к/сайту/cron.php cleanup       — удалить изображения, на которые больше нет ссылок
 *   php /путь/к/сайту/cron.php mail-backup   — отправить резервную копию на почту, если подошёл срок
 *   php /путь/к/сайту/cron.php mail-backup now — отправить сейчас
 *
 * Через веб (если хостинг умеет только «открывать ссылку по расписанию»):
 *   https://ваш-сайт/cron.php?task=backup&key=КЛЮЧ   (ключ — cron_key в data/config.php)
 */

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/pages.php';
require __DIR__ . '/lib/files.php';
require __DIR__ . '/lib/export.php';
require __DIR__ . '/lib/mailer.php';

$cli = PHP_SAPI === 'cli';
if (!$cli) {
    security_headers();
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: no-store');
}

function cron_fail($msg, $code = 400)
{
    global $cli;
    if (!$cli) http_response_code($code);
    echo $msg . "\n";
    exit(1);
}

if (!is_installed()) cron_fail('Блокнот не установлен', 503);

if ($cli) {
    $task = isset($argv[1]) ? $argv[1] : '';
    $arg = isset($argv[2]) ? $argv[2] : null;
} else {
    $key = isset($_GET['key']) ? (string) $_GET['key'] : '';
    if (!config('cron_key') || !hash_equals((string) config('cron_key'), $key)) cron_fail('Доступ запрещён', 403);
    $task = isset($_GET['task']) ? (string) $_GET['task'] : '';
    $arg = isset($_GET['keep']) ? $_GET['keep'] : null;
}

@set_time_limit(0);
switch ($task) {
    case 'backup':
        $path = backup_to_file($arg ? (int) $arg : 7);
        echo 'Резервная копия: ' . basename($path) . ' (' . round(filesize($path) / 1048576, 2) . " МБ)\n";
        break;
    case 'cleanup':
        $total = 0;
        foreach (q('SELECT id FROM users')->fetchAll(PDO::FETCH_COLUMN) as $uid) {
            $r = files_cleanup((int) $uid);
            $total += $r['deleted'];
        }
        echo "Удалено неиспользуемых файлов: $total\n";
        break;
    case 'mail-backup':
        if ($arg !== 'now' && !mail_backup_due()) {
            echo "Отправка не требуется (не подошёл срок, нет изменений или отправка выключена)\n";
            break;
        }
        $res = mail_backup_run('cron');
        if (!$res['ok']) cron_fail('Не удалось отправить: ' . $res['error'], 502);
        echo 'Резервная копия отправлена на ' . $res['status']['recipient'] . "\n";
        break;
    default:
        cron_fail('Неизвестная задача. Доступно: backup, cleanup, mail-backup');
}
