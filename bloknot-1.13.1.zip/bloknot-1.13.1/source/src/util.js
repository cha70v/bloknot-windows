// Небольшие помощники для работы с DOM и данными

export const isMac = /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent);
export const isTouch = matchMedia('(pointer: coarse)').matches;
export const modKey = (e) => (isMac ? e.metaKey : e.ctrlKey);
export const modLabel = isMac ? '⌘' : 'Ctrl';

export function el(tag, attrs, ...children) {
  const node = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'dataset') Object.assign(node.dataset, v);
      else if (v === true) node.setAttribute(k, '');
      else node.setAttribute(k, v);
    }
  }
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    node.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return node;
}

export function clear(node) {
  while (node.firstChild) node.removeChild(node.firstChild);
  return node;
}

export function debounce(fn, ms) {
  let t;
  const d = (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), ms);
  };
  d.cancel = () => clearTimeout(t);
  d.flush = (...args) => {
    clearTimeout(t);
    fn(...args);
  };
  return d;
}

export function uid() {
  const a = new Uint8Array(6);
  crypto.getRandomValues(a);
  return Array.from(a, (b) => b.toString(36).padStart(2, '0')).join('').slice(0, 10);
}

export function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

const MONTHS = ['янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];

export function formatDate(ms, withTime = true) {
  if (!ms) return '';
  const d = new Date(ms);
  const now = new Date();
  const time = `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
  const sameDay = d.toDateString() === now.toDateString();
  const yest = new Date(now);
  yest.setDate(now.getDate() - 1);
  if (sameDay) return withTime ? `сегодня, ${time}` : 'сегодня';
  if (d.toDateString() === yest.toDateString()) return withTime ? `вчера, ${time}` : 'вчера';
  const date = `${d.getDate()} ${MONTHS[d.getMonth()]}${d.getFullYear() !== now.getFullYear() ? ' ' + d.getFullYear() : ''}`;
  return withTime ? `${date}, ${time}` : date;
}

export function plural(n, one, few, many) {
  const m10 = n % 10;
  const m100 = n % 100;
  if (m10 === 1 && m100 !== 11) return one;
  if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
  return many;
}

export function formatBytes(b) {
  if (b == null) return '—';
  if (b < 1024) return `${b} Б`;
  if (b < 1048576) return `${(b / 1024).toFixed(0)} КБ`;
  if (b < 1073741824) return `${(b / 1048576).toFixed(1)} МБ`;
  return `${(b / 1073741824).toFixed(2)} ГБ`;
}

export function pageTitle(p) {
  return (p && p.title && p.title.trim()) || 'Без названия';
}

export function store(key, value) {
  try {
    if (value === undefined) {
      const v = localStorage.getItem('tetrad:' + key);
      return v === null ? null : JSON.parse(v);
    }
    if (value === null) localStorage.removeItem('tetrad:' + key);
    else localStorage.setItem('tetrad:' + key, JSON.stringify(value));
  } catch (e) {
    return null;
  }
  return value;
}

export function storeKeys(prefix) {
  const out = [];
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith('tetrad:' + prefix)) out.push(k.slice(7));
    }
  } catch (e) {
    /* хранилище недоступно */
  }
  return out;
}

export function emitter() {
  const map = new Map();
  return {
    on(evt, fn) {
      if (!map.has(evt)) map.set(evt, new Set());
      map.get(evt).add(fn);
      return () => map.get(evt).delete(fn);
    },
    emit(evt, ...args) {
      (map.get(evt) || []).forEach((fn) => fn(...args));
    },
  };
}

export function isUrl(s) {
  return /^(https?:\/\/|www\.)[^\s<>"]+\.[^\s<>"]{2,}$/i.test(String(s).trim()) && !/\s/.test(String(s).trim());
}

export function normalizeUrl(s) {
  s = String(s).trim();
  if (/^www\./i.test(s)) return 'https://' + s;
  if (/^[a-z0-9-]+(\.[a-z0-9-]+)+(\/\S*)?$/i.test(s)) return 'https://' + s;
  return s;
}

export function safeHref(href) {
  if (!href) return null;
  href = String(href).trim();
  if (/^#\/p\/\d+$/.test(href)) return href;
  if (/^(https?:|mailto:|tel:)/i.test(href)) return href;
  if (/^www\./i.test(href)) return 'https://' + href;
  return null;
}

export function hostOf(url) {
  try {
    return new URL(url).host.replace(/^www\./, '');
  } catch (e) {
    return url;
  }
}

export function nextFrame() {
  return new Promise((r) => requestAnimationFrame(() => r()));
}

export function downloadUrl(url) {
  const a = el('a', { href: url, download: '' });
  document.body.append(a);
  a.click();
  a.remove();
}
