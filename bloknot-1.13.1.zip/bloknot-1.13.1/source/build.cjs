// Сборка фронтенда: node build.cjs [--watch]
// Требуется esbuild и библиотеки highlight.js, jszip, marked (npm install).
const path = require('path');
const fs = require('fs');

const extraPaths = [path.join(__dirname, 'node_modules'), '/opt/npm-tools/node_modules'].filter((p) => fs.existsSync(p));
const esbuild = require(require.resolve('esbuild', { paths: extraPaths }));
// в репозитории сборка кладётся в app/assets, в архиве поставки — в ../upload/assets
const appDir = fs.existsSync(path.join(__dirname, 'app')) ? path.join(__dirname, 'app') : path.join(__dirname, '..', 'upload');
const assetsDir = path.join(appDir, 'assets');

const opts = {
  entryPoints: [path.join(__dirname, 'src/main.js')],
  bundle: true,
  minify: !process.argv.includes('--dev'),
  sourcemap: false,
  format: 'esm',
  splitting: true,
  entryNames: 'app',
  chunkNames: 'chunk-[hash]',
  target: ['chrome100', 'firefox110', 'safari15.4', 'edge100'],
  outdir: assetsDir,
  nodePaths: extraPaths,
  legalComments: 'eof',
  logLevel: 'info',
  charset: 'utf8',
};

const cssIn = path.join(__dirname, 'src/styles.css');
const cssOut = path.join(assetsDir, 'app.css');

async function buildCss() {
  await esbuild.build({ entryPoints: [cssIn], bundle: true, minify: !process.argv.includes('--dev'), outfile: cssOut, logLevel: 'info', charset: 'utf8' });
}

(async () => {
  if (process.argv.includes('--watch')) {
    const ctx = await esbuild.context(opts);
    await ctx.watch();
    fs.watch(cssIn, () => buildCss().catch(console.error));
    await buildCss();
  } else {
    for (const f of fs.readdirSync(assetsDir)) if (/^chunk-.*\.js$/.test(f)) fs.unlinkSync(path.join(assetsDir, f));
    await esbuild.build(opts);
    await buildCss();
  }
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
