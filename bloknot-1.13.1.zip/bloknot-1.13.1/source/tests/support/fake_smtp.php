<?php
// Простой SMTP-сервер для тестов (без шифрования): php fake_smtp.php ПОРТ КАТАЛОГ ЛОГИН ПАРОЛЬ
list(, $port, $dir, $user, $pass) = $argv;
@mkdir($dir, 0777, true);
$srv = stream_socket_server("tcp://127.0.0.1:$port", $errno, $errstr);
if (!$srv) { fwrite(STDERR, $errstr); exit(1); }
while ($c = @stream_socket_accept($srv, -1)) {
    $w = function ($s) use ($c) { fwrite($c, $s . "\r\n"); };
    $w('220 fake ESMTP');
    $state = ''; $data = ''; $authUser = null; $authed = false;
    while (($line = fgets($c)) !== false) {
        if ($state === 'data') {
            if (rtrim($line, "\r\n") === '.') { file_put_contents("$dir/" . microtime(true) . '.eml', $data); $data = ''; $state = ''; $w('250 OK queued'); continue; }
            $data .= $line; continue;
        }
        $l = rtrim($line, "\r\n");
        if ($state === 'user') { $authUser = base64_decode($l); $state = 'pass'; $w('334 UGFzc3dvcmQ6'); continue; }
        if ($state === 'pass') { $state = ''; if ($authUser === $user && base64_decode($l) === $pass) { $authed = true; $w('235 OK'); } else $w('535 Authentication failed'); continue; }
        $cmd = strtoupper(substr($l, 0, 4));
        if ($cmd === 'EHLO' || $cmd === 'HELO') { fwrite($c, "250-fake\r\n250 AUTH LOGIN\r\n"); }
        elseif ($l === 'AUTH LOGIN') { $state = 'user'; $w('334 VXNlcm5hbWU6'); }
        elseif ($cmd === 'MAIL') { $authed ? $w('250 OK') : $w('530 Auth required'); }
        elseif ($cmd === 'RCPT') { $w('250 OK'); }
        elseif ($cmd === 'DATA') { $state = 'data'; $w('354 Go'); }
        elseif ($cmd === 'QUIT') { $w('221 Bye'); break; }
        else $w('250 OK');
    }
    fclose($c);
}
