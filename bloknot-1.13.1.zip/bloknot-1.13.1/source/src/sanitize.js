// Очистка встроенного HTML: остаются только b, i, u, s, code, a, br и span с классами цвета (tc-red, tc-red_background).
// Результат строится заново из текста и разрешённых тегов, поэтому безопасен по построению.
import { escapeHtml, safeHref } from './util.js';

const DROP = new Set(['SCRIPT', 'STYLE', 'HEAD', 'TITLE', 'META', 'LINK', 'NOSCRIPT', 'TEMPLATE', 'SVG', 'MATH', 'OBJECT', 'IFRAME', 'BUTTON', 'SELECT', 'TEXTAREA', 'INPUT', 'IMG', 'VIDEO', 'AUDIO', 'CANVAS']);
const BLOCKISH = new Set(['P', 'DIV', 'LI', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'BLOCKQUOTE', 'PRE', 'TR', 'SECTION', 'ARTICLE', 'DT', 'DD', 'FIGCAPTION', 'SUMMARY']);
const parser = new DOMParser();
const INLINE_COLORS = new Set(['gray', 'brown', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink', 'red']);

/** Цвет текста и фона фрагмента: наши классы tc-*, а также highlight-* из экспорта Notion. */
function inlineColors(node) {
  const out = {};
  if (!node.classList || !node.classList.length) return out;
  for (const cls of node.classList) {
    const m = /^(?:tc|highlight)-([a-z]+?)(_background)?$/.exec(cls);
    if (!m) continue;
    const base = m[1] === 'default' ? 'default' : INLINE_COLORS.has(m[1]) ? m[1] : null;
    if (!base) continue;
    if (m[2]) out.bg = base;
    else out.fg = base;
  }
  return out;
}

function styleFlags(node) {
  const st = node.getAttribute && node.getAttribute('style');
  const f = {};
  if (!st) return f;
  const s = st.toLowerCase();
  const fw = s.match(/font-weight\s*:\s*([a-z0-9]+)/);
  if (fw) f.bold = fw[1] === 'bold' || fw[1] === 'bolder' || parseInt(fw[1], 10) >= 600;
  const fs = s.match(/font-style\s*:\s*([a-z]+)/);
  if (fs) f.italic = fs[1] === 'italic' || fs[1] === 'oblique';
  if (/text-decoration[^;]*underline/.test(s) || /border-bottom\s*:\s*0?\.05em solid/.test(s)) f.underline = true;
  if (/text-decoration[^;]*line-through/.test(s)) f.strike = true;
  if (/font-family[^;]*(mono|courier|consolas)/.test(s)) f.code = true;
  return f;
}

/**
 * @param {string|Node} input
 * @param {{resolveHref?: (href:string)=>string|null}} opts
 */
export function normalizeInline(input, opts = {}) {
  let root;
  if (typeof input === 'string') {
    if (!/[<&]/.test(input)) return opts.keepNewlines ? input.replace(/\r\n?/g, '\n').replace(/\n$/, '').replace(/\n/g, '<br>') : input; // простой текст — без изменений
    root = parser.parseFromString(`<body>${input}</body>`, 'text/html').body;
  } else {
    root = input;
  }
  const out = walk(root, { b: false, i: false, u: false, s: false, code: false, a: false }, opts);
  return tidy(out, opts.keepNewlines);
}

function walk(node, ctx, opts) {
  let html = '';
  let prevBlock = false;
  for (const c of node.childNodes) {
    if (c.nodeType === 3) {
      let t = c.nodeValue;
      if (opts.keepNewlines) {
        // текст из самого редактора (white-space: pre-wrap): переносы Shift+Enter и пробелы-отступы значимы
        t = t.replace(/\r\n?/g, '\n');
        if (t) {
          if (prevBlock && html && !html.endsWith('<br>')) html += '<br>';
          prevBlock = false;
          html += escapeHtml(t).replace(/\n/g, '<br>');
        }
        continue;
      }
      if (!ctx.pre) t = t.replace(/[\t\n\r ]+/g, ' ');
      if (t) {
        if (prevBlock && html && !html.endsWith('<br>')) html += '<br>';
        prevBlock = false;
        html += escapeHtml(t).replace(/ /g, '&nbsp;').replace(/\n/g, '<br>');
      }
      continue;
    }
    if (c.nodeType !== 1) continue;
    const tag = c.tagName;
    if (DROP.has(tag)) continue;
    if (tag === 'BR') {
      html += '<br>';
      continue;
    }
    // Notion: служебные элементы чек-листа
    if (c.classList && c.classList.contains('checkbox')) continue;
    const isBlock = BLOCKISH.has(tag);
    if (isBlock && html && !html.endsWith('<br>')) html += '<br>';
    const f = styleFlags(c);
    let open = '';
    let close = '';
    const next = Object.assign({}, ctx);
    const wrap = (t, flag) => {
      if (!next[flag]) {
        next[flag] = true;
        open += `<${t}>`;
        close = `</${t}>` + close;
      }
    };
    if ((tag === 'B' || tag === 'STRONG') && f.bold !== false) wrap('b', 'b');
    else if (f.bold) wrap('b', 'b');
    if (tag === 'I' || tag === 'EM' || f.italic) wrap('i', 'i');
    if (tag === 'U' || tag === 'INS' || f.underline) wrap('u', 'u');
    if (tag === 'S' || tag === 'STRIKE' || tag === 'DEL' || f.strike) wrap('s', 's');
    if (tag === 'CODE' || tag === 'KBD' || tag === 'SAMP' || tag === 'TT' || f.code) {
      if (!next.code) {
        next.code = true;
        // внутри кода форматирование не нужно — берём только текст
        const txt = c.textContent;
        html += `<code>${escapeHtml(txt)}</code>`;
        prevBlock = isBlock;
        continue;
      }
    }
    if (tag === 'SPAN' || tag === 'MARK') {
      const col = inlineColors(c);
      const cls = [];
      if (col.fg && col.fg !== (ctx.fg || 'default')) {
        next.fg = col.fg;
        if (col.fg !== 'default') cls.push(`tc-${col.fg}`);
      }
      if (col.bg && col.bg !== (ctx.bg || 'default')) {
        next.bg = col.bg;
        if (col.bg !== 'default') cls.push(`tc-${col.bg}_background`);
      }
      if (cls.length) {
        open += `<span class="${cls.join(' ')}">`;
        close = '</span>' + close;
      }
    }
    if (tag === 'A' && !ctx.a) {
      let href = c.getAttribute('href') || '';
      if (opts.resolveHref) href = opts.resolveHref(href) || href;
      const safe = safeHref(href);
      if (safe) {
        next.a = true;
        const internal = safe.startsWith('#/');
        open = `<a href="${escapeHtml(safe)}"${internal ? '' : ' target="_blank" rel="noopener noreferrer"'}>` + open;
        close = close + '</a>';
      }
    }
    if (tag === 'PRE') next.pre = true;
    const inner = walk(c, next, opts);
    if (inner) html += open + inner + close;
    prevBlock = isBlock;
  }
  return html;
}

function tidy(html, keep = false) {
  let prev;
  do {
    prev = html;
    html = html
      .replace(/<(b|i|u|s|code)><\/\1>/g, '')
      .replace(/<\/(b|i|u|s)><\1>/g, '')
      .replace(/<span class="[^"]*"><\/span>/g, '')
      .replace(/<span class="([^"]+)">((?:(?!<\/?span)[\s\S])*)<\/span><span class="\1">/g, '<span class="$1">$2');
  } while (html !== prev);
  if (keep) return html.replace(/<br>$/, ''); // текст редактора: пустые строки внутри сохраняем
  html = html.replace(/^(<br>)+/, '').replace(/(<br>)+$/, '');
  return html.replace(/(<br>){3,}/g, '<br><br>');
}

export function htmlToText(html) {
  if (!html) return '';
  if (!/[<&]/.test(html)) return html;
  const d = parser.parseFromString(`<body>${html.replace(/<br\s*\/?>/gi, '\n')}</body>`, 'text/html');
  return d.body.textContent || '';
}
