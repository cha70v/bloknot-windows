// Автосохранение, очередь изменений при отсутствии сети и синхронизация между устройствами
import { api, ApiError } from './api.js';
import { store as ls, storeKeys, emitter } from './util.js';
import { state, loadTree } from './store.js';

export const syncEvents = emitter();
const SAVE_DELAY = 800;
const POLL_VISIBLE = 3000;
const KEEPALIVE_LIMIT = 60000;

function draftKey(id) {
  return `draft:${id}`;
}

export function getDraft(id) {
  return ls(draftKey(id));
}

function setDraft(id, d) {
  try {
    ls(draftKey(id), d);
    return true;
  } catch (e) {
    return false;
  }
}

export function clearDraft(id, upToTs = Infinity) {
  const d = getDraft(id);
  if (d && d.ts <= upToTs) ls(draftKey(id), null);
}

/**
 * Сеанс редактирования одной страницы.
 * collect() должен вернуть { title, icon, cover, content: { blocks } }.
 */
export class PageSession {
  constructor(page, collect) {
    this.id = page.id;
    this.version = page.version;
    this.updatedAt = page.updated_at;
    this.collect = collect;
    this.dirty = false;
    this.saving = null;
    this.again = false;
    this.paused = false;
    this.retryDelay = 2000;
    this.status = 'saved';
    this.timer = null;
    this.draftTimer = null;
    this.closed = false;
    this.changeSeq = 0;
  }

  setStatus(s, detail) {
    this.status = s;
    syncEvents.emit('status', s, detail, this);
  }

  /** Вызывается при каждом изменении на странице. */
  changed() {
    if (this.closed) return;
    this.dirty = true;
    this.changeSeq++;
    if (!this.paused) this.setStatus('pending');
    clearTimeout(this.draftTimer);
    this.draftTimer = setTimeout(() => this.writeDraft(), 300);
    clearTimeout(this.timer);
    if (!this.paused) this.timer = setTimeout(() => this.save(), SAVE_DELAY);
  }

  writeDraft() {
    if (!this.dirty) return;
    const p = this.collect();
    const ok = setDraft(this.id, { base: this.version, ts: Date.now(), title: p.title, icon: p.icon, cover: p.cover, content: p.content });
    if (!ok) syncEvents.emit('draft-failed');
  }

  async save(force = false) {
    if (this.closed && !this.dirty) return true;
    if (this.paused && !force) return false;
    clearTimeout(this.timer);
    if (this.saving) {
      this.again = true;
      return this.saving;
    }
    if (!this.dirty && !force) return true;
    const seq = this.changeSeq;
    const payload = this.collect();
    const sentAt = Date.now();
    this.setStatus('saving');
    const run = (async () => {
      try {
        const res = await api('page.save', Object.assign({ id: this.id, base_version: this.version, force: force || undefined }, payload));
        this.version = res.version;
        this.updatedAt = res.updated_at;
        this.retryDelay = 2000;
        const p = state.pages.get(this.id);
        if (p) {
          p.version = res.version;
          p.updated_at = res.updated_at;
          p.title = payload.title;
          p.icon = payload.icon;
          p.cover = payload.cover;
        }
        if (this.changeSeq === seq) {
          this.dirty = false;
          clearDraft(this.id, Date.now());
          this.setStatus('saved', res.updated_at);
        }
        syncEvents.emit('saved', this.id, res);
        return true;
      } catch (err) {
        return this.handleError(err, payload, sentAt);
      } finally {
        this.saving = null;
        if (this.again && !this.paused) {
          this.again = false;
          if (this.dirty) setTimeout(() => this.save(), 0);
        }
      }
    })();
    this.saving = run;
    return run;
  }

  handleError(err, payload) {
    if (!(err instanceof ApiError)) err = new ApiError(String(err.message || err), 500);
    if (err.status === 409) {
      this.paused = true;
      this.writeDraft();
      this.setStatus('conflict');
      syncEvents.emit('conflict', this, err.data.server, payload);
      return false;
    }
    if (err.status === 410 || err.status === 404) {
      this.paused = true;
      this.setStatus('error', 'Страница удалена на другом устройстве');
      syncEvents.emit('gone', this);
      return false;
    }
    if (err.status === 413 || err.status === 422) {
      this.writeDraft();
      this.setStatus('error', err.message);
      return false;
    }
    if (err.status === 401) {
      this.writeDraft();
      this.setStatus('error', 'Нужно войти снова — изменения сохранены на этом устройстве');
      return false;
    }
    // сеть или временная ошибка сервера — повторяем
    this.writeDraft();
    this.setStatus(err.status === 0 ? 'offline' : 'error', err.status === 0 ? null : err.message);
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.save(), this.retryDelay);
    this.retryDelay = Math.min(this.retryDelay * 2, 30000);
    return false;
  }

  /** Разрешение конфликта: оставить свою версию поверх серверной. */
  async keepMine() {
    this.paused = false;
    this.dirty = true;
    return this.save(true);
  }

  /** Разрешение конфликта: принять серверную версию (локальная остаётся в истории версий). */
  acceptServer(server) {
    this.paused = false;
    this.dirty = false;
    this.version = server.version;
    this.updatedAt = server.updated_at;
    clearDraft(this.id);
    this.setStatus('saved', server.updated_at);
  }

  retryNow() {
    if (this.dirty && !this.paused) {
      this.retryDelay = 2000;
      this.save();
    }
  }

  /** Сохранить и закрыть (переход на другую страницу). */
  async close() {
    clearTimeout(this.draftTimer);
    if (this.dirty) this.writeDraft();
    let ok = true;
    if (this.dirty && !this.paused) ok = await this.save();
    this.closed = true;
    clearTimeout(this.timer);
    return ok;
  }

  /** Последняя попытка при закрытии вкладки. */
  beacon() {
    if (!this.dirty || this.paused) return;
    this.writeDraft();
    const payload = Object.assign({ id: this.id, base_version: this.version }, this.collect());
    const body = JSON.stringify(payload);
    if (body.length > KEEPALIVE_LIMIT) return; // большие страницы восстановятся из черновика при следующем открытии
    api('page.save', payload, { keepalive: true }).then(
      (res) => {
        this.version = res.version;
        this.dirty = false;
        clearDraft(this.id);
      },
      () => {},
    );
  }
}

// ---------- фоновая отправка черновиков других страниц ----------
let bgTimer = null;

export async function flushBackgroundDrafts(getCurrentId) {
  const keys = storeKeys('draft:');
  let pending = 0;
  for (const k of keys) {
    const id = Number(k.slice(6));
    if (!id || id === getCurrentId()) continue;
    const d = ls(k);
    if (!d) continue;
    if (d.conflict) {
      pending++;
      continue;
    }
    try {
      await api('page.save', { id, base_version: d.base, title: d.title, icon: d.icon, cover: d.cover, content: d.content });
      ls(k, null);
      syncEvents.emit('background-saved', id);
    } catch (err) {
      if (err.status === 409) {
        d.conflict = true;
        ls(k, d);
        pending++;
        syncEvents.emit('background-conflict', id);
      } else if (err.status === 404 || err.status === 410) {
        ls(k, null);
      } else pending++;
    }
  }
  syncEvents.emit('background-pending', pending);
  return pending;
}

export function startBackgroundSync(getCurrentId) {
  const run = () => flushBackgroundDrafts(getCurrentId).catch(() => {});
  clearInterval(bgTimer);
  bgTimer = setInterval(run, 20000);
  window.addEventListener('online', run);
  setTimeout(run, 1500);
}

// ---------- опрос изменений с других устройств ----------
let pollTimer = null;
let polling = false;

export function startPolling(getSession) {
  const tick = async () => {
    if (polling || document.hidden) return;
    polling = true;
    try {
      const s = getSession();
      const res = await api('poll', undefined, { query: s ? { page: s.id } : {} });
      syncEvents.emit('online');
      if (state.treeStamp !== null && res.tree_stamp !== state.treeStamp) await loadTree();
      if (s && res.page && !s.closed) {
        if (res.page.missing || res.page.deleted) syncEvents.emit('gone', s);
        else if (res.page.version > s.version && !s.saving && !s.paused) syncEvents.emit('remote-change', s, res.page);
      }
    } catch (e) {
      if (e.status === 0) syncEvents.emit('offline');
    } finally {
      polling = false;
    }
  };
  clearInterval(pollTimer);
  pollTimer = setInterval(tick, POLL_VISIBLE);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) tick();
  });
  window.addEventListener('focus', tick);
  window.addEventListener('online', tick);
  return tick;
}
