<?php
/** Блокнот — JSON API. Все действия требуют входа, кроме проверки статуса и входа. */

require __DIR__ . '/lib/bootstrap.php';
require __DIR__ . '/lib/auth.php';
require __DIR__ . '/lib/pages.php';
require __DIR__ . '/lib/files.php';
require __DIR__ . '/lib/export.php';
require __DIR__ . '/lib/mailer.php';
require __DIR__ . '/lib/ai.php';

security_headers();
header('Cache-Control: no-store');

function json_out($data, $status = 200)
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function simple_page($message, $status)
{
    http_response_code($status);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Блокнот</title>'
        . '<body style="font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;color:#37352f;display:grid;place-items:center;min-height:90vh;margin:0;padding:16px">'
        . '<div style="text-align:center;max-width:460px"><div style="font-size:44px">📒</div><h1 style="font-size:20px;font-weight:600">'
        . htmlspecialchars($message, ENT_QUOTES, 'UTF-8') . '</h1><p><a href="./" style="color:#2383e2">Открыть Блокнот</a></p></div>';
    exit;
}

function body()
{
    static $b = null;
    if ($b !== null) return $b;
    $ct = isset($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : '';
    if (stripos($ct, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        $b = json_decode($raw, true);
        if (!is_array($b)) $b = array();
    } else {
        $b = $_POST;
    }
    return $b;
}

function arg($key, $default = null)
{
    $b = body();
    if (array_key_exists($key, $b)) return $b[$key];
    return isset($_GET[$key]) ? $_GET[$key] : $default;
}

function require_post()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new HttpError(405, 'Нужен POST-запрос');
    // защита от CSRF: обязательный заголовок с токеном сессии (браузер не отправит его с чужого сайта)
    $token = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    if (!hash_equals(csrf_token(), (string) $token)) {
        throw new HttpError(403, 'Сессия устарела. Обновите страницу.', array('csrf' => true));
    }
}

function require_user()
{
    $u = current_user();
    if (!$u) throw new HttpError(401, 'Требуется вход', array('auth' => true));
    return $u;
}

$action = isset($_GET['a']) ? (string) $_GET['a'] : '';

try {
    if (!is_installed()) {
        throw new HttpError(503, 'Блокнот ещё не установлен. Откройте главную страницу.', array('setup' => true));
    }

    switch ($action) {
        case 'health':
            $ok = (int) q_val('SELECT 1') === 1;
            require_once __DIR__ . '/lib/changes.php';
            json_out(array('ok' => $ok, 'version' => TETRAD_VERSION, 'notes' => release_notes(TETRAD_VERSION), 'time' => now_ms()));

        case 'backup.dl':
        case 'mail.confirm':
            // ссылки из письма: вход не нужен, доступ по подписи
            try {
                if ($action === 'backup.dl') backup_signed_download($_GET);
                verify_signed('mail.confirm', $_GET);
                meta_set('mail_confirmed_at', (string) time());
                simple_page('Спасибо! Письма с резервными копиями доходят.', 200);
            } catch (HttpError $e) {
                simple_page($e->getMessage(), $e->status);
            }
        case 'auth.status':
            $u = current_user();
            json_out(array(
                'logged_in' => (bool) $u,
                'user' => $u ? array('id' => (int) $u['id'], 'email' => $u['email'], 'name' => $u['name']) : null,
                'csrf' => csrf_token(),
                'reset_available' => reset_available(),
                'https' => is_https(),
                'version' => TETRAD_VERSION,
            ));

        case 'auth.login':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new HttpError(405, 'Нужен POST-запрос');
            // для входа CSRF-токен берётся из той же сессии (выдаётся в auth.status)
            require_post();
            $u = auth_login(arg('email'), arg('password'));
            if (!empty($u['need_2fa'])) json_out(array('ok' => true, 'need_2fa' => true, 'csrf' => csrf_token()));
            json_out(array('ok' => true, 'csrf' => csrf_token(), 'user' => array('id' => (int) $u['id'], 'email' => $u['email'], 'name' => $u['name'])));

        case 'auth.2fa':
            require_post();
            list($u, $how, $left) = auth_login_2fa(arg('code'), !empty(arg('remember')));
            json_out(array('ok' => true, 'csrf' => csrf_token(), 'used' => $how, 'recovery_left' => $left, 'user' => array('id' => (int) $u['id'], 'email' => $u['email'], 'name' => $u['name'])));

        case 'auth.logout':
            require_post();
            auth_logout();
            json_out(array('ok' => true));

        case 'auth.reset':
            require_post();
            auth_reset_password(arg('email'), arg('password'));
            json_out(array('ok' => true));

        case 'auth.password':
            require_post();
            $u = require_user();
            auth_change_password($u, arg('current'), arg('password'));
            json_out(array('ok' => true, 'csrf' => csrf_token()));

        case 'auth.2fa.status':
            $u = require_user();
            json_out(twofa_status($u['id']));
        case 'auth.2fa.setup':
            require_post();
            $u = require_user();
            json_out(twofa_setup($u['id'], arg('password')));
        case 'auth.2fa.enable':
            require_post();
            $u = require_user();
            $codes = twofa_enable($u['id'], arg('code'));
            json_out(array('ok' => true, 'recovery_codes' => $codes, 'csrf' => csrf_token(), 'status' => twofa_status($u['id'])));
        case 'auth.2fa.disable':
            require_post();
            $u = require_user();
            twofa_disable($u['id'], arg('password'), arg('code'));
            json_out(array('ok' => true, 'status' => twofa_status($u['id'])));
        case 'auth.2fa.codes':
            require_post();
            $u = require_user();
            json_out(array('ok' => true, 'recovery_codes' => twofa_regenerate_codes($u['id'], arg('code')), 'status' => twofa_status($u['id'])));
        case 'auth.2fa.forget':
            require_post();
            $u = require_user();
            trusted_devices_forget($u['id']);
            json_out(array('ok' => true, 'status' => twofa_status($u['id'])));
    }

    $user = require_user();
    $uid = (int) $user['id'];
    // сессия дальше не нужна для записи — снимаем блокировку, чтобы параллельные запросы не ждали друг друга
    $csrfHeader = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
    $sessionCsrf = csrf_token();
    session_write_close();

    $isPost = $_SERVER['REQUEST_METHOD'] === 'POST';
    $postActions = array('page.create', 'page.save', 'page.move', 'page.favorite', 'page.duplicate', 'page.trash', 'page.restore', 'page.purge',
        'trash.empty', 'file.upload', 'file.fetch', 'files.cleanup', 'backup.restore', 'backup.chunk', 'mail.save', 'mail.send', 'ai.save', 'ai.test', 'ai.run', 'ai.delete', 'ai.activate', 'ai.models', 'ai.cert', 'ai.cert.delete');
    if (in_array($action, $postActions, true)) {
        if (!$isPost) throw new HttpError(405, 'Нужен POST-запрос');
        if (!hash_equals($sessionCsrf, (string) $csrfHeader)) throw new HttpError(403, 'Сессия устарела. Обновите страницу.', array('csrf' => true));
    }

    if ($action === 'tree') remember_site_url();
    if ($action === 'tree' || $action === 'poll') mail_backup_maybe_background();

    switch ($action) {
        case 'tree':
            json_out(pages_tree($uid));
        case 'poll':
            json_out(poll_state($uid, arg('page')));
        case 'mail.status':
            json_out(mail_status());
        case 'ai.status':
            json_out(ai_status());
        case 'ai.save':
            $b = body();
            $id = ai_profile_save($b);
            json_out(array_merge(ai_status(), array('saved_id' => $id)));
        case 'ai.delete':
            ai_profile_delete((string) arg('id'));
            json_out(ai_status());
        case 'ai.activate':
            ai_activate((string) arg('id'));
            json_out(ai_status());
        case 'ai.test':
            json_out(ai_test(arg('id') !== null ? (string) arg('id') : null));
        case 'ai.models':
            json_out(array('models' => ai_fetch_models(arg('id') !== null ? (string) arg('id') : null)));
        case 'ai.cert':
            if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) throw new HttpError(422, 'Файл сертификата не получен');
            ai_cert_save($_FILES['file']['tmp_name']);
            json_out(ai_status());
        case 'ai.cert.delete':
            ai_cert_delete();
            json_out(ai_status());
        case 'ai.run':
            $b = body();
            json_out(ai_run(isset($b['instruction']) ? $b['instruction'] : '', isset($b['text']) ? $b['text'] : '', isset($b['title']) ? (string) $b['title'] : '', isset($b['context']) ? (string) $b['context'] : ''));
        case 'mail.diagnose':
            json_out(mail_diagnose());
        case 'mail.save':
            $b = body();
            if (array_key_exists('smtp_pass', $b) && $b['smtp_pass'] === '') $b['smtp_pass'] = null;
            if (!empty($b['smtp_clear'])) $b = array_merge($b, array('smtp_host' => '', 'smtp_user' => '', 'smtp_pass' => ''));
            mail_settings_save($b);
            json_out(mail_status());
        case 'mail.send':
            remember_site_url();
            $res = mail_backup_run('manual');
            if (!$res['ok']) throw new HttpError(502, $res['error'], array('status' => $res['status']));
            json_out($res['status']);
        case 'page.get':
            json_out(page_open($uid, arg('id')));
        case 'page.create':
            json_out(page_create($uid, body()));
        case 'page.save':
            json_out(page_save($uid, body()));
        case 'page.move':
            json_out(page_move($uid, body()));
        case 'page.favorite':
            json_out(page_favorite($uid, arg('id'), (bool) arg('on', true)));
        case 'page.duplicate':
            json_out(page_duplicate($uid, arg('id')));
        case 'page.trash':
            json_out(page_trash($uid, arg('id')));
        case 'page.restore':
            json_out(page_restore($uid, arg('id')));
        case 'page.purge':
            json_out(page_purge($uid, arg('id')));
        case 'page.revisions':
            json_out(page_revisions($uid, arg('id')));
        case 'revision.get':
            json_out(revision_get($uid, arg('id')));
        case 'trash':
            json_out(trash_list($uid));
        case 'trash.empty':
            json_out(trash_empty($uid));
        case 'search':
            json_out(pages_search($uid, arg('q')));
        case 'recent':
            json_out(pages_recent($uid));
        case 'file.upload':
            json_out(file_upload($uid));
        case 'file.fetch':
            json_out(file_fetch_url($uid, arg('url'), arg('page_id')));
        case 'file':
            file_serve($uid, arg('id'));
        case 'files.cleanup':
            json_out(files_cleanup($uid));
        case 'stats':
            json_out(storage_stats($uid));
        case 'export.md':
            export_markdown_zip($uid, arg('id') ? (int) arg('id') : null, arg('children', '1') !== '0');
        case 'backup':
            backup_download();
        case 'backup.chunk':
            // большой архив (или его части из писем) загружается кусками — в обход лимита размера загрузки на хостинге
            json_out(backup_upload_chunk((string) arg('upload'), (int) arg('offset'), isset($_FILES['chunk']) ? $_FILES['chunk'] : null));
        case 'backup.restore':
            if (arg('upload') !== null && arg('upload') !== '') {
                $path = backup_upload_path((string) arg('upload'));
                if (!is_file($path)) throw new HttpError(422, 'Загруженный архив не найден — попробуйте ещё раз');
                try {
                    json_out(backup_restore_from($path));
                } finally {
                    @unlink($path);
                }
            }
            if (empty($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
                throw new HttpError(422, 'Архив не получен. Если он больше лимита хостинга (' . round(upload_limit_bytes() / 1048576) . ' МБ), восстановите данные по FTP — см. README.');
            }
            json_out(backup_restore_from($_FILES['file']['tmp_name']));
        default:
            throw new HttpError(404, 'Неизвестное действие');
    }
} catch (HttpError $e) {
    json_out(array_merge(array('error' => $e->getMessage()), $e->extra), $e->status);
} catch (Throwable $e) {
    error_log('[tetrad] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    json_out(array('error' => 'Внутренняя ошибка сервера. Подробности — в журнале ошибок хостинга.'), 500);
}
