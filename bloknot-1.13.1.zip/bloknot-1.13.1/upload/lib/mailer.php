<?php
/**
 * Резервная копия на почту.
 *
 * Работает без настройки: письмо отправляет сам хостинг (функция mail()), получатель — почта,
 * с которой вы входите в Блокнот. Если письма не доходят, можно указать SMTP своего ящика
 * (необязательно, в настройках).
 *
 * Расписание: при обычном использовании Блокнота (фоном, раз в N дней и только если были изменения),
 * а также командой cron: php cron.php mail-backup
 */

require_once __DIR__ . '/export.php';

if (!defined('MAIL_ATTACH_LIMIT')) define('MAIL_ATTACH_LIMIT', 15 * 1024 * 1024); // вложение в одном письме (≈20 МБ после кодирования — проходит в Gmail, Яндекс, Mail.ru)
if (!defined('MAIL_MAX_PARTS')) define('MAIL_MAX_PARTS', 12);                       // больше частей — только ссылка и текст страниц
define('MAIL_LINK_TTL', 8 * 86400);            // ссылка на полную копию действует 8 дней

function mail_settings()
{
    $m = config('mail', array());
    if (!is_array($m)) $m = array();
    return array_merge(array(
        'enabled' => true,
        'interval_days' => 7,
        'smtp_host' => '',
        'smtp_port' => 465,
        'smtp_secure' => 'ssl', // ssl | tls | none
        'smtp_user' => '',
        'smtp_pass' => '',
    ), $m);
}

function mail_settings_save($patch)
{
    $cfg = config();
    $m = mail_settings();
    foreach (array('enabled', 'interval_days', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_user', 'smtp_pass') as $k) {
        if (!array_key_exists($k, $patch)) continue;
        $v = $patch[$k];
        switch ($k) {
            case 'enabled': $v = (bool) $v; break;
            case 'interval_days': $v = in_array((int) $v, array(1, 7, 14, 30), true) ? (int) $v : 7; break;
            case 'smtp_port': $v = max(1, min(65535, (int) $v)); break;
            case 'smtp_secure': $v = in_array($v, array('ssl', 'tls', 'none'), true) ? $v : 'ssl'; break;
            case 'smtp_host': $v = preg_replace('/[^a-zA-Z0-9.-]/', '', (string) $v); break;
            case 'smtp_pass':
                if ($v === null) continue 2; // пустое поле в интерфейсе = оставить прежний пароль
                $v = (string) $v;
                break;
            default: $v = trim((string) $v);
        }
        $m[$k] = $v;
    }
    $cfg['mail'] = $m;
    write_php_config(config_path(), $cfg);
    $GLOBALS['__tetrad_cfg_reload'] = true;
    return $m;
}

function mail_recipient()
{
    $u = q_one('SELECT id, email, name FROM users ORDER BY is_admin DESC, id LIMIT 1');
    return $u ?: null;
}

// ---------- адрес сайта (нужен для ссылок в письме и адреса отправителя) ----------
function remember_site_url()
{
    if (PHP_SAPI === 'cli') return;
    $host = request_host();
    if (!$host) return;
    $url = (is_https() ? 'https://' : 'http://') . (isset($_SERVER['HTTP_HOST']) ? strtolower($_SERVER['HTTP_HOST']) : $host) . base_path();
    $url = preg_replace('#/api\.php/?$#', '/', $url);
    if (meta_get('site_url') !== $url) {
        // не понижаем https до http
        $old = (string) meta_get('site_url', '');
        if (str_starts_with($old, 'https://') && str_starts_with($url, 'http://')) return;
        meta_set('site_url', $url);
    }
}

function site_url()
{
    return (string) meta_get('site_url', '');
}

function site_host()
{
    $u = site_url();
    $h = $u ? parse_url($u, PHP_URL_HOST) : null;
    return $h ?: (request_host() ?: 'localhost');
}

// ---------- подписанные ссылки ----------
function sign_token($payload)
{
    return substr(hash_hmac('sha256', $payload, (string) config('secret')), 0, 40);
}

function signed_link($action, $params, $ttl)
{
    $params['e'] = time() + $ttl;
    ksort($params);
    $payload = $action . '|' . http_build_query($params);
    $params['s'] = sign_token($payload);
    return rtrim(site_url(), '/') . '/api.php?a=' . $action . '&' . http_build_query($params);
}

function verify_signed($action, $params)
{
    $sig = isset($params['s']) ? (string) $params['s'] : '';
    unset($params['s'], $params['a']);
    if (empty($params['e']) || (int) $params['e'] < time()) throw new HttpError(410, 'Ссылка устарела');
    ksort($params);
    $payload = $action . '|' . http_build_query($params);
    if (!hash_equals(sign_token($payload), $sig)) throw new HttpError(403, 'Неверная ссылка');
}

// ---------- письмо ----------
function mime_header($s)
{
    return preg_match('/[^\x20-\x7E]/', $s) ? '=?UTF-8?B?' . base64_encode($s) . '?=' : $s;
}

/**
 * Собирает MIME-сообщение. Возвращает [заголовки (массив строк), тело].
 * $attachments: [['name' => ..., 'path' => ..., 'type' => ...]]
 */
function build_mime($from, $fromName, $to, $subject, $text, $html, $attachments)
{
    $b1 = 'b1_' . random_token(12);
    $b2 = 'b2_' . random_token(12);
    $headers = array(
        'From: ' . mime_header($fromName) . ' <' . $from . '>',
        'Reply-To: ' . $to,
        'MIME-Version: 1.0',
        'Date: ' . date('r'),
        'Message-ID: <' . random_token(16) . '@' . site_host() . '>',
        'X-Mailer: Bloknot/' . TETRAD_VERSION,
        'Auto-Submitted: auto-generated',
        'Content-Type: multipart/mixed; boundary="' . $b1 . '"',
    );
    $eol = "\r\n";
    $body = '--' . $b1 . $eol
        . 'Content-Type: multipart/alternative; boundary="' . $b2 . '"' . $eol . $eol
        . '--' . $b2 . $eol
        . 'Content-Type: text/plain; charset=UTF-8' . $eol
        . 'Content-Transfer-Encoding: base64' . $eol . $eol
        . chunk_split(base64_encode($text), 76, $eol)
        . '--' . $b2 . $eol
        . 'Content-Type: text/html; charset=UTF-8' . $eol
        . 'Content-Transfer-Encoding: base64' . $eol . $eol
        . chunk_split(base64_encode($html), 76, $eol)
        . '--' . $b2 . '--' . $eol;
    foreach ($attachments as $a) {
        $name = $a['name'];
        $body .= '--' . $b1 . $eol
            . 'Content-Type: ' . $a['type'] . '; name="' . mime_header($name) . '"' . $eol
            . 'Content-Transfer-Encoding: base64' . $eol
            . 'Content-Disposition: attachment; filename="' . mime_header($name) . '"; filename*=UTF-8\'\'' . rawurlencode($name) . $eol . $eol
            . chunk_split(base64_encode(file_get_contents($a['path'])), 76, $eol);
    }
    $body .= '--' . $b1 . '--' . $eol;
    return array($headers, $body);
}

function mail_from_address()
{
    $m = mail_settings();
    if ($m['smtp_host'] && $m['smtp_user'] && filter_var($m['smtp_user'], FILTER_VALIDATE_EMAIL)) return $m['smtp_user'];
    $host = preg_replace('/^www\./', '', site_host());
    return 'noreply@' . $host;
}

/** Отправляет письмо через SMTP (если настроен) или через mail() хостинга. Бросает исключение при ошибке. */
function send_mail($to, $subject, $text, $html, $attachments = array())
{
    $m = mail_settings();
    $from = mail_from_address();
    list($headers, $body) = build_mime($from, '📒 Блокнот', $to, $subject, $text, $html, $attachments);
    if ($m['smtp_host'] !== '') {
        smtp_send($m, $from, $to, mime_header($subject), $headers, $body);
        return 'smtp';
    }
    if (!function_exists('mail')) throw new RuntimeException('На хостинге отключена отправка почты (функция mail). Укажите SMTP своего ящика в настройках.');
    $eol = "\r\n";
    $ok = @mail($to, mime_header($subject), $body, implode($eol, $headers), '-f' . $from);
    if (!$ok) {
        // некоторые хостинги не разрешают указывать отправителя — пробуем с адресом по умолчанию
        $headers2 = array_values(array_filter($headers, function ($h) { return stripos($h, 'From:') !== 0; }));
        $ok = @mail($to, mime_header($subject), $body, implode($eol, $headers2));
    }
    if (!$ok) throw new RuntimeException('Хостинг не принял письмо к отправке (функция mail вернула ошибку). Нажмите «Проверить отправку» в разделе «Если письма не доходят».');
    return 'mail';
}

// ---------- минимальный SMTP-клиент (SSL/STARTTLS, AUTH LOGIN) ----------
/** Сетевая ошибка: порт закрыт, сервер молчит, не удалось шифрование — можно попробовать другой порт. */
class SmtpNetworkError extends RuntimeException
{
}

/** Порты, которые пробуются по очереди, если настроенный недоступен (многие хостинги закрывают часть портов). */
function smtp_candidates($port, $secure)
{
    $list = array(array((int) $port, $secure));
    $alts = $secure === 'none' ? array(array(587, 'none'), array(2525, 'none'), array(25, 'none'))
        : array(array(465, 'ssl'), array(587, 'tls'), array(2525, 'tls'));
    foreach ($alts as $a) {
        $dup = false;
        foreach ($list as $l) if ($l[0] === $a[0]) $dup = true;
        if (!$dup) $list[] = $a;
    }
    return $list;
}

function smtp_send($m, $from, $to, $subjectEncoded, $headers, $body)
{
    $tried = array();
    foreach (smtp_candidates($m['smtp_port'], $m['smtp_secure']) as $c) {
        list($port, $secure) = $c;
        try {
            smtp_attempt($m['smtp_host'], $port, $secure, $m['smtp_user'], $m['smtp_pass'], $from, $to, $subjectEncoded, $headers, $body);
            // запоминаем рабочий порт
            if ($port !== (int) $m['smtp_port'] || $secure !== $m['smtp_secure']) {
                mail_settings_save(array('smtp_port' => $port, 'smtp_secure' => $secure));
            }
            return;
        } catch (SmtpNetworkError $e) {
            $tried[] = $port . ': ' . $e->getMessage();
        }
    }
    throw new RuntimeException('Хостинг не пропускает подключения к почтовому серверу ' . $m['smtp_host']
        . ' — проверены порты ' . implode(', ', array_map(function ($c) { return $c[0]; }, smtp_candidates($m['smtp_port'], $m['smtp_secure'])))
        . '. Так бывает, когда хостинг разрешает отправку только через свой почтовый сервер. Нажмите «Проверить отправку» — Блокнот подскажет, что подойдёт на вашем хостинге. (' . implode('; ', $tried) . ')');
}

function smtp_attempt($host, $port, $secure, $user, $pass, $from, $to, $subjectEncoded, $headers, $body)
{
    $remote = ($secure === 'ssl' ? 'ssl://' : 'tcp://') . $host . ':' . $port;
    $ctx = stream_context_create(array('ssl' => array('verify_peer' => true, 'verify_peer_name' => true, 'SNI_enabled' => true, 'peer_name' => $host)));
    $fp = @stream_socket_client($remote, $errno, $errstr, 6, STREAM_CLIENT_CONNECT, $ctx);
    if (!$fp) {
        $why = $errstr ?: 'ошибка ' . $errno;
        if (stripos($why, 'timed out') !== false || $errno === 110) $why = 'порт закрыт (нет соединения)';
        elseif (stripos($why, 'refused') !== false || $errno === 111) $why = 'соединение отклонено';
        elseif (stripos($why, 'ssl') !== false || stripos($why, 'certificate') !== false) $why = 'не удалось установить защищённое соединение';
        throw new SmtpNetworkError($why);
    }
    stream_set_timeout($fp, 9);
    $read = function () use ($fp) {
        $data = '';
        while (($line = fgets($fp, 2048)) !== false) {
            $data .= $line;
            if (strlen($line) < 4 || $line[3] === ' ') break;
        }
        return $data;
    };
    $cmd = function ($line, $expect) use ($fp, $read, $host) {
        if ($line !== null) fwrite($fp, $line . "\r\n");
        $resp = $read();
        $code = (int) substr($resp, 0, 3);
        if (!in_array($code, (array) $expect, true)) {
            $safe = preg_replace('/^AUTH.*|^[A-Za-z0-9+\/=]{8,}$/', '***', (string) $line);
            throw new RuntimeException('SMTP ' . $host . ': ' . trim($resp ?: 'нет ответа') . ($safe ? ' (на команду ' . $safe . ')' : ''));
        }
        return $resp;
    };
    try {
        // приветствие сервера: если его нет, соединение перехвачено или заблокировано хостингом
        $greet = $read();
        if ((int) substr($greet, 0, 3) !== 220) {
            throw new SmtpNetworkError($greet ? 'неожиданный ответ: ' . trim($greet) : 'сервер не ответил (соединение перехвачено хостингом)');
        }
        $ehloName = preg_replace('/[^a-z0-9.-]/i', '', site_host()) ?: 'localhost';
        $ehlo = $cmd('EHLO ' . $ehloName, 250);
        if ($secure === 'tls') {
            if (stripos($ehlo, 'STARTTLS') === false) throw new SmtpNetworkError('сервер не поддерживает шифрование STARTTLS на этом порту');
            $cmd('STARTTLS', 220);
            if (!@stream_socket_enable_crypto($fp, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new SmtpNetworkError('не удалось включить шифрование STARTTLS');
            $cmd('EHLO ' . $ehloName, 250);
        }
        if ($user !== '') {
            $cmd('AUTH LOGIN', 334);
            $cmd(base64_encode($user), 334);
            try {
                $cmd(base64_encode($pass), 235);
            } catch (RuntimeException $e) {
                throw new RuntimeException('Почтовый сервер не принял логин или пароль. Для Gmail и Яндекса нужен «пароль приложения» (создаётся при включённой двухэтапной проверке), а не обычный пароль от почты.');
            }
        }
        $cmd('MAIL FROM:<' . $from . '>', 250);
        $cmd('RCPT TO:<' . $to . '>', array(250, 251));
        $cmd('DATA', 354);
        $msg = 'To: <' . $to . ">\r\nSubject: " . $subjectEncoded . "\r\n" . implode("\r\n", $headers) . "\r\n\r\n" . $body;
        $msg = preg_replace('/^\./m', '..', str_replace(array("\r\n", "\n"), array("\n", "\r\n"), $msg));
        fwrite($fp, $msg . "\r\n.\r\n");
        $cmd(null, 250);
        @fwrite($fp, "QUIT\r\n");
    } finally {
        fclose($fp);
    }
}

// ---------- диагностика: какие пути отправки доступны на этом хостинге ----------
function detect_hosting()
{
    $names = strtolower(implode(' ', array_filter(array(
        function_exists('gethostname') ? @gethostname() : '', php_uname('n'),
        isset($_SERVER['SERVER_ADDR']) ? @gethostbyaddr($_SERVER['SERVER_ADDR']) : '',
        isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : '',
    ))));
    $known = array(
        // проверенные параметры: SMTP хостинга, логин — ящик на вашем домене, созданный в панели хостинга
        'timeweb' => array('Timeweb', 'smtp.timeweb.ru', 465, 'ssl'),
        'tw1.' => array('Timeweb', 'smtp.timeweb.ru', 465, 'ssl'),
        'hosting.reg.ru' => array('REG.RU', 'mail.hosting.reg.ru', 465, 'ssl'),
        'reg.ru' => array('REG.RU', 'mail.hosting.reg.ru', 465, 'ssl'),
        'beget' => array('Beget', null, null, null),
        'sprinthost' => array('Sprinthost', null, null, null),
        'spaceweb' => array('SpaceWeb', null, null, null),
        'sweb' => array('SpaceWeb', null, null, null),
        'hostinger' => array('Hostinger', null, null, null),
        'jino' => array('Джино', null, null, null),
    );
    foreach ($known as $k => $v) {
        if (strpos($names, $k) !== false) return array('name' => $v[0], 'smtp_host' => $v[1], 'smtp_port' => $v[2], 'smtp_secure' => $v[3]);
    }
    return null;
}

/** Проверяет подключения к SMTP-серверам параллельно. Возвращает [host:port => ['state' => ok|blocked|silent|tls_failed, 'ms' => ...]] */
function probe_smtp_targets($targets)
{
    $out = array();
    $socks = array();
    $start = microtime(true);
    foreach ($targets as $t) {
        list($host, $port) = $t;
        $key = "$host:$port";
        $ip = filter_var($host, FILTER_VALIDATE_IP) ? $host : @gethostbyname($host);
        if (!$ip || $ip === $host && !filter_var($host, FILTER_VALIDATE_IP)) {
            $out[$key] = array('state' => 'dns', 'ms' => 0);
            continue;
        }
        $s = @stream_socket_client("tcp://$ip:$port", $errno, $errstr, 6, STREAM_CLIENT_CONNECT | STREAM_CLIENT_ASYNC_CONNECT);
        if (!$s) {
            $out[$key] = array('state' => 'blocked', 'ms' => 0);
            continue;
        }
        $socks[$key] = array($s, $host, $port);
    }
    // ждём установления соединений (до 6 секунд на все сразу)
    $pending = $socks;
    while ($pending && microtime(true) - $start < 6) {
        $w = array();
        foreach ($pending as $k => $p) $w[$k] = $p[0];
        $r = null;
        $e = null;
        $n = @stream_select($r, $w, $e, 0, 300000);
        if ($n === false) break;
        foreach ($w as $k => $sock) {
            $name = @stream_socket_get_name($sock, true);
            $out[$k] = array('state' => $name ? 'connected' : 'blocked', 'ms' => (int) round((microtime(true) - $start) * 1000));
            unset($pending[$k]);
        }
    }
    foreach ($pending as $k => $p) {
        $out[$k] = array('state' => 'blocked', 'ms' => 6000);
        @fclose($p[0]);
    }
    // для открытых портов проверяем, что отвечает настоящий почтовый сервер
    foreach ($socks as $k => $p) {
        if ($out[$k]['state'] !== 'connected') {
            @fclose($p[0]);
            continue;
        }
        list($sock, $host, $port) = $p;
        stream_set_blocking($sock, true);
        stream_set_timeout($sock, 6);
        if ((int) $port === 465) {
            stream_context_set_option($sock, 'ssl', 'peer_name', $host);
            stream_context_set_option($sock, 'ssl', 'verify_peer', true);
            if (!@stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
                $out[$k]['state'] = 'tls_failed';
                @fclose($sock);
                continue;
            }
        }
        $line = @fgets($sock, 512);
        $out[$k]['state'] = $line && (int) substr($line, 0, 3) === 220 ? 'ok' : 'silent';
        $out[$k]['greeting'] = $line ? trim(substr($line, 0, 120)) : '';
        @fclose($sock);
    }
    return $out;
}

function spf_status($domain)
{
    if (!function_exists('dns_get_record')) return null;
    $parts = explode('.', $domain);
    $checked = array();
    // проверяем сам домен и родительский (notes.example.com → example.com)
    while (count($parts) >= 2) {
        $d = implode('.', $parts);
        $recs = @dns_get_record($d, DNS_TXT);
        $spf = null;
        if (is_array($recs)) foreach ($recs as $r) {
            $txt = isset($r['txt']) ? $r['txt'] : (isset($r['entries']) ? implode('', $r['entries']) : '');
            if (stripos($txt, 'v=spf1') === 0) $spf = $txt;
        }
        $checked[] = array('domain' => $d, 'spf' => $spf);
        if ($spf) break;
        array_shift($parts);
        if (count($parts) < 2) break;
    }
    return $checked;
}

function mail_diagnose()
{
    @set_time_limit(60);
    $m = mail_settings();
    $hosting = detect_hosting();
    $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));
    $mailFn = function_exists('mail') && !in_array('mail', $disabled, true);
    $targets = array(array('smtp.gmail.com', 465), array('smtp.gmail.com', 587), array('smtp.yandex.ru', 465), array('smtp.mail.ru', 465));
    if ($m['smtp_host'] !== '') array_unshift($targets, array($m['smtp_host'], (int) $m['smtp_port']));
    if ($hosting && $hosting['smtp_host']) $targets[] = array($hosting['smtp_host'], (int) $hosting['smtp_port']);
    $uniq = array();
    foreach ($targets as $t) $uniq[$t[0] . ':' . $t[1]] = $t;
    $probe = probe_smtp_targets(array_values($uniq));
    $from = mail_from_address();
    $fromDomain = substr(strrchr($from, '@'), 1);
    $spf = spf_status($fromDomain);
    $spfOk = false;
    if ($spf) foreach ($spf as $x) if ($x['spf']) $spfOk = true;
    $external = false;
    foreach ($probe as $k => $v) if ($v['state'] === 'ok' && strpos($k, 'gmail') !== false) $external = true;

    // рекомендация
    if ($external) {
        $advice = 'Хостинг пропускает подключения к Gmail. Включите отправку через свою почту: кнопка Gmail, ваш адрес и пароль приложения.';
        $verdict = 'smtp_external';
    } elseif ($hosting && $hosting['smtp_host'] && isset($probe[$hosting['smtp_host'] . ':' . $hosting['smtp_port']]) && $probe[$hosting['smtp_host'] . ':' . $hosting['smtp_port']]['state'] === 'ok') {
        $advice = 'Хостинг ' . $hosting['name'] . ' закрывает подключения к чужим почтовым серверам, но пропускает свой: ' . $hosting['smtp_host'] . '. Создайте в панели хостинга почтовый ящик на вашем домене (например, backup@ваш-домен) и укажите его здесь — кнопка «' . $hosting['name'] . '».';
        $verdict = 'smtp_hosting';
    } else {
        $advice = 'Хостинг закрывает подключения к внешним почтовым серверам. Остаётся отправка через почту самого хостинга: создайте в панели хостинга почтовый ящик на вашем домене и укажите в поле «SMTP-сервер» адрес почтового сервера хостинга (он есть в панели, в разделе «Почта» → «Настройка почтовых программ»). Логин — адрес этого ящика, пароль — его пароль.';
        $verdict = 'smtp_hosting_manual';
    }
    return array(
        'hosting' => $hosting,
        'mail_function' => $mailFn,
        'last_error' => meta_get('mail_last_error', '') ?: null,
        'from' => $from,
        'spf' => $spf,
        'spf_ok' => $spfOk,
        'probe' => $probe,
        'verdict' => $verdict,
        'advice' => $advice,
    );
}

// ---------- статус ----------
function mail_status()
{
    $m = mail_settings();
    $u = mail_recipient();
    return array(
        'enabled' => (bool) $m['enabled'],
        'interval_days' => (int) $m['interval_days'],
        'recipient' => $u ? $u['email'] : null,
        'transport' => $m['smtp_host'] !== '' ? 'smtp' : 'hosting',
        'smtp_host' => $m['smtp_host'],
        'smtp_port' => (int) $m['smtp_port'],
        'smtp_secure' => $m['smtp_secure'],
        'smtp_user' => $m['smtp_user'],
        'smtp_pass_set' => $m['smtp_pass'] !== '',
        'last_at' => (int) meta_get('mail_last_at', 0) ?: null,
        'last_ok_at' => (int) meta_get('mail_last_ok_at', 0) ?: null,
        'last_error' => meta_get('mail_last_error', '') ?: null,
        'last_info' => meta_get('mail_last_info', '') ?: null,
        'confirmed_at' => (int) meta_get('mail_confirmed_at', 0) ?: null,
        'site_url' => site_url() ?: null,
    );
}

/** Изменились ли данные с момента последней отправленной копии. */
function data_stamp()
{
    $a = (int) q_val('SELECT COALESCE(MAX(updated_at), 0) FROM pages');
    $b = (int) meta_get('tree_stamp', 0);
    $c = (int) q_val('SELECT COALESCE(MAX(created_at), 0) FROM files');
    return max($a, $b, $c);
}

function mail_backup_due()
{
    $m = mail_settings();
    if (!$m['enabled'] || !site_url()) return false;
    $last = (int) meta_get('mail_last_at', 0);
    $lastOk = (int) meta_get('mail_last_ok_at', 0);
    $now = time();
    // после ошибки повторяем не чаще раза в 6 часов
    if ($last > $lastOk && $now - $last < 6 * 3600) return false;
    if (!$lastOk) return true;
    if ($now - $lastOk < (int) $m['interval_days'] * 86400 - 3600) return false;
    return data_stamp() > (int) meta_get('mail_backup_stamp', 0);
}

/**
 * Создаёт резервную копию и отправляет её на почту. Возвращает статус.
 * Не запускается одновременно в двух процессах.
 */
function mail_backup_run($reason = 'schedule')
{
    $lock = fopen(TETRAD_DATA . '/mail.lock', 'c');
    if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) return array('ok' => false, 'error' => 'Отправка уже выполняется');
    @set_time_limit(600);
    @ignore_user_abort(true);
    $tmpMd = null;
    $tmpParts = array();
    try {
        $user = mail_recipient();
        if (!$user) throw new RuntimeException('Нет учётной записи');
        if (!site_url()) throw new RuntimeException('Адрес сайта ещё неизвестен — откройте Блокнот в браузере хотя бы один раз');
        meta_set('mail_last_at', (string) time());
        $stamp = data_stamp();
        $backup = backup_to_file(7);
        $size = filesize($backup);
        $uid = (int) $user['id'];
        $pages = (int) q_val('SELECT COUNT(*) FROM pages WHERE owner_id = ? AND deleted_at IS NULL', array($uid));
        $files = (int) q_val('SELECT COUNT(*) FROM files WHERE owner_id = ?', array($uid));
        $date = date('d.m.Y');
        $link = signed_link('backup.dl', array('f' => basename($backup)), MAIL_LINK_TTL);
        $confirmLink = meta_get('mail_confirmed_at') ? null : signed_link('mail.confirm', array('u' => $uid), 60 * 86400);
        $count = (int) ceil($size / MAIL_ATTACH_LIMIT);
        $via = null;
        if ($count <= 1) {
            $attachedWhat = 'full';
            list($subject, $text, $html) = mail_backup_message($user, $date, $pages, $files, $size, 'full', $link, $confirmLink);
            $via = send_mail($user['email'], $subject, $text, $html, array(array('name' => basename($backup), 'path' => $backup, 'type' => 'application/zip')));
        } elseif ($count <= MAIL_MAX_PARTS) {
            // полная копия частями: bloknot-backup-….zip.001, .002… — 7-Zip открывает их как один архив,
            // а «Восстановить из копии…» принимает все части сразу
            $attachedWhat = 'parts';
            $tmpParts = backup_split($backup, MAIL_ATTACH_LIMIT);
            foreach ($tmpParts as $i => $partPath) {
                list($subject, $text, $html) = mail_backup_message($user, $date, $pages, $files, $size, 'parts', $link, $i === 0 ? $confirmLink : null, $i + 1, $count, basename($backup));
                try {
                    $v = send_mail($user['email'], $subject, $text, $html, array(array('name' => basename($partPath), 'path' => $partPath, 'type' => 'application/octet-stream')));
                } catch (Throwable $e) {
                    throw new RuntimeException('Часть ' . ($i + 1) . ' из ' . $count . ' не отправлена: ' . $e->getMessage());
                }
                $via = $via ?: $v;
            }
        } else {
            $attachments = array();
            $attachedWhat = '';
            $tmpMd = backup_tmp_dir() . '/md-' . random_token(6) . '.zip';
            $fh = fopen($tmpMd, 'wb');
            write_markdown_zip($uid, null, true, $fh, false, true);
            fclose($fh);
            if (filesize($tmpMd) <= MAIL_ATTACH_LIMIT) {
                $attachments[] = array('name' => 'bloknot-text-' . date('Y-m-d') . '.zip', 'path' => $tmpMd, 'type' => 'application/zip');
                $attachedWhat = 'markdown';
            }
            list($subject, $text, $html) = mail_backup_message($user, $date, $pages, $files, $size, $attachedWhat, $link, $confirmLink);
            $via = send_mail($user['email'], $subject, $text, $html, $attachments);
        }
        meta_set('mail_last_ok_at', (string) time());
        meta_set('mail_backup_stamp', (string) $stamp);
        meta_set('mail_last_error', '');
        $info = $attachedWhat === 'full' ? 'полная копия во вложении'
            : ($attachedWhat === 'parts' ? 'полная копия во вложениях, ' . $count . ' ' . plural_ru($count, 'письмо', 'письма', 'писем')
            : ($attachedWhat === 'markdown' ? 'текст страниц во вложении, полная копия по ссылке' : 'полная копия по ссылке'));
        meta_set('mail_last_info', $info . ', ' . round($size / 1048576, 1) . ' МБ, ' . ($via === 'smtp' ? 'через SMTP' : 'через почту хостинга'));
        return array('ok' => true, 'status' => mail_status());
    } catch (Throwable $e) {
        meta_set('mail_last_error', $e->getMessage());
        error_log('[bloknot mail] ' . $e->getMessage());
        return array('ok' => false, 'error' => $e->getMessage(), 'status' => mail_status());
    } finally {
        if ($tmpMd) @unlink($tmpMd);
        foreach ($tmpParts as $tp) @unlink($tp);
        if ($tmpParts) @rmdir(dirname($tmpParts[0]));
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function mail_backup_message($user, $date, $pages, $files, $size, $attachedWhat, $link, $confirmLink, $part = 0, $count = 0, $zipName = '')
{
    $h = function ($s) { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8'); };
    $mb = round($size / 1048576, 1) . ' МБ';
    $subject = 'Блокнот: резервная копия за ' . $date . ($part ? " (часть $part из $count)" : '');
    if ($attachedWhat === 'parts') {
        $what = "Полная резервная копия ($mb) не помещается в одно письмо, поэтому разделена на $count " . plural_ru($count, 'часть', 'части', 'частей')
            . " — по одной в каждом письме. Это письмо $part из $count.";
        $how = "Как восстановить: сохраните все $count " . plural_ru($count, 'вложение', 'вложения', 'вложений') . " ($zipName.001 … ." . sprintf('%03d', $count) . ") в одну папку, "
            . "затем Блокнот → Настройки → Экспорт и бэкапы → «Восстановить из копии…» и выберите все части сразу. "
            . "Открыть на компьютере: 7-Zip или WinRAR — откройте файл .001, части соединятся сами; на Mac или Linux — команда cat $zipName.0* > $zipName.";
    } else {
        $what = $attachedWhat === 'full'
            ? "Полная резервная копия ($mb) — во вложении."
            : ($attachedWhat === 'markdown'
                ? "Полная копия ($mb) слишком велика для писем. Во вложении — текст всех страниц в Markdown, а полную копию можно скачать по ссылке ниже."
                : "Полная копия ($mb) слишком велика для писем — скачайте её по ссылке ниже.");
        $how = 'Как восстановить: Блокнот → Настройки → Экспорт и бэкапы → «Восстановить из копии…».';
    }
    $site = site_url();
    $text = "Здравствуйте" . ($user['name'] ? ', ' . $user['name'] : '') . "!\n\n"
        . "Это автоматическая резервная копия вашего Блокнота ($site).\n"
        . "Страниц: $pages, изображений: $files.\n\n"
        . $what . "\n\n"
        . "Скачать полную копию одним файлом (ссылка действует 8 дней):\n$link\n\n"
        . ($confirmLink ? "Подтвердите, что письма доходят (один раз):\n$confirmLink\n\n" : '')
        . $how . "\n"
        . "Отключить или изменить периодичность: Настройки → Бэкап на почту.\n\n"
        . "Не пересылайте это письмо: архив содержит все ваши записи.\n";
    $btn = 'display:inline-block;padding:9px 16px;border-radius:6px;text-decoration:none;font-weight:600;';
    $html = '<!doctype html><html><body style="margin:0;background:#f7f7f5;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Helvetica,Arial,sans-serif;color:#37352f">'
        . '<div style="max-width:560px;margin:0 auto;padding:28px 20px">'
        . '<div style="font-size:28px;line-height:1">📒</div>'
        . '<h1 style="font-size:20px;margin:10px 0 6px">Резервная копия за ' . $h($date) . '</h1>'
        . '<p style="margin:0 0 16px;color:#787774">Блокнот · <a href="' . $h($site) . '" style="color:#787774">' . $h(preg_replace('#^https?://#', '', rtrim($site, '/'))) . '</a></p>'
        . '<div style="background:#fff;border:1px solid #ededec;border-radius:8px;padding:18px 20px">'
        . '<p style="margin:0 0 10px">Страниц: <b>' . (int) $pages . '</b>, изображений: <b>' . (int) $files . '</b>, размер копии: <b>' . $h($mb) . '</b>.</p>'
        . '<p style="margin:0 0 16px">' . $h($what) . '</p>'
        . '<a href="' . $h($link) . '" style="' . $btn . 'background:#2383e2;color:#fff">Скачать полную копию</a>'
        . '<p style="margin:10px 0 0;font-size:13px;color:#787774">Ссылка действует 8 дней.</p>'
        . ($confirmLink ? '<hr style="border:0;border-top:1px solid #ededec;margin:18px 0"><p style="margin:0 0 10px">Подтвердите один раз, что письма с копиями доходят — тогда Блокнот перестанет напоминать о проверке.</p><a href="' . $h($confirmLink) . '" style="' . $btn . 'background:#f1f1ef;color:#37352f">Письма доходят</a>' : '')
        . '</div>'
        . '<p style="font-size:13px;color:#787774;margin:18px 0 0">' . $h($how) . '<br>Отключить или изменить периодичность: Настройки → Бэкап на почту.<br>Не пересылайте это письмо: архив содержит все ваши записи.</p>'
        . '</div></body></html>';
    return array($subject, $text, $html);
}

/** Запуск по расписанию в фоне после ответа браузеру (если хостинг без cron). */
function mail_backup_maybe_background()
{
    try {
        if (!mail_backup_due()) return;
    } catch (Throwable $e) {
        return;
    }
    register_shutdown_function(function () {
        if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
        elseif (function_exists('litespeed_finish_request')) @litespeed_finish_request();
        mail_backup_run('background');
    });
}

/** Выдаёт файл резервной копии по подписанной ссылке из письма. */
function backup_signed_download($params)
{
    verify_signed('backup.dl', $params);
    $name = basename((string) (isset($params['f']) ? $params['f'] : ''));
    $path = TETRAD_DATA . '/backups/' . $name;
    if (!preg_match('/^bloknot-backup-[0-9-]+\.zip$/', $name) || !is_file($path)) {
        throw new HttpError(404, 'Эта резервная копия уже удалена (хранятся 7 последних). Скачайте свежую в настройках Блокнота.');
    }
    @set_time_limit(0);
    header('Content-Type: application/zip');
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: attachment; filename="' . $name . '"');
    header('Cache-Control: no-store');
    readfile($path);
    exit;
}
