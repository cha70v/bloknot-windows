// Выбор страницы из списка (перемещение, ссылка на страницу)
import { el, pageTitle } from '../util.js';
import { icon } from '../icons.js';
import { modal } from './modal.js';
import { state, ancestors, sortPages } from '../store.js';

function pathLabel(p) {
  const a = ancestors(p.id).map(pageTitle);
  return a.length ? a.join(' / ') : '';
}

/**
 * @returns {Promise<{id:number|null}|null>} null — отмена; {id:null} — корень
 */
export function pickPageDialog({ title, exclude = new Set(), allowRoot = false, confirm = 'Выбрать' }) {
  return new Promise((resolve) => {
    let done = false;
    modal({
      title,
      className: 'picker',
      content: (close) => {
        const input = el('input', { class: 'input', placeholder: 'Найти страницу…', autofocus: true });
        const list = el('div', { class: 'picker-list', role: 'listbox' });
        let items = [];
        let cursor = 0;
        const choose = (id) => {
          done = true;
          resolve({ id });
          close();
        };
        const render = () => {
          const q = input.value.trim().toLowerCase();
          const all = sortPages(Array.from(state.pages.values()).filter((p) => !exclude.has(p.id)));
          items = all.filter((p) => !q || pageTitle(p).toLowerCase().includes(q)).slice(0, 80);
          if (allowRoot && !q) items.unshift({ id: null, title: 'Верхний уровень (без родителя)', root: true });
          cursor = Math.min(cursor, Math.max(0, items.length - 1));
          list.textContent = '';
          if (!items.length) list.append(el('div', { class: 'picker-empty' }, 'Страницы не найдены'));
          items.forEach((p, i) => {
            const row = el(
              'button',
              { type: 'button', class: `picker-item${i === cursor ? ' is-active' : ''}`, role: 'option' },
              el('span', { class: 'picker-icon' }, p.root ? icon('home', 16) : p.icon || icon('page', 16)),
              el('span', { class: 'picker-text' }, el('span', { class: 'picker-title' }, p.root ? p.title : pageTitle(p)), !p.root && pathLabel(p) ? el('span', { class: 'picker-path' }, pathLabel(p)) : null),
            );
            row.addEventListener('click', () => choose(p.id));
            list.append(row);
          });
        };
        input.addEventListener('input', () => {
          cursor = 0;
          render();
        });
        input.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            if (!items.length) return;
            cursor = (cursor + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
            render();
            const act = list.querySelector('.is-active');
            if (act) act.scrollIntoView({ block: 'nearest' });
          } else if (e.key === 'Enter') {
            e.preventDefault();
            if (items[cursor]) choose(items[cursor].id);
          }
        });
        render();
        return el('div', null, input, list);
      },
      onClose: () => {
        if (!done) resolve(null);
      },
    });
  });
}
