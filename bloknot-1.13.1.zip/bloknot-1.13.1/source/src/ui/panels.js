// Поиск, корзина, вход в систему, мобильная панель инструментов
import { el, clear, pageTitle, formatDate, debounce, escapeHtml, plural } from '../util.js';
import { icon } from '../icons.js';
import { api, setCsrf } from '../api.js';
import { state, ancestors, loadTree } from '../store.js';
import { modal, toast } from './modal.js';
import { showMenu, viewportBox } from './menu.js';
import { openPage, purgePage } from './actions.js';
import { SLASH_ITEMS } from '../editor/editor.js';
import { TYPE_LABELS, TYPE_ICONS, newBlock, isText } from '../editor/model.js';

// ---------- поиск ----------
export function openSearch() {
  modal({
    title: '',
    className: 'search-modal',
    content: (close) => {
      const input = el('input', { class: 'search-input', placeholder: 'Поиск по названиям и тексту страниц', autofocus: true, 'aria-label': 'Поиск', type: 'search', enterkeyhint: 'search' });
      const list = el('div', { class: 'search-results', role: 'listbox' });
      let items = [];
      let cursor = 0;
      const go = (id) => {
        close();
        openPage(id);
      };
      const render = (q) => {
        clear(list);
        if (!items.length) {
          list.append(el('div', { class: 'search-empty' }, q ? `Ничего не найдено по запросу «${q}»` : 'Начните вводить — поиск идёт по названиям и тексту'));
          return;
        }
        if (!q) list.append(el('div', { class: 'search-group' }, 'Недавние'));
        items.forEach((r, i) => {
          const path = ancestors(r.id).map(pageTitle).join(' / ');
          const snippet = r.snippet ? el('span', { class: 'sr-snippet', html: highlight(r.snippet, q) }) : null;
          const row = el(
            'button',
            { type: 'button', class: `sr-item${i === cursor ? ' is-active' : ''}`, role: 'option' },
            el('span', { class: 'sr-icon' }, r.icon || icon('page', 17)),
            el('span', { class: 'sr-text' }, el('span', { class: 'sr-title', html: highlight(pageTitle(r), q) }), path ? el('span', { class: 'sr-path' }, path) : null, snippet),
            el('span', { class: 'sr-date' }, formatDate(r.updated_at, false)),
          );
          row.addEventListener('click', () => go(r.id));
          row.addEventListener('pointermove', () => {
            if (cursor !== i) {
              cursor = i;
              list.querySelectorAll('.sr-item').forEach((n, j) => n.classList.toggle('is-active', j === i));
            }
          });
          list.append(row);
        });
      };
      let seq = 0;
      const search = debounce(async () => {
        const q = input.value.trim();
        const my = ++seq;
        cursor = 0;
        if (!q) {
          try {
            const list = (await api('recent')).filter((p) => state.pages.has(p.id));
            if (my !== seq) return;
            items = list;
          } catch (e) {
            items = [];
          }
          if (my === seq) render('');
          return;
        }
        let found;
        try {
          found = await api('search', undefined, { query: { q } });
        } catch (e) {
          // без связи ищем по названиям локально
          const ql = q.toLowerCase();
          found = Array.from(state.pages.values()).filter((p) => pageTitle(p).toLowerCase().includes(ql));
        }
        if (my !== seq) return;
        items = found;
        render(q);
      }, 160);
      input.addEventListener('input', search);
      input.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          if (!items.length) return;
          cursor = (cursor + (e.key === 'ArrowDown' ? 1 : -1) + items.length) % items.length;
          list.querySelectorAll('.sr-item').forEach((n, j) => n.classList.toggle('is-active', j === cursor));
          const a = list.querySelector('.sr-item.is-active');
          if (a) a.scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter') {
          e.preventDefault();
          if (items[cursor]) go(items[cursor].id);
        }
      });
      search();
      return el('div', null, el('div', { class: 'search-bar' }, icon('search', 18), input), list);
    },
  });
}

function highlight(text, q) {
  const safe = escapeHtml(text);
  if (!q) return safe;
  const re = new RegExp(escapeHtml(q).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  return safe.replace(re, (m) => `<mark>${m}</mark>`);
}

// ---------- корзина ----------
export function openTrash() {
  modal({
    title: 'Корзина',
    className: 'trash-modal',
    content: () => {
      const list = el('div', { class: 'trash-list' }, el('div', { class: 'muted pad' }, 'Загрузка…'));
      const emptyBtn = el('button', { type: 'button', class: 'btn btn-danger btn-small' }, 'Очистить корзину');
      const load = async () => {
        let items;
        try {
          items = await api('trash');
        } catch (e) {
          clear(list);
          list.append(el('div', { class: 'muted pad' }, e.message));
          return;
        }
        clear(list);
        emptyBtn.style.display = items.length ? '' : 'none';
        if (!items.length) {
          list.append(el('div', { class: 'empty-state small' }, el('p', null, 'Корзина пуста. Удалённые страницы попадают сюда, их можно восстановить.')));
          return;
        }
        for (const p of items) {
          const restore = el('button', { type: 'button', class: 'btn btn-small' }, icon('restore', 15), 'Восстановить');
          const del = el('button', { type: 'button', class: 'icon-btn', title: 'Удалить навсегда', 'aria-label': 'Удалить навсегда' }, icon('trash', 17));
          restore.addEventListener('click', async () => {
            try {
              await api('page.restore', { id: p.id });
              await loadTree();
              toast(`«${pageTitle(p)}» восстановлена`, 'info', { action: { label: 'Открыть', onClick: () => openPage(p.id) } });
              load();
            } catch (e) {
              toast(e.message, 'error');
            }
          });
          del.addEventListener('click', async () => {
            try {
              if (await purgePage(p.id, pageTitle(p))) load();
            } catch (e) {
              toast(e.message, 'error');
            }
          });
          list.append(
            el(
              'div',
              { class: 'trash-item' },
              el('span', { class: 'trash-icon' }, p.icon || icon('page', 17)),
              el('span', { class: 'trash-text' }, el('span', { class: 'trash-title' }, pageTitle(p)), el('span', { class: 'trash-meta' }, `удалена ${formatDate(p.deleted_at)}${p.children_count ? ` · вложенных: ${p.children_count}` : ''}`)),
              restore,
              del,
            ),
          );
        }
      };
      emptyBtn.addEventListener('click', async () => {
        const { confirmDialog } = await import('./modal.js');
        const ok = await confirmDialog({ title: 'Очистить корзину?', text: 'Все страницы из корзины будут удалены навсегда вместе с их изображениями.', confirm: 'Удалить всё', danger: true });
        if (!ok) return;
        try {
          const res = await api('trash.empty', {});
          toast(`Удалено ${res.deleted} ${plural(res.deleted, 'страница', 'страницы', 'страниц')}`);
          load();
        } catch (e) {
          toast(e.message, 'error');
        }
      });
      load();
      return el('div', null, el('div', { class: 'trash-head' }, el('p', { class: 'muted' }, 'Страницы хранятся в корзине, пока вы не удалите их навсегда.'), emptyBtn), list);
    },
  });
}

// ---------- вход ----------
export function renderLogin(root, status, onDone) {
  clear(root);
  const email = el('input', { class: 'input', type: 'email', autocomplete: 'username', required: true, autofocus: true, id: 'login-email' });
  const pwd = el('input', { class: 'input', type: 'password', autocomplete: 'current-password', required: true, id: 'login-password' });
  const err = el('div', { class: 'form-error', role: 'alert' });
  const submit = el('button', { type: 'submit', class: 'btn btn-primary btn-block' }, 'Войти');
  const form = el(
    'form',
    { class: 'login-form' },
    el('label', { class: 'field-label', for: 'login-email' }, 'Почта'),
    email,
    el('label', { class: 'field-label', for: 'login-password' }, 'Пароль'),
    pwd,
    err,
    submit,
  );
  const forgot = el('button', { type: 'button', class: 'link-btn' }, 'Забыли пароль?');
  const box = el('div', { class: 'login' }, el('div', { class: 'login-card' }, el('div', { class: 'login-brand' }, el('span', { class: 'sb-logo' }), el('span', null, 'Блокнот')), form, forgot));
  if (!status.https) box.querySelector('.login-card').append(el('p', { class: 'login-warn' }, 'Соединение не защищено (нет HTTPS). Включите сертификат в панели хостинга.'));
  root.append(box);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    submit.disabled = true;
    try {
      const res = await api('auth.login', { email: email.value, password: pwd.value });
      setCsrf(res.csrf);
      if (res.need_2fa) {
        codeStep();
        return;
      }
      onDone(res.user);
    } catch (ex) {
      err.textContent = ex.status === 0 ? 'Нет связи с сервером' : ex.message;
      pwd.select();
    } finally {
      submit.disabled = false;
    }
  });
  forgot.addEventListener('click', () => resetDialog(status));
  setTimeout(() => email.focus(), 0);

  // второй шаг: код из приложения (двухфакторный вход)
  function codeStep() {
    const card = box.querySelector('.login-card');
    let recovery = false;
    const code = el('input', { class: 'input tfa-code-input', id: 'login-code', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: '123 456', maxlength: '7', required: true });
    const remember = el('input', { type: 'checkbox', id: 'login-remember' });
    const cerr = el('div', { class: 'form-error', role: 'alert' });
    const ok = el('button', { type: 'submit', class: 'btn btn-primary btn-block' }, 'Подтвердить');
    const label = el('label', { class: 'field-label', for: 'login-code' }, 'Код из приложения');
    const hint = el('p', { class: 'login-hint' }, 'Откройте приложение для кодов (Яндекс Ключ, Google Authenticator…) и введите шесть цифр для «Блокнот».');
    const toggle = el('button', { type: 'button', class: 'link-btn' }, 'Нет доступа к телефону? Ввести резервный код');
    toggle.addEventListener('click', () => {
      recovery = !recovery;
      label.textContent = recovery ? 'Резервный код' : 'Код из приложения';
      code.placeholder = recovery ? 'abcd-efgh' : '123 456';
      code.maxLength = recovery ? 12 : 7;
      code.inputMode = recovery ? 'text' : 'numeric';
      hint.textContent = recovery ? 'Один из десяти резервных кодов, сохранённых при включении двухфакторного входа. Каждый код срабатывает один раз.' : 'Откройте приложение для кодов (Яндекс Ключ, Google Authenticator…) и введите шесть цифр для «Блокнот».';
      toggle.textContent = recovery ? 'Ввести код из приложения' : 'Нет доступа к телефону? Ввести резервный код';
      code.value = '';
      code.focus();
    });
    const back = el('button', { type: 'button', class: 'link-btn' }, '← Войти заново');
    back.addEventListener('click', () => renderLogin(root, status, onDone));
    const cform = el('form', { class: 'login-form' }, label, code, hint, el('label', { class: 'check', for: 'login-remember' }, remember, el('span', null, 'Не спрашивать на этом устройстве 30 дней')), cerr, ok);
    cform.addEventListener('submit', async (e) => {
      e.preventDefault();
      cerr.textContent = '';
      ok.disabled = true;
      try {
        const res = await api('auth.2fa', { code: code.value, remember: remember.checked });
        setCsrf(res.csrf);
        if (res.used === 'recovery') toast(`Вход по резервному коду. Осталось кодов: ${res.recovery_left}${res.recovery_left <= 3 ? ' — создайте новые в настройках (Безопасность)' : ''}.`, 'info', { duration: 9000 });
        onDone(res.user);
      } catch (ex) {
        if (ex.data && ex.data.restart) {
          renderLogin(root, status, onDone);
          toast(ex.message, 'error');
          return;
        }
        cerr.textContent = ex.status === 0 ? 'Нет связи с сервером' : ex.message;
        code.select();
      } finally {
        ok.disabled = false;
      }
    });
    // шесть цифр введены — отправляем сами
    code.addEventListener('input', () => {
      if (!recovery && code.value.replace(/\D/g, '').length === 6 && !ok.disabled) cform.requestSubmit();
    });
    form.replaceWith(cform);
    forgot.replaceWith(el('div', { class: 'login-links' }, toggle, back));
    card.querySelector('.login-brand').after(el('div', { class: 'login-step' }, 'Двухфакторный вход'));
    setTimeout(() => code.focus(), 0);
  }
}

function resetDialog(status) {
  modal({
    title: 'Сброс пароля',
    content: (close) => {
      const wrap = el('div');
      wrap.append(
        el('p', { class: 'modal-text' }, 'Чтобы сбросить пароль, подтвердите, что у вас есть доступ к хостингу:'),
        el('ol', { class: 'steps' }, el('li', null, 'Подключитесь к сайту по FTP или через файловый менеджер панели хостинга.'), el('li', { html: 'В папке <code>data</code> создайте пустой файл с именем <code>RESET-PASSWORD</code>.' }), el('li', null, 'Обновите эту страницу и задайте новый пароль здесь же.')),
      );
      if (status.reset_available) {
        const email = el('input', { class: 'input', type: 'email', placeholder: 'Почта (логин)', autocomplete: 'username' });
        const p1 = el('input', { class: 'input', type: 'password', placeholder: 'Новый пароль, не короче 8 символов', autocomplete: 'new-password' });
        const p2 = el('input', { class: 'input', type: 'password', placeholder: 'Новый пароль ещё раз', autocomplete: 'new-password' });
        const err = el('div', { class: 'form-error' });
        const btn = el('button', { type: 'submit', class: 'btn btn-primary' }, 'Сменить пароль');
        const form = el('form', { class: 'stack' }, el('p', { class: 'ok-note' }, 'Файл RESET-PASSWORD найден — можно задать новый пароль.'), email, p1, p2, err, btn);
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          if (p1.value !== p2.value) {
            err.textContent = 'Пароли не совпадают';
            return;
          }
          try {
            await api('auth.reset', { email: email.value, password: p1.value });
            close();
            toast('Пароль изменён. Войдите с новым паролем.');
          } catch (ex) {
            err.textContent = ex.message;
          }
        });
        wrap.append(form);
      }
      return wrap;
    },
  });
}

// ---------- мобильная панель редактора ----------
// Компактная горизонтальная лента над клавиатурой: действия меню строки иконкой с подписью, листается вбок.
const MB_SHORT = {
  'Превратить в': 'Тип',
  'Развернуть вложенные': 'Развернуть',
  'Свернуть вложенные': 'Свернуть',
  'Заменить изображение': 'Заменить',
  'Строка заголовков': 'Заголовки',
};
export function buildMobileBar(getEditor) {
  const bar = el('div', { class: 'mobilebar', role: 'toolbar', 'aria-label': 'Действия со строкой' });
  const strip = el('div', { class: 'mb-strip' });
  const fixed = el('div', { class: 'mb-fixed' });
  bar.append(strip, fixed);
  const btn = (ic, label, fn, opts = {}) => {
    const b = el('button', { type: 'button', class: `mb-btn${opts.danger ? ' is-danger' : ''}${opts.accent ? ' is-accent' : ''}${opts.iconOnly ? ' is-icon' : ''}`, 'aria-label': opts.title || label, title: opts.title || label }, icon(ic, 18), opts.iconOnly ? null : el('span', { class: 'mb-label' }, label));
    b.addEventListener('pointerdown', (e) => e.preventDefault());
    b.addEventListener('click', (e) => {
      e.preventDefault();
      const ed = getEditor();
      if (ed) fn(ed, b);
    });
    return b;
  };
  const cur = (ed) => {
    const id = ed.currentBlockId();
    return id ? ed.block(id) : null;
  };
  const addBtn = () =>
    btn('plus', 'Добавить', (ed, b) => {
      const block = cur(ed);
      showMenu({
        anchor: b,
        sheetTitle: 'Добавить блок',
        items: SLASH_ITEMS.map((it) => ({
          label: it.label,
          icon: TYPE_ICONS[it.type] || (it.type === 'link-page' ? 'link' : it.type === 'ai' ? 'sparkle' : 'image'),
          onSelect: () => {
            if (block && isText(block) && !block.html) ed.runCommand(block, it.type);
            else {
              const nb = ed.insertAfter(block, newBlock('p'), false);
              ed.runCommand(nb, it.type);
            }
          },
        })),
      });
    });
  /** Пересобирает ленту под текущую строку. */
  const refresh = () => {
    const ed = getEditor();
    clear(strip);
    clear(fixed);
    if (!ed) return;
    const id = ed.selected.size ? ed.selectedInOrder()[0].id : ed.currentBlockId();
    const { items } = id ? ed.blockMenuItems(id) : { items: [] };
    let added = false;
    for (const it of items) {
      if (it.separator || it.header) continue;
      if (/^Переместить (вверх|вниз)$/.test(it.label)) continue; // на телефоне строку перетаскивают долгим нажатием
      const isAi = it.icon === 'sparkle';
      const label = isAi ? 'ИИ' : MB_SHORT[it.label] || it.label;
      strip.append(
        btn(it.icon || 'more', label, (e2, b) => {
          if (it.submenu) showMenu({ anchor: b, items: it.submenu, sheetTitle: it.label, className: it.subClass || '' });
          else if (it.onSelect) it.onSelect();
          setTimeout(refresh, 0);
        }, { danger: it.danger, accent: isAi, title: it.label }),
      );
      if (isAi) {
        strip.append(addBtn());
        added = true;
      }
    }
    if (!added) strip.prepend(addBtn());
    strip.append(btn('undo', 'Отменить', (e2) => e2.undo()), btn('redo', 'Повторить', (e2) => e2.redo()));
    fixed.append(
      btn('keyboard', 'Скрыть', (e2) => {
        document.activeElement && document.activeElement.blur();
        e2.clearSelection();
        bar.classList.remove('is-visible');
        document.body.classList.remove('has-mobilebar');
      }, { iconOnly: true, title: 'Скрыть клавиатуру' }),
    );
  };
  let lastId = null;
  document.addEventListener('selectionchange', () => {
    if (!bar.classList.contains('is-visible')) return;
    const ed = getEditor();
    const id = ed ? ed.currentBlockId() : null;
    if (id && id !== lastId) {
      lastId = id;
      refresh();
    }
  });
  // плавающая панель: под строкой с курсором (или над ней, если внизу не хватает места — клавиатура, край экрана)
  bar.classList.add('is-floating');
  const caretRect = (ed) => {
    const sel = window.getSelection();
    const r = sel && sel.rangeCount ? sel.getRangeAt(0) : null;
    if (r && r.collapsed && ed.root.contains(r.startContainer)) {
      const rects = r.getClientRects();
      // строка с курсором (в конце строки браузер даёт два прямоугольника — берём последний)
      if (rects.length && rects[rects.length - 1].height) return rects[rects.length - 1];
    }
    const id = ed.selected.size ? ed.selectedInOrder().slice(-1)[0].id : ed.currentBlockId();
    const n = id ? ed.editableOf(id) || ed.nodes.get(id) : null;
    if (!n) return null;
    // пустая строка или курсор без размеров — берём первую строку блока
    const br = n.getBoundingClientRect();
    if (r && r.collapsed && n.contains(r.startContainer) && br.height > 60) {
      const lh = parseFloat(getComputedStyle(n).lineHeight) || 24;
      return { top: br.top, bottom: br.top + lh + 6, left: br.left, right: br.right, height: lh };
    }
    return br;
  };
  const place = () => {
    if (!bar.classList.contains('is-visible')) return;
    const ed = getEditor();
    if (!ed) return;
    const sel = window.getSelection();
    const r = sel && sel.rangeCount ? sel.getRangeAt(0) : null;
    // выделен текст — работает панель форматирования, панель строки прячем, чтобы они не накладывались
    const textSel = !!(r && !r.collapsed && ed.root.contains(r.commonAncestorContainer) && r.toString().trim());
    bar.classList.toggle('is-suppressed', textSel);
    if (textSel) return;
    const rect = caretRect(ed);
    if (!rect) return;
    const box = viewportBox();
    const vTop = box.top;
    const vBottom = box.bottom;
    const h = bar.offsetHeight;
    let top = rect.bottom + 6;
    if (top + h > vBottom - 8) top = rect.top - h - 6;
    top = Math.max(vTop + 8, Math.min(top, vBottom - h - 8));
    bar.style.top = `${Math.round(top + box.shift)}px`;
  };
  let raf = 0;
  const schedule = () => {
    if (raf) return;
    raf = requestAnimationFrame(() => {
      raf = 0;
      place();
    });
  };
  document.addEventListener('selectionchange', schedule);
  window.addEventListener('scroll', schedule, true);
  window.addEventListener('resize', schedule);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', schedule);
    window.visualViewport.addEventListener('scroll', schedule);
  }
  return {
    el: bar,
    show(on) {
      if (on) {
        const ed = getEditor();
        lastId = ed ? ed.currentBlockId() : null;
        refresh();
      }
      bar.classList.toggle('is-visible', on);
      document.body.classList.toggle('has-mobilebar', on);
      if (on) requestAnimationFrame(place);
    },
  };
}
