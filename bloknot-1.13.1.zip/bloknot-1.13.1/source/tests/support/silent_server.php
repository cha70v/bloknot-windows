<?php
// Принимает соединения и молчит — так ведёт себя хостинг, перехватывающий SMTP: php silent_server.php ПОРТ
$srv = stream_socket_server('tcp://127.0.0.1:' . $argv[1], $e, $es);
$clients = array();
while ($c = @stream_socket_accept($srv, -1)) { $clients[] = $c; }
