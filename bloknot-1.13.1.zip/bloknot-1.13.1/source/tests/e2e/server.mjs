// Поднимает чистый экземпляр Тетради во временной папке и выполняет установку.
import { spawn, execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
export const EMAIL = 'denis@example.com';
export const PASSWORD = 'Тестовый-пароль-123';

function freePort() {
  return new Promise((resolve) => {
    const s = net.createServer();
    s.listen(0, '127.0.0.1', () => {
      const { port } = s.address();
      s.close(() => resolve(port));
    });
  });
}

async function waitPort(port) {
  for (let i = 0; i < 60; i++) {
    const ok = await new Promise((r) => {
      const c = net.connect(port, '127.0.0.1', () => {
        c.end();
        r(true);
      });
      c.on('error', () => r(false));
    });
    if (ok) return;
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('server did not start');
}

export async function startInstance({ dir, port } = {}) {
  dir = dir || fs.mkdtempSync(path.join(os.tmpdir(), 'tetrad-e2e-'));
  if (!fs.existsSync(path.join(dir, 'index.php'))) {
    const appDir = fs.existsSync(path.join(ROOT, 'app')) ? path.join(ROOT, 'app') : path.join(ROOT, '..', 'upload');
    execSync(`cp -r ${JSON.stringify(appDir)}/. ${JSON.stringify(dir)}`);
    fs.copyFileSync(path.join(ROOT, 'tests/router.php'), path.join(dir, 'router.php'));
  }
  port = port || (await freePort());
  const sendmail = `${path.join(ROOT, 'tests/support/fake-sendmail.sh')} ${dir}-mail`;
  const proc = spawn('php', ['-d', `sendmail_path=${sendmail}`, '-S', `127.0.0.1:${port}`, '-t', dir, path.join(dir, 'router.php')], { stdio: 'ignore' });
  await waitPort(port);
  const base = `http://127.0.0.1:${port}`;
  if (!fs.existsSync(path.join(dir, 'data/config.php'))) await install(base, dir);
  return {
    base,
    dir,
    port,
    stop: () => new Promise((r) => {
      proc.once('exit', r);
      proc.kill();
    }),
  };
}

async function install(base, dir) {
  const r1 = await fetch(base + '/');
  const cookie = (r1.headers.get('set-cookie') || '').split(';')[0];
  const html = await r1.text();
  const csrf = html.match(/name="csrf" value="([^"]+)"/)[1];
  const code = fs.readFileSync(path.join(dir, 'data/setup-code.txt'), 'utf8').match(/([A-Z0-9]{4}-[A-Z0-9]{4})/)[1];
  const body = new URLSearchParams({ csrf, code, name: 'Денис', email: EMAIL, password: PASSWORD, password2: PASSWORD });
  const r2 = await fetch(base + '/', { method: 'POST', body, headers: { cookie, 'content-type': 'application/x-www-form-urlencoded' }, redirect: 'manual' });
  if (r2.status !== 302) throw new Error('install failed: ' + r2.status);
}

export async function login(page, base) {
  await page.goto(base + '/');
  await page.fill('#login-email', EMAIL);
  await page.fill('#login-password', PASSWORD);
  await page.click('.login-form button[type=submit]');
  await page.waitForSelector('.sidebar');
}
