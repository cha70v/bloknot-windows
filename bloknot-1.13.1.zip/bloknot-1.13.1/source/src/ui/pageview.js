// Страница: обложка, значок, заголовок, редактор, автосохранение
import { el, clear, pageTitle, formatDate, debounce } from '../util.js';
import { icon } from '../icons.js';
import { api, upload, fileUrl } from '../api.js';
import { state, upsertPage, children, ancestors } from '../store.js';
import { Editor } from '../editor/editor.js';
import { PageSession, getDraft, clearDraft, syncEvents } from '../sync.js';
import { toast, modal, promptDialog, pickEmoji, confirmDialog } from './modal.js';
import { showMenu } from './menu.js';
import { pickPageDialog } from './pagepicker.js';
import { openPage, createPage } from './actions.js';
import { prepareImage } from '../editor/images.js';
import { setCaretOffset, getCaretOffset } from '../editor/caret.js';

export const COVER_PRESETS = [
  ['gray', 'Серый'],
  ['blue', 'Голубой'],
  ['ink', 'Синий'],
  ['dawn', 'Рассвет'],
  ['moss', 'Мох'],
  ['sand', 'Песок'],
  ['dusk', 'Сумерки'],
  ['slate', 'Графит'],
];

export function coverStyle(cover) {
  if (!cover) return null;
  if (cover.startsWith('file:')) return { backgroundImage: `url("${fileUrl(cover.slice(5))}")` };
  return null;
}

export function coverClass(cover) {
  return cover && cover.startsWith('preset:') ? `cover-preset-${cover.slice(7)}` : '';
}

/**
 * Создаёт представление страницы.
 * ctx: { scroller, setStatus(status, detail), setTitle(title) }
 */
export async function mountPage(container, id, ctx) {
  clear(container);
  const loading = el('div', { class: 'page-loading' }, el('div', { class: 'skeleton skeleton-title' }), el('div', { class: 'skeleton' }), el('div', { class: 'skeleton short' }));
  container.append(loading);
  let page;
  try {
    page = await api('page.get', undefined, { query: { id } });
  } catch (e) {
    clear(container);
    const msg = e.status === 410 ? 'Эта страница в корзине.' : e.status === 404 ? 'Страница не найдена — возможно, её удалили.' : e.status === 0 ? 'Нет связи с сервером. Страница откроется, когда связь восстановится.' : e.message;
    const box = el('div', { class: 'empty-state' }, el('div', { class: 'empty-title' }, 'Не удалось открыть страницу'), el('p', null, msg));
    if (e.status === 410) {
      const b = el('button', { class: 'btn btn-primary', type: 'button' }, 'Восстановить из корзины');
      b.addEventListener('click', async () => {
        await api('page.restore', { id });
        location.reload();
      });
      box.append(b);
    } else if (e.status === 0) {
      const b = el('button', { class: 'btn', type: 'button' }, 'Повторить');
      b.addEventListener('click', () => mountPage(container, id, ctx).then((v) => ctx.onRemount && ctx.onRemount(v)));
      box.append(b);
    }
    container.append(box);
    return null;
  }
  upsertPage(page);
  return renderPage(container, page, ctx);
}

function renderPage(container, page, ctx) {
  clear(container);
  let meta = { title: page.title, icon: page.icon, cover: page.cover };

  const coverEl = el('div', { class: 'page-cover' });
  const iconBtn = el('button', { type: 'button', class: 'page-icon', 'aria-label': 'Сменить значок страницы' });
  const addIconBtn = el('button', { type: 'button', class: 'ghost-btn' }, icon('smile', 16), 'Значок');
  const addCoverBtn = el('button', { type: 'button', class: 'ghost-btn' }, icon('cover', 16), 'Обложка');
  const controls = el('div', { class: 'page-controls' }, addIconBtn, addCoverBtn);
  const titleEl = el('h1', { class: 'page-title', 'data-ph': 'Без названия', spellcheck: 'true' });
  titleEl.setAttribute('contenteditable', 'plaintext-only');
  if (titleEl.contentEditable !== 'plaintext-only') titleEl.setAttribute('contenteditable', 'true');
  titleEl.textContent = page.title;
  const editorRoot = el('div', { class: 'page-editor' });
  const subpages = el('div', { class: 'page-subpages' });
  const footer = el('div', { class: 'page-footer' });
  const head = el('div', { class: 'page-head' }, iconBtn, controls, titleEl);
  const article = el('article', { class: 'page' }, coverEl, el('div', { class: 'page-inner' }, head, editorRoot, subpages, footer));
  container.append(article);

  function renderMeta() {
    // обложка
    coverEl.className = `page-cover ${coverClass(meta.cover)}`;
    coverEl.removeAttribute('style');
    clear(coverEl);
    article.classList.toggle('has-cover', !!meta.cover);
    if (meta.cover) {
      const st = coverStyle(meta.cover);
      if (st) Object.assign(coverEl.style, st);
      const change = el('button', { type: 'button', class: 'cover-btn' }, 'Сменить обложку');
      change.addEventListener('click', () => coverMenu(change));
      coverEl.append(el('div', { class: 'cover-actions' }, change));
    }
    // значок
    iconBtn.textContent = meta.icon || '';
    iconBtn.style.display = meta.icon ? '' : 'none';
    addIconBtn.style.display = meta.icon ? 'none' : '';
    addCoverBtn.style.display = meta.cover ? 'none' : '';
    article.classList.toggle('has-icon', !!meta.icon);
  }

  function renderFooter() {
    const p = state.pages.get(page.id) || page;
    footer.textContent = `Изменено ${formatDate(session ? session.updatedAt : p.updated_at)} · создано ${formatDate(page.created_at, false)}`;
  }

  function renderSubpages() {
    clear(subpages);
    const referenced = new Set(editor.blocks.filter((b) => b.type === 'page').map((b) => b.pageId));
    const kids = children(page.id).filter((k) => !referenced.has(k.id));
    article.classList.toggle('has-subpages', kids.length > 0);
    if (!kids.length) return;
    subpages.append(el('div', { class: 'subpages-title' }, 'Вложенные страницы'));
    for (const k of kids) {
      subpages.append(el('a', { class: 'pagelink', href: `#/p/${k.id}` }, el('span', { class: 'pagelink-icon' }, k.icon || icon('page', 18)), el('span', { class: 'pagelink-title' }, pageTitle(k))));
    }
  }

  const collect = () => ({ title: titleEl.textContent.replace(/\n/g, ' ').trim(), icon: meta.icon, cover: meta.cover, content: { v: 1, blocks: editor.getBlocks() } });

  const session = new PageSession(page, collect);
  const editor = new Editor(editorRoot, {
    fileUrl,
    scroller: ctx.scroller,
    uploadLimit: state.uploadLimit,
    getPage: (pid) => state.pages.get(pid) || null,
    openPage: (pid) => openPage(pid),
    onChange: () => {
      session.changed();
      renderSubpagesSoon();
    },
    onExitTop: () => {
      titleEl.focus();
      setCaretOffset(titleEl, 'end');
    },
    onFocusChange: (f) => ctx.onEditorFocus && ctx.onEditorFocus(f),
    onSelectionChange: () => ctx.onEditorFocus && ctx.onEditorFocus(true),
    onTap: () => ctx.onEditorFocus && ctx.onEditorFocus(true, true),
    toast,
    prompt: promptDialog,
    pickEmoji: (anchor, cb) => pickEmoji(anchor, cb, { allowRemove: false }),
    upload: (file, onProgress) => {
      const fd = new FormData();
      fd.append('file', file, file.name || 'image');
      fd.append('page_id', page.id);
      return upload('file.upload', fd, onProgress);
    },
    fetchImage: (url) => api('file.fetch', { url, page_id: page.id }),
    downloadFile: (fid) => {
      const a = el('a', { href: `${fileUrl(fid)}&dl=1` });
      document.body.append(a);
      a.click();
      a.remove();
    },
    createSubpage: async () => {
      await session.save();
      const p = await createPage(page.id, { open: false });
      return p ? p.id : null;
    },
    pickPage: async () => {
      const res = await pickPageDialog({ title: 'Ссылка на страницу', exclude: new Set([page.id]) });
      return res ? res.id : null;
    },
    searchPages: async (q) => {
      const ql = q.toLowerCase();
      return Array.from(state.pages.values()).filter((p) => pageTitle(p).toLowerCase().includes(ql)).slice(0, 8);
    },
  });
  editor.load(page.content.blocks || []);
  const renderSubpagesSoon = debounce(renderSubpages, 400);

  // ---------- заголовок ----------
  titleEl.addEventListener('input', () => {
    if (titleEl.innerHTML === '<br>') titleEl.textContent = '';
    ctx.setTitle(titleEl.textContent.trim());
    session.changed();
  });
  titleEl.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      const first = editor.blocks[0];
      if (first && first.type === 'p' && !first.html) editor.focusStart();
      else editor.insertAtStart();
    } else if (e.key === 'ArrowDown' || (e.key === 'ArrowRight' && getCaretOffset(titleEl) === titleEl.textContent.length)) {
      e.preventDefault();
      editor.focusStart();
    }
  });
  titleEl.addEventListener('paste', (e) => {
    e.preventDefault();
    const t = (e.clipboardData.getData('text/plain') || '').replace(/\s+/g, ' ');
    document.execCommand('insertText', false, t);
  });

  // ---------- значок и обложка ----------
  const setMeta = (patch) => {
    Object.assign(meta, patch);
    renderMeta();
    session.changed();
  };
  const chooseIcon = (anchor) => pickEmoji(anchor, (v) => setMeta({ icon: v }));
  iconBtn.addEventListener('click', () => chooseIcon(iconBtn));
  addIconBtn.addEventListener('click', () => chooseIcon(addIconBtn));
  addCoverBtn.addEventListener('click', () => setMeta({ cover: 'preset:' + COVER_PRESETS[Math.floor(Math.random() * 4)][0] }));

  function coverMenu(anchor) {
    showMenu({
      anchor,
      placement: 'bottom-end',
      sheetTitle: 'Обложка',
      items: [
        ...COVER_PRESETS.map(([k, label]) => ({ label, icon: 'cover', checked: meta.cover === 'preset:' + k, onSelect: () => setMeta({ cover: 'preset:' + k }) })),
        { separator: true },
        { label: 'Загрузить изображение', icon: 'upload', onSelect: () => uploadCover() },
        { label: 'Убрать обложку', icon: 'x', danger: true, onSelect: () => setMeta({ cover: '' }) },
      ],
    });
  }

  function uploadCover() {
    const input = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif' });
    input.addEventListener('change', async () => {
      const f = input.files && input.files[0];
      if (!f) return;
      try {
        const prepared = await prepareImage(f, state.uploadLimit);
        const fd = new FormData();
        fd.append('file', prepared, prepared.name || 'cover');
        fd.append('page_id', page.id);
        const t = toast('Загрузка обложки…', 'info', { duration: Infinity });
        const res = await upload('file.upload', fd).finally(() => t.remove());
        setMeta({ cover: 'file:' + res.id });
      } catch (e) {
        toast(`Обложка не загружена: ${e.message}`, 'error');
      }
    });
    input.click();
  }

  renderMeta();
  renderFooter();
  renderSubpages();
  ctx.setTitle(page.title);

  // ---------- черновик, оставшийся с прошлого раза ----------
  const draft = getDraft(page.id);
  if (draft) {
    const same = JSON.stringify(draft.content && draft.content.blocks) === JSON.stringify(page.content.blocks) && draft.title === page.title && draft.icon === page.icon && draft.cover === page.cover;
    if (same) clearDraft(page.id);
    else if (draft.base === page.version && !draft.conflict) {
      applyContent(draft, false);
      session.changed();
      toast('Восстановлены изменения, которые не успели сохраниться');
    } else {
      setTimeout(() => offerDraftConflict(draft), 50);
    }
  }

  function applyContent(src, keepFocus = true) {
    const focus = keepFocus ? editor.focusState() : null;
    meta = { title: src.title || '', icon: src.icon || '', cover: src.cover || '' };
    if (document.activeElement !== titleEl) titleEl.textContent = meta.title;
    editor.load((src.content && src.content.blocks) || []);
    if (focus && focus.id && editor.block(focus.id)) editor.focusBlock(focus.id, focus.offset == null ? 'end' : focus.offset, { noScroll: true });
    renderMeta();
    renderSubpages();
    ctx.setTitle(meta.title);
  }

  async function offerDraftConflict(d) {
    const choice = await conflictDialog({
      text: 'На этом устройстве есть изменения страницы, которые не успели сохраниться, а на сервере за это время появилась более новая версия.',
      serverTime: page.updated_at,
      localTime: d.ts,
    });
    if (choice === 'mine') {
      applyContent(d, false);
      session.version = page.version;
      session.dirty = true;
      await session.keepMine();
    } else if (choice === 'copy') {
      await saveAsCopy(d);
      clearDraft(page.id);
    } else {
      // серверная версия; локальная попадает в историю версий
      try {
        await api('page.save', { id: page.id, base_version: d.base, title: d.title, icon: d.icon, cover: d.cover, content: d.content });
      } catch (e) {
        /* 409 ожидаем — копия сохранена в истории */
      }
      clearDraft(page.id);
    }
  }

  async function saveAsCopy(local) {
    try {
      const p = await api('page.create', {
        parent_id: page.parent_id,
        after_id: page.id,
        title: `${local.title || 'Без названия'} (моя версия)`,
        icon: local.icon,
        cover: local.cover,
        content: local.content,
      });
      upsertPage(p);
      toast('Ваша версия сохранена отдельной страницей', 'info', { action: { label: 'Открыть', onClick: () => openPage(p.id) } });
    } catch (e) {
      toast(`Не удалось сохранить копию: ${e.message}`, 'error');
    }
  }

  // ---------- события синхронизации ----------
  const offs = [];
  offs.push(
    syncEvents.on('status', (s, detail, sess) => {
      if (sess !== session) return;
      ctx.setStatus(s, detail);
      if (s === 'saved') renderFooter();
    }),
  );
  offs.push(
    syncEvents.on('conflict', async (sess, server, local) => {
      if (sess !== session) return;
      const choice = await conflictDialog({ text: 'Пока вы печатали, эта страница была изменена на другом устройстве.', serverTime: server.updated_at, localTime: Date.now() });
      if (choice === 'mine') {
        session.version = server.version;
        await session.keepMine();
      } else if (choice === 'copy') {
        await saveAsCopy(local);
        session.acceptServer(server);
        applyContent(server);
      } else {
        session.acceptServer(server);
        applyContent(server);
        toast('Загружена версия с сервера. Ваша версия — в истории версий.');
      }
    }),
  );
  offs.push(
    syncEvents.on('remote-change', async (sess) => {
      if (sess !== session || session.dirty) return;
      try {
        const fresh = await api('page.get', undefined, { query: { id: page.id } });
        if (session.dirty || session.saving) return;
        session.version = fresh.version;
        session.updatedAt = fresh.updated_at;
        applyContent(fresh);
        upsertPage(fresh);
        renderFooter();
        ctx.setStatus('synced');
      } catch (e) {
        /* повторим при следующем опросе */
      }
    }),
  );
  offs.push(
    syncEvents.on('gone', (sess) => {
      if (sess !== session) return;
      ctx.setStatus('error', 'Страница удалена на другом устройстве');
      toast('Эта страница удалена на другом устройстве. Изменения сохранены в черновике на этом устройстве.', 'error', { duration: 10000 });
    }),
  );

  const isNew = /new=1/.test(location.hash);
  if (isNew || (!page.title && editor.isEmpty())) {
    titleEl.focus();
    // повторно — только если пользователь ещё никуда не поставил курсор
    setTimeout(() => {
      const a = document.activeElement;
      if (!a || a === document.body) titleEl.focus();
    }, 30);
  }

  return {
    id: page.id,
    session,
    editor,
    titleEl,
    refreshLinks: () => {
      editor.refreshPageLinks();
      renderSubpages();
      renderFooter();
    },
    showHistory: () => historyDialog(page.id, (rev) => {
      editor.checkpoint();
      meta.title = rev.title;
      titleEl.textContent = rev.title;
      editor.load((rev.content && rev.content.blocks) || []);
      renderMeta();
      session.changed();
      toast('Версия восстановлена — её можно отменить через Ctrl+Z или историю');
    }),
    async destroy() {
      offs.forEach((f) => f());
      const ok = await session.close();
      editor.destroy();
      return ok;
    },
  };
}

// ---------- диалог конфликта ----------
function conflictDialog({ text, serverTime, localTime }) {
  return new Promise((resolve) => {
    let done = false;
    modal({
      title: 'Две версии страницы',
      dismissable: false,
      content: (close) => {
        const pick = (v) => {
          done = true;
          resolve(v);
          close();
        };
        const mk = (label, sub, v, primary) => {
          const b = el('button', { type: 'button', class: `choice${primary ? ' is-primary' : ''}` }, el('span', { class: 'choice-label' }, label), el('span', { class: 'choice-sub' }, sub));
          b.addEventListener('click', () => pick(v));
          return b;
        };
        return el(
          'div',
          null,
          el('p', { class: 'modal-text' }, text),
          el('p', { class: 'modal-text muted' }, `Версия на сервере: ${formatDate(serverTime)}. Ваши изменения: ${formatDate(localTime)}. Ни одна из версий не потеряется — обе останутся в истории.`),
          el(
            'div',
            { class: 'choices' },
            mk('Оставить мою версию', 'Серверная версия сохранится в истории версий', 'mine', true),
            mk('Взять версию с сервера', 'Ваша версия сохранится в истории версий', 'server'),
            mk('Сохранить мою отдельной страницей', 'На сервере останется его версия, ваша — рядом копией', 'copy'),
          ),
        );
      },
      onClose: () => {
        if (!done) resolve('server');
      },
    });
  });
}

// ---------- история версий ----------
function historyDialog(pageId, onRestore) {
  modal({
    title: 'История версий',
    wide: true,
    className: 'history',
    content: (close) => {
      const list = el('div', { class: 'history-list' }, el('div', { class: 'muted pad' }, 'Загрузка…'));
      const preview = el('div', { class: 'history-preview' }, el('div', { class: 'muted pad' }, 'Выберите версию слева, чтобы посмотреть её.'));
      const reasons = { auto: 'Автоснимок', conflict: 'Версия из конфликта', overwrite: 'Перед перезаписью' };
      api('page.revisions', undefined, { query: { id: pageId } }).then(
        (revs) => {
          clear(list);
          if (!revs.length) {
            list.append(el('div', { class: 'muted pad' }, 'Снимков пока нет. Они появляются автоматически не чаще раза в 10 минут во время редактирования.'));
            return;
          }
          revs.forEach((r) => {
            const item = el('button', { type: 'button', class: 'history-item' }, el('span', { class: 'history-date' }, formatDate(r.created_at)), el('span', { class: 'history-reason' }, reasons[r.reason] || r.reason));
            item.addEventListener('click', async () => {
              list.querySelectorAll('.is-active').forEach((n) => n.classList.remove('is-active'));
              item.classList.add('is-active');
              clear(preview);
              preview.append(el('div', { class: 'muted pad' }, 'Загрузка…'));
              const rev = await api('revision.get', undefined, { query: { id: r.id } });
              clear(preview);
              const restore = el('button', { type: 'button', class: 'btn btn-primary' }, icon('restore', 16), 'Восстановить эту версию');
              restore.addEventListener('click', () => {
                close();
                onRestore(rev);
              });
              const root = el('div', { class: 'history-doc' });
              preview.append(el('div', { class: 'history-bar' }, el('strong', null, rev.title || 'Без названия'), restore), root);
              const ed = new Editor(root, { readOnly: true, fileUrl, getPage: (id) => state.pages.get(id) || null });
              ed.load((rev.content && rev.content.blocks) || []);
            });
            list.append(item);
          });
        },
        (e) => {
          clear(list);
          list.append(el('div', { class: 'muted pad' }, e.message));
        },
      );
      return el('div', { class: 'history-wrap' }, list, preview);
    },
  });
}

export { confirmDialog };
