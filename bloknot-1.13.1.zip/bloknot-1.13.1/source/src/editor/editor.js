// Блочный редактор Блокнота. Каждый блок — отдельный элемент; модель — массив блоков.
import { el, uid, modKey, isUrl, normalizeUrl, escapeHtml, clamp, isTouch } from '../util.js';
import { icon } from '../icons.js';
import { normalizeInline, htmlToText } from '../sanitize.js';
import {
  TEXT_TYPES, LIST_TYPES, MAX_INDENT, TYPE_LABELS, TYPE_ICONS, isText, isEditable, isAtom, newBlock, normalizeBlocks, cloneBlocks,
  COLORS, validColor, colorLabel,
} from './model.js';
import { renderBlock, codeHtml } from './render.js';
import { attachTable } from './table.js';
import {
  getRange, getCaretOffset, setCaretOffset, caretAtStart, caretAtEnd, caretOnFirstLine, caretOnLastLine, placeCaretAtX, splitAtCaret,
  cleanEdge, textBeforeCaret, deleteRange, caretRect, selectionInside,
} from './caret.js';
import { htmlToBlocks, markdownToBlocks, plainTextToBlocks, looksLikeMarkdown, blocksToHtml, blocksToText } from './convert.js';
import { showMenu, closeMenus, positionPopup } from '../ui/menu.js';
import { InlineToolbar } from './toolbar.js';
import { prepareImage } from './images.js';

const BLOCKS_MIME = 'application/x-tetrad-blocks';
const HISTORY_LIMIT = 300;

export const SLASH_ITEMS = [
  { type: 'ai', label: 'Написать с ИИ', keys: 'ии ai спросить написать сгенерировать gigachat гигачат помощник', hint: '' },
  { type: 'p', label: 'Текст', keys: 'текст абзац paragraph text', hint: '' },
  { type: 'h1', label: 'Заголовок 1', keys: 'заголовок heading h1 #', hint: '#' },
  { type: 'h2', label: 'Заголовок 2', keys: 'заголовок heading h2 ##', hint: '##' },
  { type: 'h3', label: 'Заголовок 3', keys: 'заголовок heading h3 ###', hint: '###' },
  { type: 'ul', label: 'Маркированный список', keys: 'список маркированный bullet list ul', hint: '-' },
  { type: 'ol', label: 'Нумерованный список', keys: 'список нумерованный numbered list ol', hint: '1.' },
  { type: 'todo', label: 'Чек-лист', keys: 'задача чек todo checkbox task список дел', hint: '[]' },
  { type: 'toggle', label: 'Раскрывающийся блок', keys: 'toggle раскрывающийся свернуть спойлер', hint: '' },
  { type: 'quote', label: 'Цитата', keys: 'цитата quote', hint: '>' },
  { type: 'callout', label: 'Выноска', keys: 'выноска callout заметка важно', hint: '' },
  { type: 'code', label: 'Код', keys: 'код code программа snippet', hint: '```' },
  { type: 'hr', label: 'Разделитель', keys: 'разделитель линия divider hr', hint: '---' },
  { type: 'page', label: 'Вложенная страница', keys: 'страница подстраница вложенная page subpage', hint: '' },
  { type: 'link-page', label: 'Ссылка на страницу', keys: 'ссылка страница link page', hint: '' },
  { type: 'image', label: 'Изображение', keys: 'изображение картинка фото image picture загрузить', hint: '' },
  { type: 'image-url', label: 'Изображение по ссылке', keys: 'изображение картинка url ссылка image', hint: '' },
  { type: 'bookmark', label: 'Ссылка-закладка', keys: 'закладка ссылка bookmark url веб сайт', hint: '' },
  { type: 'table', label: 'Таблица', keys: 'таблица table', hint: '' },
];
const SLASH_ICONS = Object.assign({}, TYPE_ICONS, { 'link-page': 'link', 'image-url': 'image', ai: 'sparkle' });

export class Editor {
  constructor(root, opts = {}) {
    this.root = root;
    this.opts = opts;
    this.ro = !!opts.readOnly;
    this.blocks = [];
    this.nodes = new Map();
    this.selected = new Set();
    this.undoStack = [];
    this.redoStack = [];
    this.lastInput = { t: 0, id: null };
    this.composing = false;
    this.slash = null;
    this.normCache = new Map();
    root.classList.add('editor');
    if (this.ro) root.classList.add('is-readonly');
    root.setAttribute('tabindex', '-1');
    this.ctx = {
      ro: this.ro,
      fileUrl: (id) => (opts.fileUrl ? opts.fileUrl(id) : ''),
      getPage: (id) => (opts.getPage ? opts.getPage(id) : null),
    };
    if (!this.ro) this.bind();
  }

  // ---------- загрузка и сериализация ----------
  load(blocks) {
    this.blocks = normalizeBlocks(blocks);
    if (!this.blocks.length && !this.ro) this.blocks.push(newBlock('p'));
    this.undoStack = [];
    this.redoStack = [];
    this.selected.clear();
    this.renderAll();
  }

  /** Возвращает блоки для сохранения (очищенный HTML, без временных полей). */
  getBlocks() {
    const out = [];
    for (const b of this.blocks) {
      if (b._uploading) continue;
      const c = {};
      for (const [k, v] of Object.entries(b)) {
        if (k.startsWith('_')) continue;
        c[k] = v;
      }
      if (typeof c.html === 'string') c.html = this.norm(c.html);
      if (typeof c.caption === 'string') c.caption = this.norm(c.caption);
      if (c.rows) c.rows = c.rows.map((r) => r.map((cell) => this.norm(cell || '')));
      out.push(c);
    }
    // одиночный пустой абзац = пустая страница
    if (out.length === 1 && out[0].type === 'p' && !out[0].html && !out[0].indent) return [];
    return out;
  }

  norm(html) {
    if (!html || !/[<&\n]/.test(html)) return html || '';
    let v = this.normCache.get(html);
    if (v === undefined) {
      v = normalizeInline(html, { keepNewlines: true });
      if (this.normCache.size > 3000) this.normCache.clear();
      this.normCache.set(html, v);
    }
    return v;
  }

  isEmpty() {
    return this.getBlocks().length === 0;
  }

  // ---------- отрисовка ----------
  renderAll() {
    this.root.textContent = '';
    this.nodes.clear();
    const frag = document.createDocumentFragment();
    for (const b of this.blocks) {
      const n = this.render(b);
      this.nodes.set(b.id, n);
      frag.append(n);
    }
    this.root.append(frag);
    if (!this.ro) {
      if (!this.tail) {
        this.tail = el('div', { class: 'editor-tail', 'aria-hidden': 'true' });
      }
      this.root.append(this.tail);
    }
    this.updateStructure();
  }

  /** Отрисовка блока + управляющие элементы, которым нужен редактор (таблицы: ширина колонок, сортировка). */
  render(b) {
    const n = renderBlock(b, this.ctx);
    if (b.type === 'table' && !this.ro) attachTable(n, b, this);
    return n;
  }

  replaceNode(b) {
    const old = this.nodes.get(b.id);
    const n = this.render(b);
    if (this.selected.has(b.id)) n.classList.add('is-selected');
    if (old && old.parentNode) old.replaceWith(n);
    this.nodes.set(b.id, n);
    return n;
  }

  insertNodeAt(index, b) {
    const n = this.render(b);
    this.nodes.set(b.id, n);
    const next = this.blocks[index + 1];
    const ref = next ? this.nodes.get(next.id) : this.tail || null;
    this.root.insertBefore(n, ref && ref.parentNode === this.root ? ref : null);
    return n;
  }

  /** Нумерация списков, свёрнутые блоки, плейсхолдеры. */
  updateStructure() {
    const counters = [];
    let hideBelow = Infinity;
    const sole = this.blocks.length === 1 && this.blocks[0].type === 'p' && !this.blocks[0].html;
    for (let i = 0; i < this.blocks.length; i++) {
      const b = this.blocks[i];
      const n = this.nodes.get(b.id);
      if (!n) continue;
      const ind = b.indent || 0;
      if (ind <= hideBelow) hideBelow = Infinity;
      const hidden = ind > hideBelow;
      n.classList.toggle('is-hidden', hidden);
      const nextB = this.blocks[i + 1];
      const hasKids = !!(nextB && (nextB.indent || 0) > ind);
      // сворачивание вложенных пунктов (как в Notion) — для всех текстовых блоков, кроме раскрывающегося
      if (b.collapsed && !hasKids) delete b.collapsed;
      const canCollapse = hasKids && isText(b) && b.type !== 'toggle';
      n.classList.toggle('has-children', canCollapse);
      n.classList.toggle('is-collapsed', !!(canCollapse && b.collapsed));
      const cbtn = n.querySelector(':scope > .blk-collapse');
      if (cbtn) {
        cbtn.setAttribute('aria-expanded', b.collapsed ? 'false' : 'true');
        cbtn.setAttribute('aria-label', b.collapsed ? 'Развернуть вложенные' : 'Свернуть вложенные');
        cbtn.title = b.collapsed ? 'Развернуть вложенные' : 'Свернуть вложенные';
      }
      n.dataset.lvl = String(ind % 3);
      if (!hidden && ((b.type === 'toggle' && !b.open) || (canCollapse && b.collapsed))) hideBelow = ind;
      counters.length = ind + 1;
      if (b.type === 'ol') {
        counters[ind] = (counters[ind] || 0) + 1;
        const m = n.querySelector('.blk-num');
        if (m) m.textContent = olLabel(counters[ind], ind) + '.';
      } else counters[ind] = 0;
      if (b.type === 'toggle') {
        const next = this.blocks[i + 1];
        n.classList.toggle('is-empty-toggle', !(next && (next.indent || 0) > ind));
      }
    }
    this.root.classList.toggle('is-sole-empty', sole);
  }

  /** Скрыты ли вложенные блоки (закрытый раскрывающийся блок или свёрнутый пункт). */
  isClosed(i) {
    const b = this.blocks[i];
    if (!b) return false;
    const next = this.blocks[i + 1];
    const hasKids = !!(next && (next.indent || 0) > (b.indent || 0));
    return hasKids && ((b.type === 'toggle' && !b.open) || !!b.collapsed);
  }

  toggleCollapse(b, force) {
    const i = this.index(b.id);
    if (i < 0) return;
    if (b.type === 'toggle') {
      this.checkpoint();
      b.open = force === undefined ? !b.open : !force;
      this.replaceNode(b);
    } else {
      const next = this.blocks[i + 1];
      if (!(next && (next.indent || 0) > (b.indent || 0))) return;
      this.checkpoint();
      const on = force === undefined ? !b.collapsed : force;
      if (on) b.collapsed = true;
      else delete b.collapsed;
      // курсор не должен остаться в скрытом блоке
      const a = document.activeElement;
      const ab = a && this.root.contains(a) ? this.blockFromNode(a) : null;
      if (on && ab && ab.id !== b.id && this.index(ab.id) > i && this.index(ab.id) < this.subtreeEnd(i)) this.focusBlock(b.id, 'end');
    }
    this.updateStructure();
    this.changed();
  }

  refreshPageLinks() {
    for (const b of this.blocks) if (b.type === 'page') this.replaceNode(b);
  }

  // ---------- поиск блоков ----------
  index(id) {
    return this.blocks.findIndex((b) => b.id === id);
  }

  block(id) {
    return this.blocks.find((b) => b.id === id);
  }

  blockFromNode(node) {
    const w = node && node.closest ? node.closest('.blk') : null;
    if (!w || !this.root.contains(w)) return null;
    return this.block(w.dataset.id);
  }

  editableOf(id) {
    const n = this.nodes.get(id);
    return n ? n.querySelector('[data-editable]') : null;
  }

  visibleIndex(i, dir) {
    for (let j = i + dir; j >= 0 && j < this.blocks.length; j += dir) {
      const n = this.nodes.get(this.blocks[j].id);
      if (n && !n.classList.contains('is-hidden')) return j;
    }
    return -1;
  }

  subtreeEnd(i) {
    const ind = this.blocks[i].indent || 0;
    let j = i + 1;
    while (j < this.blocks.length && (this.blocks[j].indent || 0) > ind) j++;
    return j;
  }

  currentBlockId() {
    if (this.selected.size) return Array.from(this.selected)[0];
    const a = document.activeElement;
    const b = a && this.root.contains(a) ? this.blockFromNode(a) : null;
    return b ? b.id : this.lastFocusedId || null;
  }

  // ---------- фокус ----------
  focusBlock(id, pos = 'end', opts = {}) {
    const b = this.block(id);
    if (!b) return;
    this.clearSelection();
    if (!isEditable(b)) {
      this.selectBlocks([id]);
      return;
    }
    const e = this.editableOf(id);
    if (!e) return;
    e.focus({ preventScroll: true });
    if (pos && typeof pos === 'object' && 'x' in pos) placeCaretAtX(e, pos.x, pos.line);
    else setCaretOffset(e, pos === 'start' ? 0 : pos);
    this.lastFocusedId = id;
    if (!opts.noScroll) this.scrollIntoView(id);
  }

  focusStart() {
    if (!this.blocks.length) return;
    this.focusBlock(this.blocks[0].id, 'start');
  }

  scrollIntoView(id) {
    const n = this.nodes.get(id);
    if (!n) return;
    const r = n.getBoundingClientRect();
    const vh = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
    if (r.top < 64 || r.bottom > vh - 80) n.scrollIntoView({ block: 'nearest', behavior: 'auto' });
  }

  // ---------- выделение блоков ----------
  selectBlocks(ids, anchor) {
    this.clearSelection(false);
    for (const id of ids) {
      this.selected.add(id);
      const n = this.nodes.get(id);
      if (n) n.classList.add('is-selected');
    }
    this.selAnchor = anchor || ids[0];
    this.selHead = ids[ids.length - 1];
    const s = window.getSelection();
    if (s) s.removeAllRanges();
    this.root.focus({ preventScroll: true });
    if (ids.length) this.scrollIntoView(this.selHead);
    this.opts.onSelectionChange && this.opts.onSelectionChange();
  }

  clearSelection(notify = true) {
    if (!this.selected.size) return;
    for (const id of this.selected) {
      const n = this.nodes.get(id);
      if (n) n.classList.remove('is-selected');
    }
    this.selected.clear();
    if (notify && this.opts.onSelectionChange) this.opts.onSelectionChange();
  }

  selectRange(fromId, toId) {
    let a = this.index(fromId);
    let b = this.index(toId);
    if (a > b) [a, b] = [b, a];
    const ids = [];
    for (let i = a; i <= b; i++) {
      const n = this.nodes.get(this.blocks[i].id);
      if (n && !n.classList.contains('is-hidden')) ids.push(this.blocks[i].id);
    }
    this.selectBlocks(ids, fromId);
    this.selHead = toId;
  }

  selectedInOrder() {
    return this.blocks.filter((b) => this.selected.has(b.id));
  }

  // ---------- история ----------
  focusState() {
    if (this.selected.size) return { sel: Array.from(this.selected) };
    const a = document.activeElement;
    const b = a && this.root.contains(a) ? this.blockFromNode(a) : null;
    if (!b) return null;
    const e = this.editableOf(b.id);
    return { id: b.id, offset: e ? getCaretOffset(e) : null };
  }

  checkpoint() {
    this.undoStack.push({ blocks: JSON.stringify(this.blocks.map(stripTransient)), focus: this.focusState() });
    if (this.undoStack.length > HISTORY_LIMIT) this.undoStack.shift();
    this.redoStack = [];
    this.lastInput = { t: 0, id: null };
  }

  restoreSnapshot(snap) {
    this.blocks = JSON.parse(snap.blocks);
    this.selected.clear();
    this.renderAll();
    const f = snap.focus;
    if (f && f.sel) this.selectBlocks(f.sel.filter((id) => this.block(id)));
    else if (f && f.id && this.block(f.id)) this.focusBlock(f.id, f.offset == null ? 'end' : f.offset);
    this.changed();
  }

  undo() {
    if (!this.undoStack.length) return;
    this.flushAllEditables();
    this.redoStack.push({ blocks: JSON.stringify(this.blocks.map(stripTransient)), focus: this.focusState() });
    this.restoreSnapshot(this.undoStack.pop());
    this.lastInput = { t: 0, id: null };
  }

  redo() {
    if (!this.redoStack.length) return;
    this.undoStack.push({ blocks: JSON.stringify(this.blocks.map(stripTransient)), focus: this.focusState() });
    this.restoreSnapshot(this.redoStack.pop());
    this.lastInput = { t: 0, id: null };
  }

  flushAllEditables() {
    // модель обновляется по событию input, здесь — страховка
    for (const b of this.blocks) {
      if (TEXT_TYPES.has(b.type)) {
        const e = this.editableOf(b.id);
        if (e) b.html = e.innerHTML === '<br>' ? '' : e.innerHTML;
      }
    }
  }

  changed() {
    if (this.opts.onChange) this.opts.onChange();
  }

  // ---------- события ----------
  bind() {
    const r = this.root;
    r.addEventListener('input', (e) => this.onInput(e));
    r.addEventListener('beforeinput', (e) => this.onBeforeInput(e));
    r.addEventListener('keydown', (e) => this.onKeyDown(e));
    r.addEventListener('paste', (e) => this.onPaste(e));
    r.addEventListener('click', (e) => this.onClick(e));
    r.addEventListener('change', (e) => this.onChangeEvt(e));
    r.addEventListener('pointerdown', (e) => this.onPointerDown(e));
    r.addEventListener('touchstart', (e) => this.onTouchStart(e), { passive: true });
    // касание любой строки на телефоне делает её текущей и показывает панель строки,
    // даже если касание не ставит курсор (галочка задачи, стрелка раскрывающегося блока, маркер)
    r.addEventListener('pointerup', (e) => {
      if (e.pointerType !== 'touch' || this.ro || this.touchDrag) return;
      const b = this.blockFromNode(e.target);
      if (!b) return;
      this.lastFocusedId = b.id;
      this.lastTapAt = Date.now();
      setTimeout(() => this.opts.onTap && this.opts.onTap(b.id), 50);
    });
    r.addEventListener('focusin', (e) => this.onFocusIn(e));
    r.addEventListener('focusout', (e) => this.onFocusOut(e));
    r.addEventListener('compositionstart', () => (this.composing = true));
    r.addEventListener('compositionend', () => (this.composing = false));
    r.addEventListener('dragover', (e) => this.onDragOver(e));
    r.addEventListener('drop', (e) => this.onDrop(e));
    r.addEventListener('dragleave', () => this.hideDropLine());
    this.onDocCopy = (e) => this.onCopy(e, false);
    this.onDocCut = (e) => this.onCopy(e, true);
    this.onDocPaste = (e) => {
      if (this.selected.size && !this.root.contains(e.target)) this.onPaste(e);
    };
    document.addEventListener('copy', this.onDocCopy);
    document.addEventListener('cut', this.onDocCut);
    document.addEventListener('paste', this.onDocPaste);
    this.toolbar = new InlineToolbar(this);
  }

  destroy() {
    document.removeEventListener('copy', this.onDocCopy);
    document.removeEventListener('cut', this.onDocCut);
    document.removeEventListener('paste', this.onDocPaste);
    if (this.toolbar) this.toolbar.destroy();
    this.closeSlash();
    clearTimeout(this.hlTimer);
  }

  onFocusIn(e) {
    const b = this.blockFromNode(e.target);
    if (b && e.target !== this.root) {
      if (e.target.hasAttribute && e.target.hasAttribute('data-cell')) {
        const [r, c] = e.target.dataset.cell.split(':').map(Number);
        this.lastCell = { id: b.id, r, c };
      }
      if (this.selected.size) this.clearSelection();
      this.lastFocusedId = b.id;
      this.root.querySelectorAll('.blk.is-focused').forEach((n) => n.classList.remove('is-focused'));
      const n = this.nodes.get(b.id);
      if (n) n.classList.add('is-focused');
    }
    this.opts.onFocusChange && this.opts.onFocusChange(true);
  }

  onFocusOut(e) {
    const b = this.blockFromNode(e.target);
    if (b && b.type === 'code') {
      const c = this.editableOf(b.id);
      if (c) {
        clearTimeout(this.hlTimer);
        c.innerHTML = codeHtml(b.text, b.lang);
      }
    }
    setTimeout(() => {
      if (!this.root.contains(document.activeElement)) {
        this.root.querySelectorAll('.blk.is-focused').forEach((n) => n.classList.remove('is-focused'));
        // сразу после касания строки панель не прячем (касание кнопки в строке тоже снимает фокус)
        if (Date.now() - (this.lastTapAt || 0) < 400) return;
        this.opts.onFocusChange && this.opts.onFocusChange(false);
      }
    }, 0);
  }

  onInput(e) {
    const t = e.target;
    if (!t.hasAttribute || !(t.hasAttribute('data-editable') || t.hasAttribute('data-caption') || t.hasAttribute('data-cell'))) return;
    const b = this.blockFromNode(t);
    if (!b) return;
    // группировка ввода для отмены: новая группа после паузы или при смене блока
    const now = Date.now();
    const newGroup = now - this.lastInput.t > 900 || this.lastInput.id !== b.id || e.inputType === 'insertFromPaste' || /^delete/.test(e.inputType || '') !== this.lastInput.del;
    if (newGroup) {
      // модель ещё содержит состояние до ввода — сохраняем его
      const snap = JSON.stringify(this.blocks.map(stripTransient));
      const top = this.undoStack[this.undoStack.length - 1];
      if (!top || top.blocks !== snap) {
        this.undoStack.push({ blocks: snap, focus: { id: b.id, offset: null } });
        if (this.undoStack.length > HISTORY_LIMIT) this.undoStack.shift();
      }
      this.redoStack = [];
    }
    this.lastInput = { t: now, id: b.id, del: /^delete/.test(e.inputType || '') };

    if (t.hasAttribute('data-caption')) {
      b.caption = t.innerHTML === '<br>' ? '' : t.innerHTML;
      this.changed();
      return;
    }
    if (t.hasAttribute('data-cell')) {
      const [ri, ci] = t.dataset.cell.split(':').map(Number);
      while (b.rows.length <= ri) b.rows.push([]);
      b.rows[ri][ci] = t.innerHTML === '<br>' ? '' : t.innerHTML;
      this.changed();
      return;
    }
    if (b.type === 'code') {
      b.text = t.textContent;
      this.scheduleHighlight(b, t);
      this.changed();
      return;
    }
    if (t.innerHTML === '<br>') t.innerHTML = '';
    b.html = t.innerHTML;
    if (e.inputType === 'insertText' && !this.composing) {
      if (e.data === ' ' && this.tryMarkdownShortcut(b, t)) return;
      if (e.data === '-' && b.type === 'p' && t.textContent === '---') {
        this.convertToDivider(b);
        return;
      }
      if (e.data === '/' && !this.slash) {
        const before = textBeforeCaret(t);
        if (before.length === 1 || /\s\/$/.test(before)) this.openSlash(b, t, before.length - 1);
      }
    }
    if (this.slash) this.updateSlash();
    if (b.type === 'p' && this.blocks.length === 1) this.updateStructure();
    this.changed();
  }

  scheduleHighlight(b, codeEl) {
    clearTimeout(this.hlTimer);
    this.hlTimer = setTimeout(() => {
      if (document.activeElement !== codeEl || this.composing) return;
      const off = getCaretOffset(codeEl);
      codeEl.innerHTML = codeHtml(b.text, b.lang);
      if (off != null) setCaretOffset(codeEl, off);
    }, 350);
  }

  onBeforeInput(e) {
    const t = e.target;
    if (e.inputType === 'historyUndo') {
      e.preventDefault();
      this.undo();
      return;
    }
    if (e.inputType === 'historyRedo') {
      e.preventDefault();
      this.redo();
      return;
    }
    const b = this.blockFromNode(t);
    if (!b || this.composing) return;
    if (t.hasAttribute('data-caption') || t.hasAttribute('data-cell')) {
      if (e.inputType === 'insertParagraph') {
        e.preventDefault();
        if (t.hasAttribute('data-cell')) this.cellNav(b, t, 'down');
        else this.insertAfter(b, newBlock('p'), true);
      }
      return;
    }
    // Мобильные клавиатуры часто не присылают keydown для Enter/Backspace — обрабатываем здесь
    if (e.inputType === 'insertParagraph') {
      e.preventDefault();
      if (this.slash) {
        this.slashChoose();
        return;
      }
      this.handleEnter(b, t, false);
    } else if (e.inputType === 'insertLineBreak' && b.type === 'code') {
      e.preventDefault();
      document.execCommand('insertText', false, '\n');
    } else if (e.inputType === 'deleteContentBackward' && isText(b) && caretAtStart(t)) {
      e.preventDefault();
      this.handleBackspaceAtStart(b, t);
    }
  }

  onKeyDown(e) {
    if (e.isComposing || this.composing || e.keyCode === 229) return;
    const mod = modKey(e);
    // меню команд
    if (this.slash) {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        this.slashMove(e.key === 'ArrowDown' ? 1 : -1);
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        this.slashChoose();
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        this.closeSlash();
        return;
      }
    }
    // отмена / повтор
    if (mod && !e.altKey && (e.key === 'z' || e.key === 'Z' || e.code === 'KeyZ')) {
      e.preventDefault();
      if (e.shiftKey) this.redo();
      else this.undo();
      return;
    }
    if (mod && (e.key === 'y' || e.code === 'KeyY') && !isMacPlatform()) {
      e.preventDefault();
      this.redo();
      return;
    }
    if (this.selected.size && (e.target === this.root || this.selected.has((this.blockFromNode(e.target) || {}).id))) {
      this.onSelectionKey(e);
      return;
    }
    const t = e.target;
    const b = this.blockFromNode(t);
    if (!b) return;
    if (t.hasAttribute('data-caption')) {
      if (e.key === 'Escape') {
        e.preventDefault();
        this.selectBlocks([b.id]);
      }
      return;
    }
    if (t.hasAttribute('data-cell')) {
      this.onCellKey(e, b, t);
      return;
    }
    if (!t.hasAttribute('data-editable')) return;

    // блочные команды
    if (mod && e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
      e.preventDefault();
      this.moveBlocks([b.id], e.key === 'ArrowUp' ? -1 : 1);
      return;
    }
    if (e.altKey && e.shiftKey && (e.key === 'ArrowUp' || e.key === 'ArrowDown')) {
      e.preventDefault();
      this.moveBlocks([b.id], e.key === 'ArrowUp' ? -1 : 1);
      return;
    }
    if (mod && e.shiftKey && (e.key === 'h' || e.key === 'H' || e.code === 'KeyH')) {
      e.preventDefault();
      const last = lastColor();
      if (last) this.setColor([b.id], b.color === last ? null : last);
      return;
    }
    if (mod && (e.key === 'd' || e.code === 'KeyD')) {
      e.preventDefault();
      this.duplicate([b.id]);
      return;
    }
    if (mod && e.altKey && /^Digit[0-9]$/.test(e.code)) {
      e.preventDefault();
      const map = { 0: 'p', 1: 'h1', 2: 'h2', 3: 'h3', 4: 'todo', 5: 'ul', 6: 'ol', 7: 'toggle', 8: 'code' };
      const ty = map[e.code.slice(-1)];
      if (ty) {
        this.checkpoint();
        this.changeType(b, ty);
      }
      return;
    }
    if (mod && e.key === 'Enter' && !e.shiftKey) {
      const i = this.index(b.id);
      const next = this.blocks[i + 1];
      const hasKids = !!(next && (next.indent || 0) > (b.indent || 0));
      if (b.type === 'toggle' || (hasKids && b.type !== 'todo')) {
        e.preventDefault();
        this.toggleCollapse(b);
        return;
      }
      if (b.type === 'todo') {
        e.preventDefault();
        this.toggleCheck(b);
        return;
      }
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      this.selectBlocks([b.id]);
      return;
    }
    if (mod && (e.key === 'a' || e.code === 'KeyA')) {
      const r = getRange();
      const full = !t.textContent.length || (r && r.toString().length >= t.textContent.length);
      if (full) {
        e.preventDefault();
        this.selectBlocks(this.blocks.filter((x) => !this.nodes.get(x.id).classList.contains('is-hidden')).map((x) => x.id));
      }
      return;
    }

    if (b.type === 'code') {
      this.onCodeKey(e, b, t);
      return;
    }

    // форматирование
    if (mod && !e.altKey) {
      const k = e.key.toLowerCase();
      const code = e.code;
      if (k === 'b' || code === 'KeyB') return this.fmt(e, 'bold');
      if (k === 'i' || code === 'KeyI') return this.fmt(e, 'italic');
      if (k === 'u' || code === 'KeyU') return this.fmt(e, 'underline');
      if ((k === 's' || code === 'KeyS' || k === 'x' || code === 'KeyX') && e.shiftKey) return this.fmt(e, 'strikeThrough');
      if (k === 'e' || code === 'KeyE') {
        e.preventDefault();
        this.toolbar.toggleCode();
        return;
      }
      if (k === 'k' || code === 'KeyK') {
        e.preventDefault();
        this.toolbar.openLink();
        return;
      }
    }

    switch (e.key) {
      case 'Enter':
        if (e.shiftKey) return; // перенос строки внутри блока
        e.preventDefault();
        this.handleEnter(b, t, false);
        return;
      case 'Backspace':
        if (caretAtStart(t)) {
          e.preventDefault();
          this.handleBackspaceAtStart(b, t);
        }
        return;
      case 'Delete':
        if (caretAtEnd(t)) {
          e.preventDefault();
          this.handleDeleteAtEnd(b, t);
        }
        return;
      case 'Tab':
        e.preventDefault();
        this.indent([b.id], e.shiftKey ? -1 : 1);
        return;
      case 'ArrowUp':
        if (e.shiftKey) {
          if (caretOnFirstLine(t) && caretAtStart(t)) {
            e.preventDefault();
            const pi = this.visibleIndex(this.index(b.id), -1);
            this.selectRange(b.id, pi >= 0 ? this.blocks[pi].id : b.id);
          }
          return;
        }
        if (caretOnFirstLine(t)) {
          e.preventDefault();
          this.moveFocus(b, -1, { x: caretRect() ? caretRect().left : 0, line: 'last' });
        }
        return;
      case 'ArrowDown':
        if (e.shiftKey) {
          if (caretOnLastLine(t) && caretAtEnd(t)) {
            e.preventDefault();
            const ni = this.visibleIndex(this.index(b.id), 1);
            this.selectRange(b.id, ni >= 0 ? this.blocks[ni].id : b.id);
          }
          return;
        }
        if (caretOnLastLine(t)) {
          e.preventDefault();
          this.moveFocus(b, 1, { x: caretRect() ? caretRect().left : 0, line: 'first' });
        }
        return;
      case 'ArrowLeft':
        if (!e.shiftKey && caretAtStart(t)) {
          e.preventDefault();
          this.moveFocus(b, -1, 'end');
        }
        return;
      case 'ArrowRight':
        if (!e.shiftKey && caretAtEnd(t)) {
          e.preventDefault();
          this.moveFocus(b, 1, 'start');
        }
        return;
    }
  }

  fmt(e, cmd) {
    e.preventDefault();
    this.toolbar.exec(cmd);
  }

  onCodeKey(e, b, t) {
    if (e.key === 'Enter' && (modKey(e) || e.shiftKey)) {
      e.preventDefault();
      this.insertAfter(b, newBlock('p'), true);
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      // сохраняем отступ текущей строки
      const before = textBeforeCaret(t);
      const line = before.slice(before.lastIndexOf('\n') + 1);
      const ws = (line.match(/^[ \t]*/) || [''])[0];
      document.execCommand('insertText', false, '\n' + ws);
      return;
    }
    if (e.key === 'Tab') {
      e.preventDefault();
      if (!e.shiftKey) document.execCommand('insertText', false, '  ');
      return;
    }
    if (e.key === 'Backspace' && !t.textContent.length) {
      e.preventDefault();
      this.checkpoint();
      this.changeType(b, 'p');
      return;
    }
    if (e.key === 'ArrowUp' && caretOnFirstLine(t)) {
      e.preventDefault();
      this.moveFocus(b, -1, 'end');
      return;
    }
    if (e.key === 'ArrowDown' && caretOnLastLine(t)) {
      e.preventDefault();
      const ni = this.visibleIndex(this.index(b.id), 1);
      if (ni < 0) this.insertAfter(b, newBlock('p'), true);
      else this.moveFocus(b, 1, 'start');
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      this.selectBlocks([b.id]);
    }
  }

  moveFocus(b, dir, pos) {
    const i = this.visibleIndex(this.index(b.id), dir);
    if (i < 0) {
      if (dir < 0 && this.opts.onExitTop) this.opts.onExitTop();
      return;
    }
    const nb = this.blocks[i];
    if (isEditable(nb)) this.focusBlock(nb.id, pos);
    else this.selectBlocks([nb.id]);
  }

  // ---------- клавиатура в режиме выделения блоков ----------
  onSelectionKey(e) {
    const mod = modKey(e);
    const sel = this.selectedInOrder();
    if (!sel.length) return;
    const first = sel[0];
    const last = sel[sel.length - 1];
    switch (e.key) {
      case 'Escape':
        e.preventDefault();
        this.clearSelection();
        this.root.blur();
        return;
      case 'ArrowUp':
      case 'ArrowDown': {
        e.preventDefault();
        if ((e.altKey || mod) && e.shiftKey) {
          this.moveBlocks(sel.map((b) => b.id), e.key === 'ArrowUp' ? -1 : 1);
          return;
        }
        const dir = e.key === 'ArrowUp' ? -1 : 1;
        if (e.shiftKey) {
          const hi = this.visibleIndex(this.index(this.selHead), dir);
          if (hi >= 0) {
            const anchor = this.selAnchor;
            this.selectRange(anchor, this.blocks[hi].id);
          }
          return;
        }
        const from = dir < 0 ? first : last;
        const i = this.visibleIndex(this.index(from.id), dir);
        if (i >= 0) this.selectBlocks([this.blocks[i].id]);
        return;
      }
      case 'Enter': {
        e.preventDefault();
        if (sel.length === 1 && isEditable(first)) this.focusBlock(first.id, 'end');
        else if (sel.length === 1 && first.type === 'page') this.opts.openPage && this.opts.openPage(first.pageId);
        else this.insertAfter(last, newBlock('p'), true);
        return;
      }
      case 'Backspace':
      case 'Delete':
        e.preventDefault();
        this.deleteBlocks(sel.map((b) => b.id));
        return;
      case 'Tab':
        e.preventDefault();
        this.indent(sel.map((b) => b.id), e.shiftKey ? -1 : 1);
        return;
    }
    if (mod && e.shiftKey && (e.key === 'h' || e.key === 'H' || e.code === 'KeyH')) {
      e.preventDefault();
      const last = lastColor();
      if (last) this.setColor(sel.map((b) => b.id), last);
      return;
    }
    if (mod && (e.key === 'd' || e.code === 'KeyD')) {
      e.preventDefault();
      this.duplicate(sel.map((b) => b.id));
      return;
    }
    if (mod && (e.key === 'a' || e.code === 'KeyA')) {
      e.preventDefault();
      this.selectBlocks(this.blocks.map((b) => b.id));
      return;
    }
    if (e.key === ' ' && sel.length === 1 && first.type === 'todo') {
      e.preventDefault();
      this.toggleCheck(first);
    }
  }

  // ---------- Enter / Backspace / Delete ----------
  handleEnter(b, t) {
    if (this.slash) this.closeSlash();
    if (b.type === 'code') {
      document.execCommand('insertText', false, '\n');
      return;
    }
    const i = this.index(b.id);
    const text = t.textContent;
    const emptyText = !text.length && !t.querySelector('img');
    if (emptyText && (LIST_TYPES.has(b.type) || b.type === 'quote' || b.type === 'callout')) {
      this.checkpoint();
      if (b.indent) {
        b.indent--;
        if (!b.indent) delete b.indent;
        this.applyIndentStyle(b);
      } else {
        this.changeType(b, 'p', { focus: false });
      }
      this.focusBlock(b.id, 'start');
      this.updateStructure();
      this.changed();
      return;
    }
    this.checkpoint();
    if (caretAtStart(t) && text.length) {
      const nb = newBlock(LIST_TYPES.has(b.type) && b.type !== 'toggle' ? b.type : 'p', b.indent ? { indent: b.indent } : {});
      this.blocks.splice(i, 0, nb);
      this.insertNodeAt(i, nb);
      this.updateStructure();
      this.focusBlock(b.id, 'start');
      this.changed();
      return;
    }
    const [before, after] = splitAtCaret(t);
    b.html = before;
    t.innerHTML = before;
    let type = LIST_TYPES.has(b.type) && b.type !== 'toggle' ? b.type : 'p';
    let indent = b.indent || 0;
    let at = i + 1;
    if (b.type === 'toggle') {
      if (b.open) {
        indent += 1;
      } else {
        type = 'toggle';
        at = this.subtreeEnd(i);
      }
    } else if (this.isClosed(i)) {
      at = this.subtreeEnd(i);
    }
    const props = { html: after };
    if (indent) props.indent = Math.min(MAX_INDENT, indent);
    if (type === 'toggle') props.open = false;
    const nb = newBlock(type, props);
    this.blocks.splice(at, 0, nb);
    this.insertNodeAt(at, nb);
    this.updateStructure();
    this.focusBlock(nb.id, 'start');
    this.changed();
  }

  handleBackspaceAtStart(b, t) {
    if (this.slash) this.closeSlash();
    if (b.type !== 'p' && isText(b)) {
      this.checkpoint();
      this.changeType(b, 'p', { focus: false });
      this.focusBlock(b.id, 'start');
      this.changed();
      return;
    }
    if (b.indent) {
      this.checkpoint();
      b.indent--;
      if (!b.indent) delete b.indent;
      this.applyIndentStyle(b);
      this.updateStructure();
      this.changed();
      return;
    }
    const i = this.index(b.id);
    const pi = this.visibleIndex(i, -1);
    if (pi < 0) {
      if (!t.textContent.length && this.blocks.length > 1) {
        this.checkpoint();
        this.removeAt(i);
        this.focusBlock(this.blocks[0].id, 'start');
        this.changed();
      }
      return;
    }
    const prev = this.blocks[pi];
    if (isText(prev)) {
      this.checkpoint();
      const pe = this.editableOf(prev.id);
      const off = pe.textContent.length;
      prev.html = cleanEdge(pe.innerHTML) + (b.html || '');
      pe.innerHTML = prev.html;
      this.removeAt(i);
      this.focusBlock(prev.id, off);
      this.updateStructure();
      this.changed();
    } else if (prev.type === 'code') {
      this.checkpoint();
      const off = prev.text.length;
      prev.text += htmlToText(b.html || '');
      this.replaceNode(prev);
      this.removeAt(i);
      this.focusBlock(prev.id, off);
      this.changed();
    } else {
      if (!t.textContent.length) {
        this.checkpoint();
        this.removeAt(i);
        this.changed();
      }
      this.selectBlocks([prev.id]);
    }
  }

  handleDeleteAtEnd(b, t) {
    const i = this.index(b.id);
    const ni = this.visibleIndex(i, 1);
    if (ni < 0) return;
    const next = this.blocks[ni];
    if (isText(next)) {
      this.checkpoint();
      const off = t.textContent.length;
      b.html = cleanEdge(t.innerHTML) + (next.html || '');
      t.innerHTML = b.html;
      this.removeAt(ni);
      setCaretOffset(t, off);
      this.updateStructure();
      this.changed();
    } else if (!t.textContent.length) {
      this.checkpoint();
      this.removeAt(i);
      this.selectBlocks([next.id]);
      this.changed();
    }
  }

  // ---------- markdown-сокращения ----------
  tryMarkdownShortcut(b, t) {
    if (b.type !== 'p' && !(b.type === 'ul' || b.type === 'ol')) return false;
    const before = textBeforeCaret(t).replace(/ /g, ' ');
    const map = [
      [/^#\s$/, 'h1'], [/^##\s$/, 'h2'], [/^###\s$/, 'h3'], [/^[-*+•]\s$/, 'ul'], [/^1[.)]\s$/, 'ol'],
      [/^\[\s?\]\s$/, 'todo'], [/^\[x\]\s$/i, 'todo-x'], [/^>\s$/, 'quote'], [/^```\s$/, 'code'], [/^"\s$/, 'quote'],
    ];
    for (const [re, type] of map) {
      if (!re.test(before)) continue;
      if (b.type !== 'p' && type !== 'todo' && type !== 'todo-x') return false;
      // состояние до ввода префикса уже записано в историю
      deleteRange(t, 0, before.length);
      b.html = cleanEdge(t.innerHTML);
      if (type === 'code') {
        this.changeType(b, 'code');
      } else if (type === 'todo-x') {
        this.changeType(b, 'todo', { focus: false });
        b.checked = true;
        this.replaceNode(b);
        this.focusBlock(b.id, 'start');
      } else {
        this.changeType(b, type, { focus: false });
        this.focusBlock(b.id, 'start');
      }
      this.changed();
      return true;
    }
    return false;
  }

  convertToDivider(b) {
    const i = this.index(b.id);
    const hr = newBlock('hr');
    this.blocks.splice(i, 1, hr);
    this.nodes.get(b.id).remove();
    this.nodes.delete(b.id);
    this.insertNodeAt(i, hr);
    const p = newBlock('p');
    this.blocks.splice(i + 1, 0, p);
    this.insertNodeAt(i + 1, p);
    this.updateStructure();
    this.focusBlock(p.id, 'start');
    this.changed();
  }

  // ---------- структурные операции ----------
  applyIndentStyle(b) {
    const n = this.nodes.get(b.id);
    if (!n) return;
    if (b.indent) n.style.setProperty('--indent', b.indent);
    else n.style.removeProperty('--indent');
  }

  removeAt(i) {
    const b = this.blocks[i];
    this.blocks.splice(i, 1);
    const n = this.nodes.get(b.id);
    if (n) n.remove();
    this.nodes.delete(b.id);
    this.selected.delete(b.id);
  }

  insertAfter(b, nb, focus = true) {
    this.checkpoint();
    const i = b ? this.index(b.id) : this.blocks.length - 1;
    const at = b && this.isClosed(i) ? this.subtreeEnd(i) : i + 1;
    if (b && b.indent && !nb.indent) nb.indent = b.indent;
    this.blocks.splice(at, 0, nb);
    this.insertNodeAt(at, nb);
    this.updateStructure();
    if (focus) this.focusBlock(nb.id, 'start');
    this.changed();
    return nb;
  }

  insertAtStart() {
    this.checkpoint();
    const nb = newBlock('p');
    this.blocks.unshift(nb);
    this.insertNodeAt(0, nb);
    this.updateStructure();
    this.focusBlock(nb.id, 'start');
    this.changed();
  }

  insertBlocksAt(at, list) {
    for (let k = 0; k < list.length; k++) {
      this.blocks.splice(at + k, 0, list[k]);
      this.insertNodeAt(at + k, list[k]);
    }
    this.updateStructure();
  }

  changeType(b, type, opts = {}) {
    if (b.type === type) return;
    const wasText = isText(b);
    if (type === 'code') {
      delete b.color;
      b.text = wasText ? htmlToText(b.html || '') : b.text || '';
      b.lang = b.lang || 'plain';
      delete b.html;
    } else if (TEXT_TYPES.has(type)) {
      if (b.type === 'code') {
        b.html = escapeHtml(b.text || '').replace(/\n/g, '<br>');
        delete b.text;
        delete b.lang;
      }
      if (typeof b.html !== 'string') b.html = '';
    }
    b.type = type;
    if (type !== 'todo') delete b.checked;
    else if (b.checked === undefined) b.checked = false;
    if (type !== 'toggle') delete b.open;
    else if (b.open === undefined) b.open = true;
    if (type !== 'callout') delete b.icon;
    else if (!b.icon) b.icon = '💡';
    this.replaceNode(b);
    this.updateStructure();
    if (opts.focus !== false) this.focusBlock(b.id, 'end');
    this.changed();
  }

  turnInto(ids, type) {
    this.checkpoint();
    for (const id of ids) {
      const b = this.block(id);
      if (b && (isText(b) || b.type === 'code')) this.changeType(b, type, { focus: false });
    }
    if (ids.length === 1) this.focusBlock(ids[0], 'end');
  }

  indent(ids, delta) {
    this.checkpoint();
    let changed = false;
    for (const id of ids) {
      const i = this.index(id);
      const b = this.blocks[i];
      const prev = i > 0 ? this.blocks[i - 1] : null;
      const max = prev ? Math.min(MAX_INDENT, (prev.indent || 0) + 1) : 0;
      const cur = b.indent || 0;
      const nv = clamp(cur + delta, 0, delta > 0 ? max : MAX_INDENT);
      if (nv !== cur) {
        if (nv) b.indent = nv;
        else delete b.indent;
        this.applyIndentStyle(b);
        changed = true;
      }
    }
    if (!changed) {
      this.undoStack.pop();
      return;
    }
    // если блок попал внутрь свёрнутого пункта или закрытого раскрывающегося блока — раскрываем его
    for (const id of ids) {
      const i = this.index(id);
      const ind = this.blocks[i].indent || 0;
      for (let j = i - 1; j >= 0; j--) {
        const pb = this.blocks[j];
        if ((pb.indent || 0) < ind) {
          if (pb.collapsed) delete pb.collapsed;
          if (pb.type === 'toggle' && !pb.open) {
            pb.open = true;
            this.replaceNode(pb);
          }
          break;
        }
      }
    }
    this.updateStructure();
    this.changed();
  }

  deleteBlocks(ids) {
    if (!ids.length) return;
    this.checkpoint();
    const firstIdx = Math.min(...ids.map((id) => this.index(id)));
    for (const id of ids) {
      const i = this.index(id);
      if (i >= 0) this.removeAt(i);
    }
    this.selected.clear();
    if (!this.blocks.length) {
      const p = newBlock('p');
      this.blocks.push(p);
      this.insertNodeAt(0, p);
    }
    this.updateStructure();
    const target = this.blocks[Math.max(0, Math.min(firstIdx - 1, this.blocks.length - 1))];
    if (isEditable(target)) this.focusBlock(target.id, 'end');
    else this.selectBlocks([target.id]);
    this.changed();
  }

  duplicate(ids) {
    this.checkpoint();
    const sel = this.blocks.filter((b) => ids.includes(b.id));
    if (!sel.length) return;
    const lastIdx = this.index(sel[sel.length - 1].id);
    const copies = cloneBlocks(sel.map(stripTransient));
    this.insertBlocksAt(lastIdx + 1, copies);
    this.selectBlocks(copies.map((b) => b.id));
    this.changed();
  }

  /** Перемещает группу блоков (вместе с вложенными) на одну позицию вверх/вниз. */
  moveBlocks(ids, dir) {
    const sel = this.blocks.filter((b) => ids.includes(b.id));
    if (!sel.length) return;
    let start = this.index(sel[0].id);
    let end = this.index(sel[sel.length - 1].id) + 1;
    if (sel.length === 1) end = this.subtreeEnd(start);
    if (dir < 0) {
      if (start === 0) return;
      // встаём перед предыдущим блоком того же или меньшего уровня
      let target = start - 1;
      const ind = this.blocks[start].indent || 0;
      while (target > 0 && (this.blocks[target].indent || 0) > ind) target--;
      this.moveRange(start, end, target);
    } else {
      if (end >= this.blocks.length) return;
      const after = this.subtreeEnd(end);
      this.moveRange(start, end, after);
    }
  }

  moveRange(start, end, target) {
    this.checkpoint();
    const focus = this.focusState();
    const group = this.blocks.splice(start, end - start);
    const at = target > start ? target - group.length : target;
    this.blocks.splice(at, 0, ...group);
    // корректируем уровень вложенности первого блока группы
    const prev = this.blocks[at - 1];
    const maxInd = prev ? (prev.indent || 0) + 1 : 0;
    const shift = Math.min(0, maxInd - (group[0].indent || 0));
    if (shift) {
      for (const b of group) {
        const v = Math.max(0, (b.indent || 0) + shift);
        if (v) b.indent = v;
        else delete b.indent;
      }
    }
    this.renderAll();
    if (focus && focus.sel) this.selectBlocks(focus.sel);
    else if (focus && focus.id) this.focusBlock(focus.id, focus.offset == null ? 'end' : focus.offset);
    this.changed();
  }

  toggleCheck(b) {
    this.checkpoint();
    b.checked = !b.checked;
    const n = this.nodes.get(b.id);
    n.classList.toggle('is-checked', b.checked);
    const cb = n.querySelector('.blk-check');
    if (cb) cb.checked = b.checked;
    this.changed();
  }

  // ---------- клики ----------
  onClick(e) {
    const t = e.target;
    const actionEl = t.closest('[data-action]');
    const b = this.blockFromNode(t);
    if (e.target === this.tail || (e.target === this.root && e.clientY > (this.root.lastElementChild ? this.root.lastElementChild.getBoundingClientRect().top : 0))) {
      this.clickBelow();
      return;
    }
    if (!b) return;
    const action = actionEl ? actionEl.dataset.action : null;
    switch (action) {
      case 'add': {
        e.preventDefault();
        const text = this.editableOf(b.id);
        if (b.type === 'p' && text && !text.textContent.length) {
          this.focusBlock(b.id, 'start');
          document.execCommand('insertText', false, '/');
        } else {
          const nb = this.insertAfter(b, newBlock('p', b.indent ? { indent: b.indent } : {}));
          const te = this.editableOf(nb.id);
          te.focus();
          document.execCommand('insertText', false, '/');
        }
        return;
      }
      case 'handle':
        // открывается по pointerup без перетаскивания (см. dnd)
        e.preventDefault();
        return;
      case 'toggle':
        e.preventDefault();
        this.toggleCollapse(b);
        return;
      case 'collapse':
        e.preventDefault();
        this.toggleCollapse(b);
        return;
      case 'callout-icon':
        e.preventDefault();
        if (this.opts.pickEmoji) {
          this.opts.pickEmoji(actionEl, (emoji) => {
            this.checkpoint();
            b.icon = emoji || '💡';
            actionEl.textContent = b.icon;
            this.changed();
          });
        }
        return;
      case 'open-page':
        e.preventDefault();
        if (this.opts.openPage) this.opts.openPage(b.pageId);
        return;
      case 'code-copy': {
        e.preventDefault();
        const txt = b.text || '';
        const done = () => this.opts.toast && this.opts.toast('Код скопирован');
        if (navigator.clipboard) navigator.clipboard.writeText(txt).then(done, () => {});
        return;
      }
    }
    if (t.closest('a.bookmark')) {
      // ссылка открывается в новой вкладке; на сенсорных экранах сначала выделяем блок
      if (isTouch && !this.selected.has(b.id)) {
        e.preventDefault();
        this.selectBlocks([b.id]);
      }
      return;
    }
    if (isAtom(b) && !t.closest('[contenteditable="true"]') && !t.closest('select')) {
      e.preventDefault();
      this.selectBlocks([b.id]);
    }
  }

  clickBelow() {
    const last = this.blocks[this.blocks.length - 1];
    if (last && last.type === 'p' && !last.html) this.focusBlock(last.id, 'start');
    else this.insertAfter(this.blocks[this.blocks.length - 1], newBlock('p'), true);
  }

  onChangeEvt(e) {
    const t = e.target;
    const b = this.blockFromNode(t);
    if (!b) return;
    if (t.classList.contains('blk-check')) {
      b.checked = !t.checked; // toggleCheck инвертирует
      this.toggleCheck(b);
      return;
    }
    if (t.classList.contains('code-lang')) {
      this.checkpoint();
      b.lang = t.value;
      const c = this.editableOf(b.id);
      c.dataset.lang = b.lang;
      c.innerHTML = codeHtml(b.text, b.lang);
      this.changed();
    }
  }

  // ---------- перетаскивание блоков и выделение рамкой ----------
  onPointerDown(e) {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    const handle = e.target.closest('[data-action="handle"]');
    const resize = e.target.closest('[data-action="img-resize"]');
    if (resize) {
      e.preventDefault();
      this.startImageResize(e, this.blockFromNode(resize), resize);
      return;
    }
    if (handle) {
      e.preventDefault();
      this.startDrag(e, this.blockFromNode(handle), handle);
      return;
    }
    // выделение нескольких блоков протягиванием мыши из текста за пределы блока
    if (e.pointerType === 'mouse') {
      const b = this.blockFromNode(e.target);
      const onEditor = e.target === this.root || e.target === this.tail;
      if (!b && !onEditor) return;
      const startId = b ? b.id : null;
      const startY = e.clientY;
      let mode = null;
      const move = (ev) => {
        if (!(ev.buttons & 1)) return up();
        const under = this.blockAtY(ev.clientY);
        if (!under) return;
        if (!mode) {
          if ((startId && under.id !== startId) || (!startId && Math.abs(ev.clientY - startY) > 6)) mode = 'blocks';
          else return;
        }
        const from = startId || this.blockAtY(startY)?.id || under.id;
        window.getSelection().removeAllRanges();
        this.selectRange(from, under.id);
      };
      const up = () => {
        document.removeEventListener('pointermove', move);
        document.removeEventListener('pointerup', up);
      };
      document.addEventListener('pointermove', move);
      document.addEventListener('pointerup', up);
    }
  }

  blockAtY(y) {
    let best = null;
    for (const b of this.blocks) {
      const n = this.nodes.get(b.id);
      if (!n || n.classList.contains('is-hidden')) continue;
      const r = n.getBoundingClientRect();
      if (y < r.top) return best || b;
      best = b;
      if (y <= r.bottom) return b;
    }
    return best;
  }

  startDrag(e, b, handle) {
    if (!b) return;
    const startX = e.clientX;
    const startY = e.clientY;
    let dragging = false;
    let ghost = null;
    let line = null;
    let drop = null;
    let scrollTimer = null;
    const pointerId = e.pointerId;
    try {
      handle.setPointerCapture(pointerId);
    } catch (err) {
      /* ignore */
    }
    const ids = this.selected.has(b.id) ? this.selectedInOrder().map((x) => x.id) : null;
    const begin = () => {
      dragging = true;
      document.body.classList.add('is-dragging');
      const groupIds = ids || this.groupIds(b.id);
      groupIds.forEach((id) => this.nodes.get(id)?.classList.add('is-dragged'));
      ghost = el('div', { class: 'drag-ghost' });
      const src = this.nodes.get(b.id).querySelector('.blk-body');
      ghost.append(src.cloneNode(true));
      if (groupIds.length > 1) ghost.append(el('span', { class: 'drag-count' }, `+${groupIds.length - 1}`));
      document.body.append(ghost);
      line = el('div', { class: 'drop-line' });
      document.body.append(line);
      this.dragIds = groupIds;
    };
    const move = (ev) => {
      if (ev.pointerId !== pointerId) return;
      if (!dragging) {
        if (Math.hypot(ev.clientX - startX, ev.clientY - startY) < 5) return;
        begin();
      }
      ev.preventDefault();
      ghost.style.transform = `translate(${ev.clientX + 12}px, ${ev.clientY - 14}px)`;
      drop = this.dropTarget(ev.clientY, this.dragIds, ev.clientX - startX, this.block(this.dragIds[0]).indent || 0);
      if (drop) {
        const rr = this.root.getBoundingClientRect();
        line.style.display = 'block';
        line.classList.toggle('is-nest', !!drop.nest);
        line.style.top = `${drop.y - 1}px`;
        line.style.left = `${rr.left + drop.indentPx}px`;
        line.style.width = `${rr.width - drop.indentPx}px`;
      } else line.style.display = 'none';
      // автопрокрутка у края экрана
      clearInterval(scrollTimer);
      const vh = window.innerHeight;
      const edge = 60;
      const scroller = this.opts.scroller || document.scrollingElement;
      if (ev.clientY < edge || ev.clientY > vh - edge) {
        const d = ev.clientY < edge ? -12 : 12;
        scrollTimer = setInterval(() => scroller.scrollBy(0, d), 16);
      }
    };
    const up = (ev) => {
      if (ev.pointerId !== pointerId) return;
      handle.removeEventListener('pointermove', move);
      handle.removeEventListener('pointerup', up);
      handle.removeEventListener('pointercancel', up);
      clearInterval(scrollTimer);
      if (!dragging) {
        if (ev.type === 'pointerup') this.openBlockMenu(b.id, handle);
        return;
      }
      document.body.classList.remove('is-dragging');
      ghost.remove();
      line.remove();
      this.root.querySelectorAll('.is-dragged').forEach((n) => n.classList.remove('is-dragged'));
      if (drop && ev.type === 'pointerup') this.dropGroup(this.dragIds, drop.index, drop.level);
      this.dragIds = null;
    };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up);
    handle.addEventListener('pointercancel', up);
  }

  // ---------- перетаскивание строки на телефоне: зажать и тянуть ----------
  onTouchStart(e) {
    if (this.ro || e.touches.length !== 1 || this.touchDrag) return;
    const t = e.target;
    if (t.closest('button, a, input, textarea, select, [data-action], .img-resize, .tbl-wrap')) return;
    const b = this.blockFromNode(t);
    if (!b) return;
    // в строке, которую сейчас редактируют, долгое нажатие оставляем для выделения текста
    const ae = document.activeElement;
    if (ae && ae.isContentEditable && ae.contains(t) && this.root.contains(ae)) return;
    const touch = e.touches[0];
    const st = { b, x: touch.clientX, y: touch.clientY, active: false, drop: null, ghost: null, line: null, scrollTimer: null };
    this.touchDrag = st;
    const cleanup = () => {
      clearTimeout(st.timer);
      clearInterval(st.scrollTimer);
      document.removeEventListener('touchmove', move, { passive: false });
      document.removeEventListener('touchend', end);
      document.removeEventListener('touchcancel', end);
      document.removeEventListener('contextmenu', noMenu, true);
      document.body.classList.remove('is-dragging', 'is-touch-drag');
      if (st.ghost) st.ghost.remove();
      if (st.line) st.line.remove();
      this.root.querySelectorAll('.is-dragged, .is-touch-src').forEach((n) => n.classList.remove('is-dragged', 'is-touch-src'));
      this.touchDrag = null;
    };
    const noMenu = (ev) => ev.preventDefault();
    const begin = () => {
      st.active = true;
      const ids = this.selected.has(b.id) ? this.selectedInOrder().map((x) => x.id) : this.groupIds(b.id);
      st.ids = ids;
      this.dragIds = ids;
      if (navigator.vibrate) navigator.vibrate(12);
      const sel = window.getSelection();
      if (sel) sel.removeAllRanges();
      document.body.classList.add('is-dragging', 'is-touch-drag');
      ids.forEach((id) => this.nodes.get(id)?.classList.add('is-touch-src'));
      st.ghost = el('div', { class: 'drag-ghost is-touch' });
      st.ghost.append(this.nodes.get(b.id).querySelector('.blk-body').cloneNode(true));
      if (ids.length > 1) st.ghost.append(el('span', { class: 'drag-count' }, `+${ids.length - 1}`));
      document.body.append(st.ghost);
      st.line = el('div', { class: 'drop-line' });
      document.body.append(st.line);
      place(st.x, st.y);
    };
    const place = (x, y) => {
      st.ghost.style.transform = `translate(${Math.max(8, x - 40)}px, ${y - 46}px)`;
      st.drop = this.dropTarget(y, st.ids, x - st.x, this.block(st.ids[0]).indent || 0);
      if (st.drop) {
        const rr = this.root.getBoundingClientRect();
        st.line.style.display = 'block';
        st.line.classList.toggle('is-nest', !!st.drop.nest);
        st.line.style.top = `${st.drop.y - 1}px`;
        st.line.style.left = `${rr.left + st.drop.indentPx}px`;
        st.line.style.width = `${rr.width - st.drop.indentPx}px`;
      } else st.line.style.display = 'none';
      clearInterval(st.scrollTimer);
      const vv = window.visualViewport;
      const top = vv ? vv.offsetTop : 0;
      const bottom = vv ? vv.offsetTop + vv.height : window.innerHeight;
      const scroller = this.opts.scroller || this.root.closest('.scroller') || document.scrollingElement;
      if (y < top + 70 || y > bottom - 70) {
        const d = y < top + 70 ? -10 : 10;
        st.scrollTimer = setInterval(() => {
          scroller.scrollBy(0, d);
          if (st.active) place(st.lx, st.ly);
        }, 16);
      }
    };
    const move = (ev) => {
      const p = ev.touches[0];
      if (!p) return;
      if (!st.active) {
        // палец сдвинулся до срабатывания — это прокрутка, а не перетаскивание
        if (Math.hypot(p.clientX - st.x, p.clientY - st.y) > 10) cleanup();
        return;
      }
      ev.preventDefault();
      st.lx = p.clientX;
      st.ly = p.clientY;
      clearInterval(st.scrollTimer);
      place(p.clientX, p.clientY);
    };
    const end = (ev) => {
      const wasActive = st.active;
      const drop = st.drop;
      const ids = st.ids;
      if (wasActive && ev.cancelable) ev.preventDefault();
      cleanup();
      this.dragIds = null;
      if (wasActive && drop && ev.type === 'touchend') this.dropGroup(ids, drop.index, drop.level);
    };
    document.addEventListener('touchmove', move, { passive: false });
    document.addEventListener('touchend', end);
    document.addEventListener('touchcancel', end);
    document.addEventListener('contextmenu', noMenu, true);
    st.lx = st.x;
    st.ly = st.y;
    st.timer = setTimeout(begin, 380);
  }

  groupIds(id) {
    const i = this.index(id);
    return this.blocks.slice(i, this.subtreeEnd(i)).map((b) => b.id);
  }

  /** Шаг вложенности в пикселях (как в CSS: 1.5em). */
  indentStep() {
    const em = parseFloat(getComputedStyle(this.root).fontSize) || 16;
    return em * 1.5;
  }

  /**
   * Куда упадут перетаскиваемые блоки. dx — сдвиг указателя по горизонтали от начала перетаскивания:
   * вправо от края строки выше — вложить в неё, влево — вынести на уровень выше.
   */
  dropTarget(y, excludeIds, dx = null, baseIndent = 0) {
    const ex = new Set(excludeIds);
    let result = null;
    const visible = this.blocks.map((b, i) => ({ b, i, n: this.nodes.get(b.id) })).filter((x) => x.n && !x.n.classList.contains('is-hidden'));
    for (const { b, i, n } of visible) {
      if (ex.has(b.id)) continue;
      const r = n.getBoundingClientRect();
      const indentPx = n.querySelector('.blk-body').getBoundingClientRect().left - this.root.getBoundingClientRect().left;
      if (y < r.top + r.height / 2) {
        result = { index: i, y: r.top, indentPx };
        break;
      }
      result = { index: this.isClosed(i) ? this.subtreeEnd(i) : i + 1, y: r.bottom, indentPx };
    }
    if (!result || dx === null) return result;
    // строка над местом вставки (без перетаскиваемых)
    let above = null;
    for (let k = result.index - 1; k >= 0; k--) {
      const c = this.blocks[k];
      if (ex.has(c.id)) continue;
      const cn = this.nodes.get(c.id);
      if (cn && cn.classList.contains('is-hidden')) continue;
      above = { b: c, i: k };
      break;
    }
    const step = this.indentStep();
    const maxL = above ? Math.min(MAX_INDENT, (above.b.indent || 0) + (this.isClosed(above.i) ? 0 : 1)) : 0;
    const level = Math.max(0, Math.min(maxL, baseIndent + Math.round(dx / step)));
    result.level = level;
    result.indentPx = level * step;
    result.nest = !!above && level > (above.b.indent || 0);
    return result;
  }

  dropGroup(ids, index, level = null) {
    const start = this.index(ids[0]);
    const end = this.index(ids[ids.length - 1]) + 1;
    const contiguous = end - start === ids.length;
    const first = this.blocks[start];
    const delta = level === null ? 0 : level - (first.indent || 0);
    const shiftIndent = () => {
      for (const id of ids) {
        const x = this.block(id);
        const v = Math.max(0, Math.min(MAX_INDENT, (x.indent || 0) + delta));
        if (v) x.indent = v;
        else delete x.indent;
      }
    };
    if (contiguous) {
      if (index >= start && index <= end) {
        // строку только сдвинули вбок — меняем вложенность на месте
        if (!delta) return;
        this.checkpoint();
        shiftIndent();
        this.renderAll();
        this.selectBlocks(ids);
        this.changed();
        return;
      }
      if (delta) {
        this.checkpoint();
        shiftIndent();
        const group = this.blocks.splice(start, end - start);
        const at = index > start ? index - group.length : index;
        this.blocks.splice(at, 0, ...group);
        this.renderAll();
        this.selectBlocks(ids);
        this.changed();
        return;
      }
      this.moveRange(start, end, index);
      this.selectBlocks(ids);
      return;
    }
    if (delta) shiftIndent();
    this.checkpoint();
    const moving = this.blocks.filter((b) => ids.includes(b.id));
    const targetBlock = this.blocks[index];
    this.blocks = this.blocks.filter((b) => !ids.includes(b.id));
    const at = targetBlock ? this.index(targetBlock.id) : this.blocks.length;
    this.blocks.splice(at, 0, ...moving);
    this.renderAll();
    this.selectBlocks(ids);
    this.changed();
  }

  startImageResize(e, b, handle) {
    if (!b) return;
    const frame = handle.closest('.img-frame');
    const body = handle.closest('.blk-body');
    const bodyRect = body.getBoundingClientRect();
    const center = bodyRect.left + bodyRect.width / 2;
    const pid = e.pointerId;
    handle.setPointerCapture(pid);
    const before = JSON.stringify(this.blocks.map(stripTransient));
    const move = (ev) => {
      const w = clamp(Math.round(((Math.abs(ev.clientX - center) * 2) / bodyRect.width) * 100), 15, 100);
      frame.style.width = b.w ? `min(${w}%, ${b.w}px)` : `${w}%`;
      b.width = w;
    };
    const up = () => {
      handle.removeEventListener('pointermove', move);
      handle.removeEventListener('pointerup', up);
      handle.removeEventListener('pointercancel', up);
      this.undoStack.push({ blocks: before, focus: { sel: [b.id] } });
      this.redoStack = [];
      if (b.width >= 100) delete b.width;
      this.changed();
    };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up);
    handle.addEventListener('pointercancel', up);
  }

  // ---------- таблицы ----------
  onCellKey(e, b, td) {
    const [ri, ci] = td.dataset.cell.split(':').map(Number);
    if (e.key === 'Tab') {
      e.preventDefault();
      const cols = Math.max(...b.rows.map((r) => r.length));
      let r = ri;
      let c = ci + (e.shiftKey ? -1 : 1);
      if (c >= cols) {
        c = 0;
        r++;
      }
      if (c < 0) {
        c = cols - 1;
        r--;
      }
      if (r < 0) return;
      if (r >= b.rows.length) {
        this.tableOp(b, 'addRow', ri);
      }
      this.focusCell(b, r, c);
      return;
    }
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      this.cellNav(b, td, 'down');
      return;
    }
    if (e.key === 'Escape') {
      e.preventDefault();
      this.selectBlocks([b.id]);
      return;
    }
    if (modKey(e) && !e.altKey) {
      const k = e.key.toLowerCase();
      if (k === 'b') return this.fmt(e, 'bold');
      if (k === 'i') return this.fmt(e, 'italic');
      if (k === 'u') return this.fmt(e, 'underline');
    }
  }

  cellNav(b, td, dir) {
    const [ri, ci] = td.dataset.cell.split(':').map(Number);
    if (dir === 'down') {
      if (ri + 1 >= b.rows.length) this.tableOp(b, 'addRow', ri);
      this.focusCell(b, ri + 1, ci);
    }
  }

  focusCell(b, r, c) {
    const n = this.nodes.get(b.id);
    const td = n && n.querySelector(`[data-cell="${r}:${c}"]`);
    if (td) {
      td.focus();
      setCaretOffset(td, 'end');
    }
  }

  tableOp(b, op, ri, ci) {
    this.checkpoint();
    const cols = Math.max(1, ...b.rows.map((r) => r.length));
    b.rows = b.rows.map((r) => {
      const c = r.slice();
      while (c.length < cols) c.push('');
      return c;
    });
    if (op === 'addRow') b.rows.splice(ri + 1, 0, new Array(cols).fill(''));
    if (op === 'addCol') b.rows.forEach((r) => r.splice(ci + 1, 0, ''));
    // ширины колонок двигаются вместе с колонками
    if (Array.isArray(b.widths)) {
      while (b.widths.length < cols) b.widths.push(140);
      if (op === 'addCol') b.widths.splice(ci + 1, 0, 140);
      if (op === 'delCol' && cols > 1) b.widths.splice(ci, 1);
    }
    if (op === 'delRow' && b.rows.length > 1) b.rows.splice(ri, 1);
    if (op === 'delCol' && cols > 1) b.rows.forEach((r) => r.splice(ci, 1));
    if (op === 'header') b.header = b.header === false ? undefined : false;
    if (b.header === undefined) delete b.header;
    this.replaceNode(b);
    this.changed();
  }

  // ---------- цвет блока ----------
  colorMenu(ids, current) {
    const swatch = (c, bg) => () => el('span', { class: `color-swatch${bg ? ' is-bg' : ''} ${c ? 'c-' + c : ''}` }, bg ? '' : 'A');
    const item = (c, label, bg = !!(c && c.endsWith('_background'))) => ({ label, icon: swatch(c, bg), checked: (current || null) === c, onSelect: () => this.setColor(ids, c) });
    const list = [];
    const last = lastColor();
    if (last) {
      list.push({ header: 'Последний использованный' });
      list.push(Object.assign(item(last, colorLabel(last)), { hint: `${isMacPlatform() ? '⌘⇧' : 'Ctrl+Shift+'}H`, checked: false }));
      list.push({ separator: true });
    }
    list.push({ header: 'Цвет текста' });
    list.push(item(null, 'Обычный текст'));
    for (const [c, name] of COLORS) list.push(item(c, `${name} текст`));
    list.push({ separator: true });
    list.push({ header: 'Цвет фона' });
    list.push(Object.assign(item(null, 'Без фона', true), { checked: false }));
    for (const [c, name] of COLORS) list.push(item(`${c}_background`, `${name} фон`));
    return list;
  }

  setColor(ids, color) {
    color = validColor(color);
    const targets = this.blocks.filter((b) => ids.includes(b.id) && isText(b));
    if (!targets.length) return;
    this.checkpoint();
    for (const b of targets) {
      if (color) b.color = color;
      else delete b.color;
      this.replaceNode(b);
    }
    if (color) lastColor(color);
    this.updateStructure();
    this.changed();
  }

  // ---------- меню блока ----------
  openBlockMenu(id, anchor) {
    const b = this.block(id);
    if (!b) return;
    if (!this.selected.has(id)) this.selectBlocks([id]);
    const { items, ids } = this.blockMenuItems(id);
    showMenu({ anchor, items, placement: 'bottom-start', sheetTitle: ids.length > 1 ? `Выбрано блоков: ${ids.length}` : TYPE_LABELS[b.type] });
  }

  /** Пункты меню строки (используются и в меню ⋮⋮, и в нижней панели на телефоне). */
  blockMenuItems(id) {
    const b = this.block(id);
    if (!b) return { items: [], ids: [] };
    const ids = this.selected.has(id) ? this.selectedInOrder().map((x) => x.id) : [id];
    const items = [];
    if (isText(b) && this.toolbar && this.toolbar.ai && !this.ro) {
      const t = this.editableOf(b.id);
      const empty = !(t ? t.textContent : htmlToText(b.html || '')).trim();
      const multi = ids.filter((x) => isText(this.block(x))).length > 1;
      items.push({
        label: multi ? `Спросить ИИ (строк: ${ids.filter((x) => isText(this.block(x))).length})` : empty ? 'Написать с ИИ' : 'Спросить ИИ',
        icon: 'sparkle',
        className: 'menu-ai',
        onSelect: () => (multi ? this.toolbar.ai.openForBlocks(ids) : empty ? this.toolbar.ai.openForEmpty(b.id) : this.toolbar.ai.openForBlock(b.id)),
      }, { separator: true });
    }
    if (isText(b) || b.type === 'code') {
      items.push({
        label: 'Превратить в',
        icon: 'turn',
        submenu: ['p', 'h1', 'h2', 'h3', 'ul', 'ol', 'todo', 'toggle', 'quote', 'callout', 'code'].map((t) => ({
          label: TYPE_LABELS[t],
          icon: TYPE_ICONS[t],
          checked: b.type === t,
          onSelect: () => this.turnInto(ids, t),
        })),
      });
    }
    {
      const bi = this.index(b.id);
      const nb = this.blocks[bi + 1];
      if (isText(b) && b.type !== 'toggle' && nb && (nb.indent || 0) > (b.indent || 0)) {
        items.push({ label: b.collapsed ? 'Развернуть вложенные' : 'Свернуть вложенные', icon: b.collapsed ? 'chevron' : 'chevronDown', hint: `${isMacPlatform() ? '⌘' : 'Ctrl+'}Enter`, onSelect: () => this.toggleCollapse(b) });
      }
    }
    if (isText(b)) {
      items.push({ label: 'Цвет', icon: 'palette', subClass: 'color-menu', submenu: this.colorMenu(ids, b.color) });
    }
    if (b.type === 'image') {
      items.push({ label: 'Заменить изображение', icon: 'image', onSelect: () => this.chooseImage(b, true) });
      if (b.file) items.push({ label: 'Скачать', icon: 'download', onSelect: () => this.opts.downloadFile && this.opts.downloadFile(b.file) });
      items.push({
        label: 'Ширина',
        icon: 'cover',
        submenu: [25, 50, 75, 100].map((w) => ({
          label: `${w}%`,
          checked: (b.width || 100) === w,
          onSelect: () => {
            this.checkpoint();
            if (w === 100) delete b.width;
            else b.width = w;
            this.replaceNode(b);
            this.changed();
          },
        })),
      });
    }
    if (b.type === 'bookmark') {
      items.push({ label: 'Открыть ссылку', icon: 'open', onSelect: () => window.open(b.url, '_blank', 'noopener') });
      items.push({ label: 'Изменить ссылку', icon: 'link', onSelect: () => this.editBookmark(b) });
    }
    if (b.type === 'page') {
      items.push({ label: 'Открыть страницу', icon: 'open', onSelect: () => this.opts.openPage && this.opts.openPage(b.pageId) });
    }
    if (b.type === 'table') {
      const last = this.lastCell && this.lastCell.id === b.id ? this.lastCell : { r: b.rows.length - 1, c: 0 };
      items.push(
        { label: 'Добавить строку', icon: 'plus', onSelect: () => this.tableOp(b, 'addRow', last.r) },
        { label: 'Добавить столбец', icon: 'plus', onSelect: () => this.tableOp(b, 'addCol', 0, last.c) },
        { label: 'Удалить строку', icon: 'x', onSelect: () => this.tableOp(b, 'delRow', last.r) },
        { label: 'Удалить столбец', icon: 'x', onSelect: () => this.tableOp(b, 'delCol', 0, last.c) },
        { label: 'Строка заголовков', icon: 'check', checked: b.header !== false, onSelect: () => this.tableOp(b, 'header') },
      );
    }
    if (items.length) items.push({ separator: true });
    items.push(
      { label: 'Дублировать', icon: 'duplicate', hint: `${isMacPlatform() ? '⌘' : 'Ctrl+'}D`, onSelect: () => this.duplicate(ids) },
      { label: 'Копировать', icon: 'copy', hint: `${isMacPlatform() ? '⌘' : 'Ctrl+'}C`, onSelect: () => this.copyBlocks(ids) },
      { label: 'Переместить вверх', icon: 'arrowUp', hint: 'Alt+Shift+↑', onSelect: () => this.moveBlocks(ids, -1) },
      { label: 'Переместить вниз', icon: 'arrowDown', hint: 'Alt+Shift+↓', onSelect: () => this.moveBlocks(ids, 1) },
      { label: 'Вложить', icon: 'indent', hint: 'Tab', onSelect: () => this.indent(ids, 1) },
      { label: 'Вынести', icon: 'outdent', hint: 'Shift+Tab', onSelect: () => this.indent(ids, -1) },
      { separator: true },
      { label: 'Удалить', icon: 'trash', danger: true, hint: 'Del', onSelect: () => this.deleteBlocks(ids) },
    );
    return { items, ids, b };
  }

  async editBookmark(b) {
    const url = await this.opts.prompt({ title: 'Ссылка-закладка', label: 'Адрес', value: b.url, placeholder: 'https://…' });
    if (!url) return;
    const title = await this.opts.prompt({ title: 'Ссылка-закладка', label: 'Название (необязательно)', value: b.title || '', placeholder: 'Как подписать ссылку', allowEmpty: true });
    this.checkpoint();
    b.url = normalizeUrl(url);
    b.title = title || '';
    this.replaceNode(b);
    this.changed();
  }

  // ---------- меню «/» ----------
  openSlash(b, t, offset) {
    this.closeSlash();
    const menu = el('div', { class: 'menu slash-menu', role: 'listbox' });
    document.body.append(menu);
    this.slash = { b, t, offset, menu, cursor: 0, items: [] };
    this.updateSlash();
  }

  updateSlash() {
    const s = this.slash;
    if (!s) return;
    if (!document.body.contains(s.t)) return this.closeSlash();
    const before = textBeforeCaret(s.t);
    if (before.length <= s.offset || before[s.offset] !== '/') return this.closeSlash();
    const q = before.slice(s.offset + 1).toLowerCase();
    if (q.length > 24 || /\s{2}/.test(q)) return this.closeSlash();
    const items = SLASH_ITEMS.filter((it) => !q || it.label.toLowerCase().includes(q) || it.keys.includes(q) || it.keys.split(' ').some((k) => k.startsWith(q)));
    if (!items.length) {
      if (q.length > 3) return this.closeSlash();
    }
    s.items = items;
    s.cursor = Math.min(s.cursor, Math.max(0, items.length - 1));
    s.menu.textContent = '';
    if (!items.length) s.menu.append(el('div', { class: 'menu-empty' }, 'Ничего не найдено'));
    items.forEach((it, i) => {
      const row = el(
        'button',
        { class: `menu-item${i === s.cursor ? ' is-active' : ''}`, type: 'button', role: 'option', tabindex: '-1' },
        el('span', { class: 'slash-ic' }, icon(SLASH_ICONS[it.type] || 'text', 18)),
        el('span', { class: 'menu-label' }, it.label),
        it.hint ? el('span', { class: 'menu-hint' }, it.hint) : null,
      );
      row.addEventListener('pointerdown', (e) => e.preventDefault());
      row.addEventListener('click', () => {
        s.cursor = i;
        this.slashChoose();
      });
      s.menu.append(row);
    });
    const rect = caretRect() || s.t.getBoundingClientRect();
    positionPopup(s.menu, rect, 'bottom-start', 8);
    if (!this.slashOutside) {
      this.slashOutside = (e) => {
        if (this.slash && !this.slash.menu.contains(e.target)) this.closeSlash();
      };
      document.addEventListener('pointerdown', this.slashOutside, true);
    }
  }

  slashMove(d) {
    const s = this.slash;
    if (!s || !s.items.length) return;
    s.cursor = (s.cursor + d + s.items.length) % s.items.length;
    Array.from(s.menu.children).forEach((c, i) => c.classList.toggle('is-active', i === s.cursor));
    const act = s.menu.children[s.cursor];
    if (act) act.scrollIntoView({ block: 'nearest' });
  }

  closeSlash() {
    if (!this.slash) return;
    this.slash.menu.remove();
    this.slash = null;
    if (this.slashOutside) {
      document.removeEventListener('pointerdown', this.slashOutside, true);
      this.slashOutside = null;
    }
  }

  slashChoose() {
    const s = this.slash;
    if (!s) return;
    const it = s.items[s.cursor];
    const { b, t, offset } = s;
    this.closeSlash();
    if (!it) return;
    t.focus();
    const end = textBeforeCaret(t).length;
    deleteRange(t, offset, end);
    b.html = cleanEdge(t.innerHTML);
    t.innerHTML = b.html;
    setCaretOffset(t, offset);
    this.runCommand(b, it.type);
  }

  /** Выполняет команду вставки для блока b (если b пуст — заменяет его). */
  async runCommand(b, type) {
    const t = this.editableOf(b.id);
    const empty = isText(b) && !(t ? t.textContent : htmlToText(b.html)).trim();
    if (TEXT_TYPES.has(type) || type === 'code') {
      if (empty) {
        this.checkpoint();
        this.changeType(b, type);
      } else {
        this.insertAfter(b, newBlock(type), true);
      }
      return;
    }
    const placeAtom = (atom, withParagraph = true) => {
      this.checkpoint();
      let i = this.index(b.id);
      if (b.indent) atom.indent = b.indent;
      if (empty) {
        this.removeAt(i);
      } else {
        i += 1;
      }
      this.blocks.splice(i, 0, atom);
      this.insertNodeAt(i, atom);
      let focusId = null;
      const next = this.blocks[i + 1];
      if (withParagraph && (!next || !(isText(next) && !next.html))) {
        const p = newBlock('p', atom.indent ? { indent: atom.indent } : {});
        this.blocks.splice(i + 1, 0, p);
        this.insertNodeAt(i + 1, p);
        focusId = p.id;
      } else if (withParagraph && next) focusId = next.id;
      this.updateStructure();
      if (focusId) this.focusBlock(focusId, 'start');
      this.changed();
      return atom;
    };
    switch (type) {
      case 'ai': {
        if (!this.toolbar || !this.toolbar.ai) return;
        let target = b;
        if (!empty || !isText(b)) target = this.insertAfter(b, newBlock('p', b.indent ? { indent: b.indent } : {}), true);
        this.toolbar.ai.openForEmpty(target.id);
        return;
      }
      case 'hr':
        placeAtom(newBlock('hr'));
        return;
      case 'table': {
        const tb = placeAtom(newBlock('table'));
        this.focusCell(tb, 0, 0);
        return;
      }
      case 'image':
        this.chooseImage(b, false, empty);
        return;
      case 'image-url': {
        const url = await this.opts.prompt({ title: 'Изображение по ссылке', label: 'Адрес изображения', placeholder: 'https://example.com/photo.jpg' });
        if (!url) return;
        const img = placeAtom(newBlock('image', { src: normalizeUrl(url) }));
        this.resolveImage(img);
        return;
      }
      case 'bookmark': {
        const url = await this.opts.prompt({ title: 'Ссылка-закладка', label: 'Адрес страницы', placeholder: 'https://…' });
        if (!url) return;
        placeAtom(newBlock('bookmark', { url: normalizeUrl(url), title: '' }));
        return;
      }
      case 'page': {
        if (!this.opts.createSubpage) return;
        const id = await this.opts.createSubpage();
        if (!id) return;
        placeAtom(newBlock('page', { pageId: id }));
        if (this.opts.openPage) this.opts.openPage(id, { fresh: true });
        return;
      }
      case 'link-page': {
        if (!this.opts.pickPage) return;
        const id = await this.opts.pickPage();
        if (!id) return;
        placeAtom(newBlock('page', { pageId: id }));
        return;
      }
    }
  }

  // ---------- изображения ----------
  chooseImage(b, replace, replaceEmpty = false) {
    const input = el('input', { type: 'file', accept: 'image/jpeg,image/png,image/gif,image/webp', multiple: !replace });
    input.style.display = 'none';
    document.body.append(input);
    input.addEventListener('change', () => {
      const files = Array.from(input.files || []);
      input.remove();
      if (!files.length) return;
      if (replace) {
        this.uploadInto(b, files[0]);
      } else {
        let i = this.index(b.id);
        if (replaceEmpty) {
          this.checkpoint();
          this.removeAt(i);
          i -= 1;
        }
        this.insertImageFiles(files, i + 1, b.indent);
      }
    });
    input.click();
  }

  insertImageFiles(files, at, indent) {
    const imgs = files.filter((f) => /^image\/(jpeg|png|gif|webp)$/.test(f.type));
    if (!imgs.length) {
      if (files.length) this.opts.toast && this.opts.toast('Можно вставлять только изображения JPEG, PNG, GIF и WebP', 'error');
      return;
    }
    this.checkpoint();
    const created = imgs.map((f) => newBlock('image', Object.assign({ _local: URL.createObjectURL(f), _uploading: true, _progress: 0 }, indent ? { indent } : {})));
    this.insertBlocksAt(Math.max(0, at), created);
    // после изображения нужен текстовый блок, чтобы продолжить писать
    const lastIdx = this.index(created[created.length - 1].id);
    if (!this.blocks[lastIdx + 1]) {
      const p = newBlock('p');
      this.insertBlocksAt(lastIdx + 1, [p]);
    }
    created.forEach((b, k) => this.uploadInto(b, imgs[k], true));
    this.selectBlocks([created[created.length - 1].id]);
  }

  async uploadInto(b, file, fresh = false) {
    if (!this.opts.upload) return;
    if (!fresh) {
      this.checkpoint();
      b._local = URL.createObjectURL(file);
      b._uploading = true;
      b._progress = 0;
      this.replaceNode(b);
    }
    try {
      const prepared = await prepareImage(file, this.opts.uploadLimit);
      const res = await this.opts.upload(prepared, (p) => {
        b._progress = p;
        const bar = this.nodes.get(b.id)?.querySelector('.img-progress-bar');
        if (bar) bar.style.width = `${p}%`;
      });
      if (!this.block(b.id)) return;
      b.file = res.id;
      b.w = res.width;
      b.h = res.height;
      delete b.src;
      delete b._uploading;
      delete b._progress;
      // освобождаем локальный предпросмотр — дальше показываем копию с сервера
      const local = b._local;
      delete b._local;
      this.replaceNode(b);
      setTimeout(() => URL.revokeObjectURL(local), 5000);
      this.changed();
    } catch (err) {
      const i = this.index(b.id);
      if (i >= 0 && !b.file) this.removeAt(i);
      else if (i >= 0) {
        delete b._uploading;
        delete b._local;
        this.replaceNode(b);
      }
      this.updateStructure();
      this.opts.toast && this.opts.toast(`Изображение не загружено: ${err.message || err}`, 'error');
      this.changed();
    }
  }

  /** Загружает на сервер изображение, пришедшее ссылкой (вставка, импорт). */
  async resolveImage(b) {
    const src = b.src;
    if (!src) return;
    b._uploading = true;
    this.replaceNode(b);
    try {
      let res;
      if (/^(data:|blob:)/.test(src)) {
        const blob = await (await fetch(src)).blob();
        const file = new File([blob], 'image', { type: blob.type });
        res = await this.opts.upload(await prepareImage(file, this.opts.uploadLimit), () => {});
      } else {
        res = await this.opts.fetchImage(src);
      }
      if (!this.block(b.id)) return;
      b.file = res.id;
      b.w = res.width;
      b.h = res.height;
      delete b.src;
      delete b._uploading;
      this.replaceNode(b);
      this.changed();
    } catch (err) {
      const i = this.index(b.id);
      if (i < 0) return;
      delete b._uploading;
      if (/^https?:/.test(src)) {
        // не удалось скачать — оставляем ссылку
        b.type = 'bookmark';
        b.url = src;
        b.title = 'Изображение (не удалось сохранить копию)';
        delete b.src;
        delete b.caption;
        delete b.width;
        this.replaceNode(b);
      } else {
        this.removeAt(i);
      }
      this.updateStructure();
      this.opts.toast && this.opts.toast(`Не удалось сохранить изображение: ${err.message || err}`, 'error');
      this.changed();
    }
  }

  onDragOver(e) {
    if (!e.dataTransfer || !Array.from(e.dataTransfer.types || []).includes('Files')) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    const t = this.dropTarget(e.clientY, []);
    if (!t) return;
    if (!this.fileLine) {
      this.fileLine = el('div', { class: 'drop-line' });
      document.body.append(this.fileLine);
    }
    const rr = this.root.getBoundingClientRect();
    Object.assign(this.fileLine.style, { display: 'block', top: `${t.y - 1}px`, left: `${rr.left}px`, width: `${rr.width}px` });
    this.fileDrop = t;
  }

  hideDropLine() {
    if (this.fileLine) {
      this.fileLine.remove();
      this.fileLine = null;
    }
  }

  onDrop(e) {
    const files = e.dataTransfer ? Array.from(e.dataTransfer.files || []) : [];
    if (!files.length) return;
    e.preventDefault();
    const t = this.fileDrop || this.dropTarget(e.clientY, []);
    this.hideDropLine();
    this.insertImageFiles(files, t ? t.index : this.blocks.length);
  }

  // ---------- буфер обмена ----------
  copyBlocks(ids, cut = false) {
    const list = this.blocks.filter((b) => ids.includes(b.id)).map(stripTransient);
    const json = JSON.stringify(list);
    const html = blocksToHtml(list, this.convertCtx());
    const text = blocksToText(list, this.convertCtx());
    let ok = false;
    const handler = (e) => {
      e.clipboardData.setData('text/plain', text);
      e.clipboardData.setData('text/html', `<meta name="tetrad-blocks" content="1">${html}<!--tetrad:${encodeURIComponent(json)}-->`);
      e.preventDefault();
      ok = true;
    };
    document.addEventListener('copy', handler, { once: true, capture: true });
    try {
      document.execCommand('copy');
    } catch (err) {
      /* ignore */
    }
    document.removeEventListener('copy', handler, true);
    if (!ok && navigator.clipboard) navigator.clipboard.writeText(text).catch(() => {});
    this.clipboardBlocks = json;
    if (cut) this.deleteBlocks(ids);
    this.opts.toast && this.opts.toast(cut ? 'Вырезано' : 'Скопировано');
  }

  convertCtx() {
    return {
      fileUrl: this.ctx.fileUrl,
      pageTitle: (id) => {
        const p = this.ctx.getPage(id);
        return p ? (p.title || 'Без названия') : 'Страница';
      },
    };
  }

  onCopy(e, cut) {
    if (!this.selected.size || !document.activeElement || (document.activeElement !== this.root && !this.root.contains(document.activeElement))) return;
    const sel = window.getSelection();
    if (sel && !sel.isCollapsed && this.root.contains(sel.anchorNode) && sel.anchorNode !== this.root) return;
    const list = this.selectedInOrder().map(stripTransient);
    const json = JSON.stringify(list);
    e.clipboardData.setData('text/plain', blocksToText(list, this.convertCtx()));
    e.clipboardData.setData('text/html', `${blocksToHtml(list, this.convertCtx())}<!--tetrad:${encodeURIComponent(json)}-->`);
    try {
      e.clipboardData.setData(BLOCKS_MIME, json);
    } catch (err) {
      /* браузер может не поддерживать свой тип */
    }
    e.preventDefault();
    if (cut) this.deleteBlocks(list.map((b) => b.id));
  }

  onPaste(e) {
    if (this.ro) return;
    const cd = e.clipboardData;
    if (!cd) return;
    const t = e.target;
    const b = this.selected.size ? this.selectedInOrder().slice(-1)[0] : this.blockFromNode(t);
    if (!b) return;
    // подписи и ячейки — только текст
    if (t && (t.hasAttribute && (t.hasAttribute('data-caption') || t.hasAttribute('data-cell')))) {
      e.preventDefault();
      const html = cd.getData('text/html');
      const txt = cd.getData('text/plain');
      document.execCommand('insertHTML', false, html ? normalizeInline(html) : escapeHtml(txt).replace(/\n/g, '<br>'));
      return;
    }
    if (b.type === 'code' && !this.selected.size) {
      e.preventDefault();
      document.execCommand('insertText', false, cd.getData('text/plain'));
      return;
    }
    const files = Array.from(cd.files || []).filter((f) => f.type.startsWith('image/'));
    if (files.length) {
      e.preventDefault();
      const i = this.index(b.id);
      const empty = isText(b) && !htmlToText(b.html).trim() && !this.selected.size;
      if (empty) {
        this.checkpoint();
        this.removeAt(i);
        this.insertImageFiles(files, i, b.indent);
      } else this.insertImageFiles(files, i + 1, b.indent);
      return;
    }
    let html = cd.getData('text/html');
    const text = cd.getData('text/plain');
    let blocks = null;
    const custom = (() => {
      try {
        return cd.getData(BLOCKS_MIME);
      } catch (err) {
        return '';
      }
    })();
    const marker = html && html.match(/<!--tetrad:([^>]*)-->/);
    if (custom || marker) {
      try {
        blocks = normalizeBlocks(JSON.parse(custom || decodeURIComponent(marker[1]))).map((x) => Object.assign(x, { id: uid() }));
      } catch (err) {
        blocks = null;
      }
    }
    const te = this.selected.size ? null : this.editableOf(b.id);
    if (!blocks && !html && text && isUrl(text.trim()) && te) {
      e.preventDefault();
      const url = normalizeUrl(text.trim());
      const r = getRange();
      if (r && !r.collapsed && selectionInside(te)) {
        document.execCommand('createLink', false, url);
        this.toolbar.fixLinks(te);
      } else {
        document.execCommand('insertHTML', false, `<a href="${escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(text.trim())}</a>&nbsp;`);
      }
      return;
    }
    if (!blocks) {
      if (html) blocks = htmlToBlocks(html);
      else if (text && looksLikeMarkdown(text)) blocks = markdownToBlocks(text);
      else if (text && text.includes('\n')) blocks = plainTextToBlocks(text);
      else if (text) {
        e.preventDefault();
        if (te) document.execCommand('insertText', false, text);
        return;
      } else return;
    }
    e.preventDefault();
    if (!blocks.length) return;
    // одна строка текста — вставляем внутрь текущего блока
    if (blocks.length === 1 && isText(blocks[0]) && blocks[0].type === 'p' && te && !blocks[0].indent) {
      document.execCommand('insertHTML', false, blocks[0].html || '');
      return;
    }
    this.pasteBlocks(b, te, blocks);
  }

  pasteBlocks(b, te, blocks) {
    this.checkpoint();
    let i = this.index(b.id);
    if (te && isText(b)) {
      const empty = !te.textContent.trim();
      if (empty) {
        this.removeAt(i);
        const base = b.indent || 0;
        if (base) blocks.forEach((x) => (x.indent = Math.min(MAX_INDENT, (x.indent || 0) + base)));
        this.insertBlocksAt(i, blocks);
      } else {
        const [before, after] = splitAtCaret(te);
        b.html = before;
        te.innerHTML = before;
        const tail = after.replace(/<br>|\s|&nbsp;/g, '') ? [newBlock(b.type === 'p' || LIST_TYPES.has(b.type) ? b.type : 'p', Object.assign({ html: after }, b.indent ? { indent: b.indent } : {}))] : [];
        this.insertBlocksAt(i + 1, blocks.concat(tail));
      }
    } else {
      this.insertBlocksAt(i + 1, blocks);
    }
    blocks.filter((x) => x.type === 'image' && x.src && !x.file).forEach((x) => this.resolveImage(x));
    const last = blocks[blocks.length - 1];
    if (isEditable(last)) this.focusBlock(last.id, 'end');
    else this.selectBlocks([last.id]);
    this.changed();
  }
}

function stripTransient(b) {
  const c = {};
  for (const [k, v] of Object.entries(b)) if (!k.startsWith('_') || k === '_local') c[k] = v;
  return c;
}

function lastColor(set) {
  try {
    if (set) localStorage.setItem('tetrad:lastColor', set);
    return validColor(localStorage.getItem('tetrad:lastColor'));
  } catch (e) {
    return null;
  }
}

function isMacPlatform() {
  return /Mac|iPhone|iPad/.test(navigator.platform || '');
}

function olLabel(n, depth) {
  const kind = depth % 3;
  if (kind === 1) return toLetters(n);
  if (kind === 2) return toRoman(n);
  return String(n);
}

function toLetters(n) {
  let s = '';
  while (n > 0) {
    n--;
    s = String.fromCharCode(97 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}

function toRoman(n) {
  const map = [[1000, 'm'], [900, 'cm'], [500, 'd'], [400, 'cd'], [100, 'c'], [90, 'xc'], [50, 'l'], [40, 'xl'], [10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']];
  let s = '';
  for (const [v, r] of map) while (n >= v) {
    s += r;
    n -= v;
  }
  return s;
}
