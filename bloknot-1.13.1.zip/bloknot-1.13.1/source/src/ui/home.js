// Главная: все страницы с сортировкой
import { el, clear, pageTitle, formatDate } from '../util.js';
import { icon } from '../icons.js';
import { api } from '../api.js';
import { state, ancestors } from '../store.js';
import { createPage } from './actions.js';

export function mountHome(container, ctx) {
  clear(container);
  ctx.setTitle('Блокнот');
  const name = state.user && state.user.name ? state.user.name : '';
  const hour = new Date().getHours();
  const greet = hour < 5 ? 'Доброй ночи' : hour < 12 ? 'Доброе утро' : hour < 18 ? 'Добрый день' : 'Добрый вечер';
  const allList = el('div', { class: 'home-all' });
  let sort = 'updated';
  const sortSel = el('select', { class: 'select', 'aria-label': 'Сортировка' }, el('option', { value: 'updated' }, 'Сначала недавно изменённые'), el('option', { value: 'title' }, 'По названию'), el('option', { value: 'created' }, 'Сначала новые'));
  sortSel.addEventListener('change', () => {
    sort = sortSel.value;
    renderAll();
  });
  const newBtn = el('button', { type: 'button', class: 'btn btn-primary' }, 'Новая страница');
  newBtn.addEventListener('click', () => createPage(null));
  const banner = el('div', { class: 'home-banner-slot' });
  container.append(
    el(
      'div',
      { class: 'home' },
      el('div', { class: 'home-head' }, el('h1', { class: 'home-title' }, name ? `${greet}, ${name}` : greet), newBtn),
      banner,
      el('section', { class: 'home-section' }, el('div', { class: 'home-row' }, el('h2', { class: 'home-h' }, 'Все страницы'), sortSel), allList),
    ),
  );

  function renderAll() {
    clear(allList);
    const coll = new Intl.Collator('ru', { sensitivity: 'base', numeric: true });
    const list = Array.from(state.pages.values());
    if (sort === 'title') list.sort((a, b) => coll.compare(pageTitle(a), pageTitle(b)));
    else if (sort === 'created') list.sort((a, b) => b.created_at - a.created_at);
    else list.sort((a, b) => b.updated_at - a.updated_at);
    if (!list.length) {
      allList.append(el('div', { class: 'empty-state small' }, el('p', null, 'Здесь пока пусто. Создайте первую страницу или перенесите записи из Notion в настройках.')));
      return;
    }
    for (const p of list.slice(0, 300)) {
      const path = ancestors(p.id).map(pageTitle).join(' / ');
      allList.append(
        el(
          'a',
          { class: 'home-item', href: `#/p/${p.id}` },
          el('span', { class: 'home-item-icon' }, p.icon || icon('page', 17)),
          el('span', { class: 'home-item-text' }, el('span', { class: 'home-item-title' }, pageTitle(p)), path ? el('span', { class: 'home-item-path' }, path) : null),
          el('span', { class: 'home-item-date' }, formatDate(p.updated_at)),
        ),
      );
    }
  }

  // напоминание о резервной копии на почту
  api('mail.status').then(
    (st) => {
      if (!st.enabled) return;
      const failed = st.last_error && (!st.last_ok_at || st.last_at > st.last_ok_at);
      const unconfirmed = st.last_ok_at && !st.confirmed_at && Date.now() / 1000 - st.last_ok_at > 3600;
      if (!failed && !unconfirmed) return;
      const btn = el('button', { type: 'button', class: 'btn btn-small' }, 'Открыть настройки');
      btn.addEventListener('click', () => ctx.openSettings && ctx.openSettings('mail'));
      banner.append(
        el(
          'div',
          { class: `home-banner${failed ? ' is-bad' : ''}` },
          el('span', null, failed ? '⚠️' : '📬'),
          el(
            'div',
            { class: 'home-banner-text' },
            el('div', { class: 'home-banner-title' }, failed ? 'Резервная копия не отправлена на почту' : 'Проверьте, что письма с резервной копией доходят'),
            el('div', null, failed ? st.last_error : `Найдите письмо «Блокнот: резервная копия» на ${st.recipient} (возможно, в «Спаме») и нажмите в нём «Письма доходят».`),
          ),
          btn,
        ),
      );
    },
    () => {},
  );
  renderAll();
  return { refresh: renderAll };
}
