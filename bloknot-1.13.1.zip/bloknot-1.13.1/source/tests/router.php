<?php
// Роутер для встроенного сервера PHP: имитирует правила .htaccess (запрет data/, lib/, служебных файлов).
$path = urldecode(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
if (preg_match('#^/(data|lib)(/|$)#', $path) || preg_match('#/\.#', $path) || preg_match('#\.(sqlite|md|txt|zip|log)$#', $path)) {
    http_response_code(403);
    echo 'Forbidden';
    return true;
}
if ($path === '/' || $path === '') {
    require __DIR__ . '/index.php';
    return true;
}
return false;
