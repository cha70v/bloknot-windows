<?php
// Поддельный DeepSeek для тестов: php -S 127.0.0.1:PORT fake_deepseek.php
// Последний запрос сохраняется в файл из переменной окружения FAKE_DS_LOG.
$auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
header('Content-Type: application/json');
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$raw = file_get_contents('php://input');
$log = getenv('FAKE_DS_LOG');
if ($log) file_put_contents($log, json_encode(array('path' => $path, 'auth' => $auth, 'body' => json_decode($raw, true)), JSON_UNESCAPED_UNICODE));
if ($auth !== 'Bearer sk-test-good-key-1234567890') {
    http_response_code(401);
    echo json_encode(array('error' => array('message' => 'Authentication Fails, Your api key is invalid', 'type' => 'authentication_error')));
    return true;
}
if ($path === '/models') {
    echo json_encode(array('object' => 'list', 'data' => array(array('id' => 'deepseek-flash', 'object' => 'model'), array('id' => 'deepseek-v4-pro', 'object' => 'model'), array('id' => 'deepseek-flash-next', 'object' => 'model'))));
    return true;
}
if ($path === '/chat/completions') {
    $b = json_decode($raw, true);
    $user = $b['messages'][1]['content'];
    preg_match('#<fragment>\n(.*)\n</fragment>#s', $user, $m);
    $frag = isset($m[1]) ? $m[1] : '';
    if (strpos($user, 'БАЛАНС') !== false) {
        http_response_code(402);
        echo json_encode(array('error' => array('message' => 'Insufficient Balance')));
        return true;
    }
    if (mb_stripos($user, 'списк') !== false) $out = "- первый пункт\n- второй пункт";
    elseif (mb_stripos($user, 'английск') !== false) $out = 'Hello, world';
    else $out = 'ИИ: ' . mb_strtoupper($frag, 'UTF-8');
    if (strpos($user, '<script>') !== false) $out = '<img src=x onerror="window.__xss=1">';
    echo json_encode(array('id' => 'x', 'object' => 'chat.completion', 'model' => $b['model'], 'choices' => array(array('index' => 0, 'message' => array('role' => 'assistant', 'content' => $out), 'finish_reason' => 'stop')), 'usage' => array('total_tokens' => 42)), JSON_UNESCAPED_UNICODE);
    return true;
}
http_response_code(404);
echo '{"error":{"message":"not found"}}';
return true;
