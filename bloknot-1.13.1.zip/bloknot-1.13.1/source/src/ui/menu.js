// Всплывающие меню и поповеры с управлением с клавиатуры
import { el, clamp } from '../util.js';
import { icon } from '../icons.js';

let active = null;
const isIconName = (v) => typeof v === 'string' && /^[a-zA-Z0-9]+$/.test(v);
// значок пункта: имя иконки, эмодзи или функция, возвращающая DOM-узел (например, образец цвета)
const renderIcon = (v) => {
  if (!v) return el('span', { class: 'ic ic-empty' });
  if (typeof v === 'function') return v();
  return isIconName(v) ? icon(v) : el('span', { class: 'menu-emoji' }, v);
};

export function isSheetMode() {
  return window.innerWidth < 640;
}

let probe = null;
/**
 * Видимая часть экрана в координатах getBoundingClientRect и поправка для position: fixed.
 * На iPhone с открытой клавиатурой система сдвигает видимую область, и координаты выделения
 * (getBoundingClientRect) и координаты «приклеенных» панелей (style.top) начинают расходиться
 * на величину этого сдвига. Поэтому сдвиг не угадываем, а меряем: невидимая метка стоит
 * в position: fixed; top: 0, и её getBoundingClientRect показывает, где «ноль» панелей.
 * top/bottom — границы видимой области (в координатах выделения), shift — что прибавить к координате
 * выделения, чтобы получить style.top панели.
 */
export function viewportBox() {
  if (!probe || !probe.isConnected) {
    probe = document.createElement('div');
    probe.setAttribute('aria-hidden', 'true');
    probe.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;visibility:hidden;pointer-events:none;padding-top:env(safe-area-inset-top,0px);box-sizing:content-box;';
    document.body.appendChild(probe);
  }
  const p = probe.getBoundingClientRect().top;
  const vv = window.visualViewport;
  const top = (vv ? vv.offsetTop : 0) + p;
  // высота статус-бара/«чёлки» сверху: системное меню iOS туда не встаёт
  const safeTop = parseFloat(getComputedStyle(probe).paddingTop) || 0;
  return { top, bottom: top + (vv ? vv.height : window.innerHeight), shift: -p, safeTop };
}

/** Позиционирует элемент рядом с прямоугольником-якорем, не выходя за экран. */
export function positionPopup(popup, rect, placement = 'bottom-start', gap = 6) {
  const vw = window.innerWidth;
  const vh = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
  const pw = popup.offsetWidth;
  const ph = popup.offsetHeight;
  let left = placement.endsWith('end') ? rect.right - pw : placement.startsWith('right') ? rect.right + gap : rect.left;
  let top = placement.startsWith('top') ? rect.top - ph - gap : placement.startsWith('right') ? rect.top : rect.bottom + gap;
  if (placement.startsWith('bottom') && top + ph > vh - 8 && rect.top - ph - gap > 8) top = rect.top - ph - gap;
  if (placement.startsWith('top') && top < 8) top = rect.bottom + gap;
  if (placement.startsWith('right') && left + pw > vw - 8) left = rect.left - pw - gap;
  left = clamp(left, 8, Math.max(8, vw - pw - 8));
  top = clamp(top, 8, Math.max(8, vh - ph - 8));
  popup.style.left = `${left}px`;
  popup.style.top = `${top}px`;
}

function anchorRect(anchor) {
  if (!anchor) return { left: 100, top: 100, right: 100, bottom: 100, width: 0, height: 0 };
  if (anchor.getBoundingClientRect) return anchor.getBoundingClientRect();
  if ('x' in anchor && !('left' in anchor)) return { left: anchor.x, right: anchor.x, top: anchor.y, bottom: anchor.y, width: 0, height: 0 };
  return anchor;
}

export function closeMenus() {
  if (active) active.close();
}

/**
 * items: [{ label, icon, hint, onSelect, submenu, danger, checked, disabled, separator, header }]
 */
export function showMenu({ anchor, items, placement = 'bottom-start', className = '', onClose, focusFirst = true, sheetTitle = '' }) {
  closeMenus();
  const sheet = isSheetMode();
  const backdrop = sheet ? el('div', { class: 'sheet-backdrop' }) : null;
  const menu = el('div', { class: `menu ${sheet ? 'is-sheet' : ''} ${className}`, role: 'menu', tabindex: '-1' });
  let sub = null;
  let cursor = -1;
  let buttons = [];

  function render(list, title) {
    menu.textContent = '';
    buttons = [];
    if (sheet && (title || sheetTitle)) menu.append(el('div', { class: 'menu-sheet-title' }, title || sheetTitle));
    if (sheet && list !== items) {
      const back = el('button', { class: 'menu-item', type: 'button' }, icon('chevron'), el('span', { class: 'menu-label' }, 'Назад'));
      back.querySelector('.ic').style.transform = 'rotate(180deg)';
      back.addEventListener('click', () => render(items));
      menu.append(back);
      buttons.push({ btn: back, item: { onSelect: () => render(items), keep: true } });
    }
    for (const it of list) {
      if (!it) continue;
      if (it.separator) {
        menu.append(el('div', { class: 'menu-sep', role: 'separator' }));
        continue;
      }
      if (it.header) {
        menu.append(el('div', { class: 'menu-header' }, it.header));
        continue;
      }
      if (it.custom) {
        menu.append(it.custom);
        continue;
      }
      const btn = el(
        'button',
        { class: `menu-item${it.danger ? ' is-danger' : ''}${it.checked ? ' is-checked' : ''}`, type: 'button', role: 'menuitem', disabled: it.disabled },
        renderIcon(it.icon),
        el('span', { class: 'menu-label' }, it.label),
        it.hint ? el('span', { class: 'menu-hint' }, it.hint) : null,
        it.submenu ? icon('chevron', 14) : it.checked ? icon('check', 16) : null,
      );
      const idx = buttons.length;
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        activate(idx);
      });
      btn.addEventListener('pointerenter', () => {
        if (!sheet) setCursor(idx, false);
        if (!sheet && it.submenu) openSub(idx);
        else if (!sheet) closeSub();
      });
      menu.append(btn);
      buttons.push({ btn, item: it });
    }
  }

  function setCursor(i, scroll = true) {
    buttons.forEach((b, j) => b.btn.classList.toggle('is-active', j === i));
    cursor = i;
    if (scroll && buttons[i]) buttons[i].btn.scrollIntoView({ block: 'nearest' });
  }

  function openSub(i) {
    const { btn, item } = buttons[i];
    if (sheet) {
      render(item.submenu, item.label);
      return;
    }
    if (sub && sub.owner === i) return;
    closeSub();
    const sm = el('div', { class: `menu menu-sub ${item.subClass || ''}`, role: 'menu' });
    let subCursor = -1;
    const subButtons = [];
    for (const s of item.submenu) {
      if (s.separator) {
        sm.append(el('div', { class: 'menu-sep' }));
        continue;
      }
      if (s.header) {
        sm.append(el('div', { class: 'menu-header' }, s.header));
        continue;
      }
      const b = el(
        'button',
        { class: `menu-item${s.checked ? ' is-checked' : ''}`, type: 'button', role: 'menuitem' },
        renderIcon(s.icon),
        el('span', { class: 'menu-label' }, s.label),
        s.hint ? el('span', { class: 'menu-hint' }, s.hint) : null,
        s.checked ? icon('check', 16) : null,
      );
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        api.close();
        s.onSelect && s.onSelect();
      });
      sm.append(b);
      subButtons.push(b);
    }
    document.body.append(sm);
    positionPopup(sm, btn.getBoundingClientRect(), 'right-start', 2);
    sub = {
      owner: i,
      el: sm,
      move(d) {
        subCursor = (subCursor + d + subButtons.length) % subButtons.length;
        subButtons.forEach((b, j) => b.classList.toggle('is-active', j === subCursor));
      },
      enter() {
        if (subButtons[subCursor]) subButtons[subCursor].click();
      },
    };
  }

  function closeSub() {
    if (sub) {
      sub.el.remove();
      sub = null;
    }
  }

  function activate(i) {
    const b = buttons[i];
    if (!b || b.item.disabled) return;
    if (b.item.submenu) {
      openSub(i);
      if (!sheet && sub) sub.move(1);
      return;
    }
    if (!b.item.keep) api.close();
    b.item.onSelect && b.item.onSelect();
  }

  function onKey(e) {
    if (e.key === 'Escape') {
      e.preventDefault();
      e.stopPropagation();
      if (sub) closeSub();
      else api.close(true);
      return;
    }
    if (sub && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault();
      sub.move(e.key === 'ArrowDown' ? 1 : -1);
      return;
    }
    if (sub && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault();
      sub.enter();
      return;
    }
    if (sub && e.key === 'ArrowLeft') {
      e.preventDefault();
      closeSub();
      return;
    }
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      const n = buttons.length;
      if (!n) return;
      let i = cursor;
      for (let k = 0; k < n; k++) {
        i = (i + (e.key === 'ArrowDown' ? 1 : -1) + n) % n;
        if (!buttons[i].item.disabled) break;
      }
      setCursor(i);
      return;
    }
    if (e.key === 'ArrowRight' && buttons[cursor] && buttons[cursor].item.submenu) {
      e.preventDefault();
      openSub(cursor);
      if (sub) sub.move(1);
      return;
    }
    if (e.key === 'Enter' || (e.key === ' ' && document.activeElement === menu)) {
      e.preventDefault();
      if (cursor >= 0) activate(cursor);
      return;
    }
    if (e.key === 'Tab') {
      e.preventDefault();
    }
  }

  function onOutside(e) {
    if (menu.contains(e.target) || (sub && sub.el.contains(e.target))) return;
    if (anchor && anchor.contains && anchor.contains(e.target)) {
      e.stopPropagation();
    }
    api.close();
  }

  const prevFocus = document.activeElement;
  const api = {
    el: menu,
    closed: false,
    close(restoreFocus = false) {
      if (api.closed) return;
      api.closed = true;
      closeSub();
      menu.remove();
      if (backdrop) backdrop.remove();
      document.removeEventListener('keydown', onKey, true);
      document.removeEventListener('pointerdown', onOutside, true);
      window.removeEventListener('resize', onResize);
      if (active === api) active = null;
      if (restoreFocus && prevFocus && prevFocus.focus) prevFocus.focus({ preventScroll: true });
      onClose && onClose();
    },
    handleKey: onKey,
  };
  function onResize() {
    if (!sheet) api.close();
  }

  render(items);
  if (backdrop) {
    document.body.append(backdrop);
    backdrop.addEventListener('click', () => api.close());
  }
  document.body.append(menu);
  if (!sheet) positionPopup(menu, anchorRect(anchor), placement);
  document.addEventListener('keydown', onKey, true);
  setTimeout(() => document.addEventListener('pointerdown', onOutside, true), 0);
  window.addEventListener('resize', onResize);
  if (focusFirst) {
    menu.focus({ preventScroll: true });
    const first = buttons.findIndex((b) => !b.item.disabled);
    if (first >= 0 && !sheet) setCursor(first);
  }
  active = api;
  return api;
}
