// Блокнот — точка входа интерфейса
import { el, clear, pageTitle, formatDate, modKey, isTouch, store as ls } from './util.js';
import { icon } from './icons.js';
import { api, apiEvents, setCsrf } from './api.js';
import { state, events, loadTree, ancestors, expandTo } from './store.js';
import { syncEvents, startPolling, startBackgroundSync } from './sync.js';
import { buildSidebar } from './ui/sidebar.js';
import { mountPage } from './ui/pageview.js';
import { mountHome } from './ui/home.js';
import { openSearch, openTrash, renderLogin, buildMobileBar } from './ui/panels.js';
import { openSettings } from './ui/settings.js';
import { showMenu, closeMenus } from './ui/menu.js';
import { toast } from './ui/modal.js';
import { initTheme } from './ui/theme.js';
import { navigate, trashPage, duplicatePage, movePageDialog, exportPage, createPage, toggleFavorite } from './ui/actions.js';

const app = document.getElementById('app');
let view = null; // текущее представление страницы
let sidebar = null;
let viewEl = null;
let crumbs = null;
let statusEl = null;
let pageMenuBtn = null;
let favBtn = null;
let mobileBar = null;
let routeSeq = 0;

initTheme();

async function boot() {
  let status;
  try {
    status = await api('auth.status');
  } catch (e) {
    clear(app);
    app.append(el('div', { class: 'empty-state boot-error' }, el('div', { class: 'empty-title' }, 'Сервер недоступен'), el('p', null, e.message), el('button', { class: 'btn', type: 'button', onclick: () => location.reload() }, 'Повторить')));
    return;
  }
  setCsrf(status.csrf);
  watchVersion(status.version);
  if (!status.logged_in) {
    renderLogin(app, status, (user) => {
      state.user = user;
      start();
    });
    return;
  }
  state.user = status.user;
  start();
}

/**
 * Новая версия на сервере (её залили по FTP) — предлагаем перезагрузить страницу.
 * Проверяем раз в 10 минут и при возвращении во вкладку/окно.
 */
function watchVersion(loaded) {
  if (!loaded) return;
  let shown = '';
  let last = 0;
  const check = async () => {
    if (Date.now() - last < 60000) return;
    last = Date.now();
    try {
      const h = await api('health');
      if (h.version && h.version !== loaded && h.version !== shown) {
        shown = h.version;
        const notes = (h.notes || []).slice(0, 2).join('. ');
        toast(`Блокнот обновлён до версии ${h.version}${notes ? ': ' + notes : ''}`, 'info', {
          duration: Infinity,
          action: { label: 'Обновить', onClick: () => location.reload() },
        });
      }
    } catch (e) {
      /* нет связи — проверим позже */
    }
  };
  setInterval(check, 10 * 60 * 1000);
  document.addEventListener('visibilitychange', () => document.visibilityState === 'visible' && check());
}

async function start() {
  clear(app);
  try {
    await loadTree();
  } catch (e) {
    app.append(el('div', { class: 'empty-state boot-error' }, el('div', { class: 'empty-title' }, 'Не удалось загрузить страницы'), el('p', null, e.message), el('button', { class: 'btn', type: 'button', onclick: () => location.reload() }, 'Повторить')));
    return;
  }
  buildLayout();
  api('stats').then((s) => (state.uploadLimit = s.upload_limit), () => {});
  startPolling(() => (view ? view.session : null));
  startBackgroundSync(() => (view ? view.id : null));
  window.addEventListener('hashchange', route);
  route();
}

let lastPointer = isTouch ? 'touch' : 'mouse';
document.addEventListener('pointerdown', (e) => (lastPointer = e.pointerType || lastPointer), true);

function buildLayout() {
  const collapsed = ls('sidebarHidden') === true && window.innerWidth >= 900;
  const shell = el('div', { class: `shell${collapsed ? ' sidebar-hidden' : ''}` });
  const setSidebar = (open) => {
    if (window.innerWidth < 900) shell.classList.toggle('sidebar-open', open);
    else {
      shell.classList.toggle('sidebar-hidden', !open);
      ls('sidebarHidden', !open);
    }
  };
  sidebar = buildSidebar({
    onSearch: () => openSearch(),
    onSettings: () => openSettings({ onLogout: logout }),
    onTrash: () => openTrash(),
    onClose: () => setSidebar(false),
  });
  setupSidebarResize(shell, sidebar.el);
  const scrim = el('div', { class: 'scrim', onclick: () => setSidebar(false) });
  const menuBtn = el('button', { type: 'button', class: 'icon-btn topbar-menu', 'aria-label': 'Показать панель', title: 'Показать панель' }, icon('menu', 20));
  menuBtn.addEventListener('click', () => setSidebar(window.innerWidth < 900 ? !shell.classList.contains('sidebar-open') : true));
  crumbs = el('nav', { class: 'crumbs', 'aria-label': 'Расположение страницы' });
  statusEl = el('div', { class: 'save-status', role: 'status', 'aria-live': 'polite' });
  pageMenuBtn = el('button', { type: 'button', class: 'icon-btn', 'aria-label': 'Действия со страницей', title: 'Действия со страницей' }, icon('more', 20));
  pageMenuBtn.addEventListener('click', () => openPageMenu());
  const searchBtn = el('button', { type: 'button', class: 'icon-btn topbar-search', 'aria-label': 'Поиск', title: 'Поиск' }, icon('search', 19));
  searchBtn.addEventListener('click', openSearch);
  favBtn = el('button', { type: 'button', class: 'icon-btn fav-btn', 'aria-label': 'Добавить в избранное', title: 'Добавить в избранное' }, icon('star', 19));
  favBtn.addEventListener('click', () => state.currentId && toggleFavorite(state.currentId));
  const topbar = el('header', { class: 'topbar' }, menuBtn, crumbs, el('div', { class: 'topbar-spacer' }), statusEl, searchBtn, favBtn, pageMenuBtn);
  viewEl = el('div', { class: 'view', id: 'view' });
  const main = el('main', { class: 'main' }, topbar, el('div', { class: 'scroller' }, viewEl));
  mobileBar = buildMobileBar(() => (view ? view.editor : null));
  shell.append(sidebar.el, scrim, main, mobileBar.el);
  app.append(shell);

  events.on('tree', () => {
    renderCrumbs();
    if (view && view.refreshLinks) view.refreshLinks();
  });
  syncEvents.on('online', () => document.body.classList.remove('is-offline'));
  syncEvents.on('offline', () => document.body.classList.add('is-offline'));
  syncEvents.on('background-conflict', (id) => {
    const p = state.pages.get(id);
    toast(`Несохранённые изменения страницы «${pageTitle(p)}» конфликтуют с более новой версией. Откройте её, чтобы выбрать вариант.`, 'error', { duration: 12000, action: { label: 'Открыть', onClick: () => navigate(`#/p/${id}`) } });
  });
  syncEvents.on('draft-failed', () => toast('Не удаётся сохранить черновик в браузере — хранилище переполнено или отключено.', 'error'));
  apiEvents.on('auth-required', () => {
    if (document.querySelector('.relogin')) return;
    toast('Сессия истекла — войдите снова. Несохранённые изменения хранятся на этом устройстве.', 'error', { duration: Infinity, action: { label: 'Войти', onClick: () => location.reload() } }).classList.add('relogin');
  });
  apiEvents.on('csrf-expired', () => toast('Сессия обновилась. Перезагрузите страницу.', 'error', { action: { label: 'Перезагрузить', onClick: () => location.reload() } }));

  // открыть нужный раздел настроек из любого места (например, из панели ИИ)
  window.addEventListener('tetrad:settings', (e) => openSettings({ onLogout: logout, tab: e.detail || undefined }));

  document.addEventListener('keydown', (e) => {
    if (modKey(e) && !e.shiftKey && (e.key === 'k' || e.code === 'KeyK') && !(e.target.closest && e.target.closest('[contenteditable="true"] , .editor'))) {
      e.preventDefault();
      openSearch();
    } else if (modKey(e) && (e.key === 'p' || e.code === 'KeyP') && !e.shiftKey) {
      e.preventDefault();
      openSearch();
    } else if (modKey(e) && e.key === '\\') {
      e.preventDefault();
      setSidebar(shell.classList.contains('sidebar-hidden'));
    } else if (modKey(e) && e.altKey && (e.key === 'n' || e.code === 'KeyN')) {
      e.preventDefault();
      createPage(view ? view.id : null);
    }
  });

  window.addEventListener('beforeunload', (e) => {
    if (view && view.session && (view.session.dirty || view.session.saving)) {
      view.session.beacon();
      e.preventDefault();
      e.returnValue = '';
    }
  });
  window.addEventListener('pagehide', () => {
    if (view && view.session) view.session.beacon();
  });
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && view && view.session && view.session.dirty) view.session.save();
  });
  window.addEventListener('online', () => view && view.session && view.session.retryNow());
}

function renderFavBtn() {
  if (!favBtn) return;
  const p = state.currentId ? state.pages.get(state.currentId) : null;
  favBtn.style.display = p ? '' : 'none';
  const on = !!(p && p.favorite_at);
  favBtn.classList.toggle('is-on', on);
  favBtn.textContent = '';
  favBtn.append(icon(on ? 'starFill' : 'star', 19));
  const label = on ? 'Убрать из избранного' : 'Добавить в избранное';
  favBtn.title = label;
  favBtn.setAttribute('aria-label', label);
  favBtn.setAttribute('aria-pressed', on ? 'true' : 'false');
}

function renderCrumbs() {
  renderFavBtn();
  if (!crumbs) return;
  clear(crumbs);
  const id = state.currentId;
  if (!id) {
    crumbs.append(el('span', { class: 'crumb is-current' }, 'Главная'));
    return;
  }
  const p = state.pages.get(id);
  const list = ancestors(id);
  const max = window.innerWidth < 640 ? 1 : 3;
  const shown = list.length > max ? list.slice(-max) : list;
  if (list.length > max) crumbs.append(el('span', { class: 'crumb crumb-more' }, '…'), el('span', { class: 'crumb-sep' }, '/'));
  for (const a of shown) {
    crumbs.append(el('a', { class: 'crumb', href: `#/p/${a.id}` }, a.icon ? `${a.icon} ` : '', pageTitle(a)), el('span', { class: 'crumb-sep' }, '/'));
  }
  crumbs.append(el('span', { class: 'crumb is-current' }, p && p.icon ? `${p.icon} ` : '', pageTitle(p)));
}

const STATUS_TEXT = {
  saved: 'Сохранено',
  synced: 'Обновлено',
  pending: 'Изменено',
  saving: 'Сохранение…',
  offline: 'Нет сети — сохранено на устройстве',
  error: 'Ошибка сохранения',
  conflict: 'Конфликт версий',
};

function setStatus(s, detail) {
  if (!statusEl) return;
  statusEl.className = `save-status is-${s}`;
  let text = STATUS_TEXT[s] || '';
  if (s === 'error' && detail) text = detail;
  statusEl.textContent = '';
  statusEl.append(el('span', { class: 'save-dot', 'aria-hidden': 'true' }), el('span', { class: 'save-text' }, text));
  statusEl.title = s === 'saved' && detail ? `Сохранено ${formatDate(detail)}` : text;
}

async function route() {
  const seq = ++routeSeq;
  closeMenus();
  const hash = location.hash || '#/';
  const m = hash.match(/^#\/p\/(\d+)/);
  const id = m ? Number(m[1]) : null;
  if (view && view.id === id && id) return;
  // сохраняем текущую страницу перед уходом
  if (view && view.destroy) {
    const old = view;
    view = null;
    const ok = await old.destroy();
    if (!ok) toast('Последние изменения не сохранены на сервере — они отправятся автоматически, когда появится связь.', 'error');
  }
  if (seq !== routeSeq) return;
  state.currentId = id;
  sidebar.renderTree();
  renderCrumbs();
  mobileBar.show(false);
  viewEl.parentElement.scrollTop = 0;
  pageMenuBtn.style.visibility = id ? '' : 'hidden';
  if (!id) {
    statusEl.textContent = '';
    statusEl.className = 'save-status';
    view = mountHome(viewEl, { setTitle, openSettings: (tab) => openSettings({ onLogout: logout, tab }) });
    view.id = null;
    sidebar.renderRecent();
    return;
  }
  expandTo(id);
  setStatus('saved');
  const ctx = {
    scroller: viewEl.parentElement,
    setStatus,
    setTitle: (t) => {
      setTitle(t);
      const p = state.pages.get(id);
      if (p && p.title !== t) {
        p.title = t;
        clearTimeout(ctx.treeTimer);
        ctx.treeTimer = setTimeout(() => {
          sidebar.renderTree();
          renderCrumbs();
        }, 250);
      }
    },
    onEditorFocus: (on, tapped = false) => {
      // телефон: сенсорный экран по CSS, последнее касание пальцем или узкий экран
      if (!(isTouch || lastPointer === 'touch' || window.innerWidth <= 640)) return;
      const ed = view && view.editor;
      mobileBar.show(!!(on && ed && (tapped || ed.root.contains(document.activeElement) || ed.selected.size)));
    },
    onRemount: (v) => {
      view = v;
    },
  };
  const v = await mountPage(viewEl, id, ctx);
  if (seq !== routeSeq) {
    if (v) v.destroy();
    return;
  }
  view = v;
  sidebar.renderRecent();
  if (!v) {
    statusEl.textContent = '';
    statusEl.className = 'save-status';
  }
}

function setTitle(t) {
  document.title = t ? `${t} — Блокнот` : 'Без названия — Блокнот';
}

function openPageMenu() {
  if (!view || !view.id) return;
  const id = view.id;
  const p = state.pages.get(id);
  showMenu({
    anchor: pageMenuBtn,
    placement: 'bottom-end',
    sheetTitle: pageTitle(p),
    items: [
      { header: p ? `Изменено ${formatDate(view.session.updatedAt || p.updated_at)}` : '' },
      p && p.favorite_at
        ? { label: 'Убрать из избранного', icon: 'starOff', onSelect: () => toggleFavorite(id, false) }
        : { label: 'Добавить в избранное', icon: 'star', onSelect: () => toggleFavorite(id, true) },
      { label: 'История версий', icon: 'history', onSelect: () => view.showHistory() },
      { label: 'Экспорт в Markdown', icon: 'download', onSelect: () => exportPage(id, true) },
      { label: 'Дублировать', icon: 'duplicate', onSelect: async () => {
        await view.session.save();
        duplicatePage(id);
      } },
      { label: 'Переместить в…', icon: 'move', onSelect: () => movePageDialog(id) },
      { label: 'Вложенная страница', icon: 'plus', onSelect: () => createPage(id) },
      { label: 'Скопировать ссылку', icon: 'link', onSelect: () => {
        const url = `${location.origin}${location.pathname}#/p/${id}`;
        if (navigator.clipboard) navigator.clipboard.writeText(url).then(() => toast('Ссылка скопирована'), () => toast(url));
      } },
      { separator: true },
      { label: 'В корзину', icon: 'trash', danger: true, onSelect: async () => {
        await view.session.save();
        trashPage(id);
      } },
    ],
  });
}

async function logout() {
  if (view && view.destroy) await view.destroy();
  try {
    await api('auth.logout', {});
  } catch (e) {
    /* ignore */
  }
  location.hash = '';
  location.reload();
}

boot();

/** Ширина боковой панели: перетаскивание правого края (двойной щелчок — по умолчанию), запоминается. */
const SB_MIN = 200;
const SB_MAX = 480;
const SB_DEFAULT = 240;
function setupSidebarResize(shell, sidebarEl) {
  const apply = (w) => shell.style.setProperty('--sidebar-w', `${Math.round(w)}px`);
  const saved = Number(ls('sidebarWidth'));
  if (saved >= SB_MIN && saved <= SB_MAX) apply(saved);
  const handle = el('div', { class: 'sb-resizer', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': 'Ширина панели', title: 'Потяните, чтобы изменить ширину. Двойной щелчок — по умолчанию' });
  sidebarEl.append(handle);
  handle.addEventListener('pointerdown', (e) => {
    if (e.button !== 0 || window.innerWidth < 900) return;
    e.preventDefault();
    const startX = e.clientX;
    const startW = sidebarEl.getBoundingClientRect().width;
    const maxW = Math.min(SB_MAX, window.innerWidth - 420);
    let w = startW;
    handle.setPointerCapture(e.pointerId);
    shell.classList.add('is-resizing');
    const move = (ev) => {
      w = Math.max(SB_MIN, Math.min(maxW, startW + ev.clientX - startX));
      apply(w);
    };
    const up = () => {
      handle.removeEventListener('pointermove', move);
      handle.removeEventListener('pointerup', up);
      handle.removeEventListener('pointercancel', up);
      shell.classList.remove('is-resizing');
      ls('sidebarWidth', Math.round(w));
    };
    handle.addEventListener('pointermove', move);
    handle.addEventListener('pointerup', up);
    handle.addEventListener('pointercancel', up);
  });
  handle.addEventListener('dblclick', () => {
    apply(SB_DEFAULT);
    ls('sidebarWidth', SB_DEFAULT);
  });
}
