// Тема оформления: системная, светлая или тёмная
import { store } from '../util.js';

export function getTheme() {
  return store('theme') || 'system';
}

export function applyTheme(v) {
  store('theme', v);
  const root = document.documentElement;
  if (v === 'light' || v === 'dark') {
    root.dataset.theme = v;
    document.cookie = `tetrad_theme=${v}; path=/; max-age=31536000; samesite=lax`;
  } else {
    delete root.dataset.theme;
    document.cookie = 'tetrad_theme=; path=/; max-age=0; samesite=lax';
  }
}

export function initTheme() {
  const v = getTheme();
  if (v !== 'system') applyTheme(v);
}
