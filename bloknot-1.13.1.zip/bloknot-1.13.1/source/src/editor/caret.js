// Работа с кареткой внутри contenteditable-элемента

export function getRange() {
  const sel = window.getSelection();
  return sel && sel.rangeCount ? sel.getRangeAt(0) : null;
}

export function selectionInside(el) {
  const r = getRange();
  return !!(r && el.contains(r.startContainer) && el.contains(r.endContainer));
}

/** Смещение каретки (в символах текста) от начала элемента. */
export function getCaretOffset(el, useEnd = false) {
  const r = getRange();
  if (!r || !el.contains(r.startContainer)) return null;
  const pre = document.createRange();
  pre.selectNodeContents(el);
  if (useEnd) pre.setEnd(r.endContainer, r.endOffset);
  else pre.setEnd(r.startContainer, r.startOffset);
  return pre.toString().length;
}

export function textLength(el) {
  return el.textContent.length;
}

function locate(el, offset) {
  const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
  let n;
  let left = offset;
  let last = null;
  while ((n = walker.nextNode())) {
    last = n;
    if (left <= n.nodeValue.length) return { node: n, offset: left };
    left -= n.nodeValue.length;
  }
  if (last) return { node: last, offset: last.nodeValue.length };
  return { node: el, offset: el.childNodes.length };
}

export function setCaretOffset(el, offset, endOffset = null) {
  const sel = window.getSelection();
  const r = document.createRange();
  if (offset === 'end' || offset == null) {
    r.selectNodeContents(el);
    r.collapse(false);
  } else if (offset === 'start' || offset === 0) {
    const s = locate(el, 0);
    r.setStart(s.node, s.offset);
    r.collapse(true);
  } else {
    const s = locate(el, offset);
    r.setStart(s.node, s.offset);
    if (endOffset != null) {
      const e = locate(el, endOffset);
      r.setEnd(e.node, e.offset);
    } else r.collapse(true);
  }
  sel.removeAllRanges();
  sel.addRange(r);
}

export function caretAtStart(el) {
  const r = getRange();
  if (!r || !r.collapsed || !el.contains(r.startContainer)) return false;
  return getCaretOffset(el) === 0;
}

export function caretAtEnd(el) {
  const r = getRange();
  if (!r || !r.collapsed || !el.contains(r.startContainer)) return false;
  return getCaretOffset(el) === textLength(el);
}

export function caretRect() {
  const r = getRange();
  if (!r) return null;
  const range = r.cloneRange();
  range.collapse(true);
  let rect = range.getClientRects()[0];
  if (!rect || (rect.width === 0 && rect.height === 0 && rect.top === 0)) {
    // пустая строка или начало строки — измеряем временным маркером
    const marker = document.createElement('span');
    marker.textContent = '​';
    range.insertNode(marker);
    rect = marker.getBoundingClientRect();
    const parent = marker.parentNode;
    marker.remove();
    if (parent) parent.normalize();
    // восстанавливаем выделение
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(r);
  }
  return rect;
}

function lineHeight(el) {
  const lh = parseFloat(getComputedStyle(el).lineHeight);
  return isNaN(lh) ? 24 : lh;
}

export function caretOnFirstLine(el) {
  if (!el.textContent.length) return true;
  const rect = caretRect();
  if (!rect) return true;
  const box = el.getBoundingClientRect();
  return rect.top - box.top < lineHeight(el) * 0.75;
}

export function caretOnLastLine(el) {
  if (!el.textContent.length) return true;
  const rect = caretRect();
  if (!rect) return true;
  const box = el.getBoundingClientRect();
  return box.bottom - rect.bottom < lineHeight(el) * 0.75;
}

/** Ставит каретку в элементе на первой или последней строке как можно ближе к координате x. */
export function placeCaretAtX(el, x, line) {
  const box = el.getBoundingClientRect();
  const lh = lineHeight(el);
  const y = line === 'first' ? box.top + Math.min(lh / 2, box.height / 2) : box.bottom - Math.min(lh / 2, box.height / 2);
  const cx = Math.max(box.left + 1, Math.min(box.right - 1, x));
  let range = null;
  if (document.caretRangeFromPoint) {
    range = document.caretRangeFromPoint(cx, y);
  } else if (document.caretPositionFromPoint) {
    const pos = document.caretPositionFromPoint(cx, y);
    if (pos) {
      range = document.createRange();
      range.setStart(pos.offsetNode, pos.offset);
    }
  }
  if (range && el.contains(range.startContainer)) {
    range.collapse(true);
    const sel = window.getSelection();
    sel.removeAllRanges();
    sel.addRange(range);
  } else {
    setCaretOffset(el, line === 'first' ? 0 : 'end');
  }
}

function fragmentHtml(frag) {
  const d = document.createElement('div');
  d.append(frag);
  return d.innerHTML;
}

/** Делит содержимое элемента по каретке: возвращает [html до, html после], удаляя выделенное. */
export function splitAtCaret(el) {
  const r = getRange();
  if (!r || !el.contains(r.startContainer)) return [el.innerHTML, ''];
  if (!r.collapsed) r.deleteContents();
  const after = document.createRange();
  after.setStart(r.startContainer, r.startOffset);
  after.setEnd(el, el.childNodes.length);
  const frag = after.extractContents();
  return [cleanEdge(el.innerHTML), cleanEdge(fragmentHtml(frag))];
}

export function cleanEdge(html) {
  let prev;
  do {
    prev = html;
    html = html.replace(/<(b|i|u|s|code|a)(\s[^>]*)?><\/\1>/g, '');
  } while (prev !== html);
  if (html === '<br>') return '';
  return html.replace(/<br>$/, '');
}

export function textBeforeCaret(el) {
  const r = getRange();
  if (!r || !el.contains(r.startContainer)) return '';
  const pre = document.createRange();
  pre.selectNodeContents(el);
  pre.setEnd(r.startContainer, r.startOffset);
  return pre.toString();
}

/** Удаляет n символов перед кареткой. */
export function deleteBeforeCaret(el, n) {
  const off = getCaretOffset(el);
  if (off == null || n <= 0) return;
  const s = locate(el, Math.max(0, off - n));
  const e = locate(el, off);
  const range = document.createRange();
  range.setStart(s.node, s.offset);
  range.setEnd(e.node, e.offset);
  range.deleteContents();
  setCaretOffset(el, Math.max(0, off - n));
}

/** Удаляет диапазон символов [from, to) в элементе. */
export function deleteRange(el, from, to) {
  const s = locate(el, from);
  const e = locate(el, to);
  const range = document.createRange();
  range.setStart(s.node, s.offset);
  range.setEnd(e.node, e.offset);
  range.deleteContents();
}
