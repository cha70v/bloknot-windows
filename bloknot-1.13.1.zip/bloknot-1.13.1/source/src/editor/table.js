// Таблицы: ширина колонок перетаскиванием и сортировка строк по колонке
import { el, clamp } from '../util.js';
import { icon } from '../icons.js';
import { htmlToText } from '../sanitize.js';
import { showMenu } from '../ui/menu.js';

export const COL_MIN = 60;
export const COL_MAX = 1200;
export const COL_DEFAULT = 140;

/** Ширины колонок из блока: массив чисел или null, если таблица подстраивается под текст. */
export function validWidths(w) {
  if (!Array.isArray(w) || !w.length) return null;
  return w.map((x) => (Number.isFinite(+x) && +x > 0 ? clamp(Math.round(+x), COL_MIN, COL_MAX) : COL_DEFAULT));
}

/** Применяет ширины к <table>: фиксированная раскладка и <colgroup>. */
export function applyWidths(table, widths, cols) {
  let cg = table.querySelector(':scope > colgroup');
  if (!widths) {
    if (cg) cg.remove();
    table.classList.remove('is-fixed');
    table.style.width = '';
    return;
  }
  if (!cg) {
    cg = document.createElement('colgroup');
    table.prepend(cg);
  }
  const n = cols || widths.length;
  while (cg.children.length < n) cg.append(document.createElement('col'));
  while (cg.children.length > n) cg.lastChild.remove();
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const w = widths[i] || COL_DEFAULT;
    cg.children[i].style.width = `${w}px`;
    sum += w;
  }
  table.classList.add('is-fixed');
  table.style.width = `${sum}px`;
}

// ---------- сортировка ----------

/** «1 234,5», «-7», «12%», «1 500 ₽», «3.14» → число; иначе null. */
export function parseNumber(s) {
  let t = String(s).replace(/[\s  ]/g, '').replace(/−/g, '-');
  t = t.replace(/^(руб\.?|₽|\$|€|£|¥)/i, '').replace(/(руб\.?|р\.|₽|\$|€|£|¥|%)$/i, '');
  if (!t) return null;
  const hasDot = t.includes('.');
  const hasComma = t.includes(',');
  if (hasDot && hasComma) {
    // десятичный разделитель — тот, что стоит последним
    if (t.lastIndexOf(',') > t.lastIndexOf('.')) t = t.replace(/\./g, '').replace(',', '.');
    else t = t.replace(/,/g, '');
  } else if (hasComma) {
    if ((t.match(/,/g) || []).length > 1) return null;
    t = t.replace(',', '.');
  } else if (hasDot && (t.match(/\./g) || []).length > 1) {
    // 1.234.567 — точки как разделители тысяч
    if (!/^[-+]?\d{1,3}(\.\d{3})+$/.test(t)) return null;
    t = t.replace(/\./g, '');
  }
  return /^[-+]?(\d+\.?\d*|\.\d+)(e[-+]?\d+)?$/i.test(t) ? parseFloat(t) : null;
}

/** «21.10.2026», «21.10.26», «2026-10-21» → время; иначе null. */
export function parseDate(s) {
  const t = String(s).trim();
  let m = t.match(/^(\d{1,2})[./](\d{1,2})[./](\d{2}|\d{4})$/);
  if (m) {
    const y = m[3].length === 2 ? 2000 + +m[3] : +m[3];
    const d = new Date(y, +m[2] - 1, +m[1]);
    return d.getMonth() === +m[2] - 1 ? d.getTime() : null;
  }
  m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) {
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    return d.getMonth() === +m[2] - 1 ? d.getTime() : null;
  }
  return null;
}

const cellText = (html) => htmlToText(html || '').replace(/\s+/g, ' ').trim();

/** Тип данных колонки: 'number', 'date' или 'text' (по всем непустым ячейкам, кроме шапки). */
export function columnKind(rows, ci) {
  const vals = rows.slice(1).map((r) => cellText(r[ci])).filter(Boolean);
  if (!vals.length) return 'text';
  if (vals.every((v) => parseNumber(v) !== null)) return 'number';
  if (vals.every((v) => parseDate(v) !== null)) return 'date';
  return 'text';
}

const collator = new Intl.Collator(['ru', 'en'], { numeric: true, sensitivity: 'base' });

/** Новые строки таблицы: шапка на месте, остальные отсортированы; пустые ячейки всегда в конце. */
export function sortRows(rows, ci, dir) {
  const kind = columnKind(rows, ci);
  const key = (html) => {
    const t = cellText(html);
    if (!t) return null;
    if (kind === 'number') return parseNumber(t);
    if (kind === 'date') return parseDate(t);
    return t;
  };
  const sign = dir === 'desc' ? -1 : 1;
  const body = rows.slice(1).map((r, i) => ({ r, i, k: key(r[ci]) }));
  body.sort((a, b) => {
    if (a.k === null || b.k === null) return a.k === b.k ? a.i - b.i : a.k === null ? 1 : -1;
    const c = kind === 'text' ? collator.compare(a.k, b.k) : a.k - b.k;
    return c ? c * sign : a.i - b.i;
  });
  return [rows[0], ...body.map((x) => x.r)];
}

const SORT_LABELS = {
  number: ['По возрастанию (1 → 9)', 'По убыванию (9 → 1)'],
  date: ['Сначала ранние даты', 'Сначала поздние даты'],
  text: ['По алфавиту (А → Я)', 'В обратном порядке (Я → А)'],
};

// ---------- элементы управления поверх таблицы ----------

/**
 * Ручки ширины колонок (на границах) и кнопки сортировки (в ячейках шапки).
 * Лежат в отдельном слое поверх таблицы, а не в ячейках, чтобы не попадать в их текст.
 */
export function attachTable(node, b, ed) {
  const wrap = node.querySelector('.tbl-wrap');
  const table = wrap && wrap.querySelector('table');
  if (!table) return;
  const layer = el('div', { class: 'tbl-layer', contenteditable: 'false' });
  wrap.append(layer);
  const firstRow = () => Array.from(table.rows[0] ? table.rows[0].cells : []);
  const cells = firstRow();
  const sortable = b.header !== false && b.rows.length >= 3;
  if (sortable) table.classList.add('is-sortable');

  const handles = cells.map((_, ci) => {
    const h = el('div', { class: 'tbl-col-handle', 'data-col': String(ci), 'data-last': ci === cells.length - 1 ? '1' : null, title: 'Перетащите, чтобы изменить ширину колонки. Двойной щелчок — ширина по содержимому' });
    h.addEventListener('pointerdown', (e) => startResize(e, ci, h));
    h.addEventListener('click', (e) => e.stopPropagation());
    h.addEventListener('dblclick', (e) => {
      e.preventDefault();
      e.stopPropagation();
      if (!b.widths) return;
      ed.checkpoint();
      delete b.widths;
      ed.replaceNode(b);
      ed.changed();
      ed.selectBlocks([b.id]);
    });
    layer.append(h);
    return h;
  });

  const sorts = sortable
    ? cells.map((_, ci) => {
        const s = el('button', { type: 'button', class: 'tbl-sort', 'data-col': String(ci), 'aria-label': 'Сортировать по этой колонке', title: 'Сортировать' }, icon('sort', 14));
        s.addEventListener('pointerdown', (e) => {
          e.preventDefault();
          e.stopPropagation();
        });
        s.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          const kind = columnKind(b.rows, ci);
          const [asc, desc] = SORT_LABELS[kind];
          const run = (dir) => {
            ed.checkpoint();
            b.rows = sortRows(b.rows, ci, dir);
            ed.replaceNode(b);
            ed.changed();
            // фокус остаётся в редакторе: Ctrl+Z сразу отменяет сортировку
            ed.selectBlocks([b.id]);
          };
          showMenu({
            anchor: s,
            placement: 'bottom-end',
            sheetTitle: 'Сортировка',
            items: [
              { header: kind === 'number' ? 'Числа' : kind === 'date' ? 'Даты' : 'Текст' },
              { label: asc, icon: 'arrowUp', onSelect: () => run('asc') },
              { label: desc, icon: 'arrowDown', onSelect: () => run('desc') },
            ],
          });
        });
        layer.append(s);
        return s;
      })
    : [];

  function layout() {
    const row = firstRow();
    const top = table.offsetTop;
    const height = table.offsetHeight;
    row.forEach((c, ci) => {
      const right = table.offsetLeft + c.offsetLeft + c.offsetWidth;
      const last = ci === row.length - 1;
      const h = handles[ci];
      if (h) {
        h.style.left = `${right - (last ? h.offsetWidth : h.offsetWidth / 2)}px`;
        h.style.top = `${top}px`;
        h.style.height = `${height}px`;
      }
      const s = sorts[ci];
      if (s) {
        s.style.left = `${right - 28}px`;
        s.style.top = `${top + c.offsetTop + 7}px`;
      }
    });
  }

  function startResize(e, ci, h) {
    if (e.button > 0) return;
    e.preventDefault();
    e.stopPropagation();
    h.setPointerCapture(e.pointerId);
    const start = firstRow().map((c) => Math.round(c.getBoundingClientRect().width));
    const widths = start.slice();
    const x0 = e.clientX;
    let moved = false;
    h.classList.add('is-active');
    const move = (ev) => {
      const dx = ev.clientX - x0;
      if (!moved && Math.abs(dx) < 3) return;
      if (!moved) {
        moved = true;
        ed.checkpoint();
        document.body.classList.add('is-col-resizing');
      }
      widths[ci] = clamp(Math.round(start[ci] + dx), COL_MIN, COL_MAX);
      applyWidths(table, widths, start.length);
      layout();
    };
    const up = () => {
      h.removeEventListener('pointermove', move);
      h.removeEventListener('pointerup', up);
      h.removeEventListener('pointercancel', up);
      h.classList.remove('is-active');
      document.body.classList.remove('is-col-resizing');
      if (moved) {
        b.widths = widths.slice();
        ed.changed();
      }
    };
    h.addEventListener('pointermove', move);
    h.addEventListener('pointerup', up);
    h.addEventListener('pointercancel', up);
  }

  if (typeof ResizeObserver === 'function') new ResizeObserver(() => layout()).observe(table);
  requestAnimationFrame(layout);
}
