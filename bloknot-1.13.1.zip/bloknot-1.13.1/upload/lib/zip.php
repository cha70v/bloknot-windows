<?php
/**
 * Минимальный ZIP без внешних расширений: потоковая запись (с deflate-сжатием без потерь или без сжатия) и чтение.
 * Для чтения сжатых архивов используется ZipArchive, если он есть на хостинге.
 */

class StoreZipWriter
{
    private $out;
    private $entries = array();
    private $offset = 0;

    private $compress = false;
    private $level = 9;
    private $tmpDir;

    /**
     * @param resource $out поток для записи (файл или php://output)
     * @param bool $compress сжимать записи (deflate, без потерь). Уже сжатые данные (JPEG, PNG, WebP…)
     *                       сохраняются как есть, если сжатие не даёт выигрыша.
     */
    public function __construct($out, $compress = false, $tmpDir = null)
    {
        $this->out = $out;
        $this->compress = $compress && function_exists('gzdeflate');
        $this->tmpDir = $tmpDir ?: sys_get_temp_dir();
    }

    private function write($bin)
    {
        fwrite($this->out, $bin);
        $this->offset += strlen($bin);
    }

    private static function dosTime($ts)
    {
        $d = getdate($ts);
        if ($d['year'] < 1980) $d = getdate(315532800);
        $time = ($d['hours'] << 11) | ($d['minutes'] << 5) | intdiv($d['seconds'], 2);
        $date = (($d['year'] - 1980) << 9) | ($d['mon'] << 5) | $d['mday'];
        return array($time, $date);
    }

    public function addString($name, $data, $mtime = null)
    {
        $crc = hexdec(hash('crc32b', $data));
        if ($this->compress && strlen($data) > 256) {
            $packed = gzdeflate($data, $this->level);
            if (strlen($packed) < strlen($data)) {
                $this->header($name, $crc, strlen($data), $mtime ?: time(), 8, strlen($packed));
                $this->write($packed);
                return;
            }
        }
        $this->header($name, $crc, strlen($data), $mtime ?: time());
        $this->write($data);
    }

    /** Есть ли смысл сжимать файл: пробуем первые 256 КБ быстрым сжатием. */
    private static function worthCompressing($path, $size)
    {
        if ($size < 512) return false;
        $fh = fopen($path, 'rb');
        $head = fread($fh, 262144);
        fclose($fh);
        if ($head === false || $head === '') return false;
        // заведомо сжатые форматы: JPEG, GIF, WebP, ZIP, gzip
        if (preg_match('/^(\xFF\xD8\xFF|GIF8|RIFF....WEBP|PK\x03\x04|\x1F\x8B)/s', $head)) return false;
        return strlen(gzdeflate($head, 1)) < strlen($head) * 0.92;
    }

    public function addFile($name, $path)
    {
        $size = filesize($path);
        if ($size > 0xFFFFFFFE) throw new HttpError(413, 'Файл слишком большой для архива: ' . $name);
        $crc = hexdec(hash_file('crc32b', $path));
        if ($this->compress && function_exists('deflate_init') && self::worthCompressing($path, $size)) {
            $tmp = $this->tmpDir . '/zip-' . bin2hex(random_bytes(6)) . '.part';
            try {
                $ctx = deflate_init(ZLIB_ENCODING_RAW, array('level' => $this->level, 'memory' => 9));
                $in = fopen($path, 'rb');
                $tf = fopen($tmp, 'wb');
                while (!feof($in)) {
                    $chunk = fread($in, 1048576);
                    if ($chunk === false || $chunk === '') break;
                    fwrite($tf, deflate_add($ctx, $chunk, ZLIB_NO_FLUSH));
                }
                fwrite($tf, deflate_add($ctx, '', ZLIB_FINISH));
                fclose($in);
                fclose($tf);
                $csize = filesize($tmp);
                if ($csize < $size * 0.97) {
                    $this->header($name, $crc, $size, filemtime($path), 8, $csize);
                    $this->copyFrom($tmp);
                    return;
                }
            } finally {
                @unlink($tmp);
            }
        }
        $this->header($name, $crc, $size, filemtime($path));
        $this->copyFrom($path);
    }

    private function copyFrom($path)
    {
        $in = fopen($path, 'rb');
        while (!feof($in)) {
            $chunk = fread($in, 1048576);
            if ($chunk === false || $chunk === '') break;
            $this->write($chunk);
        }
        fclose($in);
    }

    private function header($name, $crc, $size, $mtime, $method = 0, $csize = null)
    {
        $name = str_replace('\\', '/', $name);
        if ($csize === null) $csize = $size;
        list($t, $d) = self::dosTime($mtime);
        $this->entries[] = array('name' => $name, 'crc' => $crc, 'size' => $size, 'csize' => $csize, 'method' => $method, 'offset' => $this->offset, 't' => $t, 'd' => $d);
        $this->write(pack('VvvvvvVVVvv', 0x04034b50, 20, 0x0800, $method, $t, $d, $crc, $csize, $size, strlen($name), 0) . $name);
    }

    public function finish()
    {
        $cdStart = $this->offset;
        foreach ($this->entries as $e) {
            $this->write(pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0x0800, $e['method'], $e['t'], $e['d'], $e['crc'], $e['csize'], $e['size'],
                strlen($e['name']), 0, 0, 0, 0, 0, $e['offset']) . $e['name']);
        }
        $cdSize = $this->offset - $cdStart;
        $n = count($this->entries);
        $this->write(pack('VvvvvVVv', 0x06054b50, 0, 0, $n, $n, $cdSize, $cdStart, 0));
    }
}

/**
 * Распаковывает архив в каталог. Возвращает список путей. Защищено от выхода за пределы каталога (zip-slip).
 */
function zip_extract_safe($zipPath, $destDir, $maxTotal = 4294967296)
{
    if (!is_dir($destDir)) mkdir($destDir, 0750, true);
    $names = array();
    $check = function ($name) {
        $name = str_replace('\\', '/', $name);
        if ($name === '' || str_starts_with($name, '/') || preg_match('#(^|/)\.\.(/|$)#', $name) || str_contains($name, "\0")) {
            throw new HttpError(422, 'Архив содержит недопустимый путь: ' . $name);
        }
        return $name;
    };
    if (class_exists('ZipArchive') && !defined('TETRAD_NO_ZIPARCHIVE')) {
        $z = new ZipArchive();
        if ($z->open($zipPath) !== true) throw new HttpError(422, 'Не удалось открыть архив');
        $total = 0;
        for ($i = 0; $i < $z->numFiles; $i++) {
            $st = $z->statIndex($i);
            $name = $check($st['name']);
            $total += $st['size'];
            if ($total > $maxTotal) throw new HttpError(413, 'Архив слишком большой');
            if (str_ends_with($name, '/')) {
                @mkdir($destDir . '/' . $name, 0750, true);
                continue;
            }
            $target = $destDir . '/' . $name;
            if (!is_dir(dirname($target))) mkdir(dirname($target), 0750, true);
            $in = $z->getStream($st['name']);
            $out = fopen($target, 'wb');
            stream_copy_to_stream($in, $out);
            fclose($in);
            fclose($out);
            if (filesize($target) !== (int) $st['size'] || hexdec(hash_file('crc32b', $target)) !== ($st['crc'] & 0xFFFFFFFF)) {
                throw new HttpError(422, 'Архив повреждён или загружен не полностью (' . $name . ')');
            }
            $names[] = $name;
        }
        $z->close();
        return $names;
    }
    // Чтение без ZipArchive: записи без сжатия и deflate (такие создаёт сам Блокнот)
    $total = 0;
    $fh = fopen($zipPath, 'rb');
    $size = filesize($zipPath);
    $tail = min($size, 65557);
    fseek($fh, $size - $tail);
    $buf = fread($fh, $tail);
    $pos = strrpos($buf, pack('V', 0x06054b50));
    if ($pos === false) throw new HttpError(422, 'Повреждённый архив');
    $eocd = unpack('Vsig/vdisk/vcd_disk/ventries_disk/ventries/Vcd_size/Vcd_offset/vcomment', substr($buf, $pos, 22));
    fseek($fh, $eocd['cd_offset']);
    $cd = fread($fh, $eocd['cd_size']);
    $p = 0;
    for ($i = 0; $i < $eocd['entries']; $i++) {
        $h = unpack('Vsig/vver/vneed/vflags/vmethod/vtime/vdate/Vcrc/Vcsize/Vsize/vnlen/velen/vclen/vdisk/vint/Vext/Voffset', substr($cd, $p, 46));
        $name = $check(substr($cd, $p + 46, $h['nlen']));
        $p += 46 + $h['nlen'] + $h['elen'] + $h['clen'];
        if (str_ends_with($name, '/')) continue;
        if ($h['method'] !== 0 && !($h['method'] === 8 && function_exists('inflate_init'))) {
            throw new HttpError(422, 'Архив сжат способом, который этот хостинг не поддерживает. Распакуйте его на компьютере и загрузите папку data по FTP (см. README).');
        }
        $total += $h['size'];
        if ($total > $maxTotal) throw new HttpError(413, 'Архив слишком большой');
        fseek($fh, $h['offset']);
        $lh = unpack('Vsig/vver/vflags/vmethod/vtime/vdate/Vcrc/Vcsize/Vsize/vnlen/velen', fread($fh, 30));
        fseek($fh, $h['offset'] + 30 + $lh['nlen'] + $lh['elen']);
        $target = $destDir . '/' . $name;
        if (!is_dir(dirname($target))) mkdir(dirname($target), 0750, true);
        $out = fopen($target, 'wb');
        $left = $h['csize'];
        $ctx = $h['method'] === 8 ? inflate_init(ZLIB_ENCODING_RAW) : null;
        $crc = hash_init('crc32b');
        while ($left > 0) {
            $chunk = fread($fh, min(1048576, $left));
            if ($chunk === false || $chunk === '') break;
            $left -= strlen($chunk);
            if ($ctx) {
                $chunk = inflate_add($ctx, $chunk, $left > 0 ? ZLIB_SYNC_FLUSH : ZLIB_FINISH);
                if ($chunk === false) throw new HttpError(422, 'Повреждённый архив: ' . $name);
            }
            hash_update($crc, $chunk);
            fwrite($out, $chunk);
        }
        fclose($out);
        if ($left > 0 || hexdec(hash_final($crc)) !== $h['crc']) throw new HttpError(422, 'Архив повреждён или загружен не полностью (' . $name . ')');
        $names[] = $name;
    }
    fclose($fh);
    return $names;
}
