// Боковая панель: навигация, недавние, дерево страниц с перетаскиванием
import { el, clear, pageTitle, modLabel, isTouch } from '../util.js';
import { icon } from '../icons.js';
import { state, events, children, toggleExpanded, setSort, loadTree, descendants } from '../store.js';
import { api } from '../api.js';
import { showMenu } from './menu.js';
import { toast } from './modal.js';
import { navigate, openPage, createPage, trashPage, duplicatePage, movePageDialog, exportPage, toggleFavorite } from './actions.js';

export function buildSidebar({ onSearch, onSettings, onTrash, onClose }) {
  const tree = el('div', { class: 'tree', role: 'tree', 'aria-label': 'Страницы' });
  const favList = el('div', { class: 'fav-list' });
  const sortBtn = el('button', { type: 'button', class: 'icon-btn icon-btn-small', title: 'Сортировка', 'aria-label': 'Сортировка страниц' }, icon('sort', 16));
  const addBtn = el('button', { type: 'button', class: 'icon-btn icon-btn-small', title: 'Новая страница', 'aria-label': 'Новая страница' }, icon('plus', 16));
  const userName = (state.user && (state.user.name || state.user.email)) || '';

  const navItem = (ic, label, hint, onClick) => {
    const b = el('button', { type: 'button', class: 'nav-item' }, icon(ic, 17), el('span', { class: 'nav-label' }, label), hint ? el('span', { class: 'nav-hint' }, hint) : null);
    b.addEventListener('click', onClick);
    return b;
  };

  const closeBtn = el('button', { type: 'button', class: 'icon-btn sidebar-close', title: 'Скрыть панель', 'aria-label': 'Скрыть панель' }, icon('sidebar', 18));
  closeBtn.addEventListener('click', onClose);

  const aside = el(
    'aside',
    { class: 'sidebar', 'aria-label': 'Навигация' },
    el('div', { class: 'sb-head' }, el('a', { class: 'sb-brand', href: '#/' }, el('span', { class: 'sb-logo', 'aria-hidden': 'true' }), el('span', { class: 'sb-brand-text' }, el('span', { class: 'sb-name' }, 'Блокнот'), el('span', { class: 'sb-user' }, userName))), closeBtn),
    el(
      'nav',
      { class: 'sb-nav' },
      navItem('search', 'Поиск', `${modLabel}+K`, onSearch),
      navItem('home', 'Главная', '', () => navigate('#/')),
      navItem('settings', 'Настройки', '', onSettings),
    ),
    el(
      'div',
      { class: 'sb-scroll' },
      el('div', { class: 'sb-section sb-favorites' }, el('div', { class: 'sb-section-head' }, el('span', { class: 'sb-section-title' }, 'Избранное')), favList),
      el('div', { class: 'sb-section' }, el('div', { class: 'sb-section-head' }, el('span', { class: 'sb-section-title' }, 'Страницы'), el('span', { class: 'sb-section-actions' }, sortBtn, addBtn)), tree),
    ),
    el('div', { class: 'sb-foot' }, navItem('trash', 'Корзина', '', onTrash), navItem('plus', 'Новая страница', '', () => createPage(null))),
  );

  addBtn.addEventListener('click', () => createPage(null));
  sortBtn.addEventListener('click', () => {
    showMenu({
      anchor: sortBtn,
      sheetTitle: 'Сортировка',
      items: [
        { label: 'Вручную (перетаскиванием)', checked: state.sort === 'manual', onSelect: () => setSort('manual') },
        { label: 'По названию', checked: state.sort === 'title', onSelect: () => setSort('title') },
        { label: 'По дате изменения', checked: state.sort === 'updated', onSelect: () => setSort('updated') },
      ],
    });
  });

  // ---------- дерево ----------
  function renderTree() {
    clear(tree);
    const roots = children(null);
    if (!roots.length) {
      tree.append(el('div', { class: 'tree-empty' }, 'Страниц пока нет'));
      return;
    }
    const frag = document.createDocumentFragment();
    const walk = (list, depth) => {
      for (const p of list) {
        const kids = children(p.id);
        const open = state.expanded.has(p.id);
        frag.append(row(p, depth, kids.length > 0, open));
        if (open && kids.length) walk(kids, depth + 1);
        else if (open && !kids.length) frag.append(el('div', { class: 'tree-none', style: { paddingLeft: `${28 + (depth + 1) * 14}px` } }, 'Нет вложенных страниц'));
      }
    };
    walk(roots, 0);
    tree.append(frag);
  }

  function row(p, depth, hasKids, open) {
    const chev = el('button', { type: 'button', class: `tree-chev${open ? ' is-open' : ''}`, tabindex: '-1', 'aria-label': open ? 'Свернуть' : 'Развернуть' }, icon('chevron', 14));
    const add = el('button', { type: 'button', class: 'tree-act', tabindex: '-1', title: 'Добавить вложенную страницу', 'aria-label': 'Добавить вложенную страницу' }, icon('plus', 15));
    const more = el('button', { type: 'button', class: 'tree-act', tabindex: '-1', title: 'Действия', 'aria-label': 'Действия со страницей' }, icon('more', 15));
    const r = el(
      'a',
      {
        class: `tree-row${state.currentId === p.id ? ' is-current' : ''}${hasKids ? '' : ' no-kids'}`, href: `#/p/${p.id}`, role: 'treeitem', 'aria-expanded': hasKids ? String(open) : null,
        'aria-current': state.currentId === p.id ? 'page' : null, 'data-id': p.id, style: { paddingLeft: `${6 + depth * 14}px` }, draggable: 'false',
      },
      chev,
      el('span', { class: 'tree-icon' }, p.icon || icon('page', 16)),
      el('span', { class: 'tree-title' }, pageTitle(p)),
      el('span', { class: 'tree-actions' }, more, add),
    );
    chev.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleExpanded(p.id);
    });
    add.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      createPage(p.id);
    });
    more.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      pageMenu(p, more);
    });
    r.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      pageMenu(p, { x: e.clientX, y: e.clientY });
    });
    r.addEventListener('click', (e) => {
      if (r.dataset.dragged) {
        e.preventDefault();
        delete r.dataset.dragged;
        return;
      }
      if (window.innerWidth < 900) onClose(true);
    });
    r.addEventListener('pointerdown', (e) => startTreeDrag(e, r, p));
    return r;
  }

  function pageMenu(p, anchor) {
    showMenu({
      anchor,
      sheetTitle: pageTitle(p),
      items: [
        { label: 'Открыть', icon: 'open', onSelect: () => openPage(p.id) },
        p.favorite_at
          ? { label: 'Убрать из избранного', icon: 'starOff', onSelect: () => toggleFavorite(p.id, false) }
          : { label: 'Добавить в избранное', icon: 'star', onSelect: () => toggleFavorite(p.id, true) },
        { label: 'Добавить вложенную', icon: 'plus', onSelect: () => createPage(p.id) },
        { label: 'Дублировать', icon: 'duplicate', onSelect: () => duplicatePage(p.id) },
        { label: 'Переместить в…', icon: 'move', onSelect: () => movePageDialog(p.id) },
        { label: 'Экспорт в Markdown', icon: 'download', onSelect: () => exportPage(p.id) },
        { separator: true },
        { label: 'В корзину', icon: 'trash', danger: true, onSelect: () => trashPage(p.id) },
      ],
    });
  }

  // ---------- перетаскивание страниц ----------
  function startTreeDrag(e, rowEl, p) {
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    if (e.target.closest('.tree-act, .tree-chev')) return;
    const startX = e.clientX;
    const startY = e.clientY;
    const pid = e.pointerId;
    let dragging = false;
    let ghost = null;
    let marker = null;
    let target = null;
    let longPress = null;
    const touch = e.pointerType !== 'mouse';
    const forbidden = new Set([p.id, ...descendants(p.id)]);
    const begin = () => {
      dragging = true;
      rowEl.dataset.dragged = '1';
      document.body.classList.add('is-dragging');
      ghost = el('div', { class: 'drag-ghost tree-ghost' }, p.icon || '📄', ' ', pageTitle(p));
      document.body.append(ghost);
      marker = el('div', { class: 'tree-drop' });
      tree.append(marker);
      rowEl.classList.add('is-dragged');
      if (navigator.vibrate && touch) navigator.vibrate(10);
    };
    if (touch) {
      // на сенсорных экранах — долгое нажатие, чтобы не мешать прокрутке
      longPress = setTimeout(() => {
        begin();
        try {
          rowEl.setPointerCapture(pid);
        } catch (err) {
          /* ignore */
        }
      }, 380);
    }
    const move = (ev) => {
      if (ev.pointerId !== pid) return;
      if (!dragging) {
        const dist = Math.hypot(ev.clientX - startX, ev.clientY - startY);
        if (touch) {
          if (dist > 8) cleanup();
          return;
        }
        if (dist < 5) return;
        begin();
      }
      ev.preventDefault();
      ghost.style.transform = `translate(${ev.clientX + 10}px, ${ev.clientY - 12}px)`;
      target = computeTarget(ev.clientX, ev.clientY, forbidden);
      showMarker(target, marker);
    };
    const up = (ev) => {
      if (ev.pointerId !== pid) return;
      const t = target;
      const was = dragging;
      cleanup();
      if (was && t) applyDrop(p, t);
    };
    const prevent = (ev) => {
      if (dragging) ev.preventDefault();
    };
    function cleanup() {
      clearTimeout(longPress);
      document.removeEventListener('pointermove', move);
      document.removeEventListener('pointerup', up);
      document.removeEventListener('pointercancel', up);
      document.removeEventListener('touchmove', prevent);
      if (ghost) ghost.remove();
      if (marker) marker.remove();
      rowEl.classList.remove('is-dragged');
      tree.querySelectorAll('.is-drop-into').forEach((n) => n.classList.remove('is-drop-into'));
      document.body.classList.remove('is-dragging');
      dragging = false;
      setTimeout(() => delete rowEl.dataset.dragged, 50);
    }
    document.addEventListener('pointermove', move);
    document.addEventListener('pointerup', up);
    document.addEventListener('pointercancel', up);
    document.addEventListener('touchmove', prevent, { passive: false });
  }

  function computeTarget(x, y, forbidden) {
    const rows = Array.from(tree.querySelectorAll('.tree-row'));
    for (const r of rows) {
      const rect = r.getBoundingClientRect();
      if (y < rect.top || y > rect.bottom) continue;
      const id = Number(r.dataset.id);
      if (forbidden.has(id)) return null;
      const rel = (y - rect.top) / rect.height;
      const manual = state.sort === 'manual';
      if (manual && rel < 0.28) return { mode: 'before', id, row: r };
      if (manual && rel > 0.72 && !state.expanded.has(id)) return { mode: 'after', id, row: r };
      return { mode: 'into', id, row: r };
    }
    const last = rows[rows.length - 1];
    if (last && y > last.getBoundingClientRect().bottom) return { mode: 'root-end', id: null, row: last };
    return null;
  }

  function showMarker(t, marker) {
    tree.querySelectorAll('.is-drop-into').forEach((n) => n.classList.remove('is-drop-into'));
    if (!t) {
      marker.style.display = 'none';
      return;
    }
    if (t.mode === 'into') {
      marker.style.display = 'none';
      t.row.classList.add('is-drop-into');
      return;
    }
    const tr = tree.getBoundingClientRect();
    const rr = t.row.getBoundingClientRect();
    marker.style.display = 'block';
    marker.style.top = `${(t.mode === 'before' ? rr.top : rr.bottom) - tr.top + tree.scrollTop - 1}px`;
    marker.style.left = t.mode === 'root-end' ? '6px' : `${parseFloat(t.row.style.paddingLeft) + 20}px`;
  }

  async function applyDrop(p, t) {
    let payload;
    if (t.mode === 'into') payload = { id: p.id, parent_id: t.id };
    else if (t.mode === 'root-end') payload = { id: p.id, parent_id: null };
    else {
      const target = state.pages.get(t.id);
      payload = { id: p.id, parent_id: target.parent_id, [t.mode === 'before' ? 'before_id' : 'after_id']: t.id };
    }
    try {
      await api('page.move', payload);
      if (t.mode === 'into') toggleExpanded(t.id, true);
      await loadTree();
    } catch (err) {
      toast(err.message, 'error');
    }
  }

  // ---------- избранное ----------
  function renderFavorites() {
    clear(favList);
    const items = Array.from(state.pages.values()).filter((p) => p.favorite_at).sort((a, b) => a.favorite_at - b.favorite_at);
    aside.querySelector('.sb-favorites').style.display = items.length ? '' : 'none';
    for (const p of items) {
      const more = el('button', { type: 'button', class: 'tree-act', tabindex: '-1', title: 'Действия', 'aria-label': 'Действия со страницей' }, icon('more', 15));
      const a = el(
        'a',
        { class: `tree-row fav-row${state.currentId === p.id ? ' is-current' : ''}`, href: `#/p/${p.id}`, 'data-fav': p.id, style: { paddingLeft: '6px' } },
        el('span', { class: 'tree-icon' }, p.icon || icon('page', 16)),
        el('span', { class: 'tree-title' }, pageTitle(p)),
        el('span', { class: 'tree-actions' }, more),
      );
      more.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        pageMenu(p, more);
      });
      a.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        pageMenu(p, { x: e.clientX, y: e.clientY });
      });
      a.addEventListener('click', () => {
        if (window.innerWidth < 900) onClose(true);
      });
      favList.append(a);
    }
  }

  events.on('tree', () => {
    renderTree();
    renderFavorites();
  });
  renderTree();
  renderFavorites();
  return { el: aside, renderTree: () => {
    renderTree();
    renderFavorites();
  }, renderRecent: renderFavorites };
}

export { isTouch };
