// Преобразование HTML / Markdown ↔ блоки. Используется при вставке, копировании и импорте из Notion.
import { marked } from 'marked';
import { normalizeInline, htmlToText } from '../sanitize.js';
import { newBlock, validColor } from './model.js';
import { normalizeLang } from './highlight.js';
import { escapeHtml, safeHref } from '../util.js';

const BLOCK_TAGS = new Set([
  'ADDRESS', 'ARTICLE', 'ASIDE', 'BLOCKQUOTE', 'DETAILS', 'DIALOG', 'DD', 'DIV', 'DL', 'DT', 'FIELDSET', 'FIGCAPTION', 'FIGURE', 'FOOTER',
  'FORM', 'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'HEADER', 'HGROUP', 'HR', 'LI', 'MAIN', 'NAV', 'OL', 'P', 'PRE', 'SECTION', 'TABLE', 'UL',
  'IMG', 'SUMMARY', 'VIDEO', 'IFRAME', 'CENTER', 'AUDIO', 'PICTURE',
]);
const SKIP = new Set(['SCRIPT', 'STYLE', 'META', 'LINK', 'TITLE', 'HEAD', 'NOSCRIPT', 'TEMPLATE', 'SVG', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'COLGROUP']);
const BLOCK_SELECTOR = Array.from(BLOCK_TAGS).map((t) => t.toLowerCase()).join(',');

function isBlockEl(n) {
  return n.nodeType === 1 && (BLOCK_TAGS.has(n.tagName) || !!n.querySelector(BLOCK_SELECTOR));
}

/**
 * @param {string|Document|Element} input
 * @param {object} opts { resolveHref(href)->href|null, resolvePageLink(href)->pageId|null, notion: bool }
 * Изображения возвращаются как { type:'image', src } — загрузку выполняет вызывающий код.
 */
export function htmlToBlocks(input, opts = {}) {
  let root;
  if (typeof input === 'string') {
    const doc = new DOMParser().parseFromString(input, 'text/html');
    root = doc.body;
  } else if (input.nodeType === 9) root = input.body;
  else root = input;
  const out = [];
  walkContainer(root, 0, out, opts);
  // убираем пустые абзацы подряд и в начале/конце
  const res = [];
  for (const b of out) {
    const empty = b.type === 'p' && !b.html;
    const prevEmpty = res.length && res[res.length - 1].type === 'p' && !res[res.length - 1].html;
    if (empty && (prevEmpty || !res.length)) continue;
    res.push(b);
  }
  while (res.length && res[res.length - 1].type === 'p' && !res[res.length - 1].html) res.pop();
  return res;
}

function inline(nodeOrNodes, opts) {
  const holder = document.createElement('div');
  for (const n of Array.isArray(nodeOrNodes) ? nodeOrNodes : [nodeOrNodes]) holder.append(n.cloneNode(true));
  return normalizeInline(holder, { resolveHref: opts.resolveHref });
}

function withIndent(b, indent) {
  if (indent > 0) b.indent = Math.min(6, indent);
  return b;
}

// Notion: цвет блока задаётся классом block-color-red / block-color-red_background
function notionColor(el) {
  for (let n = el, i = 0; n && n.classList && i < 3; n = n.parentElement, i++) {
    for (const c of n.classList) {
      const m = c.match(/^block-color-([a-z]+(?:_background)?)$/);
      if (m && m[1] !== 'default') return validColor(m[1]);
    }
  }
  return null;
}

function walkContainer(container, indent, out, opts) {
  let buffer = [];
  const flush = () => {
    if (!buffer.length) return;
    const html = inline(buffer, opts);
    buffer = [];
    if (html.replace(/<br>|&nbsp;|\s/g, '')) out.push(withIndent(newBlock('p', { html }), indent));
  };
  for (const child of Array.from(container.childNodes)) {
    if (child.nodeType === 3) {
      if (child.nodeValue.trim() || buffer.length) buffer.push(child);
      continue;
    }
    if (child.nodeType !== 1 || SKIP.has(child.tagName)) continue;
    if (child.tagName === 'BR') {
      if (buffer.length) buffer.push(child);
      continue;
    }
    if (!isBlockEl(child)) {
      buffer.push(child);
      continue;
    }
    flush();
    const before = out.length;
    handleBlock(child, indent, out, opts);
    const color = child.classList ? notionColor(child) : null;
    if (color) {
      for (let k = before; k < out.length; k++) {
        if (!out[k].color && out[k].type !== 'code' && out[k].type !== 'image' && out[k].type !== 'table' && out[k].type !== 'hr') out[k].color = color;
      }
    }
  }
  flush();
}

function textOf(el) {
  return (el.textContent || '').replace(/\s+/g, ' ').trim();
}

function msoList(el) {
  const style = el.getAttribute('style') || '';
  const cls = el.className || '';
  if (!/MsoList/i.test(cls) && !/mso-list/i.test(style)) return null;
  const lvl = style.match(/level(\d+)/i);
  const clone = el.cloneNode(true);
  let marker = '';
  clone.querySelectorAll('span').forEach((s) => {
    if (/mso-list\s*:\s*ignore/i.test(s.getAttribute('style') || '')) {
      marker += s.textContent;
      s.remove();
    }
  });
  if (!marker) {
    // маркер может быть первым текстом
    const m = clone.textContent.match(/^\s*([·•o§▪\-]|\d+[.)]|[a-z][.)])\s+/i);
    if (m) marker = m[1];
  }
  const ordered = /\d+[.)]|[a-z][.)]/i.test(marker.trim());
  return { ordered, level: lvl ? parseInt(lvl[1], 10) - 1 : 0, content: clone, marker };
}

function handleBlock(el, indent, out, opts) {
  const tag = el.tagName;
  const cls = el.classList;
  switch (tag) {
    case 'H1':
    case 'H2':
    case 'H3':
    case 'H4':
    case 'H5':
    case 'H6': {
      if (cls.contains('page-title')) return;
      const type = tag === 'H1' ? 'h1' : tag === 'H2' ? 'h2' : 'h3';
      const html = inline(Array.from(el.childNodes), opts);
      if (html) out.push(withIndent(newBlock(type, { html }), indent));
      return;
    }
    case 'P': {
      const imgs = el.querySelectorAll('img');
      if (imgs.length && !textOf(el)) {
        imgs.forEach((img) => pushImage(img, out, indent));
        return;
      }
      const mso = msoList(el);
      if (mso) {
        let html = inline(Array.from(mso.content.childNodes), opts);
        html = html.replace(/^(\s|&nbsp;)*([·•o§▪\-]|\d+[.)]|[a-z][.)])(\s|&nbsp;)+/i, '');
        out.push(withIndent(newBlock(mso.ordered ? 'ol' : 'ul', { html }), indent + mso.level));
        return;
      }
      if (el.querySelector(BLOCK_SELECTOR)) {
        walkContainer(el, indent, out, opts);
        return;
      }
      out.push(withIndent(newBlock('p', { html: inline(Array.from(el.childNodes), opts) }), indent));
      return;
    }
    case 'UL':
    case 'OL': {
      const ordered = tag === 'OL';
      const isTodo = cls.contains('to-do-list');
      const isToggle = cls.contains('toggle');
      for (const li of Array.from(el.children)) {
        if (li.tagName !== 'LI') {
          handleBlock(li, indent + 1, out, opts);
          continue;
        }
        handleListItem(li, ordered ? 'ol' : 'ul', indent, out, opts, isTodo, isToggle);
      }
      return;
    }
    case 'LI':
      handleListItem(el, 'ul', indent, out, opts, false, false);
      return;
    case 'BLOCKQUOTE': {
      const html = inline(Array.from(el.childNodes), opts);
      if (html) out.push(withIndent(newBlock('quote', { html }), indent));
      return;
    }
    case 'PRE': {
      const codeEl = el.querySelector('code') || el;
      const langCls = (codeEl.className + ' ' + el.className).match(/language-([\w+#-]+)/i);
      const text = (codeEl.innerText !== undefined && codeEl.isConnected ? codeEl.innerText : codeEl.textContent).replace(/\n$/, '');
      out.push(withIndent(newBlock('code', { text, lang: normalizeLang(langCls ? langCls[1] : el.getAttribute('data-language') || '') }), indent));
      return;
    }
    case 'HR':
      out.push(withIndent(newBlock('hr'), indent));
      return;
    case 'IMG':
      pushImage(el, out, indent);
      return;
    case 'PICTURE': {
      const img = el.querySelector('img');
      if (img) pushImage(img, out, indent);
      return;
    }
    case 'TABLE': {
      const rows = [];
      el.querySelectorAll('tr').forEach((tr) => {
        const cells = [];
        tr.querySelectorAll('th,td').forEach((td) => cells.push(inline(Array.from(td.childNodes), opts)));
        if (cells.length) rows.push(cells);
      });
      if (rows.length) out.push(withIndent(newBlock('table', { rows }), indent));
      return;
    }
    case 'DETAILS': {
      const summary = el.querySelector(':scope > summary');
      const html = summary ? inline(Array.from(summary.childNodes), opts) : '';
      out.push(withIndent(newBlock('toggle', { html, open: el.hasAttribute('open') }), indent));
      const rest = el.cloneNode(true);
      const s2 = rest.querySelector(':scope > summary');
      if (s2) s2.remove();
      walkContainer(rest, indent + 1, out, opts);
      return;
    }
    case 'FIGURE': {
      if (cls.contains('callout')) {
        const iconEl = el.querySelector('.icon');
        const icon = iconEl ? iconEl.textContent.trim() : '💡';
        const divs = Array.from(el.children).filter((c) => c.tagName === 'DIV');
        const body = divs.length > 1 ? divs[divs.length - 1] : el;
        const blocks = [];
        walkContainer(body, 0, blocks, opts);
        const first = blocks.shift();
        out.push(withIndent(newBlock('callout', { icon: icon && icon.length <= 8 ? icon : '💡', html: first ? first.html || htmlToText('') : '' }), indent));
        blocks.forEach((b) => out.push(withIndent(b, indent + 1 + (b.indent || 0))));
        return;
      }
      if (cls.contains('link-to-page')) {
        const a = el.querySelector('a');
        const href = a ? a.getAttribute('href') : '';
        const pageId = opts.resolvePageLink ? opts.resolvePageLink(href) : null;
        if (pageId) out.push(withIndent(newBlock('page', { pageId }), indent));
        else if (a) out.push(withIndent(newBlock('p', { html: inline(a, opts) }), indent));
        return;
      }
      const bm = el.querySelector('a.bookmark') || (el.querySelector('.bookmark-info') && el.querySelector('a'));
      if (bm) {
        pushBookmark(bm, out, indent);
        return;
      }
      if (cls.contains('equation')) {
        out.push(withIndent(newBlock('code', { text: textOf(el), lang: 'plain' }), indent));
        return;
      }
      const img = el.querySelector('img');
      if (img) {
        const cap = el.querySelector('figcaption');
        pushImage(img, out, indent, cap ? inline(Array.from(cap.childNodes), opts) : '');
        return;
      }
      const src = el.querySelector('.source a, a');
      if (src && !textOf(el).replace(textOf(src), '').trim()) {
        pushBookmark(src, out, indent);
        return;
      }
      walkContainer(el, indent, out, opts);
      return;
    }
    case 'A':
      if (cls.contains('bookmark')) {
        pushBookmark(el, out, indent);
        return;
      }
      walkContainer(el, indent, out, opts);
      return;
    case 'IFRAME':
    case 'VIDEO':
    case 'AUDIO': {
      const src = el.getAttribute('src') || (el.querySelector('source') || {}).src;
      const href = safeHref(src);
      if (href) out.push(withIndent(newBlock('bookmark', { url: href, title: '' }), indent));
      return;
    }
    case 'DIV':
      if (cls.contains('indented')) {
        walkContainer(el, indent + 1, out, opts);
        return;
      }
      walkContainer(el, indent, out, opts);
      return;
    default:
      walkContainer(el, indent, out, opts);
  }
}

function pushImage(img, out, indent, caption = '') {
  const src = img.getAttribute('src') || '';
  if (!src) return;
  const b = newBlock('image', { src, caption: caption || '' });
  const w = parseInt(img.getAttribute('width') || '', 10);
  if (w && w < 700) b.width = Math.max(20, Math.min(100, Math.round((w / 720) * 100)));
  out.push(withIndent(b, indent));
}

function pushBookmark(a, out, indent) {
  const url = safeHref(a.getAttribute('href'));
  if (!url) return;
  const t = a.querySelector('.bookmark-title');
  out.push(withIndent(newBlock('bookmark', { url, title: t ? textOf(t) : textOf(a) === url ? '' : textOf(a).slice(0, 300) }), indent));
}

function handleListItem(li, listType, indent, out, opts, notionTodo, notionToggle) {
  // Notion: раскрывающийся блок
  const details = li.querySelector(':scope > details');
  if (notionToggle || details) {
    if (details) {
      handleBlock(details, indent, out, opts);
      return;
    }
  }
  let type = listType;
  let checked = false;
  const inlineNodes = [];
  const nested = [];
  const firstInput = li.querySelector(':scope > input[type=checkbox], :scope > p > input[type=checkbox], :scope > label > input[type=checkbox]');
  const notionBox = li.querySelector(':scope > .checkbox');
  if (notionTodo || firstInput || notionBox) {
    type = 'todo';
    checked = firstInput ? firstInput.checked || firstInput.hasAttribute('checked') : !!(notionBox && notionBox.classList.contains('checkbox-on'));
  }
  for (const c of Array.from(li.childNodes)) {
    if (c.nodeType === 1 && (c.tagName === 'UL' || c.tagName === 'OL' || (c.tagName === 'DIV' && c.classList.contains('indented')))) nested.push(c);
    else if (c.nodeType === 1 && isBlockEl(c) && c.tagName !== 'P' && c.tagName !== 'SPAN') nested.push(c);
    else if (c.nodeType === 1 && c.tagName === 'P' && inlineNodes.length) nested.push(c);
    else if (c.nodeType === 1 && c.tagName === 'INPUT') continue;
    else inlineNodes.push(c);
  }
  let html = inline(inlineNodes, opts).replace(/^\[( |x)\]\s*/i, (m, x) => {
    type = 'todo';
    checked = x.toLowerCase() === 'x';
    return '';
  });
  const b = newBlock(type, { html });
  if (type === 'todo') b.checked = checked;
  out.push(withIndent(b, indent));
  for (const n of nested) {
    if (n.tagName === 'DIV' && n.classList.contains('indented')) walkContainer(n, indent + 1, out, opts);
    else handleBlock(n, indent + 1, out, opts);
  }
}

// ---------- Markdown ----------
export function looksLikeMarkdown(text) {
  return /^(#{1,6} |[-*+] |\d+[.)] |> |```|\|.+\|)/m.test(text) || /\*\*[^*]+\*\*|\[[^\]]+\]\([^)]+\)/.test(text);
}

export function markdownToBlocks(md, opts = {}) {
  const html = marked.parse(md, { gfm: true, breaks: false, async: false });
  return htmlToBlocks(html, opts);
}

export function plainTextToBlocks(text) {
  return text
    .replace(/\r\n?/g, '\n')
    .split(/\n/)
    .map((line) => newBlock('p', { html: escapeHtml(line) }));
}

// ---------- Блоки → HTML/текст (копирование) ----------
export function blocksToHtml(blocks, ctx = {}) {
  const parts = [];
  for (const b of blocks) {
    const h = b.html || '';
    switch (b.type) {
      case 'h1': case 'h2': case 'h3': parts.push(`<${b.type}>${h}</${b.type}>`); break;
      case 'ul': parts.push(`<ul><li>${h}</li></ul>`); break;
      case 'ol': parts.push(`<ol><li>${h}</li></ol>`); break;
      case 'todo': parts.push(`<ul><li><input type="checkbox"${b.checked ? ' checked' : ''}> ${h}</li></ul>`); break;
      case 'toggle': parts.push(`<p>▸ ${h}</p>`); break;
      case 'quote': parts.push(`<blockquote>${h}</blockquote>`); break;
      case 'callout': parts.push(`<blockquote>${escapeHtml(b.icon || '')} ${h}</blockquote>`); break;
      case 'code': parts.push(`<pre><code class="language-${escapeHtml(b.lang || 'plain')}">${escapeHtml(b.text || '')}</code></pre>`); break;
      case 'hr': parts.push('<hr>'); break;
      case 'image': {
        const src = b.file && ctx.fileUrl ? ctx.fileUrl(b.file) : b.src || '';
        parts.push(`<p><img src="${escapeHtml(src)}" alt="${escapeHtml(htmlToText(b.caption || ''))}"></p>`);
        break;
      }
      case 'bookmark': parts.push(`<p><a href="${escapeHtml(b.url || '')}">${escapeHtml(b.title || b.url || '')}</a></p>`); break;
      case 'page': {
        const t = ctx.pageTitle ? ctx.pageTitle(b.pageId) : 'Страница';
        parts.push(`<p><a href="#/p/${b.pageId}">${escapeHtml(t)}</a></p>`);
        break;
      }
      case 'table':
        parts.push('<table>' + (b.rows || []).map((r) => '<tr>' + r.map((c) => `<td>${c}</td>`).join('') + '</tr>').join('') + '</table>');
        break;
      default: parts.push(`<p>${h}</p>`);
    }
  }
  return parts.join('');
}

export function blocksToText(blocks, ctx = {}) {
  const lines = [];
  let n = 0;
  for (const b of blocks) {
    const pad = '  '.repeat(b.indent || 0);
    const t = htmlToText(b.html || '');
    if (b.type === 'ol') n++;
    else n = 0;
    switch (b.type) {
      case 'h1': lines.push('# ' + t); break;
      case 'h2': lines.push('## ' + t); break;
      case 'h3': lines.push('### ' + t); break;
      case 'ul': lines.push(pad + '- ' + t); break;
      case 'ol': lines.push(pad + n + '. ' + t); break;
      case 'todo': lines.push(pad + (b.checked ? '- [x] ' : '- [ ] ') + t); break;
      case 'quote': lines.push('> ' + t); break;
      case 'callout': lines.push('> ' + (b.icon || '') + ' ' + t); break;
      case 'code': lines.push('```' + (b.lang && b.lang !== 'plain' ? b.lang : ''), b.text || '', '```'); break;
      case 'hr': lines.push('---'); break;
      case 'image': lines.push(htmlToText(b.caption || '') || '[изображение]'); break;
      case 'bookmark': lines.push(b.url || ''); break;
      case 'page': lines.push(ctx.pageTitle ? ctx.pageTitle(b.pageId) : 'Страница'); break;
      case 'table': (b.rows || []).forEach((r) => lines.push(r.map(htmlToText).join('\t'))); break;
      default: lines.push(pad + t);
    }
  }
  return lines.join('\n');
}
