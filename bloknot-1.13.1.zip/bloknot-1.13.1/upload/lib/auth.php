<?php
/** Авторизация: вход, выход, защита от перебора, смена и сброс пароля. */

define('LOGIN_WINDOW', 15 * 60);       // окно подсчёта попыток
define('LOGIN_MAX_PER_IP', 8);         // неудачных попыток с одного IP за окно
define('LOGIN_MAX_GLOBAL', 40);        // неудачных попыток всего за окно (защита от распределённого перебора)

function reset_file_path()
{
    return TETRAD_DATA . '/RESET-PASSWORD';
}

function reset_available()
{
    return is_file(reset_file_path()) || is_file(reset_file_path() . '.txt');
}

function login_throttle_check()
{
    $since = time() - LOGIN_WINDOW;
    q('DELETE FROM login_attempts WHERE created_at < ?', array(time() - 86400));
    $ipFails = (int) q_val('SELECT COUNT(*) FROM login_attempts WHERE ip = ? AND ok = 0 AND created_at > ?', array(client_ip(), $since));
    $allFails = (int) q_val('SELECT COUNT(*) FROM login_attempts WHERE ok = 0 AND created_at > ?', array($since));
    if ($ipFails >= LOGIN_MAX_PER_IP || $allFails >= LOGIN_MAX_GLOBAL) {
        $oldest = (int) q_val('SELECT MIN(created_at) FROM login_attempts WHERE ok = 0 AND created_at > ?' . ($ipFails >= LOGIN_MAX_PER_IP ? ' AND ip = ?' : ''),
            $ipFails >= LOGIN_MAX_PER_IP ? array($since, client_ip()) : array($since));
        $wait = max(60, $oldest + LOGIN_WINDOW - time());
        throw new HttpError(429, 'Слишком много неудачных попыток входа. Попробуйте через ' . ceil($wait / 60) . ' мин.', array('retry_after' => $wait));
    }
}

function login_record($ok)
{
    q('INSERT INTO login_attempts(ip, ok, created_at) VALUES(?, ?, ?)', array(client_ip(), $ok ? 1 : 0, time()));
}

function auth_login($email, $password)
{
    login_throttle_check();
    $email = trim(t_lower((string) $email));
    $user = q_one('SELECT * FROM users WHERE email = ?', array($email));
    // одинаковое время ответа для существующих и несуществующих логинов
    $hash = $user ? $user['password_hash'] : '$2y$10$usesomesillystringforsaltauVfl1YyJQKn4zNVbx2v5W1XcBlP6';
    $ok = password_verify((string) $password, $hash) && $user;
    login_record($ok);
    if (!$ok) {
        usleep(400000);
        throw new HttpError(401, 'Неверная почта или пароль');
    }
    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        q('UPDATE users SET password_hash = ? WHERE id = ?', array(password_hash($password, PASSWORD_DEFAULT), $user['id']));
    }
    // двухфакторный вход: нужен код из приложения, если это не доверенное устройство
    if (!empty($user['totp_enabled_at']) && !empty($user['totp_secret']) && !trusted_device_valid($user['id'])) {
        start_session();
        session_regenerate_id(true);
        $_SESSION = array('pending_2fa' => (int) $user['id'], 'pending_at' => time(), 'csrf' => random_token(24));
        $user['need_2fa'] = true;
        return $user;
    }
    auth_start_session_for($user);
    return $user;
}

function auth_logout()
{
    start_session();
    $_SESSION = array();
    if (ini_get('session.use_cookies')) {
        setcookie(session_name(), '', array('expires' => time() - 3600, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax'));
    }
    session_destroy();
}

function validate_password($pwd)
{
    if (!is_string($pwd) || strlen($pwd) < 8) {
        throw new HttpError(422, 'Пароль должен быть не короче 8 символов');
    }
    if (strlen($pwd) > 200) {
        throw new HttpError(422, 'Пароль слишком длинный');
    }
}

function set_user_password($userId, $pwd)
{
    validate_password($pwd);
    $changedAt = now_ms();
    q('UPDATE users SET password_hash = ?, password_changed_at = ? WHERE id = ?', array(password_hash($pwd, PASSWORD_DEFAULT), $changedAt, $userId));
    return $changedAt;
}

function auth_change_password($user, $current, $new)
{
    login_throttle_check();
    $row = q_one('SELECT password_hash FROM users WHERE id = ?', array($user['id']));
    if (!$row || !password_verify((string) $current, $row['password_hash'])) {
        login_record(false);
        throw new HttpError(403, 'Текущий пароль указан неверно');
    }
    $changedAt = set_user_password($user['id'], $new);
    trusted_devices_forget($user['id']);
    // текущая сессия остаётся действительной, остальные — завершаются
    start_session();
    session_regenerate_id(true);
    $_SESSION['login_at'] = $changedAt;
}

/**
 * Сброс пароля без почты: владелец доказывает доступ к хостингу,
 * создав по FTP файл data/RESET-PASSWORD (пустой). После сброса файл удаляется.
 */
function auth_reset_password($email, $new)
{
    if (!reset_available()) throw new HttpError(403, 'Сброс пароля не активирован');
    $email = trim(t_lower((string) $email));
    $user = q_one('SELECT id FROM users WHERE email = ?', array($email));
    if (!$user) {
        // если почта не указана или не совпала — сбрасываем пароль администратора, когда он единственный
        $count = (int) q_val('SELECT COUNT(*) FROM users');
        if ($count === 1) $user = q_one('SELECT id FROM users LIMIT 1');
    }
    if (!$user) throw new HttpError(404, 'Пользователь с такой почтой не найден');
    set_user_password($user['id'], $new);
    // доступ к хостингу подтверждён — снимаем и двухфакторный вход (на случай потерянного телефона)
    twofa_turn_off($user['id']);
    @unlink(reset_file_path());
    @unlink(reset_file_path() . '.txt');
    q('DELETE FROM login_attempts');
    return (int) $user['id'];
}

// ======================================================================
// Двухфакторный вход: одноразовые коды из приложения (TOTP, RFC 6238),
// резервные коды и «доверенные устройства» на 30 дней.
// ======================================================================

define('TOTP_PERIOD', 30);
define('TOTP_DIGITS', 6);
define('TRUSTED_DAYS', 30);
define('PENDING_2FA_TTL', 300);     // 5 минут на ввод кода после пароля

function base32_encode_raw($bin)
{
    $alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split($bin) as $c) $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    $out = '';
    foreach (str_split($bits, 5) as $chunk) $out .= $alpha[bindec(str_pad($chunk, 5, '0'))];
    return $out;
}

function base32_decode_raw($s)
{
    $alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = strtoupper(preg_replace('/[\s=-]/', '', (string) $s));
    $bits = '';
    for ($i = 0; $i < strlen($s); $i++) {
        $v = strpos($alpha, $s[$i]);
        if ($v === false) return null;
        $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $byte) if (strlen($byte) === 8) $out .= chr(bindec($byte));
    return $out;
}

/** Код для шага времени $step (HOTP, SHA-1, 6 цифр). */
function totp_code($secretB32, $step)
{
    $key = base32_decode_raw($secretB32);
    $msg = pack('N2', ($step >> 32) & 0xFFFFFFFF, $step & 0xFFFFFFFF);
    $h = hash_hmac('sha1', $msg, $key, true);
    $o = ord($h[19]) & 0x0F;
    $num = ((ord($h[$o]) & 0x7F) << 24) | (ord($h[$o + 1]) << 16) | (ord($h[$o + 2]) << 8) | ord($h[$o + 3]);
    return str_pad((string) ($num % 1000000), TOTP_DIGITS, '0', STR_PAD_LEFT);
}

/**
 * Проверяет код с допуском ±1 шаг (часы телефона могут немного спешить или отставать).
 * Возвращает номер шага или false. Код, уже использованный для входа, повторно не принимается.
 */
function totp_verify($secretB32, $code, $lastStep = 0)
{
    $code = preg_replace('/\D/', '', (string) $code);
    if (strlen($code) !== TOTP_DIGITS) return false;
    $now = (int) floor(time() / TOTP_PERIOD);
    foreach (array(0, -1, 1) as $d) {
        $step = $now + $d;
        if ($step <= (int) $lastStep) continue;
        if (hash_equals(totp_code($secretB32, $step), $code)) return $step;
    }
    return false;
}

function totp_uri($secretB32, $email)
{
    $issuer = 'Блокнот';
    $host = request_host();
    $label = rawurlencode($issuer) . ':' . rawurlencode($email . ($host ? ' (' . $host . ')' : ''));
    return 'otpauth://totp/' . $label . '?secret=' . $secretB32 . '&issuer=' . rawurlencode($issuer) . '&algorithm=SHA1&digits=' . TOTP_DIGITS . '&period=' . TOTP_PERIOD;
}

function twofa_user($uid)
{
    return q_one('SELECT id, email, name, password_hash, totp_secret, totp_enabled_at, totp_last_step, recovery_codes FROM users WHERE id = ?', array((int) $uid));
}

function twofa_enabled($user)
{
    return !empty($user['totp_enabled_at']) && !empty($user['totp_secret']);
}

/** 10 резервных кодов вида abcd-efgh; хранятся только их хэши. */
function twofa_new_recovery_codes($uid)
{
    $alpha = 'abcdefghjkmnpqrstuvwxyz23456789';
    $codes = array();
    $hashes = array();
    for ($i = 0; $i < 10; $i++) {
        $c = '';
        for ($j = 0; $j < 8; $j++) $c .= $alpha[random_int(0, strlen($alpha) - 1)];
        $c = substr($c, 0, 4) . '-' . substr($c, 4);
        $codes[] = $c;
        $hashes[] = hash('sha256', $c);
    }
    q('UPDATE users SET recovery_codes = ? WHERE id = ?', array(json_encode($hashes), (int) $uid));
    return $codes;
}

function twofa_use_recovery($user, $code)
{
    $code = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) $code));
    if (strlen($code) !== 8) return false;
    $h = hash('sha256', substr($code, 0, 4) . '-' . substr($code, 4));
    $list = json_decode((string) $user['recovery_codes'], true);
    if (!is_array($list)) return false;
    foreach ($list as $i => $x) {
        if (hash_equals((string) $x, $h)) {
            array_splice($list, $i, 1);
            q('UPDATE users SET recovery_codes = ? WHERE id = ?', array(json_encode(array_values($list)), (int) $user['id']));
            return true;
        }
    }
    return false;
}

/** Код из приложения или резервный код. Возвращает 'totp' | 'recovery' | false. */
function twofa_check_code($user, $code)
{
    $code = trim((string) $code);
    if (preg_match('/^\d[\d\s]{5,8}$/', $code)) {
        $step = totp_verify($user['totp_secret'], $code, (int) $user['totp_last_step']);
        if ($step !== false) {
            q('UPDATE users SET totp_last_step = ? WHERE id = ?', array($step, (int) $user['id']));
            return 'totp';
        }
        return false;
    }
    return twofa_use_recovery($user, $code) ? 'recovery' : false;
}

// ---------- доверенные устройства ----------
function trusted_cookie_name()
{
    return is_https() ? '__Host-bloknot-td' : 'bloknot_td';
}

function trusted_device_valid($uid)
{
    $name = trusted_cookie_name();
    if (empty($_COOKIE[$name]) || !preg_match('/^[a-f0-9]{64}$/', $_COOKIE[$name])) return false;
    $row = q_one('SELECT id FROM trusted_devices WHERE user_id = ? AND token_hash = ? AND expires_at > ?', array((int) $uid, hash('sha256', $_COOKIE[$name]), time()));
    return (bool) $row;
}

function trusted_device_remember($uid)
{
    $token = bin2hex(random_bytes(32));
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? substr((string) $_SERVER['HTTP_USER_AGENT'], 0, 200) : '';
    q('DELETE FROM trusted_devices WHERE expires_at < ?', array(time()));
    q('INSERT INTO trusted_devices(user_id, token_hash, label, created_at, expires_at) VALUES(?, ?, ?, ?, ?)', array((int) $uid, hash('sha256', $token), $ua, time(), time() + TRUSTED_DAYS * 86400));
    setcookie(trusted_cookie_name(), $token, array('expires' => time() + TRUSTED_DAYS * 86400, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax'));
}

function trusted_devices_forget($uid)
{
    q('DELETE FROM trusted_devices WHERE user_id = ?', array((int) $uid));
}

/** Завершает вход: новая сессия для пользователя. */
function auth_start_session_for($user)
{
    start_session();
    session_regenerate_id(true);
    $_SESSION = array(
        'uid' => (int) $user['id'],
        'login_at' => now_ms(),
        'csrf' => random_token(24),
        'renewed' => time(),
    );
    q('DELETE FROM login_attempts WHERE ip = ? AND ok = 0', array(client_ip()));
}

/** Второй шаг входа: код после правильного пароля. */
function auth_login_2fa($code, $remember)
{
    login_throttle_check();
    start_session();
    $uid = isset($_SESSION['pending_2fa']) ? (int) $_SESSION['pending_2fa'] : 0;
    $at = isset($_SESSION['pending_at']) ? (int) $_SESSION['pending_at'] : 0;
    if (!$uid || $at < time() - PENDING_2FA_TTL) {
        unset($_SESSION['pending_2fa'], $_SESSION['pending_at']);
        throw new HttpError(410, 'Время на ввод кода истекло — войдите заново', array('restart' => true));
    }
    $user = twofa_user($uid);
    if (!$user || !twofa_enabled($user)) throw new HttpError(410, 'Войдите заново', array('restart' => true));
    $how = twofa_check_code($user, $code);
    login_record($how !== false);
    if ($how === false) {
        usleep(300000);
        throw new HttpError(401, 'Неверный код. Проверьте, что время на телефоне установлено автоматически.');
    }
    auth_start_session_for($user);
    if ($remember) trusted_device_remember($uid);
    $left = count(json_decode((string) q_val('SELECT recovery_codes FROM users WHERE id = ?', array($uid)), true) ?: array());
    return array($user, $how, $left);
}

function twofa_status($uid)
{
    $u = twofa_user($uid);
    $codes = json_decode((string) $u['recovery_codes'], true);
    return array(
        'enabled' => twofa_enabled($u),
        'enabled_at' => $u['totp_enabled_at'] ? (int) $u['totp_enabled_at'] : null,
        'recovery_left' => is_array($codes) ? count($codes) : 0,
        'trusted_devices' => (int) q_val('SELECT COUNT(*) FROM trusted_devices WHERE user_id = ? AND expires_at > ?', array((int) $uid, time())),
        'trusted_here' => trusted_device_valid($uid),
    );
}

function twofa_require_password($uid, $password)
{
    login_throttle_check();
    $u = twofa_user($uid);
    if (!$u || !password_verify((string) $password, $u['password_hash'])) {
        login_record(false);
        throw new HttpError(403, 'Пароль указан неверно');
    }
    return $u;
}

/** Шаг 1 включения: новый секрет (пока только в сессии) и ссылка для приложения. */
function twofa_setup($uid, $password)
{
    $u = twofa_require_password($uid, $password);
    if (twofa_enabled($u)) throw new HttpError(409, 'Двухфакторный вход уже включён');
    $secret = base32_encode_raw(random_bytes(20));
    start_session();
    $_SESSION['totp_setup'] = array('secret' => $secret, 'at' => time());
    return array('secret' => $secret, 'uri' => totp_uri($secret, $u['email']));
}

/** Шаг 2: проверка первого кода, включение, резервные коды. Остальные сеансы завершаются. */
function twofa_enable($uid, $code)
{
    start_session();
    $s = isset($_SESSION['totp_setup']) ? $_SESSION['totp_setup'] : null;
    if (!$s || $s['at'] < time() - 1800) throw new HttpError(410, 'Начните настройку заново', array('restart' => true));
    login_throttle_check();
    $step = totp_verify($s['secret'], $code, 0);
    if ($step === false) {
        login_record(false);
        throw new HttpError(422, 'Код не подошёл. Введите текущий код из приложения; если не помогает — проверьте, что время на телефоне установлено автоматически.');
    }
    $now = now_ms();
    q('UPDATE users SET totp_secret = ?, totp_enabled_at = ?, totp_last_step = ?, password_changed_at = ? WHERE id = ?', array($s['secret'], time(), $step, $now, (int) $uid));
    unset($_SESSION['totp_setup']);
    $_SESSION['login_at'] = $now; // текущий сеанс остаётся, остальные завершаются
    trusted_devices_forget($uid);
    return twofa_new_recovery_codes($uid);
}

function twofa_disable($uid, $password, $code)
{
    $u = twofa_require_password($uid, $password);
    if (!twofa_enabled($u)) return;
    if (twofa_check_code($u, $code) === false) {
        login_record(false);
        throw new HttpError(422, 'Неверный код из приложения или резервный код');
    }
    twofa_turn_off($uid);
}

function twofa_turn_off($uid)
{
    q("UPDATE users SET totp_secret = NULL, totp_enabled_at = NULL, totp_last_step = 0, recovery_codes = '[]' WHERE id = ?", array((int) $uid));
    trusted_devices_forget($uid);
}

function twofa_regenerate_codes($uid, $code)
{
    $u = twofa_user($uid);
    if (!twofa_enabled($u)) throw new HttpError(409, 'Двухфакторный вход выключен');
    login_throttle_check();
    if (twofa_check_code($u, $code) === false) {
        login_record(false);
        throw new HttpError(422, 'Неверный код из приложения');
    }
    return twofa_new_recovery_codes($uid);
}
