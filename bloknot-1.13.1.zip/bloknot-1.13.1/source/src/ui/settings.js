// Настройки: тема, аккаунт, импорт, экспорт, резервные копии, хранилище, безопасность
import { el, clear, formatBytes, downloadUrl, plural, formatDate } from '../util.js';
import { icon } from '../icons.js';
import { api, upload, setCsrf } from '../api.js';
import { state, loadTree } from '../store.js';
import { modal, toast, confirmDialog } from './modal.js';
import { applyTheme, getTheme } from './theme.js';
import { openPage } from './actions.js';
import { qrSvg } from './qr.js';

export function openSettings({ onLogout, tab } = {}) {
  modal({
    title: 'Настройки',
    wide: true,
    className: 'settings',
    content: (close) => {
      const nav = el('nav', { class: 'settings-nav' });
      const body = el('div', { class: 'settings-body' });
      const sections = [
        ['view', 'Оформление', 'sun', viewSection],
        ['import', 'Импорт из Notion', 'import', () => importSection(close)],
        ['mail', 'Бэкап на почту', 'mail', mailSection],
        ['ai', 'ИИ-помощник', 'sparkle', aiSection],
        ['backup', 'Экспорт и бэкапы', 'download', backupSection],
        ['account', 'Аккаунт', 'key', () => accountSection(onLogout, close)],
        ['storage', 'Хранилище', 'file', storageSection],
        ['security', 'Безопасность', 'shield', securitySection],
      ];
      const show = (key) => {
        nav.querySelectorAll('button').forEach((b) => b.classList.toggle('is-active', b.dataset.key === key));
        clear(body);
        const s = sections.find((x) => x[0] === key);
        body.append(s[3]());
      };
      for (const [key, label, ic] of sections) {
        const b = el('button', { type: 'button', class: 'settings-tab', 'data-key': key }, icon(ic, 17), el('span', null, label));
        b.addEventListener('click', () => show(key));
        nav.append(b);
      }
      show(tab || 'view');
      return el('div', { class: 'settings-wrap' }, nav, body);
    },
  });
}

function section(title, ...content) {
  return el('section', { class: 'set-section' }, el('h3', { class: 'set-title' }, title), ...content);
}

function viewSection() {
  const current = getTheme();
  const opt = (v, label, ic) => {
    const b = el('button', { type: 'button', class: `theme-opt${current === v ? ' is-active' : ''}` }, icon(ic, 18), label);
    b.addEventListener('click', () => {
      applyTheme(v);
      b.parentElement.querySelectorAll('.theme-opt').forEach((x) => x.classList.toggle('is-active', x === b));
    });
    return b;
  };
  return el(
    'div',
    null,
    section('Тема', el('div', { class: 'theme-opts' }, opt('system', 'Как в системе', 'settings'), opt('light', 'Светлая', 'sun'), opt('dark', 'Тёмная', 'moon'))),
    section(
      'Быстрые клавиши',
      el(
        'dl',
        { class: 'keys' },
        ...[
          ['Ctrl/⌘ + K', 'Поиск'],
          ['/', 'Меню блоков'],
          ['Ctrl/⌘ + B, I, U', 'Жирный, курсив, подчёркнутый'],
          ['Ctrl/⌘ + Shift + S', 'Зачёркнутый'],
          ['Ctrl/⌘ + E', 'Код в строке'],
          ['Ctrl/⌘ + K в тексте', 'Ссылка'],
          ['Tab / Shift + Tab', 'Вложить / вынести'],
          ['Esc', 'Выделить блок'],
          ['Alt + Shift + ↑/↓', 'Переместить блок'],
          ['Ctrl/⌘ + D', 'Дублировать блок'],
          ['Ctrl/⌘ + Z / Shift + Z', 'Отменить / повторить'],
          ['Ctrl/⌘ + Alt + 0…8', 'Текст, заголовки, списки, код'],
        ].flatMap(([k, v]) => [el('dt', null, k), el('dd', null, v)]),
      ),
    ),
  );
}

function accountSection(onLogout, closeModal) {
  const cur = el('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Текущий пароль' });
  const p1 = el('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: 'Новый пароль (не короче 8 символов)' });
  const p2 = el('input', { class: 'input', type: 'password', autocomplete: 'new-password', placeholder: 'Новый пароль ещё раз' });
  const err = el('div', { class: 'form-error' });
  const save = el('button', { type: 'submit', class: 'btn btn-primary' }, 'Сменить пароль');
  const form = el('form', { class: 'stack narrow' }, cur, p1, p2, err, save);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    err.textContent = '';
    if (p1.value !== p2.value) {
      err.textContent = 'Новые пароли не совпадают';
      return;
    }
    try {
      const res = await api('auth.password', { current: cur.value, password: p1.value });
      setCsrf(res.csrf);
      form.reset();
      toast('Пароль изменён. На других устройствах нужно будет войти заново.');
    } catch (ex) {
      err.textContent = ex.message;
    }
  });
  const logout = el('button', { type: 'button', class: 'btn' }, icon('logout', 16), 'Выйти на этом устройстве');
  logout.addEventListener('click', () => {
    closeModal();
    onLogout();
  });
  return el(
    'div',
    null,
    section('Вы вошли как', el('p', { class: 'set-value' }, state.user ? `${state.user.name ? state.user.name + ' — ' : ''}${state.user.email}` : '')),
    section('Пароль', form),
    section('Выход', logout),
  );
}

function backupSection() {
  const exportAll = el('button', { type: 'button', class: 'btn' }, icon('download', 16), 'Скачать все страницы (Markdown, ZIP)');
  exportAll.addEventListener('click', () => downloadUrl('api.php?a=export.md'));
  const backup = el('button', { type: 'button', class: 'btn btn-primary' }, icon('download', 16), 'Скачать резервную копию');
  backup.addEventListener('click', () => downloadUrl('api.php?a=backup'));
  const restoreInput = el('input', { type: 'file', multiple: true, accept: '.zip,application/zip,.001,.002,.003,.004,.005,.006,.007,.008,.009,.010,.011,.012', class: 'visually-hidden', id: 'restore-file' });
  const restoreBtn = el('label', { class: 'btn', for: 'restore-file' }, icon('upload', 16), 'Восстановить из копии…');
  restoreInput.addEventListener('change', async () => {
    const picked = Array.from(restoreInput.files || []);
    restoreInput.value = '';
    if (!picked.length) return;
    let files;
    try {
      files = orderBackupParts(picked);
    } catch (e) {
      toast(e.message, 'error', { duration: 12000 });
      return;
    }
    const label = files.length > 1 ? `${files.length} частей архива «${files[0].name.replace(/\.\d{3}$/, '')}»` : `архива «${files[0].name}»`;
    const ok = await confirmDialog({
      title: 'Восстановить из резервной копии?',
      text: `Текущие страницы и изображения будут заменены содержимым ${label}. Текущие данные сохранятся в папке data/pre-restore-… на хостинге.`,
      confirm: 'Восстановить',
      danger: true,
    });
    if (!ok) return;
    const t = toast('Восстановление… не закрывайте страницу', 'info', { duration: Infinity });
    try {
      await uploadBackup(files, (pct) => {
        const txt = t.querySelector('.toast-text');
        if (txt) txt.textContent = pct < 99 ? `Загрузка архива: ${pct}% — не закрывайте страницу` : 'Восстановление… не закрывайте страницу';
      });
      t.remove();
      toast('Данные восстановлены. Страница перезагрузится.');
      setTimeout(() => location.reload(), 1200);
    } catch (e) {
      t.remove();
      toast(`Не удалось восстановить: ${e.message}`, 'error', { duration: 12000 });
    }
  });
  return el(
    'div',
    null,
    section(
      'Резервная копия',
      el('p', { class: 'set-text' }, 'Полный архив, сжатый без потерь: база данных со всеми страницами и историей версий, изображения и конфигурация. Храните копии вне хостинга — на компьютере или в облаке.'),
      el('div', { class: 'btn-row' }, backup, restoreBtn, restoreInput),
      el('p', { class: 'set-hint' }, 'Если копия пришла на почту несколькими частями (.zip.001, .zip.002…), выберите все части сразу.'),
      el('p', { class: 'set-hint', html: 'Автоматические ежедневные копии настраиваются в разделе «Cron» панели хостинга — команда приведена в README (раздел «Резервные копии»). Копии сохраняются в <code>data/backups</code>, хранятся 7 последних.' }),
    ),
    section('Экспорт в Markdown', el('p', { class: 'set-text' }, 'Все страницы с сохранением вложенности и изображениями — для переноса в другие программы. Отдельную страницу можно выгрузить через меню «⋯» на ней.'), exportAll),
  );
}

function storageSection() {
  const box = el('div', null, el('p', { class: 'muted' }, 'Загрузка…'));
  api('stats').then(
    (s) => {
      clear(box);
      const row = (k, v) => [el('dt', null, k), el('dd', null, v)];
      const clean = el('button', { type: 'button', class: 'btn' }, icon('trash', 16), 'Удалить неиспользуемые изображения');
      clean.addEventListener('click', async () => {
        try {
          const r = await api('files.cleanup', {});
          toast(r.deleted ? `Удалено ${r.deleted} ${plural(r.deleted, 'файл', 'файла', 'файлов')}, освобождено ${formatBytes(r.freed)}` : 'Неиспользуемых изображений нет');
        } catch (e) {
          toast(e.message, 'error');
        }
      });
      box.append(
        section(
          'Использование',
          el(
            'dl',
            { class: 'stats' },
            ...row('Страниц', String(s.pages)),
            ...row('В корзине', String(s.trash)),
            ...row('Изображений', `${s.files} (${formatBytes(s.files_bytes)})`),
            ...row('База данных', formatBytes(s.db_bytes)),
            ...row('Свободно на диске', s.disk_free ? formatBytes(s.disk_free) : 'неизвестно'),
            ...row('Лимит загрузки', formatBytes(s.upload_limit)),
          ),
        ),
        section('Очистка', el('p', { class: 'set-text' }, 'Изображения, удалённые из страниц, хранятся ещё сутки и остаются доступны через историю версий. Очистка удалит файлы, на которые не ссылается ни одна страница и ни одна версия.'), clean),
      );
    },
    (e) => {
      clear(box);
      box.append(el('p', { class: 'form-error' }, e.message));
    },
  );
  return box;
}

function securitySection() {
  const box = el('div');
  box.append(twoFactorSection());
  const https = location.protocol === 'https:';
  const item = (ok, title, text) => el('div', { class: `sec-item ${ok === true ? 'is-ok' : ok === false ? 'is-bad' : ''}` }, el('span', { class: 'sec-mark' }, ok === true ? '✓' : ok === false ? '!' : '…'), el('div', null, el('div', { class: 'sec-title' }, title), el('div', { class: 'sec-text' }, text)));
  box.append(section('Проверки', item(https, 'HTTPS', https ? 'Соединение зашифровано.' : 'Сайт открыт без HTTPS. Включите бесплатный сертификат Let’s Encrypt в панели хостинга — перенаправление на HTTPS включится автоматически в течение 10 минут.')));
  const probe = item(null, 'Защита папки data', 'Проверяем…');
  box.querySelector('.set-section').append(probe);
  fetch('data/probe', { cache: 'no-store', credentials: 'omit' }).then(
    async (r) => {
      const t = r.ok ? await r.text() : '';
      const exposed = r.ok && t.includes('tetrad-probe');
      probe.replaceWith(item(!exposed, 'Защита папки data', exposed ? 'Папка data доступна из интернета! Сервер не применяет .htaccess (вероятно, nginx). Попросите поддержку хостинга запретить доступ к папке data или перенесите её выше корня сайта (см. README).' : 'Файлы базы данных и изображения недоступны напрямую из браузера.'));
    },
    () => probe.replaceWith(item(true, 'Защита папки data', 'Папка data недоступна напрямую.')),
  );
  box.append(section('Как устроена защита', el('ul', { class: 'set-list' }, el('li', null, 'Пароль хранится только в виде хеша (bcrypt).'), el('li', null, 'После 8 неудачных попыток вход с адреса блокируется на 15 минут — это касается и кодов двухфакторного входа.'), el('li', null, 'Изображения выдаются только после входа; исполняемые файлы под видом картинок отклоняются.'), el('li', null, 'Внешние сервисы, счётчики и телеметрия не используются.'))));
  return box;
}

// ---------- двухфакторный вход ----------
function codesBlock(codes) {
  const text = codes.join('\n');
  const copy = el('button', { type: 'button', class: 'btn btn-small' }, icon('copy', 14), 'Копировать');
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(text);
      toast('Коды скопированы');
    } catch (e) {
      toast('Не удалось скопировать — выделите коды вручную', 'error');
    }
  });
  const dl = el('button', { type: 'button', class: 'btn btn-small' }, icon('download', 14), 'Скачать .txt');
  dl.addEventListener('click', () => {
    const blob = new Blob([`Блокнот (${location.host}) — резервные коды для входа\nКаждый код можно использовать один раз.\n\n${text}\n`], { type: 'text/plain;charset=utf-8' });
    const a = el('a', { href: URL.createObjectURL(blob), download: `bloknot-recovery-codes-${location.host}.txt` });
    document.body.append(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(a.href);
      a.remove();
    }, 1000);
  });
  return el(
    'div',
    { class: 'tfa-codes-wrap' },
    el('p', { class: 'set-text' }, 'Резервные коды — на случай, если телефон потеряется. Каждый код срабатывает один раз вместо кода из приложения. Сохраните их вне телефона: в менеджере паролей или распечатайте.'),
    el('div', { class: 'tfa-codes' }, ...codes.map((c) => el('code', null, c))),
    el('div', { class: 'btn-row' }, copy, dl),
  );
}

function twoFactorSection() {
  const wrap = el('div', { class: 'set-section tfa' }, el('h3', { class: 'set-title' }, 'Двухфакторный вход'), el('p', { class: 'muted' }, 'Загрузка…'));
  const head = wrap.firstChild;
  const body = () => {
    while (wrap.lastChild !== head) wrap.lastChild.remove();
  };
  const lead = () => el('p', { class: 'set-text' }, 'После пароля Блокнот спросит шестизначный код из приложения на телефоне — Яндекс Ключ, Google Authenticator, Microsoft Authenticator, 1Password и другие. Даже если пароль узнают, без телефона войти не получится.');
  const render = (st) => {
    body();
    if (!st.enabled) {
      const pwd = el('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Текущий пароль', 'aria-label': 'Текущий пароль' });
      const err = el('p', { class: 'form-error' });
      const start = el('button', { type: 'submit', class: 'btn btn-primary' }, icon('shield', 16), 'Включить');
      const form = el('form', { class: 'stack tfa-form' }, el('label', { class: 'field-label' }, 'Для включения подтвердите пароль'), pwd, err, el('div', { class: 'btn-row' }, start));
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        err.textContent = '';
        start.disabled = true;
        try {
          setup(await api('auth.2fa.setup', { password: pwd.value }));
        } catch (ex) {
          err.textContent = ex.message;
        } finally {
          start.disabled = false;
        }
      });
      wrap.append(el('p', { class: 'method-current is-off' }, el('span', { class: 'method-dot' }), 'Выключен'), lead(), form);
      return;
    }
    const devices = st.trusted_devices
      ? `Устройств, где код не спрашивается 30 дней: ${st.trusted_devices}${st.trusted_here ? ' (включая это)' : ''}.`
      : 'Код спрашивается при каждом входе.';
    const forget = el('button', { type: 'button', class: 'btn btn-small' }, 'Спрашивать код везде');
    forget.addEventListener('click', async () => {
      render((await api('auth.2fa.forget', {})).status);
      toast('Теперь код будет спрашиваться на всех устройствах');
    });
    const regen = el('button', { type: 'button', class: 'btn btn-small' }, icon('refresh', 14), 'Новые резервные коды');
    regen.addEventListener('click', () => askCode('Новые резервные коды', 'Старые коды перестанут действовать.', 'Создать', async (code) => {
      const r = await api('auth.2fa.codes', { code });
      render(r.status);
      wrap.append(codesBlock(r.recovery_codes));
    }));
    const off = el('button', { type: 'button', class: 'btn btn-small btn-danger-text' }, 'Выключить');
    off.addEventListener('click', () => askCode('Выключить двухфакторный вход?', 'Для входа снова будет достаточно пароля.', 'Выключить', async (code, password) => {
      const r = await api('auth.2fa.disable', { code, password });
      render(r.status);
      toast('Двухфакторный вход выключен');
    }, true));
    wrap.append(
      el('p', { class: 'method-current' }, el('span', { class: 'method-dot' }), `Включён${st.enabled_at ? ' ' + formatDate(st.enabled_at * 1000, false) : ''}`),
      el('p', { class: 'set-text' }, `Резервных кодов осталось: ${st.recovery_left} из 10. ${devices}`),
      st.recovery_left <= 3 ? el('p', { class: 'set-hint ai-warn' }, '⚠️ Резервных кодов почти не осталось — создайте новые.') : null,
      el('div', { class: 'btn-row' }, regen, st.trusted_devices ? forget : null, off),
    );
  };
  const askCode = (title, text, confirmLabel, fn, withPassword = false) => {
    modal({
      title,
      content: (close) => {
        const pwd = withPassword ? el('input', { class: 'input', type: 'password', autocomplete: 'current-password', placeholder: 'Пароль' }) : null;
        const code = el('input', { class: 'input tfa-code-input', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: 'Код из приложения или резервный код', maxlength: '12' });
        const err = el('p', { class: 'form-error' });
        const ok = el('button', { type: 'submit', class: `btn ${withPassword ? 'btn-danger' : 'btn-primary'}` }, confirmLabel);
        const form = el('form', { class: 'stack' }, el('p', { class: 'modal-text' }, text), pwd, code, err, el('div', { class: 'btn-row' }, ok));
        form.addEventListener('submit', async (e) => {
          e.preventDefault();
          err.textContent = '';
          ok.disabled = true;
          try {
            await fn(code.value, pwd ? pwd.value : undefined);
            close();
          } catch (ex) {
            err.textContent = ex.message;
          } finally {
            ok.disabled = false;
          }
        });
        setTimeout(() => (pwd || code).focus(), 0);
        return form;
      },
    });
  };
  const setup = (d) => {
    body();
    const qr = el('div', { class: 'tfa-qr', html: qrSvg(d.uri, 176) });
    const secret = el('code', { class: 'tfa-secret' }, d.secret.replace(/(.{4})/g, '$1 ').trim());
    const openApp = el('a', { class: 'btn btn-small tfa-open', href: d.uri }, 'Открыть в приложении на этом телефоне');
    const code = el('input', { class: 'input tfa-code-input', inputmode: 'numeric', autocomplete: 'one-time-code', placeholder: '123 456', maxlength: '7', 'aria-label': 'Код из приложения' });
    const err = el('p', { class: 'form-error' });
    const ok = el('button', { type: 'submit', class: 'btn btn-primary' }, 'Подтвердить и включить');
    const cancel = el('button', { type: 'button', class: 'btn btn-small' }, 'Отмена');
    cancel.addEventListener('click', load);
    const form = el('form', { class: 'stack tfa-form' }, el('label', { class: 'field-label' }, '3. Введите шестизначный код из приложения'), code, err, el('div', { class: 'btn-row' }, ok, cancel));
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      err.textContent = '';
      ok.disabled = true;
      try {
        const r = await api('auth.2fa.enable', { code: code.value });
        if (r.csrf) setCsrf(r.csrf);
        render(r.status);
        wrap.append(codesBlock(r.recovery_codes));
        toast('Двухфакторный вход включён. Другие устройства потребуют войти заново.', 'info', { duration: 7000 });
      } catch (ex) {
        err.textContent = ex.message;
        code.select();
      } finally {
        ok.disabled = false;
      }
    });
    wrap.append(
      el('p', { class: 'set-text' }, '1. Установите на телефон приложение для кодов: Яндекс Ключ, Google Authenticator или любое другое с поддержкой TOTP.'),
      el('p', { class: 'set-text' }, '2. Добавьте в нём аккаунт: отсканируйте QR-код или введите ключ вручную.'),
      el('div', { class: 'tfa-setup' }, qr, el('div', { class: 'tfa-manual' }, el('div', { class: 'field-label' }, 'Ключ для ручного ввода'), secret, el('p', { class: 'set-hint' }, 'Тип — «по времени», 6 цифр, 30 секунд.'), openApp)),
      form,
    );
    setTimeout(() => code.focus(), 0);
  };
  function load() {
    api('auth.2fa.status').then(render, (e) => {
      body();
      wrap.append(el('p', { class: 'form-error' }, e.message));
    });
  }
  load();
  return wrap;
}

function importSection(closeModal) {
  const input = el('input', { type: 'file', accept: '.zip,application/zip', class: 'visually-hidden', id: 'notion-file' });
  const pick = el('label', { class: 'btn btn-primary', for: 'notion-file' }, icon('upload', 16), 'Выбрать ZIP-архив из Notion');
  const into = el('label', { class: 'check' }, el('input', { type: 'checkbox', checked: true }), el('span', null, 'Сложить импорт в отдельную страницу «Импорт из Notion»'));
  const progress = el('div', { class: 'import-progress' });
  input.addEventListener('change', async () => {
    const f = input.files && input.files[0];
    input.value = '';
    if (!f) return;
    pick.classList.add('is-disabled');
    clear(progress);
    const bar = el('div', { class: 'progress' }, el('span', { class: 'progress-bar' }));
    const label = el('div', { class: 'progress-label' }, 'Чтение архива…');
    const log = el('ul', { class: 'import-log' });
    progress.append(label, bar, log);
    try {
      const { importNotionZip } = await import('../import/notion.js');
      const res = await importNotionZip(f, {
        container: into.querySelector('input').checked,
        uploadLimit: state.uploadLimit,
        onProgress: (done, total, text) => {
          bar.firstChild.style.width = `${total ? Math.round((done / total) * 100) : 0}%`;
          label.textContent = text;
        },
        onWarning: (msg) => {
          if (log.children.length < 200) log.append(el('li', null, msg));
        },
      });
      await loadTree();
      label.textContent = `Готово: ${res.pages} ${plural(res.pages, 'страница', 'страницы', 'страниц')}, ${res.images} ${plural(res.images, 'изображение', 'изображения', 'изображений')}.${res.warnings ? ` Замечаний: ${res.warnings}.` : ''}`;
      bar.firstChild.style.width = '100%';
      if (res.rootId) {
        const open = el('button', { type: 'button', class: 'btn' }, 'Открыть импортированное');
        open.addEventListener('click', () => {
          closeModal();
          openPage(res.rootId);
        });
        progress.append(open);
      }
    } catch (e) {
      label.textContent = `Импорт прерван: ${e.message}`;
      label.classList.add('form-error');
    } finally {
      pick.classList.remove('is-disabled');
    }
  });
  return el(
    'div',
    null,
    section(
      'Как выгрузить страницы из Notion',
      el(
        'ol',
        { class: 'steps' },
        el('li', { html: 'В Notion откройте <b>Settings → Workspace → Export</b> (или «⋯» у страницы → <b>Export</b>).' }),
        el('li', { html: 'Формат — <b>HTML</b> (лучше всего) или <b>Markdown &amp; CSV</b>; включите <b>Include subpages</b> и выгрузку файлов и изображений.' }),
        el('li', null, 'Дождитесь письма со ссылкой, скачайте ZIP-архив и выберите его ниже. Распаковывать не нужно.'),
      ),
    ),
    section(
      'Импорт',
      el('p', { class: 'set-text' }, 'Архив обрабатывается прямо в браузере, поэтому лимит хостинга на размер файла не мешает. Сохраняется вложенность страниц, значки, обложки, изображения и ссылки между страницами. Базы данных Notion переносятся как таблицы.'),
      into,
      el('div', { class: 'btn-row' }, pick, input),
      progress,
    ),
  );
}

// ---------- бэкап на почту ----------
const SMTP_PRESETS = [
  ['Gmail', 'smtp.gmail.com', 465, 'ssl', 'https://myaccount.google.com/apppasswords'],
  ['Яндекс', 'smtp.yandex.ru', 465, 'ssl', 'https://id.yandex.ru/security/app-passwords'],
  ['Mail.ru', 'smtp.mail.ru', 465, 'ssl', 'https://account.mail.ru/user/2-step-auth/passwords/'],
  ['Outlook', 'smtp-mail.outlook.com', 587, 'tls', 'https://account.live.com/proofs/AppPassword'],
  // почта хостинга: логин — ящик на вашем домене, созданный в панели хостинга
  ['Timeweb', 'smtp.timeweb.ru', 465, 'ssl', null, true],
  ['REG.RU', 'mail.hosting.reg.ru', 465, 'ssl', null, true],
];

const PROBE_TEXT = {
  ok: ['ok', 'доступно'],
  blocked: ['bad', 'закрыто хостингом'],
  silent: ['bad', 'перехватывается хостингом (сервер не отвечает)'],
  tls_failed: ['bad', 'не удалось защищённое соединение'],
  dns: ['bad', 'адрес сервера не найден'],
  connected: ['bad', 'нет ответа'],
};

function diagnoseView(d, onApply) {
  const row = (state, title, text) => el('div', { class: `sec-item${state === 'ok' ? ' is-ok' : state === 'bad' ? ' is-bad' : ''}` }, el('span', { class: 'sec-mark' }, state === 'ok' ? '✓' : state === 'bad' ? '✕' : '–'), el('div', null, el('div', { class: 'sec-title' }, title), text ? el('div', { class: 'sec-text' }, text) : null));
  const rows = [];
  rows.push(row(null, 'Хостинг', d.hosting ? d.hosting.name : 'не удалось определить'));
  rows.push(row(d.mail_function ? (d.last_error && d.last_error.includes('mail') ? 'bad' : null) : 'bad', 'Отправка самим хостингом (функция mail)', d.mail_function ? (d.spf_ok ? `включена; для домена ${d.from.split('@')[1]} есть запись SPF` : `включена, но у домена ${d.from.split('@')[1]} нет записи SPF — Gmail и Яндекс такие письма обычно отклоняют`) : 'отключена на хостинге'));
  const names = { 'smtp.gmail.com': 'Gmail', 'smtp.yandex.ru': 'Яндекс', 'smtp.mail.ru': 'Mail.ru' };
  for (const [key, v] of Object.entries(d.probe)) {
    const [host, port] = key.split(':');
    const [state, text] = PROBE_TEXT[v.state] || ['bad', v.state];
    rows.push(row(state, `Подключение к ${names[host] || host} (порт ${port})`, text));
  }
  const advice = el('div', { class: 'diag-advice' }, el('div', { class: 'sec-title' }, 'Что сделать'), el('p', { class: 'set-text' }, d.advice));
  if (d.verdict === 'smtp_hosting' && d.hosting && d.hosting.smtp_host) {
    const b = el('button', { type: 'button', class: 'btn btn-small btn-primary' }, `Подставить параметры ${d.hosting.name}`);
    b.addEventListener('click', () => onApply([d.hosting.name, d.hosting.smtp_host, d.hosting.smtp_port, d.hosting.smtp_secure, null, true]));
    advice.append(b);
  } else if (d.verdict === 'smtp_external') {
    const b = el('button', { type: 'button', class: 'btn btn-small btn-primary' }, 'Подставить параметры Gmail');
    b.addEventListener('click', () => onApply(SMTP_PRESETS[0]));
    advice.append(b);
  }
  return el('div', { class: 'diag' }, ...rows, advice);
}

function presetFor(email) {
  const d = String(email || '').split('@')[1] || '';
  if (/^(gmail|googlemail)\./.test(d)) return SMTP_PRESETS[0];
  if (/^(yandex|ya)\./.test(d)) return SMTP_PRESETS[1];
  if (/^(mail|inbox|list|bk)\.ru$/.test(d)) return SMTP_PRESETS[2];
  if (/^(outlook|hotmail|live)\./.test(d)) return SMTP_PRESETS[3];
  return null;
}

function mailSection() {
  const box = el('div', null, el('p', { class: 'muted' }, 'Загрузка…'));
  const render = (st) => {
    clear(box);
    // частота отправки: один выбор, включая «Не отправлять»
    const FREQ = [
      [0, 'Не отправлять', 'Резервные копии на почту выключены'],
      [1, 'Каждый день', 'Если за день что-то изменилось'],
      [7, 'Раз в неделю', 'Рекомендуется'],
      [14, 'Раз в две недели', ''],
      [30, 'Раз в месяц', ''],
    ];
    const current = st.enabled ? st.interval_days : 0;
    const save = async (patch) => {
      try {
        render(await api('mail.save', patch));
        toast('Сохранено');
      } catch (e) {
        toast(e.message, 'error');
      }
    };
    const freq = el(
      'div',
      { class: 'freq-opts', role: 'radiogroup', 'aria-label': 'Частота отправки' },
      ...FREQ.map(([v, label, sub]) => {
        const input = el('input', { type: 'radio', name: 'mail-freq', value: String(v), checked: current === v });
        input.addEventListener('change', () => save(v === 0 ? { enabled: false } : { enabled: true, interval_days: v }));
        return el('label', { class: `freq-opt${current === v ? ' is-active' : ''}` }, input, el('span', { class: 'freq-label' }, label), sub ? el('span', { class: 'freq-sub' }, sub) : null);
      }),
    );
    const sendBtn = el('button', { type: 'button', class: 'btn btn-primary' }, icon('mail', 16), 'Отправить сейчас');
    sendBtn.addEventListener('click', async () => {
      sendBtn.disabled = true;
      sendBtn.lastChild.textContent = 'Отправка…';
      try {
        const res = await api('mail.send', {});
        render(res);
        toast(`Письмо отправлено на ${res.recipient}. Если его нет во «Входящих» — проверьте «Спам».`, 'info', { duration: 8000 });
      } catch (e) {
        if (e.data && e.data.status) render(e.data.status);
        toast(`Не удалось отправить: ${e.message}`, 'error', { duration: 12000 });
      } finally {
        sendBtn.disabled = false;
      }
    });

    const statusLines = [];
    if (st.last_ok_at) statusLines.push(el('div', { class: 'sec-item is-ok' }, el('span', { class: 'sec-mark' }, '✓'), el('div', null, el('div', { class: 'sec-title' }, `Последняя копия отправлена ${formatDate(st.last_ok_at * 1000)}`), st.last_info ? el('div', { class: 'sec-text' }, st.last_info) : null)));
    if (st.last_error && (!st.last_ok_at || st.last_at > st.last_ok_at)) {
      statusLines.push(el('div', { class: 'sec-item is-bad' }, el('span', { class: 'sec-mark' }, '!'), el('div', null, el('div', { class: 'sec-title' }, 'Последняя отправка не удалась'), el('div', { class: 'sec-text' }, st.last_error))));
    }
    if (st.last_ok_at && !st.confirmed_at) {
      statusLines.push(el('div', { class: 'sec-item' }, el('span', { class: 'sec-mark' }, '?'), el('div', null, el('div', { class: 'sec-title' }, 'Доставка ещё не подтверждена'), el('div', { class: 'sec-text' }, 'Найдите письмо «Блокнот: резервная копия» (если его нет во «Входящих» — в папке «Спам») и нажмите в нём «Письма доходят». Если письма нет совсем — включите отправку через свою почту ниже.'))));
    }
    if (st.confirmed_at) statusLines.push(el('div', { class: 'sec-item is-ok' }, el('span', { class: 'sec-mark' }, '✓'), el('div', null, el('div', { class: 'sec-title' }, 'Письма доходят'), el('div', { class: 'sec-text' }, `Подтверждено ${formatDate(st.confirmed_at * 1000, false)}`))));
    if (!st.last_ok_at && !st.last_error) statusLines.push(el('p', { class: 'set-hint' }, st.enabled ? 'Первая копия уйдёт в ближайшие минуты, пока Блокнот открыт, — или нажмите «Отправить сейчас».' : 'Отправка выключена.'));

    // SMTP — необязательно
    const preset = presetFor(st.recipient);
    const host = el('input', { class: 'input', placeholder: 'smtp.example.com', value: st.smtp_host || '' });
    const port = el('input', { class: 'input', type: 'number', min: '1', max: '65535', value: st.smtp_port || 465 });
    const secure = el('select', { class: 'select' }, ...[['ssl', 'SSL (порт 465)'], ['tls', 'STARTTLS (порт 587)'], ['none', 'Без шифрования']].map(([v, l]) => el('option', { value: v, selected: (st.smtp_secure || 'ssl') === v }, l)));
    const user = el('input', { class: 'input', type: 'email', placeholder: st.recipient || 'вы@почта', value: st.smtp_user || st.recipient || '', autocomplete: 'off' });
    const pass = el('input', { class: 'input', type: 'password', placeholder: st.smtp_pass_set ? 'сохранён — оставьте пустым, чтобы не менять' : 'пароль приложения', autocomplete: 'new-password' });
    const userHint = el('p', { class: 'set-hint' });
    const applyPreset = (p) => {
      host.value = p[1];
      port.value = p[2];
      secure.value = p[3];
      if (p[5]) {
        user.value = '';
        user.placeholder = 'ящик на вашем домене, например backup@ваш-домен';
        userHint.textContent = `Почта ${p[0]}: создайте в панели хостинга почтовый ящик на вашем домене и укажите здесь его адрес и пароль. Письма будут приходить на ${st.recipient}.`;
      } else {
        if (!user.value) user.value = st.recipient || '';
        userHint.textContent = '';
      }
      host.focus();
    };
    // выбранный вариант почты подсвечивается: по сохранённым настройкам и при правке адреса сервера
    const presetBtns = [];
    const markPreset = () => {
      const h = host.value.trim().toLowerCase();
      const hit = SMTP_PRESETS.find((p) => p[1] === h);
      for (const [b, p] of presetBtns) {
        const on = p ? hit === p : !!h && !hit;
        b.classList.toggle('is-active', on);
        b.setAttribute('aria-pressed', on ? 'true' : 'false');
      }
    };
    const presets = el('div', { class: 'btn-row preset-row', role: 'group', 'aria-label': 'Почтовый сервис' }, ...SMTP_PRESETS.concat([null]).map((p) => {
      const b = el('button', { type: 'button', class: 'btn btn-small preset-btn' }, p ? p[0] : 'Другой сервер');
      b.addEventListener('click', () => {
        if (p) applyPreset(p);
        else {
          if (SMTP_PRESETS.some((x) => x[1] === host.value.trim())) host.value = '';
          userHint.textContent = '';
          host.focus();
          presetBtns.forEach(([x, q]) => x.classList.toggle('is-active', !q));
          return;
        }
        markPreset();
      });
      presetBtns.push([b, p]);
      return b;
    }));
    host.addEventListener('input', markPreset);
    markPreset();
    const smtpSave = el('button', { type: 'submit', class: 'btn btn-primary' }, st.transport === 'smtp' ? 'Сохранить изменения и проверить' : 'Сохранить и отправить проверочное письмо');
    const smtpForm = el(
      'form',
      { class: 'stack smtp-form' },
      el('p', { class: 'set-text' }, 'Блокнот будет отправлять копии через ваш почтовый ящик — себе же. Выберите почтовый сервис; для Gmail, Яндекса и Mail.ru понадобится «пароль приложения» (не обычный пароль от почты).'),
      preset ? el('p', { class: 'set-hint', html: `Для вашей почты: <a href="${preset[4]}" target="_blank" rel="noopener noreferrer">создать пароль приложения в ${preset[0]}</a>.` }) : null,
      presets,
      el('label', { class: 'field-label' }, 'SMTP-сервер'),
      host,
      el('div', { class: 'smtp-row' }, el('div', null, el('label', { class: 'field-label' }, 'Порт'), port), el('div', null, el('label', { class: 'field-label' }, 'Шифрование'), secure)),
      el('label', { class: 'field-label' }, 'Логин (адрес ящика)'),
      user,
      userHint,
      el('label', { class: 'field-label' }, 'Пароль (для Gmail и Яндекса — пароль приложения)'),
      pass,
      el('div', { class: 'btn-row' }, smtpSave),
    );
    smtpForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      smtpSave.disabled = true;
      try {
        await api('mail.save', { smtp_host: host.value.trim(), smtp_port: Number(port.value), smtp_secure: secure.value, smtp_user: user.value.trim(), smtp_pass: pass.value });
        const res = await api('mail.send', {});
        render(res);
        toast('Готово: проверочное письмо отправлено через вашу почту', 'info', { duration: 8000 });
      } catch (err) {
        if (err.data && err.data.status) render(err.data.status);
        toast(err.message, 'error', { duration: 12000 });
      } finally {
        smtpSave.disabled = false;
      }
    });
    // способ отправки: всегда видно, какой сейчас действует
    const usingSmtp = st.transport === 'smtp';
    const savedPreset = usingSmtp ? SMTP_PRESETS.find((p) => p[1] === String(st.smtp_host || '').toLowerCase()) : null;
    const smtpName = usingSmtp ? (savedPreset ? `${savedPreset[0]} (${st.smtp_host})` : st.smtp_host) : '';
    const smtpWrap = el('div', { class: 'smtp-wrap' }, smtpForm);
    const methodOpts = [];
    const setMethod = (m) => {
      for (const [lab, inp, v] of methodOpts) {
        inp.checked = v === m;
        lab.classList.toggle('is-active', v === m);
      }
      smtpWrap.hidden = m !== 'smtp';
    };
    const methodOpt = (value, label, sub) => {
      const input = el('input', { type: 'radio', name: 'mail-method', value });
      const lab = el('label', { class: 'freq-opt method-opt' }, input, el('span', { class: 'method-text' }, el('span', { class: 'freq-label' }, label), sub ? el('span', { class: 'method-sub' }, sub) : null));
      input.addEventListener('change', () => {
        if (value === 'hosting' && usingSmtp) save({ smtp_clear: true });
        else {
          setMethod(value);
          if (value === 'smtp') host.focus();
        }
      });
      methodOpts.push([lab, input, value]);
      return lab;
    };
    const method = el(
      'div',
      { class: 'freq-opts', role: 'radiogroup', 'aria-label': 'Способ отправки' },
      methodOpt('hosting', 'Через хостинг', 'Без настройки — письмо отправляет сервер сайта'),
      methodOpt('smtp', 'Через свою почту (SMTP)', usingSmtp ? `Настроено: ${smtpName}${st.smtp_user ? ', ящик ' + st.smtp_user : ''}` : 'Если письма от хостинга не доходят'),
    );
    const currentLine = el('p', { class: 'method-current' }, el('span', { class: 'method-dot' }), usingSmtp ? `Сейчас письма уходят через свою почту: ${smtpName}` : 'Сейчас письма уходят через хостинг');
    setMethod(usingSmtp ? 'smtp' : 'hosting');
    const details = smtpWrap;
    function diagBox() {
      const out = el('div', { class: 'diag-out' });
      const btn = el('button', { type: 'button', class: 'btn' }, icon('shield', 16), 'Проверить отправку');
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        btn.lastChild.textContent = 'Проверка… (до 15 секунд)';
        clear(out);
        try {
          const d = await api('mail.diagnose');
          out.append(diagnoseView(d, (p) => {
            setMethod('smtp');
            applyPreset(p);
            markPreset();
            details.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }));
        } catch (e) {
          out.append(el('p', { class: 'form-error' }, e.message));
        } finally {
          btn.disabled = false;
          btn.lastChild.textContent = 'Проверить отправку';
        }
      });
      return el('div', { class: 'diag-wrap' }, el('p', { class: 'set-text' }, 'Блокнот проверит, может ли ваш хостинг отправлять письма и через какие почтовые серверы, и подскажет, что выбрать.'), btn, out);
    }

    box.append(
      section(
        'Резервная копия на почту',
        el('p', { class: 'set-text' }, `Блокнот сам присылает полную резервную копию на почту, с которой вы входите: ${st.recipient || '—'}. Ничего настраивать не нужно — письмо отправляет хостинг. Полная копия сжимается без потерь и приходит вложением; если она больше 15 МБ — частями (.zip.001, .002…) в нескольких письмах. Ещё в каждом письме есть ссылка на копию одним файлом (действует 8 дней).`),
      ),
      section(
        'Частота отправки',
        freq,
        el('p', { class: 'set-hint' }, 'Письмо уходит, только если с прошлой копии что-то изменилось. Отправка происходит в фоне, пока Блокнот открыт; чтобы письма уходили строго по расписанию, добавьте в cron хостинга команду php cron.php mail-backup (см. README).'),
        st.enabled ? el('div', { class: 'btn-row' }, sendBtn) : null,
      ),
      section('Способ отправки', currentLine, method, details),
      section('Состояние', ...statusLines),
      section('Если письма не доходят', diagBox()),
    );
  };
  api('mail.status').then(render, (e) => {
    clear(box);
    box.append(el('p', { class: 'form-error' }, e.message));
  });
  return box;
}

/** Части из писем (name.zip.001, .002…) — по порядку и без пропусков; один .zip — как есть. */
export function orderBackupParts(list) {
  if (list.length === 1 && !/\.\d{3}$/.test(list[0].name)) return list;
  const parts = list.map((f) => {
    const m = /^(.*)\.(\d{3})$/.exec(f.name);
    if (!m) throw new Error(`«${f.name}» — не часть архива. Выберите либо один файл .zip, либо все части .001, .002…`);
    return { f, base: m[1], n: Number(m[2]) };
  });
  if (new Set(parts.map((p) => p.base)).size > 1) throw new Error('Выбраны части разных архивов — выберите части одной копии');
  parts.sort((a, b) => a.n - b.n);
  for (let i = 0; i < parts.length; i++) {
    if (parts[i].n !== i + 1) throw new Error(`Не хватает части .${String(i + 1).padStart(3, '0')} — выберите все части из писем`);
  }
  return parts.map((p) => p.f);
}

/** Загружает архив (или его части подряд) кусками меньше лимита хостинга, затем запускает восстановление. */
async function uploadBackup(files, onProgress) {
  let limit = 0;
  try {
    limit = (await api('stats')).upload_limit || 0;
  } catch (e) {
    limit = 0;
  }
  const chunkSize = Math.max(256 * 1024, Math.min(8 * 1048576, limit ? Math.floor(limit * 0.8) : 2 * 1048576));
  const total = files.reduce((s, f) => s + f.size, 0);
  const id = Array.from(crypto.getRandomValues(new Uint8Array(12)), (b) => b.toString(16).padStart(2, '0')).join('');
  let offset = 0;
  for (const f of files) {
    for (let pos = 0; pos < f.size; pos += chunkSize) {
      const fd = new FormData();
      fd.append('upload', id);
      fd.append('offset', String(offset));
      fd.append('chunk', f.slice(pos, pos + chunkSize), 'chunk.bin');
      await upload('backup.chunk', fd);
      offset += Math.min(chunkSize, f.size - pos);
      onProgress(Math.min(99, Math.round((offset / total) * 100)));
    }
  }
  await api('backup.restore', { upload: id });
}

const AI_SCOPES = [
  ['GIGACHAT_API_PERS', 'Физические лица (GIGACHAT_API_PERS)'],
  ['GIGACHAT_API_B2B', 'ИП и юрлица, предоплата (GIGACHAT_API_B2B)'],
  ['GIGACHAT_API_CORP', 'ИП и юрлица, постоплата (GIGACHAT_API_CORP)'],
];
const AI_SSL = [
  ['auto', 'Автоматически — проверять, а если сертификат не принят, работать без проверки'],
  ['verify', 'Всегда проверять сертификат'],
  ['off', 'Не проверять сертификат'],
];
// готовые варианты для нового подключения: [название, адрес API, модель, где взять ключ]
const AI_PRESETS = [
  ['DeepSeek', 'https://api.deepseek.com', 'deepseek-chat', 'https://platform.deepseek.com/api_keys'],
  ['OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini', 'https://platform.openai.com/api-keys'],
  ['OpenRouter', 'https://openrouter.ai/api/v1', 'openai/gpt-4o-mini', 'https://openrouter.ai/keys'],
];

function aiSection() {
  const box = el('div', null, el('p', { class: 'muted' }, 'Загрузка…'));
  let editing = null; // id подключения, форма которого открыта; 'new' — новое
  const render = (st) => {
    clear(box);
    if (editing === null) editing = st.active;
    const active = st.profiles.find((p) => p.id === st.active);
    const statusLine = st.configured
      ? el('p', { class: 'method-current' }, el('span', { class: 'method-dot' }), `Сейчас используется: ${active.name} · модель ${active.model}`)
      : el('p', { class: 'method-current is-off' }, el('span', { class: 'method-dot' }), `Не подключено: введите ${active.type === 'gigachat' ? 'ключ авторизации GigaChat' : 'API-ключ'} ниже`);

    // список подключений: выбранное — активное, его настройки открыты ниже
    const list = el('div', { class: 'freq-opts ai-profiles', role: 'radiogroup', 'aria-label': 'Подключения' });
    for (const p of st.profiles) {
      const input = el('input', { type: 'radio', name: 'ai-profile', value: p.id, checked: p.id === st.active });
      const sub = [p.type === 'gigachat' ? 'GigaChat' : 'OpenAI-совместимый', p.model, p.configured ? `ключ ${p.key_hint}` : 'ключ не введён'].join(' · ');
      const lab = el('label', { class: `freq-opt method-opt ai-profile${p.id === st.active ? ' is-active' : ''}`, 'data-id': p.id }, input, el('span', { class: 'method-text' }, el('span', { class: 'freq-label' }, p.name, p.builtin ? el('span', { class: 'ai-tag' }, 'по умолчанию') : null), el('span', { class: 'method-sub' }, sub)));
      input.addEventListener('change', async () => {
        editing = p.id;
        try {
          render(await api('ai.activate', { id: p.id }));
          toast(`ИИ-помощник: ${p.name}`);
        } catch (e) {
          toast(e.message, 'error');
        }
      });
      list.append(lab);
    }
    const addBtn = el('button', { type: 'button', class: 'btn btn-small' }, icon('plus', 15), 'Новое подключение');
    addBtn.addEventListener('click', () => {
      editing = 'new';
      render(st);
      const f = box.querySelector('.ai-form input');
      if (f) f.focus();
    });
    const formProfile = editing === 'new' ? null : st.profiles.find((p) => p.id === editing) || active;
    const form = profileForm(formProfile, st, (next, keepEditing) => {
      if (keepEditing) editing = keepEditing;
      render(next);
    }, () => {
      editing = st.active;
      render(st);
    });

    // сертификат Минцифры
    const certInput = el('input', { type: 'file', accept: '.crt,.cer,.pem,application/x-x509-ca-cert', class: 'visually-hidden', id: 'ai-cert-file' });
    certInput.addEventListener('change', async () => {
      const f = certInput.files && certInput.files[0];
      certInput.value = '';
      if (!f) return;
      try {
        const fd = new FormData();
        fd.append('file', f);
        render(await upload('ai.cert', fd));
        toast('Сертификат загружен — теперь соединение с GigaChat проверяется');
      } catch (e) {
        toast(e.message, 'error', { duration: 8000 });
      }
    });
    const certBtns = el('div', { class: 'btn-row' }, el('label', { class: 'btn btn-small', for: 'ai-cert-file' }, icon('upload', 15), st.cert ? 'Заменить сертификат' : 'Загрузить сертификат…'), certInput);
    if (st.cert) {
      const del = el('button', { type: 'button', class: 'btn btn-small' }, 'Удалить');
      del.addEventListener('click', async () => render(await api('ai.cert.delete', {})));
      certBtns.append(del);
    }
    const insecure = st.profiles.filter((p) => p.insecure).map((p) => p.name);

    box.append(
      section(
        'ИИ-помощник',
        el('p', { class: 'set-text' }, 'Выделите текст на странице и нажмите «✦ ИИ» в панели форматирования: можно попросить исправить ошибки, сократить, переписать, перевести или задать свой вопрос. Результат вставляется вместо выделенного или ниже.'),
        statusLine,
        st.last_error ? el('div', { class: 'sec-item is-bad' }, el('span', { class: 'sec-mark' }, '!'), el('div', null, el('div', { class: 'sec-title' }, 'Последний запрос не удался'), el('div', { class: 'sec-text' }, st.last_error))) : null,
      ),
      section('Подключения', list, el('div', { class: 'btn-row' }, addBtn), form),
      section(
        'Сертификат Минцифры (для GigaChat)',
        el('p', { class: 'set-text', html: 'Серверы GigaChat используют сертификат Национального удостоверяющего центра, которого может не быть на хостинге. Скачайте «Корневой сертификат» на <a href="https://www.gosuslugi.ru/crt" target="_blank" rel="noopener noreferrer">gosuslugi.ru/crt</a> и загрузите его сюда — тогда соединение будет проверяться.' }),
        el('p', { class: 'method-current' + (st.cert ? '' : ' is-off') }, el('span', { class: 'method-dot' }), st.cert ? 'Сертификат загружен' : 'Сертификат не загружен'),
        insecure.length ? el('p', { class: 'set-hint ai-warn' }, `⚠️ ${insecure.join(', ')}: соединение сейчас работает без проверки сертификата. Загрузите сертификат, чтобы включить проверку.`) : null,
        certBtns,
      ),
      section(
        'Что важно знать',
        el('ul', { class: 'set-list' },
          el('li', null, 'Выделенный текст и ваша команда отправляются выбранному сервису ИИ. Не используйте помощника для паролей и других секретов.'),
          el('li', null, 'Запросы тратят лимит или баланс вашего аккаунта в этом сервисе (у GigaChat для физлиц есть бесплатный лимит токенов).'),
          el('li', null, 'Ключи хранятся только на вашем сервере (data/config.php), в браузер не передаются и входят в резервные копии — храните их бережно.'),
          st.transport ? null : el('li', null, 'На этом хостинге нет расширения cURL — запросы к ИИ невозможны, обратитесь в поддержку хостинга.'),
        ),
      ),
    );
  };

  function profileForm(p, st, onSaved, onCancel) {
    const isNew = !p;
    let type = p ? p.type : 'openai';
    const wrap = el('div', { class: 'smtp-wrap ai-form-wrap' });
    const draw = () => {
      clear(wrap);
      const giga = type === 'gigachat';
      const name = el('input', { class: 'input', value: p ? p.name : '', placeholder: 'Например: DeepSeek, GigaChat Pro', maxlength: '60', 'aria-label': 'Название' });
      const typeSel = el('select', { class: 'select', 'aria-label': 'Тип' }, el('option', { value: 'openai', selected: !giga }, 'OpenAI-совместимый API (DeepSeek, OpenAI, OpenRouter и др.)'), el('option', { value: 'gigachat', selected: giga }, 'GigaChat (Сбер)'));
      typeSel.addEventListener('change', () => {
        type = typeSel.value;
        draw();
      });
      const key = el('input', { class: 'input', type: 'password', autocomplete: 'new-password', spellcheck: 'false', 'aria-label': giga ? 'Ключ авторизации' : 'API-ключ', placeholder: p && p.configured ? `сохранён (${p.key_hint}) — оставьте пустым, чтобы не менять` : giga ? 'Authorization key из личного кабинета GigaChat' : 'sk-…' });
      const scope = el('select', { class: 'select', 'aria-label': 'Версия API' }, ...AI_SCOPES.map(([v, l]) => el('option', { value: v, selected: (p && p.scope ? p.scope : 'GIGACHAT_API_PERS') === v }, l)));
      const listId = `ai-models-${p ? p.id : 'new'}`;
      const models = el('datalist', { id: listId }, ...((p && p.models) || (giga ? ['GigaChat', 'GigaChat-Pro', 'GigaChat-Max', 'GigaChat-2', 'GigaChat-2-Pro', 'GigaChat-2-Max'] : [])).map((m) => el('option', { value: m })));
      const model = el('input', { class: 'input', list: listId, value: p ? p.model : giga ? 'GigaChat' : '', placeholder: giga ? 'GigaChat' : 'например deepseek-chat', spellcheck: 'false', 'aria-label': 'Модель' });
      const loadModels = el('button', { type: 'button', class: 'btn btn-small' }, icon('refresh', 14), 'Загрузить список');
      loadModels.addEventListener('click', async () => {
        if (!p || !p.configured) {
          err.textContent = 'Сначала сохраните подключение с ключом — затем можно загрузить список моделей.';
          return;
        }
        loadModels.disabled = true;
        try {
          const r = await api('ai.models', { id: p.id });
          clear(models);
          r.models.forEach((m) => models.append(el('option', { value: m })));
          toast(r.models.length ? `Доступно моделей: ${r.models.length} — выберите в поле «Модель»` : 'Сервис не вернул список моделей');
          model.focus();
        } catch (e) {
          err.textContent = e.message;
        } finally {
          loadModels.disabled = false;
        }
      });
      const temp = el('input', { class: 'input', type: 'number', min: '0', max: '2', step: '0.1', value: p ? p.temperature : 0.7, 'aria-label': 'Температура' });
      const maxTok = el('input', { class: 'input', type: 'number', min: '0', max: '200000', step: '1', value: p ? p.max_tokens : 0, 'aria-label': 'Максимальная длина ответа' });
      const baseUrl = el('input', { class: 'input', value: p ? p.base_url : giga ? 'https://gigachat.devices.sberbank.ru/api/v1' : '', placeholder: 'https://api.example.com/v1', spellcheck: 'false', 'aria-label': 'Адрес API' });
      const oauthUrl = el('input', { class: 'input', value: p && p.oauth_url ? p.oauth_url : 'https://ngw.devices.sberbank.ru:9443/api/v2/oauth', spellcheck: 'false', 'aria-label': 'Адрес авторизации' });
      const ssl = el('select', { class: 'select', 'aria-label': 'Проверка сертификата' }, ...AI_SSL.map(([v, l]) => el('option', { value: v, selected: (p ? p.ssl : giga ? 'auto' : 'verify') === v }, l)));
      const err = el('p', { class: 'form-error' });
      const ok = el('div', { class: 'ai-test-out' });
      const keyHelp = giga
        ? el('p', { class: 'set-hint', html: 'Ключ авторизации (Authorization key) выдаётся в <a href="https://developers.sber.ru/studio" target="_blank" rel="noopener noreferrer">личном кабинете GigaChat API</a>: проект → «Настройки API» → «Получить ключ». Для физлиц доступен бесплатный лимит.' })
        : null;
      const presetRow = isNew && !giga
        ? el('div', { class: 'btn-row preset-row' }, ...AI_PRESETS.map(([n, url, m, link]) => {
            const b = el('button', { type: 'button', class: 'btn btn-small preset-btn' }, n);
            b.addEventListener('click', () => {
              if (!name.value.trim() || AI_PRESETS.some((x) => x[0] === name.value.trim())) name.value = n;
              baseUrl.value = url;
              model.value = m;
              presetRow.querySelectorAll('.preset-btn').forEach((x) => x.classList.toggle('is-active', x === b));
              presetHint.innerHTML = `Ключ: <a href="${link}" target="_blank" rel="noopener noreferrer">${link.replace('https://', '')}</a>`;
              key.focus();
            });
            return b;
          }))
        : null;
      const presetHint = el('p', { class: 'set-hint' });
      const save = el('button', { type: 'submit', class: 'btn btn-primary' }, isNew ? 'Создать и проверить' : 'Сохранить и проверить');
      const field = (label, ...c) => [el('label', { class: 'field-label' }, label), ...c];
      const adv = el(
        'details',
        { class: 'smtp-details ai-adv' },
        el('summary', null, 'Дополнительно'),
        ...(giga ? field('Адрес авторизации (OAuth)', oauthUrl) : []),
        ...(giga ? field('Адрес API', baseUrl) : []),
        ...field('Проверка сертификата', ssl),
        ...field('Максимальная длина ответа, токенов (0 — по умолчанию)', maxTok),
      );
      const form = el(
        'form',
        { class: 'stack ai-form' },
        el('div', { class: 'ai-form-title' }, isNew ? 'Новое подключение' : `Настройки: ${p.name}`),
        ...(isNew ? field('Тип', typeSel) : []),
        ...(isNew || !p.builtin ? field('Название', name) : []),
        presetRow,
        presetRow ? presetHint : null,
        ...(giga ? [] : field('Адрес API (OpenAI-совместимый)', baseUrl)),
        ...field(giga ? 'Ключ авторизации' : 'API-ключ', key),
        keyHelp,
        ...(giga ? field('Версия API', scope) : []),
        el('label', { class: 'field-label' }, 'Модель'),
        el('div', { class: 'ai-model-row' }, model, loadModels),
        models,
        ...field('Температура: 0 — точнее и предсказуемее, 1 и выше — свободнее', temp),
        adv,
        err,
        ok,
        el('div', { class: 'btn-row' }, save),
      );
      if (!isNew) {
        const row = form.querySelector('.btn-row:last-child');
        if (p.builtin) {
          if (p.configured) {
            const clearKey = el('button', { type: 'button', class: 'btn btn-small' }, 'Удалить ключ');
            clearKey.addEventListener('click', async () => {
              if (!(await confirmDialog({ title: 'Удалить ключ GigaChat?', text: 'Помощник перестанет работать через GigaChat, пока вы не введёте ключ снова.', confirm: 'Удалить', danger: true }))) return;
              onSaved(await api('ai.save', { id: p.id, clear_key: true }), p.id);
            });
            row.append(clearKey);
          }
        } else {
          const del = el('button', { type: 'button', class: 'btn btn-small btn-danger-text' }, icon('trash', 14), 'Удалить подключение');
          del.addEventListener('click', async () => {
            if (!(await confirmDialog({ title: `Удалить «${p.name}»?`, text: 'Ключ и настройки этого подключения будут удалены.', confirm: 'Удалить', danger: true }))) return;
            try {
              onSaved(await api('ai.delete', { id: p.id }), 'gigachat');
            } catch (e) {
              err.textContent = e.message;
            }
          });
          row.append(del);
        }
      } else {
        const cancel = el('button', { type: 'button', class: 'btn btn-small' }, 'Отмена');
        cancel.addEventListener('click', onCancel);
        form.querySelector('.btn-row:last-child').append(cancel);
      }
      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        err.textContent = '';
        clear(ok);
        save.disabled = true;
        const label = save.textContent;
        save.textContent = 'Проверка…';
        const data = { type, model: model.value.trim(), temperature: temp.value, max_tokens: maxTok.value, ssl: ssl.value };
        if (!isNew) data.id = p.id;
        if (isNew || !p.builtin) data.name = name.value.trim();
        if (key.value.trim()) data.key = key.value.trim();
        if (giga) {
          data.scope = scope.value;
          data.oauth_url = oauthUrl.value.trim();
          data.base_url = baseUrl.value.trim();
        } else data.base_url = baseUrl.value.trim();
        let savedId = null;
        try {
          if (isNew && !data.key) throw new Error(giga ? 'Введите ключ авторизации' : 'Введите API-ключ');
          if (!isNew && !p.configured && !data.key) throw new Error(giga ? 'Введите ключ авторизации' : 'Введите API-ключ');
          const saved = await api('ai.save', Object.assign(data, { activate: true }));
          savedId = saved.saved_id;
          const t = await api('ai.test', { id: savedId });
          onSaved(t.status, savedId);
          const out = box.querySelector('.ai-test-out');
          if (out) {
            out.append(el('div', { class: 'sec-item is-ok' }, el('span', { class: 'sec-mark' }, '✓'), el('div', null, el('div', { class: 'sec-title' }, 'Подключение работает'), el('div', { class: 'sec-text' }, t.models.length ? `Доступные модели: ${t.models.join(', ')}` : 'Ключ принят.'))));
            if (!t.model_ok) out.append(el('p', { class: 'set-hint ai-warn' }, `⚠️ Модели «${data.model}» нет в списке доступных — выберите другую.`));
            if (t.warning) out.append(el('p', { class: 'set-hint ai-warn' }, `⚠️ ${t.warning}`));
          }
          toast('ИИ-помощник подключён. Выделите текст на странице и нажмите ✦ ИИ.', 'info', { duration: 6000 });
        } catch (ex) {
          if (savedId) {
            // сохранено, но проверка не прошла — показываем ошибку в форме сохранённого подключения
            try {
              onSaved(await api('ai.status'), savedId);
            } catch (e2) {
              /* ignore */
            }
            const e3 = box.querySelector('.ai-form .form-error');
            if (e3) e3.textContent = `Сохранено, но проверка не прошла: ${ex.message}`;
          } else {
            err.textContent = ex.message;
          }
        } finally {
          save.disabled = false;
          save.textContent = label;
        }
      });
      wrap.append(form);
    };
    draw();
    return wrap;
  }

  api('ai.status').then(render, (e) => {
    clear(box);
    box.append(el('p', { class: 'form-error' }, e.message));
  });
  return box;
}
