<?php
// Поддельный GigaChat для тестов: php -S 127.0.0.1:PORT fake_gigachat.php
// Все запросы дописываются в файл из переменной окружения FAKE_GC_LOG (по строке JSON).
$auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
$rq = isset($_SERVER['HTTP_RQUID']) ? $_SERVER['HTTP_RQUID'] : '';
header('Content-Type: application/json');
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$raw = file_get_contents('php://input');
$log = getenv('FAKE_GC_LOG');
if ($log) file_put_contents($log, json_encode(array('path' => $path, 'auth' => $auth, 'rquid' => $rq, 'raw' => $raw), JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
$tokFile = sys_get_temp_dir() . '/fake-gc-token-' . getenv('FAKE_GC_ID');

if ($path === '/api/v2/oauth') {
    parse_str($raw, $f);
    if (!preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', $rq)) {
        http_response_code(400);
        echo '{"code":4,"message":"Invalid RqUID"}';
        return true;
    }
    if ($auth !== 'Basic R29vZEtleUZvckdpZ2FDaGF0MTIzNA==' || ($f['scope'] ?? '') !== 'GIGACHAT_API_PERS') {
        http_response_code(401);
        echo '{"code":6,"message":"Credentials doesn\'t match db data"}';
        return true;
    }
    $tok = 'tok-' . bin2hex(random_bytes(4));
    file_put_contents($tokFile, $tok);
    echo json_encode(array('access_token' => $tok, 'expires_at' => (int) round(microtime(true) * 1000) + 1800 * 1000));
    return true;
}
$valid = is_file($tokFile) ? 'Bearer ' . file_get_contents($tokFile) : '-';
if ($auth !== $valid) {
    http_response_code(401);
    echo '{"status":401,"message":"Token has expired"}';
    return true;
}
if ($path === '/api/v1/models') {
    echo json_encode(array('object' => 'list', 'data' => array(
        array('id' => 'GigaChat', 'object' => 'model', 'owned_by' => 'salutedevices', 'type' => 'chat'),
        array('id' => 'GigaChat-2-Pro', 'object' => 'model', 'owned_by' => 'salutedevices', 'type' => 'chat'),
        array('id' => 'GigaChat-2-Max', 'object' => 'model', 'owned_by' => 'salutedevices', 'type' => 'chat'),
        array('id' => 'Embeddings', 'object' => 'model', 'owned_by' => 'salutedevices', 'type' => 'embedder'),
    )));
    return true;
}
if ($path === '/api/v1/chat/completions') {
    $b = json_decode($raw, true);
    if (!in_array($b['model'], array('GigaChat', 'GigaChat-2-Pro', 'GigaChat-2-Max'), true)) {
        http_response_code(404);
        echo '{"status":404,"message":"No such model"}';
        return true;
    }
    $user = $b['messages'][1]['content'];
    if (strpos($user, 'Запрос: ') === 0) {
        // режим «написать в пустую строку»
        preg_match('/^Запрос: (.*)$/m', $user, $q);
        $hasPage = strpos($user, '<page>') !== false;
        $out = mb_stripos($q[1], 'план') !== false ? "## План\n\n- шаг один\n- шаг два" : 'Ответ: ' . $q[1] . ($hasPage ? ' (с контекстом)' : '');
        echo json_encode(array('choices' => array(array('message' => array('role' => 'assistant', 'content' => $out), 'index' => 0, 'finish_reason' => 'stop')), 'model' => $b['model'], 'object' => 'chat.completion', 'usage' => array('total_tokens' => 20)), JSON_UNESCAPED_UNICODE);
        return true;
    }
    preg_match('#<fragment>\n(.*)\n</fragment>#s', $user, $m);
    $frag = $m[1] ?? '';
    if (mb_stripos($user, 'списк') !== false) $out = "- первый пункт\n- второй пункт";
    elseif (mb_stripos($user, 'английск') !== false) $out = 'Hello, world';
    else $out = 'Гига: ' . mb_strtoupper($frag, 'UTF-8');
    echo json_encode(array('choices' => array(array('message' => array('role' => 'assistant', 'content' => $out), 'index' => 0, 'finish_reason' => 'stop')), 'created' => time(), 'model' => $b['model'] . ':2.0.28.2', 'object' => 'chat.completion', 'usage' => array('prompt_tokens' => 30, 'completion_tokens' => 7, 'total_tokens' => 37)), JSON_UNESCAPED_UNICODE);
    return true;
}
http_response_code(404);
echo '{"status":404,"message":"not found"}';
return true;
