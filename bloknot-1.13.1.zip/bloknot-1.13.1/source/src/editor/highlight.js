// Подсветка синтаксиса (highlight.js, BSD-3-Clause) с ограниченным набором языков
import hljs from 'highlight.js/lib/core';
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import python from 'highlight.js/lib/languages/python';
import php from 'highlight.js/lib/languages/php';
import xml from 'highlight.js/lib/languages/xml';
import css from 'highlight.js/lib/languages/css';
import scss from 'highlight.js/lib/languages/scss';
import sql from 'highlight.js/lib/languages/sql';
import bash from 'highlight.js/lib/languages/bash';
import json from 'highlight.js/lib/languages/json';
import markdown from 'highlight.js/lib/languages/markdown';
import java from 'highlight.js/lib/languages/java';
import kotlin from 'highlight.js/lib/languages/kotlin';
import swift from 'highlight.js/lib/languages/swift';
import go from 'highlight.js/lib/languages/go';
import rust from 'highlight.js/lib/languages/rust';
import c from 'highlight.js/lib/languages/c';
import cpp from 'highlight.js/lib/languages/cpp';
import csharp from 'highlight.js/lib/languages/csharp';
import ruby from 'highlight.js/lib/languages/ruby';
import yaml from 'highlight.js/lib/languages/yaml';
import dockerfile from 'highlight.js/lib/languages/dockerfile';
import nginx from 'highlight.js/lib/languages/nginx';
import ini from 'highlight.js/lib/languages/ini';
import diff from 'highlight.js/lib/languages/diff';
import { escapeHtml } from '../util.js';

const LANGS = {
  javascript, typescript, python, php, xml, css, scss, sql, bash, json, markdown, java, kotlin, swift, go, rust, c, cpp, csharp, ruby, yaml, dockerfile, nginx, ini, diff,
};
for (const [name, def] of Object.entries(LANGS)) hljs.registerLanguage(name, def);

export const LANGUAGE_OPTIONS = [
  ['plain', 'Текст'],
  ['bash', 'Bash'],
  ['c', 'C'],
  ['cpp', 'C++'],
  ['csharp', 'C#'],
  ['css', 'CSS'],
  ['diff', 'Diff'],
  ['dockerfile', 'Dockerfile'],
  ['go', 'Go'],
  ['xml', 'HTML / XML'],
  ['ini', 'INI / TOML'],
  ['java', 'Java'],
  ['javascript', 'JavaScript'],
  ['json', 'JSON'],
  ['kotlin', 'Kotlin'],
  ['markdown', 'Markdown'],
  ['nginx', 'Nginx'],
  ['php', 'PHP'],
  ['python', 'Python'],
  ['ruby', 'Ruby'],
  ['rust', 'Rust'],
  ['scss', 'SCSS'],
  ['sql', 'SQL'],
  ['swift', 'Swift'],
  ['typescript', 'TypeScript'],
  ['yaml', 'YAML'],
];

const ALIASES = {
  js: 'javascript', jsx: 'javascript', ts: 'typescript', tsx: 'typescript', py: 'python', html: 'xml', htm: 'xml', svg: 'xml',
  sh: 'bash', shell: 'bash', zsh: 'bash', console: 'bash', yml: 'yaml', md: 'markdown', 'c++': 'cpp', 'c#': 'csharp', cs: 'csharp',
  rb: 'ruby', rs: 'rust', golang: 'go', kt: 'kotlin', toml: 'ini', docker: 'dockerfile', text: 'plain', txt: 'plain', plaintext: 'plain',
  'plain text': 'plain', 'java/c/c++/c#': 'java', 'html/xml': 'xml', sass: 'scss', mysql: 'sql', postgresql: 'sql', postgres: 'sql',
};

export function normalizeLang(lang) {
  if (!lang) return 'plain';
  const l = String(lang).toLowerCase().trim();
  if (LANGS[l]) return l;
  if (ALIASES[l]) return ALIASES[l];
  return 'plain';
}

export function highlight(text, lang) {
  lang = normalizeLang(lang);
  if (lang === 'plain' || text.length > 200000) return escapeHtml(text);
  try {
    return hljs.highlight(text, { language: lang, ignoreIllegals: true }).value;
  } catch (e) {
    return escapeHtml(text);
  }
}
