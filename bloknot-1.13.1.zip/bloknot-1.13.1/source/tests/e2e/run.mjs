// Браузерные сценарии Тетради (Playwright + Chromium).
// Запуск: node tests/e2e/run.mjs   (нужны PHP 7.4+ и пакет playwright с установленным Chromium)
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { createRequire } from 'node:module';
import { startInstance, login, EMAIL, PASSWORD } from './server.mjs';

const require = createRequire(import.meta.url);
let pw;
try {
  pw = await import('playwright');
} catch (e) {
  pw = await import('/opt/node22/lib/node_modules/playwright/index.mjs');
}
const { chromium, devices } = pw;
let JSZip;
try {
  JSZip = require('jszip');
} catch (e) {
  JSZip = require('/opt/npm-tools/node_modules/jszip');
}

const SHOTS = path.join(os.tmpdir(), 'tetrad-e2e-shots');
fs.mkdirSync(SHOTS, { recursive: true });
let passed = 0;
let failed = 0;
const errors = [];

async function step(name, fn, page) {
  try {
    await fn();
    passed++;
    console.log(`  ✓ ${name}`);
    return true;
  } catch (e) {
    failed++;
    console.log(`  ✕ ${name}\n      ${String(e.message || e).split('\n')[0]}`);
    if (page) await page.screenshot({ path: path.join(SHOTS, `fail-${failed}.png`) }).catch(() => {});
    return false;
  }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

const blocks = (page) => page.$$eval('.page-editor .blk', (els) => els.map((e) => ({ type: e.className.match(/blk-(\w+)/)[1], text: (e.querySelector('[data-editable]') || e).textContent.trim() })));
const waitSaved = (page) => page.waitForSelector('.save-status.is-saved, .save-status.is-synced', { timeout: 8000 });
// новая пустая строка в конце страницы (клик под последним блоком)
async function newLine(page) {
  await page.locator('.page-editor .editor-tail').scrollIntoViewIfNeeded();
  await page.click('.page-editor .editor-tail');
  await page.waitForFunction(() => document.activeElement && document.activeElement.matches('.blk-p .blk-text') && !document.activeElement.textContent);
}

async function typeInBlock(page, text) {
  await page.keyboard.type(text, { delay: 5 });
}

const inst = await startInstance();
const browser = await chromium.launch();
const ctxA = await browser.newContext({ viewport: { width: 1360, height: 900 } });
const A = await ctxA.newPage();
A.on('pageerror', (e) => errors.push(`[A] ${e.message}`));
let pageId = null;

console.log('\nОсновной сценарий (компьютер)');
await step('Вход в систему', async () => {
  await login(A, inst.base);
  assert(await A.isVisible('.tree-row'), 'нет дерева страниц');
}, A);

await step('Создание страницы и заголовок', async () => {
  await A.click('.sb-foot .nav-item:has-text("Новая страница")');
  await A.waitForSelector('.page-title:focus');
  await A.keyboard.type('Проект «Тетрадь»');
  await A.keyboard.press('Enter');
  pageId = Number((await A.evaluate(() => location.hash)).match(/p\/(\d+)/)[1]);
  assert(pageId > 0, 'нет id страницы');
}, A);

await step('Заголовки, абзацы, списки, чек-листы через markdown-сокращения', async () => {
  await typeInBlock(A, '# Главный заголовок');
  await A.keyboard.press('Enter');
  await typeInBlock(A, 'Обычный абзац с текстом по-русски.');
  await A.keyboard.press('Enter');
  await typeInBlock(A, '- первый пункт');
  await A.keyboard.press('Enter');
  await typeInBlock(A, 'второй пункт');
  await A.keyboard.press('Enter');
  await A.keyboard.press('Enter'); // выход из списка
  await typeInBlock(A, '1. нумерованный');
  await A.keyboard.press('Enter');
  await typeInBlock(A, 'ещё один');
  await A.keyboard.press('Enter');
  await A.keyboard.press('Backspace'); // пустой пункт → абзац
  await typeInBlock(A, '[] задача на завтра');
  await A.keyboard.press('Enter');
  await A.keyboard.press('Enter');
  const b = await blocks(A);
  const types = b.map((x) => x.type).join(',');
  assert(types.startsWith('h1,p,ul,ul,ol,ol,todo'), 'типы блоков: ' + types);
  assert(b[0].text === 'Главный заголовок', 'текст заголовка: ' + b[0].text);
  const nums = await A.$$eval('.blk-num', (n) => n.map((x) => x.textContent));
  assert(nums.join('') === '1.2.', 'нумерация: ' + nums.join(''));
}, A);

await step('Меню команд «/»: блок кода с подсветкой', async () => {
  await typeInBlock(A, '/код');
  await A.waitForSelector('.slash-menu .menu-item.is-active');
  await A.keyboard.press('Enter');
  await A.waitForSelector('.blk-code code:focus');
  await A.keyboard.type('const x = 1;');
  await A.selectOption('.blk-code .code-lang', 'javascript');
  await A.waitForTimeout(100);
  await A.locator('.blk-code code').evaluate((e) => e.blur());
  assert((await A.$$('.blk-code .hljs-keyword')).length > 0, 'нет подсветки');
}, A);

await step('Форматирование текста и внешняя ссылка', async () => {
  await A.click('.blk-p >> nth=0');
  await A.keyboard.press('End');
  await A.keyboard.press('Shift+ArrowLeft');
  for (let i = 0; i < 6; i++) await A.keyboard.press('Shift+ArrowLeft');
  await A.keyboard.press('Control+b');
  const html = await A.locator('.blk-p >> nth=0').locator('.blk-text').innerHTML();
  assert(/<b>/.test(html), 'нет жирного: ' + html);
  await A.keyboard.press('Control+k');
  await A.waitForSelector('.link-pop input:focus');
  await A.keyboard.type('example.com');
  await A.keyboard.press('Enter');
  const a = await A.locator('.blk-p >> nth=0').locator('a').getAttribute('href');
  assert(a === 'https://example.com', 'ссылка: ' + a);
}, A);

await step('Автосохранение и сохранение после перезагрузки', async () => {
  await waitSaved(A);
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  const b = await blocks(A);
  assert(b[0].type === 'h1' && b[0].text === 'Главный заголовок', 'после перезагрузки: ' + JSON.stringify(b[0]));
  assert(b.some((x) => x.type === 'code' && x.text.includes('const x = 1')), 'код не сохранился');
  assert((await A.locator('.page-title').textContent()) === 'Проект «Тетрадь»', 'название не сохранилось');
}, A);

await step('Отмена и повтор (Ctrl+Z / Ctrl+Shift+Z)', async () => {
  await A.click('.blk-h1 .blk-text');
  await A.keyboard.press('End');
  await A.keyboard.type(' X');
  await A.waitForTimeout(950);
  await A.keyboard.press('Control+z');
  let t = await A.locator('.blk-h1 .blk-text').textContent();
  assert(t === 'Главный заголовок', 'undo: ' + t);
  await A.keyboard.press('Control+Shift+z');
  t = await A.locator('.blk-h1 .blk-text').textContent();
  assert(t === 'Главный заголовок X', 'redo: ' + t);
  await A.keyboard.press('Control+z');
}, A);

await step('Перетаскивание блока мышью', async () => {
  const before = await blocks(A);
  const target = A.locator('.page-editor .blk').nth(0);
  const source = A.locator('.page-editor .blk-ol').nth(0);
  await source.hover();
  const handle = source.locator('.blk-handle');
  const hb = await handle.boundingBox();
  const tb = await target.boundingBox();
  await A.mouse.move(hb.x + hb.width / 2, hb.y + hb.height / 2);
  await A.mouse.down();
  await A.mouse.move(hb.x + 10, hb.y - 20, { steps: 4 });
  await A.mouse.move(tb.x + 40, tb.y + 4, { steps: 8 });
  await A.mouse.up();
  const after = await blocks(A);
  assert(after[0].type === 'ol' && after[0].text === 'нумерованный', 'порядок после перетаскивания: ' + after.map((x) => x.type).join(','));
  assert(after.length === before.length, 'количество блоков изменилось');
  await waitSaved(A);
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  const reloaded = await blocks(A);
  assert(reloaded[0].type === 'ol', 'перестановка не сохранилась');
}, A);

await step('Перемещение блока с клавиатуры (Alt+Shift+↓)', async () => {
  await A.click('.page-editor .blk-ol .blk-text >> nth=0');
  await A.keyboard.press('Alt+Shift+ArrowDown');
  const b = await blocks(A);
  assert(b[1].type === 'ol' && b[0].type === 'h1', 'порядок: ' + b.map((x) => x.type).join(','));
}, A);

await step('Цвет блока: текст и фон через меню, Ctrl+Shift+H, сохранение', async () => {
  const blk = A.locator('.page-editor .blk-h1').first();
  await blk.hover();
  await blk.locator('.blk-handle').click();
  await A.hover('.menu-item:has-text("Цвет")');
  await A.click('.color-menu .menu-item:has-text("Синий текст")');
  const p = A.locator('.page-editor .blk-p').first();
  await p.hover();
  await p.locator('.blk-handle').click();
  await A.hover('.menu-item:has-text("Цвет")');
  await A.click('.color-menu .menu-item:has-text("Зелёный фон")');
  await A.click('.page-editor .blk-ul .blk-text >> nth=0');
  await A.keyboard.press('Control+Shift+H');
  await waitSaved(A);
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  assert(await A.$('.blk-h1.c-blue'), 'нет синего текста у заголовка');
  assert(await A.$('.blk-p.c-green_background'), 'нет зелёного фона у абзаца');
  assert(await A.$('.blk-ul.c-green_background'), 'Ctrl+Shift+H не применил последний цвет');
  const bg = await A.$eval('.blk-p.c-green_background > .blk-body', (e) => getComputedStyle(e).backgroundColor);
  assert(bg !== 'rgba(0, 0, 0, 0)', 'фон не отрисован');
}, A);

await step('Перенос строки Shift+Enter и отступы сохраняются (в том числе в тексте с форматированием)', async () => {
  const t = A.locator('.page-editor .blk-p .blk-text').first();
  await t.click();
  await A.keyboard.press('End');
  await A.keyboard.press('Shift+Enter');
  await A.keyboard.type('вторая строка');
  await A.keyboard.press('Shift+Enter');
  await A.keyboard.type('    с отступом');
  await waitSaved(A);
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  const r = await A.$eval('.page-editor .blk-p .blk-text', (e) => ({ html: e.innerHTML, h: e.getBoundingClientRect().height, lh: parseFloat(getComputedStyle(e).lineHeight) }));
  assert(/<br>вторая строка<br>    с отступом/.test(r.html) && r.h > r.lh * 2.5, 'переносы или отступ потеряны: ' + r.html);
  // убираем добавленное, чтобы не мешать следующим проверкам
  await A.click('.page-editor .blk-p .blk-text');
  await A.evaluate(() => {
    const e = document.querySelector('.page-editor .blk-p .blk-text');
    e.innerHTML = e.innerHTML.replace(/<br>вторая строка<br>    с отступом/, '');
    e.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
  });
  await waitSaved(A);
}, A);

await step('Цвет фрагмента текста из панели форматирования', async () => {
  const t = A.locator('.page-editor .blk-p .blk-text').first();
  await t.click();
  await A.keyboard.press('End');
  await A.keyboard.type(' цветной фрагмент');
  for (let i = 0; i < 'фрагмент'.length; i++) await A.keyboard.press('Shift+ArrowLeft');
  await A.waitForSelector('.fmt-bar .fmt-color', { state: 'visible' });
  const order = await A.$$eval('.fmt-bar > button', (bs) => bs.map((b) => b.dataset.fmt));
  assert(order.indexOf('color') >= 0 && order.indexOf('color') === order.indexOf('bold') - 1, 'кнопка цвета должна стоять перед «Жирный»: ' + order.join(','));
  await A.click('.fmt-bar .fmt-color');
  await A.click('.fmt-color-menu .menu-item:has-text("Красный текст")');
  await A.click('.fmt-bar .fmt-color');
  await A.click('.fmt-color-menu .menu-item:has-text("Жёлтый фон")');
  await waitSaved(A);
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  const r = await A.$eval('.page-editor .blk-p .blk-text', (e) => ({ html: e.innerHTML, red: [...e.querySelectorAll('.tc-red')].map((x) => x.textContent).join(''), bg: [...e.querySelectorAll('.tc-yellow_background')].map((x) => x.textContent).join('') }));
  assert(r.red === 'фрагмент' && r.bg === 'фрагмент', 'цвет не сохранился или задел лишнее: ' + r.html);
}, A);

await step('ИИ-помощник: подключение GigaChat в настройках и команда над выделенным текстом', async () => {
  const { spawn } = await import('node:child_process');
  const gcPort = 20000 + Math.floor(Math.random() * 20000);
  const gc = spawn('php', ['-S', `127.0.0.1:${gcPort}`, path.resolve('tests/support/fake_gigachat.php')], { env: Object.assign({}, process.env, { FAKE_GC_ID: `e2e${gcPort}` }), stdio: 'ignore' });
  try {
    for (let i = 0; i < 50; i++) {
      try {
        await fetch(`http://127.0.0.1:${gcPort}/`);
        break;
      } catch (e) {
        await new Promise((r) => setTimeout(r, 100));
      }
    }
    // без ключа — помощник подсказывает открыть настройки
    const t = A.locator('.page-editor .blk-p .blk-text').first();
    await t.click();
    await A.keyboard.press('End');
    await A.keyboard.type(' проверка ии');
    for (let i = 0; i < 'проверка ии'.length; i++) await A.keyboard.press('Shift+ArrowLeft');
    await A.click('.fmt-bar .fmt-ai');
    await A.fill('.ai-input', 'Сделай заглавными');
    await A.keyboard.press('Enter');
    await A.waitForSelector('.ai-error:has-text("ключ авторизации GigaChat")');
    await A.click('.ai-error .btn:has-text("Открыть настройки")');
    await A.waitForSelector('.settings-tab.is-active:has-text("ИИ-помощник"), .settings-tab[aria-selected="true"]:has-text("ИИ-помощник")');
    await A.waitForSelector('.ai-profile.is-active:has-text("GigaChat")');
    assert(await A.isVisible('.method-current.is-off'), 'должно быть видно, что ИИ не подключён');
    // GigaChat: вводим только ключ (адреса — на поддельный сервер)
    await A.fill('.ai-form input[aria-label="Ключ авторизации"]', 'R29vZEtleUZvckdpZ2FDaGF0MTIzNA==');
    await A.click('.ai-adv summary');
    await A.fill('.ai-form input[aria-label="Адрес авторизации"]', `http://127.0.0.1:${gcPort}/api/v2/oauth`);
    await A.fill('.ai-form input[aria-label="Адрес API"]', `http://127.0.0.1:${gcPort}/api/v1`);
    await A.click('.ai-form button[type="submit"]');
    await A.waitForSelector('.ai-test-out .sec-title:has-text("Подключение работает")', { timeout: 20000 });
    await A.waitForSelector('.method-current:has-text("Сейчас используется: GigaChat")');
    await A.screenshot({ path: path.join(SHOTS, 'ai-settings.png') });
    // новое подключение появляется в списке и становится активным, затем снова выбираем GigaChat
    await A.click('.btn:has-text("Новое подключение")');
    await A.click('.ai-form .preset-btn:has-text("DeepSeek")');
    assert((await A.inputValue('.ai-form input[aria-label="Название"]')) === 'DeepSeek', 'пресет не заполнил название');
    await A.click('.ai-form .btn:has-text("Отмена")');
    await A.keyboard.press('Escape');
    // команда над выделенным текстом и замена результатом
    await t.click();
    await A.keyboard.press('End');
    for (let i = 0; i < 'проверка ии'.length; i++) await A.keyboard.press('Shift+ArrowLeft');
    await A.click('.fmt-bar .fmt-ai');
    const marked = await A.evaluate(() => (window.CSS && CSS.highlights ? (CSS.highlights.has('ai-target') ? [...CSS.highlights.get('ai-target')][0].toString() : '') : document.querySelectorAll('.ai-mark').length ? 'проверка ии' : ''));
    assert(marked === 'проверка ии', 'текст для ИИ не подсвечен, пока открыта панель: ' + marked);
    await A.fill('.ai-input', 'Сделай заглавными');
    await A.keyboard.press('Enter');
    await A.waitForSelector('.ai-result:has-text("Гига: ПРОВЕРКА ИИ")', { timeout: 20000 });
    assert((await A.$eval('.ai-actions .ai-icon-btn', (b) => b.textContent.trim() === '' && b.getAttribute('aria-label') === 'Копировать')), 'кнопка «Копировать» должна быть только иконкой');
    assert((await A.textContent('.ai-meta')).includes('GigaChat'), 'в ответе не указано подключение');
    await A.screenshot({ path: path.join(SHOTS, 'ai-panel.png') });
    await A.click('.ai-actions .btn:has-text("Заменить")');
    await A.waitForFunction(() => document.querySelector('.page-editor .blk-p .blk-text').textContent.includes('Гига: ПРОВЕРКА ИИ'));
    assert(!(await A.textContent('.page-editor .blk-p .blk-text')).includes('проверка ии'), 'выделенный текст не заменён');
    assert(!(await A.evaluate(() => window.CSS && CSS.highlights && CSS.highlights.has('ai-target'))), 'подсветка не снята после закрытия панели');
    // ИИ из меню блока: работает со всем текстом строки
    const blk = A.locator('.page-editor .blk-p').first();
    await blk.hover();
    await blk.locator('.blk-handle').click();
    await A.click('.menu-item:has-text("Спросить ИИ")');
    await A.waitForSelector('.ai-pop');
    const full = await A.$eval('.page-editor .blk-p .blk-text', (e) => e.textContent.length);
    assert((await A.textContent('.ai-sel')).includes(String(full)), 'из меню блока должен браться весь текст строки');
    await A.keyboard.press('Escape');
    await A.waitForSelector('.ai-pop', { state: 'detached' });
    // пустая строка: «Написать с ИИ» в меню строки — ответ сразу появляется в этой строке
    await A.click('.page-editor .blk-p .blk-text >> nth=0');
    await A.keyboard.press('End');
    await A.keyboard.press('Enter');
    const emptyId = await A.evaluate(() => document.activeElement.closest('.blk').dataset.id);
    const eb = A.locator(`.blk[data-id="${emptyId}"]`);
    await eb.hover();
    await eb.locator('.blk-handle').click();
    await A.click('.menu-item:has-text("Написать с ИИ")');
    await A.waitForSelector('.ai-pop');
    assert(await A.$(`.blk[data-id="${emptyId}"].is-ai-target`), 'пустая строка не отмечена как место для ответа');
    await A.fill('.ai-input', 'Составь план');
    await A.keyboard.press('Enter');
    await A.waitForSelector('.ai-pop', { state: 'detached', timeout: 20000 });
    await A.waitForSelector('.page-editor .blk-h2:has-text("План")');
    const after = await A.$$eval('.page-editor .blk', (els) => els.map((e) => e.className.match(/blk-(\w+)/)[1] + ':' + (e.querySelector('.blk-text') || {}).textContent));
    const at = after.indexOf('h2:План');
    assert(at > 0 && after[at + 1] === 'ul:шаг один' && after[at + 2] === 'ul:шаг два', 'ответ не вставлен в пустую строку: ' + after.join(' | '));
    await A.click('.toast .toast-action:has-text("Отменить")');
    await A.waitForSelector('.page-editor .blk-h2:has-text("План")', { state: 'detached' });
    await waitSaved(A);
    // несколько выделенных строк: команда выполняется над всеми
    const before = await A.$$eval('.page-editor .blk', (els) => els.map((e) => e.dataset.id));
    const pIdx = await A.$$eval('.page-editor .blk', (els) => els.findIndex((e) => e.classList.contains('blk-p')));
    const firstId = before[pIdx];
    const secondId = before[pIdx + 1];
    const t1 = (await A.textContent(`.blk[data-id="${firstId}"] .blk-text`)).trim();
    const t2 = (await A.textContent(`.blk[data-id="${secondId}"] .blk-text`)).trim();
    await A.click(`.blk[data-id="${firstId}"] .blk-text`);
    await A.keyboard.press('Escape');
    await A.keyboard.press('Shift+ArrowDown');
    assert((await A.$$('.page-editor .blk.is-selected')).length === 2, 'не выделились две строки');
    const fb = A.locator(`.blk[data-id="${firstId}"]`);
    await fb.hover();
    await fb.locator('.blk-handle').click();
    await A.click('.menu-item:has-text("Спросить ИИ (строк: 2)")');
    await A.waitForSelector('.ai-pop .ai-sel:has-text("Выделено строк: 2")');
    assert((await A.$$('.page-editor .blk.is-ai-target')).length === 2, 'обе строки должны быть подсвечены');
    await A.fill('.ai-input', 'Сделай заглавными');
    await A.keyboard.press('Enter');
    await A.waitForSelector('.ai-result', { timeout: 20000 });
    const res = await A.textContent('.ai-result');
    assert(res.includes(t1.toUpperCase()) && res.includes(t2.toUpperCase()), 'ИИ получил не все строки: ' + res);
    await A.click('.ai-actions .btn:has-text("Заменить")');
    await A.waitForTimeout(300);
    const txt = await A.$eval('.page-editor', (e) => e.textContent);
    assert(txt.includes(t2.toUpperCase()) && !(await A.$(`.blk[data-id="${firstId}"]`)) && !(await A.$(`.blk[data-id="${secondId}"]`)), 'строки не заменены результатом');
    await A.keyboard.press('Control+z');
    await A.waitForSelector(`.blk[data-id="${firstId}"]`);
    await waitSaved(A);
    await waitSaved(A);
  } finally {
    gc.kill();
  }
}, A);

await step('Двухфакторный вход: QR-код, подтверждение, вход с кодом и резервным кодом, выключение', async () => {
  const crypto = await import('node:crypto');
  const b32 = (s) => {
    const a = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let bits = '';
    for (const c of s.replace(/\s/g, '')) bits += a.indexOf(c).toString(2).padStart(5, '0');
    const out = [];
    for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2));
    return Buffer.from(out);
  };
  const totp = (secret, offset = 0) => {
    const step = Math.floor(Date.now() / 30000) + offset;
    const msg = Buffer.alloc(8);
    msg.writeUInt32BE(step, 4);
    const h = crypto.createHmac('sha1', b32(secret)).update(msg).digest();
    const o = h[19] & 15;
    return String((h.readUInt32BE(o) & 0x7fffffff) % 1000000).padStart(6, '0');
  };
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Безопасность")');
  await A.waitForSelector('.tfa .method-current.is-off');
  await A.fill('.tfa input[type="password"]', PASSWORD);
  await A.click('.tfa button:has-text("Включить")');
  await A.waitForSelector('.tfa-qr svg');
  const secret = (await A.textContent('.tfa-secret')).replace(/\s/g, '');
  assert(/^[A-Z2-7]{32}$/.test(secret), 'нет ключа для ручного ввода: ' + secret);
  await A.screenshot({ path: path.join(SHOTS, 'tfa-setup.png') });
  await A.fill('.tfa-code-input', totp(secret));
  await A.click('.tfa button:has-text("Подтвердить и включить")');
  await A.waitForSelector('.tfa-codes code');
  const codes = await A.$$eval('.tfa-codes code', (cs) => cs.map((c) => c.textContent));
  assert(codes.length === 10, 'нет резервных кодов');
  await A.waitForSelector('.tfa .method-current:not(.is-off)');
  // выход и вход с кодом
  await A.click('.settings-tab:has-text("Аккаунт")');
  await A.click('.btn:has-text("Выйти на этом устройстве")');
  await A.waitForSelector('#login-email');
  await A.fill('#login-email', EMAIL);
  await A.fill('#login-password', PASSWORD);
  await A.click('.login-form button[type="submit"]');
  await A.waitForSelector('#login-code');
  await A.screenshot({ path: path.join(SHOTS, 'tfa-login.png') });
  await A.fill('#login-code', totp(secret, 1)); // шесть цифр — форма отправляется сама
  await A.waitForSelector('.sidebar', { timeout: 15000 });
  // вход по резервному коду
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Аккаунт")');
  await A.click('.btn:has-text("Выйти на этом устройстве")');
  await A.waitForSelector('#login-email');
  await A.fill('#login-email', EMAIL);
  await A.fill('#login-password', PASSWORD);
  await A.click('.login-form button[type="submit"]');
  await A.waitForSelector('#login-code');
  await A.click('.link-btn:has-text("резервный код")');
  await A.fill('#login-code', codes[0]);
  await A.click('.login-form button[type="submit"]');
  await A.waitForSelector('.sidebar', { timeout: 15000 });
  await A.waitForSelector('.toast:has-text("Осталось кодов: 9")');
  // выключение (пароль + резервный код)
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Безопасность")');
  await A.click('.tfa button:has-text("Выключить")');
  await A.fill('.modal input[type="password"]', PASSWORD);
  await A.fill('.modal .tfa-code-input', codes[1]);
  await A.click('.modal button.btn-danger:has-text("Выключить")');
  await A.waitForSelector('.tfa .method-current.is-off');
  await A.keyboard.press('Escape');
  await A.goto(`${inst.base}/#/p/${pageId}`);
  await A.waitForSelector('.page-editor .blk');
}, A);

await step('Tab вкладывает только текущую строку; перетаскивание вправо вкладывает в строку выше', async () => {
  const id = await A.evaluate(async () => {
    const csrf = (await (await fetch('api.php?a=auth.status')).json()).csrf;
    const blocks = [{ id: 'n1', type: 'ul', html: 'Один' }, { id: 'n2', type: 'ul', html: 'Два' }, { id: 'n3', type: 'ul', html: 'Три' }, { id: 'n4', type: 'p', html: 'Абзац' }];
    return (await (await fetch('api.php?a=page.create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ title: 'Вложенность', content: { blocks } }) })).json()).id;
  });
  await A.goto(`${inst.base}/#/p/${id}`);
  await A.waitForSelector('.blk[data-id="n4"]');
  const x = (bid) => A.$eval(`.blk[data-id="${bid}"] .blk-text`, (t) => Math.round(t.getBoundingClientRect().left));
  const lvl = () => A.$$eval('.page-editor .blk', (els) => els.map((e) => e.dataset.id + ':' + (e.style.getPropertyValue('--indent') || 0)).join(' '));
  const x1 = await x('n1');
  await A.click('.blk[data-id="n2"] .blk-text');
  await A.keyboard.press('End');
  await A.keyboard.press('Tab');
  assert((await lvl()).startsWith('n1:0 n2:1 n3:0'), 'Tab: ' + (await lvl()));
  assert((await x('n1')) === x1, 'строка выше сдвинулась после Tab: ' + x1 + ' → ' + (await x('n1')));
  assert((await x('n2')) > x1, 'вложенная строка должна быть правее родителя');
  await A.keyboard.press('Shift+Tab');
  // перетаскивание за ручку вправо — вложить «Три» в «Два»
  await A.hover('.blk[data-id="n3"]');
  const h = await A.locator('.blk[data-id="n3"] .blk-handle').boundingBox();
  await A.mouse.move(h.x + 5, h.y + 5);
  await A.mouse.down();
  for (let i = 1; i <= 8; i++) await A.mouse.move(h.x + 5 + i * 7, h.y + 6);
  assert(await A.$eval('.drop-line', (l) => l.classList.contains('is-nest')), 'нет отметки «вложить» на линии вставки');
  await A.mouse.up();
  await A.waitForTimeout(200);
  assert((await lvl()).startsWith('n1:0 n2:0 n3:1'), 'перетаскивание вправо не вложило строку: ' + (await lvl()));
  await waitSaved(A);
  await A.goto(`${inst.base}/#/p/${pageId}`);
  await A.waitForSelector('.page-editor .blk');
}, A);

await step('Таблица: ширина колонок перетаскиванием и сортировка по шапке (числа, текст, даты)', async () => {
  const id = await A.evaluate(async () => {
    const csrf = (await (await fetch('api.php?a=auth.status')).json()).csrf;
    const rows = [['Название', 'Цена', 'Дата'], ['Яблоко', '1 200,50', '05.03.2025'], ['арбуз', '99', '12.01.2024'], ['Банан', '', '01.12.2024'], ['Вишня', '1500', '']];
    const blocks = [{ id: 't1', type: 'table', rows }, { id: 't2', type: 'p', html: 'После таблицы' }];
    return (await (await fetch('api.php?a=page.create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ title: 'Таблица', content: { blocks } }) })).json()).id;
  });
  await A.goto(`${inst.base}/#/p/${id}`);
  await A.waitForSelector('.blk[data-id="t1"] .tbl-sort');
  const col = (ci) => A.$$eval(`.blk[data-id="t1"] tr`, (trs, ci) => trs.slice(1).map((tr) => tr.cells[ci].textContent), ci);
  const sortBy = async (ci, label) => {
    await A.hover(`.blk[data-id="t1"] th >> nth=${ci}`);
    await A.click(`.blk[data-id="t1"] .tbl-sort[data-col="${ci}"]`);
    await A.click(`.menu .menu-item:has-text("${label}")`);
    await A.waitForTimeout(100);
  };
  await sortBy(1, 'По убыванию');
  assert((await col(0)).join() === 'Вишня,Яблоко,арбуз,Банан', 'сортировка чисел по убыванию (пустые в конце): ' + (await col(0)));
  await sortBy(1, 'По возрастанию');
  assert((await col(0)).join() === 'арбуз,Яблоко,Вишня,Банан', 'сортировка чисел по возрастанию: ' + (await col(0)));
  await sortBy(0, 'По алфавиту');
  assert((await col(0)).join() === 'арбуз,Банан,Вишня,Яблоко', 'сортировка по алфавиту без учёта регистра: ' + (await col(0)));
  await sortBy(0, 'В обратном порядке');
  assert((await col(0)).join() === 'Яблоко,Вишня,Банан,арбуз', 'сортировка Я → А: ' + (await col(0)));
  await sortBy(2, 'Сначала ранние');
  assert((await col(0)).join() === 'арбуз,Банан,Яблоко,Вишня', 'сортировка дат: ' + (await col(0)));
  // отмена сортировки
  await A.keyboard.press('Control+z');
  assert((await col(0)).join() === 'Яблоко,Вишня,Банан,арбуз', 'Ctrl+Z должен отменить сортировку: ' + (await col(0)));
  // ширина колонки: тянем правую границу первой колонки на 80 px
  const w0 = await A.$eval('.blk[data-id="t1"] th', (c) => c.getBoundingClientRect().width);
  const hb = await A.locator('.blk[data-id="t1"] .tbl-col-handle[data-col="0"]').boundingBox();
  await A.mouse.move(hb.x + hb.width / 2, hb.y + 10);
  await A.mouse.down();
  await A.mouse.move(hb.x + hb.width / 2 + 40, hb.y + 10, { steps: 4 });
  await A.mouse.move(hb.x + hb.width / 2 + 80, hb.y + 10, { steps: 4 });
  await A.mouse.up();
  const w1 = await A.$eval('.blk[data-id="t1"] th', (c) => c.getBoundingClientRect().width);
  assert(Math.abs(w1 - w0 - 80) <= 3, `колонка должна стать шире на 80 px: ${w0} → ${w1}`);
  await waitSaved(A);
  const saved = await A.evaluate(async (id) => (await (await fetch(`api.php?a=page.get&id=${id}`)).json()).content.blocks[0], id);
  assert(Array.isArray(saved.widths) && saved.widths.length === 3, 'ширины колонок не сохранились: ' + JSON.stringify(saved));
  assert(!JSON.stringify(saved.rows).includes('tbl-'), 'служебные элементы попали в ячейки: ' + JSON.stringify(saved.rows));
  await A.reload();
  await A.waitForSelector('.blk[data-id="t1"] th');
  const w2 = await A.$eval('.blk[data-id="t1"] th', (c) => c.getBoundingClientRect().width);
  assert(Math.abs(w2 - w1) <= 2, `ширина колонки после перезагрузки: ${w1} → ${w2}`);
  // ручка следует за границей колонки
  const hb2 = await A.locator('.blk[data-id="t1"] .tbl-col-handle[data-col="0"]').boundingBox();
  const right = await A.$eval('.blk[data-id="t1"] th', (c) => c.getBoundingClientRect().right);
  assert(Math.abs(hb2.x + hb2.width / 2 - right) <= 2, 'ручка не на границе колонки: ' + JSON.stringify({ hb2, right }));
  // двойной щелчок по ручке возвращает ширину по содержимому
  await A.dblclick('.blk[data-id="t1"] .tbl-col-handle[data-col="0"]');
  assert(!(await A.$eval('.blk[data-id="t1"] table', (t) => t.classList.contains('is-fixed'))), 'двойной щелчок должен сбросить ширины');
  await waitSaved(A);
  await A.screenshot({ path: path.join(SHOTS, 'table.png') });
  await A.goto(`${inst.base}/#/p/${pageId}`);
  await A.waitForSelector('.page-editor .blk');
}, A);

await step('Ширина боковой панели меняется перетаскиванием и запоминается', async () => {
  const h = await A.locator('.sb-resizer').boundingBox();
  await A.mouse.move(h.x + 3, 400);
  await A.mouse.down();
  await A.mouse.move(h.x + 60, 400, { steps: 6 });
  await A.mouse.up();
  const w1 = (await A.locator('.sidebar').boundingBox()).width;
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  await A.waitForTimeout(300);
  const w2 = (await A.locator('.sidebar').boundingBox()).width;
  assert(w1 > 280 && Math.abs(w1 - w2) < 2, `ширина ${w1} → после перезагрузки ${w2}`);
  await A.dblclick('.sb-resizer');
  await A.waitForTimeout(300);
  assert(Math.round((await A.locator('.sidebar').boundingBox()).width) === 240, 'двойной щелчок не вернул ширину по умолчанию');
}, A);

await step('Пустая страница с вложенными: без пустого места под заголовком', async () => {
  const id = await A.evaluate(async () => {
    const csrf = (await (await fetch('api.php?a=auth.status')).json()).csrf;
    const mk = async (b) => (await (await fetch('api.php?a=page.create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify(b) })).json()).id;
    const p = await mk({ title: 'Только заголовок' });
    await mk({ title: 'Вложенная А', parent_id: p });
    await mk({ title: 'Вложенная Б', parent_id: p });
    return p;
  });
  await A.goto(`${inst.base}/#/p/${id}`);
  await A.waitForSelector('.page-subpages .pagelink');
  const gap = await A.evaluate(() => document.querySelector('.subpages-title').getBoundingClientRect().top - document.querySelector('.page-title').getBoundingClientRect().bottom);
  assert(gap < 50, 'зазор между заголовком и «Вложенные страницы»: ' + gap);
  const links = await A.$$eval('.page-subpages .pagelink', (ls) => ls.map((l) => { const r = l.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top)]; }));
  assert(links.length === 2 && links[0][0] === links[1][0] && links[1][1] > links[0][1], 'вложенные страницы должны идти столбцом: ' + JSON.stringify(links));
  await A.click('.editor-tail');
  await A.keyboard.type('Можно писать');
  assert((await A.$eval('.page-editor .blk .blk-text', (e) => e.textContent)) === 'Можно писать', 'не удалось начать писать под заголовком');
  await waitSaved(A);
  await A.goto(`${inst.base}/#/`);
  await A.waitForSelector('.home-title');
  assert(!(await A.$('.home-recent')) && !(await A.isVisible('text=Недавно открытые')), 'на главной остался раздел «Недавно открытые»');
  assert(!(await A.$('.home-head .btn-primary svg')), 'у кнопки «Новая страница» остался значок');
  await A.goto(`${inst.base}/#/p/${pageId}`);
  await A.waitForSelector('.page-editor .blk');
}, A);

await step('Выделение блоков: залитые и обычные строки с одинаковыми отступами', async () => {
  await A.click('.page-editor .blk-h1 .blk-text');
  await A.keyboard.press('Escape');
  for (let i = 0; i < 4; i++) await A.keyboard.press('Shift+ArrowDown');
  const r = await A.$$eval('.page-editor .blk.is-selected', (els) => els.map((e) => {
    const a = getComputedStyle(e, '::after'), blk = e.getBoundingClientRect(), body = e.querySelector('.blk-body').getBoundingClientRect();
    const colored = /_background/.test(e.className) && !/blk-(callout|quote)/.test(e.className);
    return { id: e.dataset.id, colored, own: getComputedStyle(e).backgroundColor, ov: a.content !== 'none' && a.backgroundColor,
      l: blk.left - 6, r: blk.right + 6, t: blk.top + 1, b: blk.bottom - 1, bl: body.left, br: body.right, bt: body.top, bb: body.bottom };
  }));
  assert(r.length >= 3 && r.some((x) => x.colored) && r.some((x) => !x.colored), 'нужны и залитые, и обычные строки: ' + JSON.stringify(r));
  for (const x of r) {
    assert(x.own === 'rgba(0, 0, 0, 0)' && x.ov && x.ov !== 'rgba(0, 0, 0, 0)', 'выделение не единым слоем: ' + JSON.stringify(x));
    if (x.colored) assert([x.bl - x.l, x.br - x.r, x.bt - x.t, x.bb - x.b].every((d) => Math.abs(d) < 0.6), 'заливка не совпадает с выделением: ' + JSON.stringify(x));
  }
  assert(new Set(r.map((x) => Math.round(x.l) + ':' + Math.round(x.r))).size === 1, 'разная ширина выделения: ' + JSON.stringify(r));
  await A.keyboard.press('Escape');
}, A);

await step('Избранное: добавление звёздочкой, раздел в боковой панели, удаление из меню', async () => {
  assert(!(await A.isVisible('.sb-favorites')), 'раздел «Избранное» виден, хотя он пуст');
  await A.click('.topbar .fav-btn');
  await A.waitForSelector(`.fav-row[data-fav="${pageId}"]`);
  assert(await A.$('.fav-btn.is-on'), 'звёздочка не включилась');
  await A.reload();
  await A.waitForSelector(`.fav-row[data-fav="${pageId}"]`);
  const row = A.locator(`.fav-row[data-fav="${pageId}"]`);
  await row.hover();
  await row.locator('.tree-act').click();
  await A.click('.menu-item:has-text("Убрать из избранного")');
  await A.waitForFunction(() => !document.querySelector('.fav-row'));
  const tr = A.locator(`.tree-row[data-id="${pageId}"]`);
  await tr.hover();
  await tr.locator('.tree-act[aria-label="Действия со страницей"]').click();
  await A.click('.menu-item:has-text("Добавить в избранное")');
  await A.waitForSelector(`.fav-row[data-fav="${pageId}"]`);
}, A);

await step('Сворачивание вложенных пунктов списка и выравнивание маркеров', async () => {
  await newLine(A);
  await typeInBlock(A, '- Родитель');
  await A.keyboard.press('Enter');
  await A.keyboard.press('Tab');
  await typeInBlock(A, 'Ребёнок 1');
  await A.keyboard.press('Enter');
  await typeInBlock(A, 'Ребёнок 2');
  await A.keyboard.press('Enter');
  await A.keyboard.press('Enter');
  await A.keyboard.press('Enter');
  const parent = A.locator('.page-editor .blk-ul:has-text("Родитель")');
  assert(await parent.evaluate((e) => e.classList.contains('has-children')), 'у пункта с вложенными нет признака has-children');
  await A.mouse.move(5, 5);
  const geo = await parent.evaluate((e) => {
    const c = e.querySelector(':scope > .blk-collapse').getBoundingClientRect();
    const m = e.querySelector('.blk-marker').getBoundingClientRect();
    return { op: getComputedStyle(e.querySelector(':scope > .blk-collapse')).opacity, chevRight: c.right, chevLeft: c.left, marker: m.left, blk: e.getBoundingClientRect().left };
  });
  assert(geo.op === '1' && geo.chevRight <= geo.marker + 1, 'стрелка должна быть видна всегда и стоять слева от маркера, не закрывая его: ' + JSON.stringify(geo));
  await parent.hover();
  await parent.locator('.blk-collapse').click();
  const hidden = await A.$$eval('.page-editor .blk-ul', (els) => els.filter((e) => /Ребёнок/.test(e.textContent)).map((e) => e.classList.contains('is-hidden')));
  assert(hidden.length === 2 && hidden.every(Boolean), 'вложенные пункты не скрылись');
  // Enter в конце свёрнутого пункта создаёт соседний пункт после скрытых
  await parent.locator('.blk-text').click();
  await A.keyboard.press('End');
  await A.keyboard.press('Enter');
  await typeInBlock(A, 'Сосед');
  const order = await A.$$eval('.page-editor .blk-ul', (els) => els.map((e) => e.textContent.trim()));
  const pi = order.indexOf('Родитель');
  assert(order[pi + 3] === 'Сосед', 'новый пункт вставлен не после скрытых: ' + order.join(' | '));
  await waitSaved(A);
  await A.reload();
  await A.waitForSelector('.page-editor .blk');
  assert(await A.$('.blk-ul.is-collapsed'), 'свёрнутое состояние не сохранилось');
  await A.click('.blk-ul.is-collapsed .blk-text');
  await A.keyboard.press('Control+Enter');
  assert(!(await A.$('.blk-ul.is-collapsed')), 'Ctrl+Enter не развернул пункт');
  // маркер выровнен по строке текста
  const off = await A.$eval('.blk-ul:has-text("Родитель")', (e) => {
    const m = e.querySelector('.blk-marker').getBoundingClientRect();
    const t = e.querySelector('.blk-text');
    const lh = parseFloat(getComputedStyle(t).lineHeight);
    const tt = t.getBoundingClientRect().top + parseFloat(getComputedStyle(t).paddingTop);
    return Math.abs(m.top + m.height / 2 - (tt + lh / 2));
  });
  assert(off < 1, 'маркер смещён относительно строки на ' + off + 'px');
  // при смене стиля (пункт → заголовки) стрелка сворачивания остаётся по центру первой строки
  for (const [key, cls] of [['Digit1', 'h1'], ['Digit2', 'h2'], ['Digit3', 'h3'], ['Digit7', 'toggle'], ['Digit0', 'p']]) {
    await A.click('.page-editor .blk:has-text("Родитель") .blk-text');
    await A.keyboard.press(`Control+Alt+${key}`);
    const d = await A.$eval(`.page-editor .blk-${cls}:has-text("Родитель")`, (e) => {
      const t = e.querySelector('.blk-text');
      const cs = getComputedStyle(t);
      const mid = t.getBoundingClientRect().top + parseFloat(cs.paddingTop) + parseFloat(cs.lineHeight) / 2;
      const b = e.querySelector(':scope > .blk-collapse') || e.querySelector('.blk-toggle-btn');
      const r = b.getBoundingClientRect();
      const h = e.querySelector(':scope > .blk-gutter .blk-handle').getBoundingClientRect();
      return [Math.abs(r.top + r.height / 2 - mid), Math.abs(h.top + h.height / 2 - mid)];
    });
    assert(d[0] < 1 && d[1] < 1, `${cls}: стрелка смещена на ${d[0].toFixed(1)}px, ручка на ${d[1].toFixed(1)}px`);
  }
}, A);

// изображение
const png = fs.readFileSync(new URL('../fixtures/photo.png', import.meta.url));
const pngPath = path.join(os.tmpdir(), 'tetrad-test.png');
fs.writeFileSync(pngPath, png);

await step('Загрузка изображения и его удаление', async () => {
  await newLine(A);
  const chooser = A.waitForEvent('filechooser');
  chooser.catch(() => {});
  await typeInBlock(A, '/изображение');
  await A.waitForSelector('.slash-menu .menu-item.is-active');
  await A.keyboard.press('Enter');
  const fc = await chooser;
  await fc.setFiles(pngPath);
  await A.waitForSelector('.blk-image img[src*="api.php?a=file"]', { timeout: 8000 });
  const ok = await A.$eval('.blk-image img', (i) => i.complete && i.naturalWidth === 48);
  assert(ok, 'изображение не отобразилось');
  await waitSaved(A);
  // удаление: выделить блок и нажать Delete
  await A.click('.blk-image img');
  await A.keyboard.press('Delete');
  assert((await A.$$('.blk-image')).length === 0, 'изображение не удалено');
  await A.keyboard.press('Control+z');
  assert((await A.$$('.blk-image')).length === 1, 'отмена удаления не вернула изображение');
}, A);

await step('Вставка изображения из буфера обмена', async () => {
  await newLine(A);
  const n0 = (await A.$$('.blk-image')).length;
  await A.evaluate(async (b64) => {
    const bin = Uint8Array.from(atob(b64), (c) => c.charCodeAt(0));
    const dt = new DataTransfer();
    dt.items.add(new File([bin], 'clip.png', { type: 'image/png' }));
    document.activeElement.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  }, png.toString('base64'));
  await A.waitForFunction((n) => document.querySelectorAll('.blk-image img[src*="api.php?a=file"]').length > n, n0, { timeout: 8000 });
}, A);

await step('Вставка форматированного текста (HTML из браузера/Word)', async () => {
  await newLine(A);
  await A.evaluate(() => {
    const dt = new DataTransfer();
    dt.setData('text/html', '<h2>Вставленный заголовок</h2><p>Текст с <strong>жирным</strong> и <a href="https://ya.ru">ссылкой</a></p><ul><li>раз</li><li>два<ul><li>вложенный</li></ul></li></ul><p class="MsoListParagraph" style="mso-list:l0 level1 lfo1"><span style="mso-list:Ignore">·</span> пункт из Word</p><script>alert(1)</script>');
    dt.setData('text/plain', 'x');
    document.activeElement.dispatchEvent(new ClipboardEvent('paste', { clipboardData: dt, bubbles: true, cancelable: true }));
  });
  const b = await blocks(A);
  const tail = b.slice(-6).map((x) => x.type + ':' + x.text).join(' | ');
  assert(tail.includes('h2:Вставленный заголовок') && tail.includes('ul:раз') && tail.includes('ul:вложенный') && tail.includes('ul:пункт из Word'), 'вставка: ' + tail);
  assert(!(await A.$('.page-editor script')), 'скрипт попал в документ');
  const ind = await A.$eval('.blk-ul:has-text("вложенный")', (e) => e.style.getPropertyValue('--indent'));
  assert(ind === '1', 'вложенность списка: ' + ind);
}, A);

let childId = null;
await step('Вложенная страница через «/» и блок-ссылка на неё', async () => {
  await newLine(A);
  await typeInBlock(A, '/вложенная');
  await A.waitForSelector('.slash-menu .menu-item.is-active');
  await A.keyboard.press('Enter');
  await A.waitForFunction((id) => !location.hash.includes(`/p/${id}`) && /\/p\/\d+/.test(location.hash), pageId, { timeout: 8000 });
  childId = Number((await A.evaluate(() => location.hash)).match(/p\/(\d+)/)[1]);
  await A.waitForSelector('.page-title');
  await A.click('.page-title');
  await A.keyboard.type('Дочерняя страница');
  await A.keyboard.press('Enter');
  await A.keyboard.type('Текст дочерней страницы');
  await waitSaved(A);
  const crumbs = await A.textContent('.crumbs');
  assert(crumbs.includes('Проект «Тетрадь»'), 'хлебные крошки: ' + crumbs);
  await A.click(`.tree-row[data-id="${pageId}"]`);
  await A.waitForSelector(`.pagelink[href="#/p/${childId}"]`);
  const t = await A.textContent(`.blk-page .pagelink-title`);
  assert(t === 'Дочерняя страница', 'название в блоке-ссылке: ' + t);
  assert(await A.isVisible(`.tree-row[data-id="${childId}"]`), 'нет вложенной страницы в дереве');
}, A);

await step('Внутренняя ссылка на страницу в тексте', async () => {
  await A.click('.page-editor .blk-p .blk-text >> nth=0');
  await A.keyboard.press('End');
  await A.keyboard.type(' см. ');
  await A.keyboard.press('Control+k');
  await A.waitForSelector('.link-pop input:focus');
  await A.keyboard.type('Дочерняя');
  await A.waitForSelector('.link-opt:has-text("Дочерняя страница")');
  await A.keyboard.press('Enter');
  const href = await A.locator(`.page-editor a[href="#/p/${childId}"]`).first().getAttribute('href');
  assert(href === `#/p/${childId}`, 'внутренняя ссылка');
  await waitSaved(A);
}, A);

await step('Поиск по тексту (кириллица, Ctrl+K)', async () => {
  await A.click('.page-title');
  await A.keyboard.press('Escape');
  await A.locator('body').press('Control+k');
  await A.waitForSelector('.search-input');
  await A.keyboard.type('ДОЧЕРНЕЙ');
  await A.waitForSelector('.sr-item:has-text("Дочерняя страница")');
  await A.keyboard.press('Enter');
  await A.waitForFunction((id) => location.hash.includes(`/p/${id}`), childId);
  await A.click(`.tree-row[data-id="${pageId}"]`);
  await A.waitForSelector('.page-editor .blk');
}, A);

await step('Новая версия на сервере: уведомление «Обновить»', async () => {
  const h = await A.evaluate(() => fetch('api.php?a=health').then((r) => r.json()));
  assert(h.version && Array.isArray(h.notes), 'health должен отдавать версию и список изменений: ' + JSON.stringify(h));
  await A.route('**/api.php?a=health*', (route) => route.fulfill({ contentType: 'application/json', body: JSON.stringify({ ok: true, version: '99.0.0', notes: ['Проверка'] }) }));
  await A.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));
  const t = A.locator('.toast:has-text("Блокнот обновлён до версии 99.0.0")');
  await t.waitFor({ timeout: 5000 });
  assert(await t.locator('.toast-action:has-text("Обновить")').count(), 'в уведомлении нет кнопки «Обновить»');
  await A.unroute('**/api.php?a=health*');
  await t.locator('.toast-close').click();
}, A);

console.log('\nДва устройства');
const ctxB = await browser.newContext({ viewport: { width: 1200, height: 860 } });
const B = await ctxB.newPage();
B.on('pageerror', (e) => errors.push(`[B] ${e.message}`));

await step('Второе устройство получает актуальное содержимое', async () => {
  await login(B, inst.base);
  await B.goto(`${inst.base}/#/p/${pageId}`);
  await B.waitForSelector('.page-editor .blk-h1');
  const b = await blocks(B);
  assert(b.some((x) => x.text === 'Главный заголовок'), 'нет содержимого на втором устройстве');
}, B);

await step('Правка на одном устройстве появляется на другом без перезагрузки', async () => {
  await A.click('.blk-h1 .blk-text');
  await A.keyboard.press('End');
  await A.keyboard.type(' — правка А');
  await waitSaved(A);
  await B.waitForFunction(() => document.querySelector('.blk-h1 .blk-text').textContent.includes('правка А'), null, { timeout: 10000 });
}, B);

await step('Конфликт при одновременном редактировании обрабатывается', async () => {
  await ctxB.setOffline(true);
  await B.click('.blk-h1 .blk-text');
  await B.keyboard.press('End');
  await B.keyboard.type(' + версия Б');
  await B.waitForSelector('.save-status.is-offline', { timeout: 8000 });
  await A.click('.blk-h1 .blk-text');
  await A.keyboard.press('End');
  await A.keyboard.type(' + версия А');
  await waitSaved(A);
  await ctxB.setOffline(false);
  await B.waitForSelector('.modal:has-text("Две версии страницы")', { timeout: 15000 });
  await B.click('.choice:has-text("Оставить мою версию")');
  await waitSaved(B);
  await A.waitForFunction(() => document.querySelector('.blk-h1 .blk-text').textContent.includes('версия Б'), null, { timeout: 10000 });
  // версия А не потеряна — она в истории
  const revs = await A.evaluate(async (id) => (await (await fetch(`api.php?a=page.revisions&id=${id}`)).json()), pageId);
  assert(revs.length >= 1, 'нет снимков в истории');
}, B);

await step('Обрыв связи: изменения в очереди и отправка после восстановления', async () => {
  await ctxA.setOffline(true);
  await A.click('.blk-h1 .blk-text');
  await A.keyboard.press('End');
  await A.keyboard.type(' офлайн');
  await A.waitForSelector('.save-status.is-offline', { timeout: 8000 });
  const draft = await A.evaluate((id) => localStorage.getItem('tetrad:draft:' + id), pageId);
  assert(draft && draft.includes('офлайн'), 'черновик не записан на устройстве');
  await ctxA.setOffline(false);
  await A.waitForSelector('.save-status.is-saved', { timeout: 40000 });
  await A.reload();
  await A.waitForSelector('.blk-h1');
  assert((await A.textContent('.blk-h1 .blk-text')).includes('офлайн'), 'изменение потеряно');
}, A);

await step('Закрытие вкладки сразу после ввода: изменения не теряются', async () => {
  await A.click('.blk-h1 .blk-text');
  await A.keyboard.press('End');
  await A.keyboard.type(' быстро');
  await A.goto('about:blank');
  const P = await ctxA.newPage();
  await P.goto(`${inst.base}/#/p/${pageId}`);
  await P.waitForSelector('.blk-h1');
  await P.waitForTimeout(500);
  assert((await P.textContent('.blk-h1 .blk-text')).includes('быстро'), 'изменение потеряно при закрытии');
  await P.close();
  await A.goto(`${inst.base}/#/p/${pageId}`);
  await A.waitForSelector('.blk-h1');
}, A);

console.log('\nДанные и доступ');
await step('Перезапуск сервера: данные сохраняются', async () => {
  const { dir, port } = inst;
  await inst.stop();
  const again = await startInstance({ dir, port });
  inst.stop = again.stop;
  await A.reload();
  await A.waitForSelector('.blk-h1');
  assert((await A.textContent('.blk-h1 .blk-text')).includes('Главный заголовок'), 'данные пропали');
}, A);

await step('Неавторизованный пользователь не видит страницы и вложения', async () => {
  const fileId = await A.$eval('.blk-image img', (i) => new URL(i.src).searchParams.get('id'));
  const ctxC = await browser.newContext();
  const C = await ctxC.newPage();
  await C.goto(inst.base + '/');
  await C.waitForSelector('.login-form');
  const res = await C.evaluate(async (fid) => {
    const t = await fetch('api.php?a=tree');
    const p = await fetch('api.php?a=page.get&id=1');
    const f = await fetch('api.php?a=file&id=' + fid);
    const d = await fetch('data/');
    return [t.status, p.status, f.status, d.status];
  }, fileId);
  assert(res.join() === '401,401,401,403', 'коды ответа: ' + res.join());
  await ctxC.close();
}, A);

await step('Корзина: удаление и восстановление страницы', async () => {
  await A.click(`.tree-row[data-id="${childId}"]`);
  await A.waitForSelector('.page-title');
  await A.click('.topbar .icon-btn[aria-label="Действия со страницей"]');
  await A.click('.menu-item:has-text("В корзину")');
  await A.waitForFunction((id) => !document.querySelector(`.tree-row[data-id="${id}"]`), childId);
  await A.click('.sb-foot .nav-item:has-text("Корзина")');
  await A.waitForSelector('.trash-item:has-text("Дочерняя страница")');
  await A.click('.trash-item .btn:has-text("Восстановить")');
  await A.waitForSelector(`.tree-row[data-id="${childId}"]`);
  await A.keyboard.press('Escape');
}, A);

await step('Перетаскивание страницы в дереве (вложенность)', async () => {
  // новая корневая страница → перетаскиваем её внутрь «Проекта»
  await A.click('.sb-foot .nav-item:has-text("Новая страница")');
  await A.waitForSelector('.page-title:focus');
  await A.keyboard.type('Перемещаемая');
  await waitSaved(A);
  const id = Number((await A.evaluate(() => location.hash)).match(/p\/(\d+)/)[1]);
  const src = await A.locator(`.tree-row[data-id="${id}"]`).boundingBox();
  const dst = await A.locator(`.tree-row[data-id="${pageId}"]`).boundingBox();
  await A.mouse.move(src.x + 60, src.y + src.height / 2);
  await A.mouse.down();
  await A.mouse.move(src.x + 60, src.y - 10, { steps: 3 });
  await A.mouse.move(dst.x + 60, dst.y + dst.height / 2, { steps: 8 });
  await A.mouse.up();
  await A.waitForFunction(([id, parent]) => {
    const rows = Array.from(document.querySelectorAll('.tree-row'));
    const r = rows.find((x) => x.dataset.id == id);
    const p = rows.find((x) => x.dataset.id == parent);
    return r && p && parseFloat(r.style.paddingLeft) > parseFloat(p.style.paddingLeft);
  }, [id, pageId], { timeout: 6000 });
}, A);

await step('Экспорт страницы в Markdown', async () => {
  const res = await A.evaluate(async (id) => {
    const r = await fetch(`api.php?a=export.md&id=${id}`);
    const b = await r.arrayBuffer();
    return [r.status, r.headers.get('content-type'), b.byteLength];
  }, pageId);
  assert(res[0] === 200 && res[1] === 'application/zip' && res[2] > 200, 'экспорт: ' + res.join());
}, A);

await step('Восстановление из копии, присланной частями (.zip.001…)', async () => {
  const bytes = await A.evaluate(async () => Array.from(new Uint8Array(await (await fetch('api.php?a=backup')).arrayBuffer())));
  const buf = Buffer.from(bytes);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bk-parts-'));
  const size = Math.ceil(buf.length / 3);
  const parts = [0, 1, 2].map((i) => {
    const p = path.join(dir, `bloknot-backup-2026-10-18-120000.zip.00${i + 1}`);
    fs.writeFileSync(p, buf.subarray(i * size, (i + 1) * size));
    return p;
  });
  const extra = await A.evaluate(async () => {
    const csrf = (await (await fetch('api.php?a=auth.status')).json()).csrf;
    const r = await fetch('api.php?a=page.create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ title: 'Создана после бэкапа' }) });
    return (await r.json()).id;
  });
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Экспорт и бэкапы")');
  await A.setInputFiles('#restore-file', [parts[0], parts[2]]);
  await A.waitForSelector('.toast-error:has-text("Не хватает части .002")');
  await A.setInputFiles('#restore-file', [parts[2], parts[0], parts[1]]);
  await A.waitForSelector('.modal:has-text("3 частей архива")');
  await A.click('.modal .btn-danger:has-text("Восстановить")');
  await A.waitForSelector('.toast:has-text("Данные восстановлены")', { timeout: 30000 });
  await A.waitForLoadState('load');
  await A.waitForTimeout(1800);
  await A.waitForSelector('.sidebar');
  const st = await A.evaluate(async (id) => (await fetch(`api.php?a=page.get&id=${id}`)).status, extra);
  assert(st === 404, 'страница, созданная после бэкапа, должна исчезнуть: ' + st);
}, A);

await step('Бэкап на почту: частота отправки, включение и отправка без настройки почты', async () => {
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Бэкап на почту")');
  await A.waitForSelector('.settings-body .set-text:has-text("${EMAIL}")'.replace('${EMAIL}', EMAIL));
  await A.check('.freq-opt:has-text("Раз в неделю") input');
  await A.waitForSelector('.toast:has-text("Сохранено")');
  await A.check('.freq-opt:has-text("Раз в месяц") input');
  await A.waitForSelector('.freq-opt.is-active:has-text("Раз в месяц")');
  const st1 = await A.evaluate(async () => (await (await fetch('api.php?a=mail.status')).json()));
  assert(st1.enabled === true && st1.interval_days === 30, 'частота не сохранилась: ' + JSON.stringify([st1.enabled, st1.interval_days]));
  await A.check('.freq-opt:has-text("Не отправлять") input');
  await A.waitForSelector('.freq-opt.is-active:has-text("Не отправлять")');
  assert((await A.evaluate(async () => (await (await fetch('api.php?a=mail.status')).json()).enabled)) === false, 'отправка не выключилась');
  await A.check('.freq-opt:has-text("Раз в неделю") input');
  await A.waitForSelector('.freq-opt.is-active:has-text("Раз в неделю")');
  await A.click('.settings-body .btn:has-text("Отправить сейчас")');
  await A.waitForSelector('.toast:has-text("Письмо отправлено")', { timeout: 20000 });
  await A.waitForSelector('.sec-title:has-text("Последняя копия отправлена")');
  await A.waitForSelector('.sec-title:has-text("Доставка ещё не подтверждена")');
  const mails = fs.readdirSync(inst.dir + '-mail').filter((f) => f.endsWith('.eml'));
  assert(mails.length >= 1, 'письмо не создано');
  await A.click('.settings-body .btn:has-text("Проверить отправку")');
  await A.waitForSelector('.diag-advice', { timeout: 30000 });
  assert((await A.$$('.diag .sec-item')).length >= 4, 'нет результатов проверки');
  await A.$eval('.diag-advice', (e) => e.scrollIntoView());
  await A.screenshot({ path: path.join(SHOTS, 'mail-settings.png') });
  await A.keyboard.press('Escape');
}, A);

await step('Бэкап на почту: выбранный способ и почтовый сервис видны после повторного открытия', async () => {
  await A.evaluate(async () => {
    const csrf = (await (await fetch('api.php?a=auth.status')).json()).csrf;
    await fetch('api.php?a=mail.save', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ smtp_host: 'smtp.yandex.ru', smtp_port: 465, smtp_secure: 'ssl', smtp_user: 'me@yandex.ru', smtp_pass: 'x' }) });
  });
  await A.keyboard.press('Escape');
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Бэкап на почту")');
  await A.waitForSelector('.method-current');
  const st = await A.evaluate(() => ({ cur: document.querySelector('.method-current').textContent, active: document.querySelector('.method-opt.is-active input').value, preset: [...document.querySelectorAll('.preset-btn.is-active')].map((b) => b.textContent) }));
  assert(st.active === 'smtp' && st.preset.join() === 'Яндекс' && st.cur.includes('Яндекс'), 'не видно выбранной почты: ' + JSON.stringify(st));
  await A.click('.method-opt:has-text("Через хостинг")');
  await A.waitForSelector('.method-current:has-text("через хостинг")');
  assert((await A.$eval('.method-opt.is-active input', (e) => e.value)) === 'hosting' && (await A.$eval('.smtp-wrap', (e) => e.hidden)), 'не вернулось на отправку через хостинг');
  await A.keyboard.press('Escape');
}, A);

console.log('\nИмпорт из Notion');
await step('Импорт ZIP-экспорта Notion (HTML) с вложенностью, картинкой и ссылками', async () => {
  const zip = new JSZip();
  const id1 = 'a'.repeat(32);
  const id2 = 'b'.repeat(32);
  const page = (title, icon, body) => `<html><head><meta charset="utf-8"><title>${title}</title></head><body><article class="page sans"><header><div class="page-header-icon undefined"><span class="icon">${icon}</span></div><h1 class="page-title">${title}</h1></header><div class="page-body">${body}</div></article></body></html>`;
  zip.file(`Рабочие заметки ${id1}.html`, page('Рабочие заметки', '🗂️', `
    <h1 id="1">Цели</h1><p>Обычный <strong>текст</strong> и <code>код</code>.</p>
    <ul class="to-do-list"><li><div class="checkbox checkbox-on"></div> <span class="to-do-children-checked">Сделано</span></li></ul>
    <ul class="to-do-list"><li><div class="checkbox checkbox-off"></div> <span class="to-do-children-unchecked">Не сделано</span></li></ul>
    <ul class="toggle"><li><details open=""><summary>Раскрывашка</summary><p>Внутри</p></details></li></ul>
    <figure class="block-color-gray_background callout" style="white-space:pre-wrap;display:flex"><div style="font-size:1.5em"><span class="icon">⚠️</span></div><div style="width:100%">Важное замечание</div></figure>
    <figure class="image"><a href="${encodeURIComponent('Рабочие заметки ' + id1)}/photo.png"><img style="width:240px" src="${encodeURIComponent('Рабочие заметки ' + id1)}/photo.png"/></a><figcaption>Подпись к фото</figcaption></figure>
    <pre id="c" class="code"><code class="language-Python">print("привет")</code></pre>
    <figure class="link-to-page"><a href="${encodeURIComponent('Рабочие заметки ' + id1)}/${encodeURIComponent('Подстраница ' + id2)}.html"><span class="icon">📄</span>Подстраница</a></figure>
    <table class="simple-table"><tbody><tr><td>А</td><td>Б</td></tr><tr><td>1</td><td>2</td></tr></tbody></table>
    <figure><div class="source"><a href="${encodeURIComponent('Рабочие заметки ' + id1)}/doc.pdf">doc.pdf</a></div></figure>
  `));
  zip.file(`Рабочие заметки ${id1}/Подстраница ${id2}.html`, page('Подстраница', '📄', `<p>Назад к <a href="../${encodeURIComponent('Рабочие заметки ' + id1)}.html">заметкам</a></p>`));
  zip.file(`Рабочие заметки ${id1}/photo.png`, png);
  zip.file(`Рабочие заметки ${id1}/doc.pdf`, 'pdf');
  const outer = new JSZip();
  outer.file('Export-123-Part-1.zip', await zip.generateAsync({ type: 'uint8array' }));
  const zipPath = path.join(os.tmpdir(), 'notion-export.zip');
  fs.writeFileSync(zipPath, await outer.generateAsync({ type: 'nodebuffer' }));

  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Импорт из Notion")');
  await A.setInputFiles('#notion-file', zipPath);
  await A.waitForSelector('.progress-label:has-text("Готово")', { timeout: 30000 });
  const label = await A.textContent('.progress-label');
  assert(/2 страницы, 1 изображение/.test(label), 'итог импорта: ' + label);
  await A.click('.import-progress .btn:has-text("Открыть")');
  await A.waitForSelector('.page-title');
  await A.click('.blk-page .pagelink, .page-subpages .pagelink');
  await A.waitForSelector('.page-title:has-text("Рабочие заметки")');
  const b = await blocks(A);
  const types = b.map((x) => x.type).join(',');
  for (const t of ['h1', 'todo', 'toggle', 'callout', 'image', 'code', 'page', 'table']) assert(types.includes(t), `нет блока ${t}: ${types}`);
  assert(await A.$('.blk-todo.is-checked'), 'не перенесена отметка чек-листа');
  assert(await A.$eval('.blk-image img', (i) => i.src.includes('api.php?a=file')), 'изображение не загружено на сервер');
  assert((await A.textContent('.blk-callout .blk-callout-icon')).includes('⚠️'), 'значок выноски');
  assert(await A.$('.blk-callout.c-gray_background'), 'цвет блока из Notion не перенесён');
  assert(b.some((x) => x.text.includes('doc.pdf (файл не перенесён)')), 'нет пометки о вложении');
  await A.click('.blk-page .pagelink');
  await A.waitForSelector('.page-title:has-text("Подстраница")');
  const href = await A.getAttribute('.page-editor a', 'href');
  assert(/^#\/p\/\d+$/.test(href), 'ссылка между страницами не преобразована: ' + href);
}, A);

await step('Импорт экспорта Notion в формате Markdown & CSV', async () => {
  const id1 = '1'.repeat(32);
  const id2 = '2'.repeat(32);
  const id3 = '3'.repeat(32);
  const zip = new JSZip();
  zip.file(`Дневник ${id1}.md`, `# Дневник\n\nТекст **жирный** и [ссылка](https://example.org)\n\n- [x] готово\n- [ ] не готово\n\n![фото](${encodeURIComponent('Дневник ' + id1)}/img.png)\n\n[Запись](${encodeURIComponent('Дневник ' + id1)}/${encodeURIComponent('Запись ' + id2)}.md)\n\n\`\`\`js\nlet a = 1;\n\`\`\`\n`);
  zip.file(`Дневник ${id1}/Запись ${id2}.md`, '# Запись\n\nПривет из Markdown');
  zip.file(`Дневник ${id1}/img.png`, png);
  zip.file(`База ${id3}.csv`, 'Name,Tags\nПервая,x\n"Вторая, с запятой",y\n');
  const zipPath = path.join(os.tmpdir(), 'notion-md.zip');
  fs.writeFileSync(zipPath, await zip.generateAsync({ type: 'nodebuffer' }));
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Импорт из Notion")');
  await A.setInputFiles('#notion-file', zipPath);
  await A.waitForSelector('.progress-label:has-text("Готово")', { timeout: 30000 });
  const label = await A.textContent('.progress-label');
  assert(/3 страницы, 1 изображение/.test(label), 'итог: ' + label);
  await A.keyboard.press('Escape');
  const ids = await A.evaluate(async () => {
    const t = await (await fetch('api.php?a=tree')).json();
    const find = (title) => (t.pages.find((p) => p.title === title) || {}).id;
    return { diary: find('Дневник'), entry: find('Запись'), base: find('База') };
  });
  assert(ids.diary && ids.entry && ids.base, 'страницы не созданы: ' + JSON.stringify(ids));
  const diary = await A.evaluate(async (id) => (await (await fetch('api.php?a=page.get&id=' + id)).json()), ids.diary);
  const types = diary.content.blocks.map((b) => b.type).join(',');
  assert(types.includes('todo') && types.includes('image') && types.includes('code'), 'блоки: ' + types);
  assert(diary.content.blocks.some((b) => b.type === 'todo' && b.checked), 'отметка чек-листа');
  assert(JSON.stringify(diary.content.blocks).includes(`#/p/${ids.entry}`), 'ссылка на вложенную страницу не преобразована');
  const base = await A.evaluate(async (id) => (await (await fetch('api.php?a=page.get&id=' + id)).json()), ids.base);
  assert(base.content.blocks[0].type === 'table' && base.content.blocks[0].rows[2][0] === 'Вторая, с запятой', 'CSV → таблица');
}, A);

await step('Импорт Notion: вложенность по папкам без id и экспорт без папок', async () => {
  const h = (title, body) => `<html><body><article class="page"><header><h1 class="page-title">${title}</h1></header><div class="page-body">${body}</div></article></body></html>`;
  const L = (href, t) => `<figure class="link-to-page"><a href="${href}">${t}</a></figure>`;
  const zip = new JSZip();
  const r = 'c'.repeat(32), c = 'd'.repeat(32), g = 'e'.repeat(32), f = 'f'.repeat(32), l = '0'.repeat(32);
  zip.file(`Export/Корень ${r}.html`, h('Корень', L(encodeURIComponent('Корень') + '/' + encodeURIComponent(`Ребёнок ${c}.html`), 'Ребёнок')));
  zip.file(`Export/Корень/Ребёнок ${c}.html`, h('Ребёнок', L(encodeURIComponent('Ребёнок') + '/' + encodeURIComponent(`Внук ${g}.html`), 'Внук')));
  zip.file(`Export/Корень/Ребёнок/Внук ${g}.html`, h('Внук', '<p>глубоко</p>'));
  zip.file(`Export/Плоский ${f}.html`, h('Плоский', L(encodeURIComponent(`Лист ${l}.html`), 'Лист')));
  zip.file(`Export/Лист ${l}.html`, h('Лист', '<p>без папок</p>'));
  const zipPath = path.join(os.tmpdir(), 'notion-nesting.zip');
  fs.writeFileSync(zipPath, await zip.generateAsync({ type: 'nodebuffer' }));
  await A.click('.nav-item:has-text("Настройки")');
  await A.click('.settings-tab:has-text("Импорт из Notion")');
  await A.setInputFiles('#notion-file', zipPath);
  await A.waitForSelector('.progress-label:has-text("Готово")', { timeout: 30000 });
  await A.keyboard.press('Escape');
  const rel = await A.evaluate(async () => {
    const t = await (await fetch('api.php?a=tree')).json();
    const by = (title) => t.pages.filter((p) => p.title === title).pop();
    const name = (id) => (t.pages.find((p) => p.id === id) || {}).title || null;
    return { child: name(by('Ребёнок').parent_id), grand: name(by('Внук').parent_id), leaf: name(by('Лист').parent_id), root: name(by('Корень').parent_id) };
  });
  assert(rel.child === 'Корень' && rel.grand === 'Ребёнок' && rel.leaf === 'Плоский' && rel.root === 'Импорт из Notion', 'вложенность: ' + JSON.stringify(rel));
}, A);

await step('Прокрутка в окнах: каждый раздел настроек и история версий прокручиваются до конца (1440×900 и 1280×600)', async () => {
  const lastVisibleReachable = () => A.evaluate(() => {
    const m = document.querySelector('.modal');
    const mr = m.getBoundingClientRect();
    if (mr.bottom > innerHeight + 1) return 'окно выходит за экран';
    const els = Array.from(m.querySelectorAll('.modal-body *')).filter((e) => {
      const r = e.getBoundingClientRect();
      return r.height > 0 && r.width > 0 && getComputedStyle(e).visibility !== 'hidden' && !e.closest('details:not([open]) > :not(summary)');
    });
    const maxBottom = Math.max(...els.map((e) => e.getBoundingClientRect().bottom));
    return maxBottom <= mr.bottom + 1 ? 'ok' : `содержимое обрезано на ${Math.round(maxBottom - mr.bottom)}px`;
  });
  const scrollAll = async () => {
    const boxes = await A.$$eval('.modal .settings-body, .modal .settings-nav, .modal .history-list, .modal .history-preview, .modal .modal-body', (els) => els.map((e) => { const r = e.getBoundingClientRect(); return [r.x + r.width / 2, r.y + Math.min(r.height / 2, 120)]; }));
    for (const [x, y] of boxes) {
      await A.mouse.move(x, y);
      for (let i = 0; i < 6; i++) await A.mouse.wheel(0, 800);
    }
    await A.waitForTimeout(150);
  };
  for (const size of [{ width: 1440, height: 900 }, { width: 1280, height: 600 }]) {
    await A.setViewportSize(size);
    await A.click('.nav-item:has-text("Настройки")');
    await A.waitForSelector('.settings');
    const tabs = await A.$$eval('.settings-tab', (t) => t.map((x) => x.textContent.trim()));
    for (const t of tabs) {
      await A.click(`.settings-tab:has-text("${t}")`);
      await A.waitForTimeout(300);
      await A.$$eval('.modal details', (d) => d.forEach((x) => (x.open = true)));
      await scrollAll();
      const res = await lastVisibleReachable();
      assert(res === 'ok', `${size.width}×${size.height}, «${t}»: ${res}`);
    }
    await A.keyboard.press('Escape');
    await A.click(`.tree-row[data-id="${pageId}"]`);
    await A.waitForSelector('.page-editor .blk-h1');
    await A.click('.topbar .icon-btn[aria-label="Действия со страницей"]');
    await A.click('.menu-item:has-text("История версий")');
    await A.waitForSelector('.history-item');
    await A.click('.history-item >> nth=-1');
    await A.waitForSelector('.history-doc');
    await A.waitForTimeout(300);
    await scrollAll();
    const res = await lastVisibleReachable();
    assert(res === 'ok', `${size.width}×${size.height}, история версий: ${res}`);
    await A.keyboard.press('Escape');
  }
  await A.setViewportSize({ width: 1360, height: 900 });
}, A);

console.log('\nСмартфон');
const phone = devices['iPhone 13'] || { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 3 };
const ctxM = await browser.newContext({ ...phone, browserName: undefined, defaultBrowserType: undefined });
const M = await ctxM.newPage();
M.on('pageerror', (e) => errors.push(`[M] ${e.message}`));

await step('Вход и открытие страницы на смартфоне', async () => {
  await M.goto(inst.base + '/');
  await M.fill('#login-email', EMAIL);
  await M.fill('#login-password', PASSWORD);
  await M.tap('.login-form button[type=submit]');
  await M.waitForSelector('.topbar-menu');
  await M.tap('.topbar-menu');
  await M.waitForSelector('.shell.sidebar-open');
  await M.tap(`.tree-row[data-id="${pageId}"] .tree-title`);
  await M.waitForSelector('.page-editor .blk');
  assert(!(await M.$('.shell.sidebar-open')), 'панель не закрылась');
}, M);

await step('Создание и редактирование блока на смартфоне', async () => {
  await M.tap('.blk-h1 .blk-text');
  await M.waitForSelector('.mobilebar.is-visible');
  // касание маркера списка (не текста) тоже показывает панель строки
  await M.evaluate(() => {
    document.activeElement && document.activeElement.blur();
    document.querySelector('.mobilebar').classList.remove('is-visible');
  });
  const mk = await M.$('.page-editor .blk-marker');
  if (mk) {
    const bb = await mk.boundingBox();
    await M.touchscreen.tap(bb.x + bb.width / 2, bb.y + bb.height / 2);
    await M.waitForSelector('.mobilebar.is-visible', { timeout: 3000 });
  }
  await M.evaluate(() => {
    document.activeElement && document.activeElement.blur();
    document.querySelector('.mobilebar').classList.remove('is-visible');
  });
  await M.tap('.blk-h1 .blk-text');
  await M.waitForSelector('.mobilebar.is-visible');
  await M.waitForTimeout(250);
  // панель строки плавает рядом с курсором — сразу под текущей строкой
  const near = await M.evaluate(() => {
    const bar = document.querySelector('.mobilebar').getBoundingClientRect();
    const sel = getSelection();
    const rs = sel.rangeCount ? sel.getRangeAt(0).getClientRects() : [];
    const line = rs.length ? rs[rs.length - 1] : document.querySelector('.blk-h1 .blk-text').getBoundingClientRect();
    return { gap: bar.top - line.bottom, above: line.top - bar.bottom, barH: bar.height };
  });
  assert(((near.gap >= 0 && near.gap < 40) || (near.above >= 0 && near.above < 40)) && near.barH < 80, 'панель строки должна быть компактной и рядом со строкой: ' + JSON.stringify(near));
  // курсор в первой строке длинного абзаца — панель сразу под этой строкой, а не под всем абзацем
  const caret = await M.evaluate(async () => {
    const t = [...document.querySelectorAll('.page-editor .blk-paragraph .blk-text, .page-editor .blk .blk-text')].pop();
    const orig = t.innerHTML;
    t.textContent = 'Длинный абзац для проверки положения панели строки рядом с курсором. '.repeat(4);
    t.focus();
    t.scrollIntoView({ block: 'center' });
    const r = document.createRange();
    r.setStart(t.firstChild, 3);
    r.collapse(true);
    getSelection().removeAllRanges();
    getSelection().addRange(r);
    await new Promise((res) => setTimeout(res, 250));
    const cr = r.getClientRects()[0];
    const bar = document.querySelector('.mobilebar').getBoundingClientRect();
    const res = { gap: bar.top - cr.bottom, above: cr.top - bar.bottom, block: t.getBoundingClientRect().height };
    t.innerHTML = orig;
    return res;
  });
  await M.tap('.blk-h1 .blk-text');
  await M.waitForSelector('.mobilebar.is-visible');
  await M.waitForTimeout(250);
  assert(caret.block > 60 && ((caret.gap >= 0 && caret.gap <= 12) || (caret.above >= 0 && caret.above <= 12)), 'панель строки должна стоять вплотную к строке с курсором: ' + JSON.stringify(caret));
  // панель строки: компактная горизонтальная лента с прокруткой вбок
  const strip = await M.$eval('.mb-strip', (s) => ({ labels: [...s.querySelectorAll('.mb-btn')].map((b) => b.textContent.trim()), tops: [...new Set([...s.querySelectorAll('.mb-btn')].map((b) => Math.round(b.getBoundingClientRect().top)))], scroll: s.scrollWidth > s.clientWidth, ox: getComputedStyle(s).overflowX }));
  assert(['ИИ', 'Добавить', 'Тип', 'Цвет', 'Дублировать', 'Удалить'].every((l) => strip.labels.includes(l)), 'в ленте нет действий строки: ' + strip.labels.join(','));
  assert(strip.tops.length === 1 && strip.scroll && strip.ox === 'auto', 'лента должна быть в одну строку с прокруткой: ' + JSON.stringify(strip));
  await M.tap('.mb-btn[aria-label="Добавить"]');
  await M.waitForSelector('.menu.is-sheet');
  await M.tap('.menu.is-sheet .menu-item:has-text("Чек-лист")');
  await M.keyboard.type('Задача с телефона');
  const b = await blocks(M);
  assert(b[1].type === 'todo' && b[1].text === 'Задача с телефона', 'блок: ' + JSON.stringify(b[1]));
  await waitSaved(M);
}, M);

await step('Перемещение строки на смартфоне: зажать и перетащить, рамка вокруг строки', async () => {
  assert(!(await M.$('.mb-btn[aria-label="Переместить вверх"]')), 'кнопок «вверх/вниз» на телефоне быть не должно');
  const gut = await M.$$eval('.page-editor .blk-gutter', (gs) => gs.filter((g) => getComputedStyle(g).display !== 'none').length);
  assert(gut === 0, 'на телефоне у строк не должно быть ручки');
  // строку, которую не редактируют, зажимаем и тянем вниз
  await M.evaluate(() => document.activeElement && document.activeElement.blur());
  const rows = await M.$$eval('.page-editor .blk', (els) => els.filter((e) => e.querySelector('.blk-text')).map((e) => e.dataset.id));
  const src = rows[0];
  const dst = rows[rows.length - 1];
  const sb = await M.locator(`.blk[data-id="${src}"] .blk-text`).boundingBox();
  const db = await M.locator(`.blk[data-id="${dst}"] .blk-text`).boundingBox();
  const cdp = await ctxM.newCDPSession(M);
  const pt = (x, y) => [{ x, y, id: 1 }];
  const x = sb.x + 20;
  const y0 = sb.y + sb.height / 2;
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: pt(x, y0) });
  await M.waitForTimeout(500);
  const y1 = db.y + db.height - 2;
  for (let i = 1; i <= 8; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt(x, y0 + ((y1 - y0) * i) / 8) });
  const frame = await M.evaluate(() => {
    const n = document.querySelector('.blk.is-touch-src');
    return n ? getComputedStyle(n, '::after').borderTopColor : '';
  });
  assert(/0\.55\)$/.test(frame) && (await M.$('.drag-ghost.is-touch')), 'нет рамки вокруг перетаскиваемой строки: ' + frame);
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await M.waitForTimeout(300);
  const after = await M.$$eval('.page-editor .blk', (els) => els.map((e) => e.dataset.id));
  assert(after.indexOf(src) > after.indexOf(dst), 'строка не переместилась: ' + after.join(','));
  // обычный свайп по строке — прокрутка, а не перетаскивание
  const s2 = await M.locator(`.blk[data-id="${dst}"] .blk-text`).boundingBox();
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: pt(s2.x + 20, s2.y + 5) });
  for (let i = 1; i <= 5; i++) await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: pt(s2.x + 20, s2.y + 5 - i * 25) });
  await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] });
  await M.waitForTimeout(500);
  assert(!(await M.$('.drag-ghost')) && (await M.$$eval('.page-editor .blk', (els) => els.map((e) => e.dataset.id))).join() === after.join(), 'свайп не должен перетаскивать строку');
  await waitSaved(M);
}, M);

await step('ИИ на телефоне: полноэкранное окно над клавиатурой с кнопкой закрытия', async () => {
  // имитация экранной клавиатуры: уменьшается только visualViewport (как в iOS Safari)
  await M.evaluate(() => {
    const fake = new EventTarget();
    let kb = 0;
    Object.defineProperty(fake, 'height', { get: () => window.innerHeight - kb });
    Object.defineProperty(fake, 'width', { get: () => window.innerWidth });
    Object.defineProperty(fake, 'offsetTop', { get: () => 0 });
    Object.defineProperty(fake, 'offsetLeft', { get: () => 0 });
    Object.defineProperty(fake, 'scale', { get: () => 1 });
    Object.defineProperty(window, 'visualViewport', { configurable: true, get: () => fake });
    window.__kb = (h) => {
      kb = h;
      fake.dispatchEvent(new Event('resize'));
    };
  });
  const last = M.locator('.page-editor .blk .blk-text').last();
  await last.evaluate((t) => {
    t.focus();
    if (!t.textContent) t.textContent = 'текст для ИИ на телефоне';
    const r = document.createRange();
    r.selectNodeContents(t);
    const s = getSelection();
    s.removeAllRanges();
    s.addRange(r);
  });
  await M.waitForSelector('.fmt-bar .fmt-ai', { state: 'visible' });
  await M.tap('.fmt-bar .fmt-ai');
  await M.waitForSelector('.ai-pop.is-sheet');
  await M.evaluate(() => window.__kb(300));
  await M.waitForTimeout(300);
  const r = await M.evaluate(() => {
    const p = document.querySelector('.ai-pop').getBoundingClientRect();
    const src = document.querySelector('.ai-pop .ai-source');
    const c = document.querySelector('.ai-pop .ai-close').getBoundingClientRect();
    const i = document.querySelector('.ai-pop .ai-input').getBoundingClientRect();
    return { popTop: p.top, popBottom: p.bottom, popW: p.width, w: innerWidth, kbTop: innerHeight - 300, src: src ? src.textContent : null, closeW: c.width, inputBottom: i.bottom };
  });
  await M.screenshot({ path: path.join(SHOTS, 'ai-phone.png') });
  // полноэкранное окно: от верха экрана до клавиатуры, с исходным текстом и крупной кнопкой закрытия
  assert(Math.abs(r.popTop) <= 1 && Math.abs(r.popBottom - r.kbTop) <= 1 && r.popW === r.w, 'окно ИИ на телефоне должно занимать экран над клавиатурой: ' + JSON.stringify(r));
  assert(r.src && r.src.length > 0, 'в окне ИИ должен быть виден обрабатываемый текст: ' + JSON.stringify(r));
  assert(r.closeW >= 36 && r.inputBottom <= r.kbTop, 'кнопка закрытия и поле команды должны быть доступны: ' + JSON.stringify(r));
  await M.evaluate(() => window.__kb(0));
  await M.waitForTimeout(200);
  const full = await M.evaluate(() => document.querySelector('.ai-pop').getBoundingClientRect().height);
  assert(Math.abs(full - (await M.evaluate(() => innerHeight))) <= 1, 'без клавиатуры окно ИИ должно занимать весь экран: ' + full);
  await M.tap('.ai-close');
  await M.waitForSelector('.ai-pop', { state: 'detached' });
}, M);

await step('Телефон: панель форматирования у выделения и не перекрывает ленту строки', async () => {
  const last = M.locator('.page-editor .blk .blk-text').last();
  await last.tap();
  await M.evaluate(() => window.__kb && window.__kb(300));
  await last.evaluate((t) => {
    if (!t.textContent) t.textContent = 'текст для проверки';
    t.scrollIntoView({ block: 'end' });
    const r = document.createRange();
    r.selectNodeContents(t);
    const sel = getSelection();
    sel.removeAllRanges();
    sel.addRange(r);
  });
  await M.waitForSelector('.fmt-bar', { state: 'visible' });
  await M.waitForTimeout(250);
  const r = await M.evaluate(() => {
    const f = document.querySelector('.fmt-bar').getBoundingClientRect();
    const m = document.querySelector('.mobilebar.is-visible:not(.is-suppressed)');
    const mr = m ? m.getBoundingClientRect() : null;
    const s = getSelection().getRangeAt(0).getBoundingClientRect();
    return { kb: innerHeight - 300, fTop: f.top, fBottom: f.bottom, mTop: mr ? mr.top : null, sTop: s.top, sBottom: s.bottom, docked: document.querySelector('.fmt-bar').classList.contains('is-docked') };
  });
  assert(!r.docked && r.fTop >= 0, 'панель форматирования должна быть у выделения: ' + JSON.stringify(r));
  assert(r.mTop === null, 'при выделении текста панель строки должна уступать место панели форматирования: ' + JSON.stringify(r));
  // над выделением система показывает своё меню («Скопировать · Вставить») — наша панель туда не лезет
  const freeOfSystemMenu = (q) => q.fBottom <= q.sTop - 64 || q.fTop >= q.sBottom + 72;
  assert(freeOfSystemMenu(r), 'панель форматирования заходит в зону системного меню над выделением: ' + JSON.stringify(r));
  assert(r.fBottom <= r.kb + 1, 'панель форматирования закрыта клавиатурой: ' + JSON.stringify(r));
  const measure = (where) =>
    M.evaluate(async (where) => {
      const t = document.querySelector('.page-editor .blk .blk-text');
      const sc = t.closest('.scroller');
      if (where === 'top') sc.scrollTop += t.getBoundingClientRect().top - 4;
      else sc.scrollTop += t.getBoundingClientRect().top - 220;
      const r = document.createRange();
      r.selectNodeContents(t);
      getSelection().removeAllRanges();
      getSelection().addRange(r);
      await new Promise((res) => setTimeout(res, 250));
      const f = document.querySelector('.fmt-bar').getBoundingClientRect();
      const s = r.getBoundingClientRect();
      return { fTop: f.top, fBottom: f.bottom, sTop: s.top, sBottom: s.bottom, kb: innerHeight - 300 };
    }, where);
  // выделение посреди экрана — панель под ним, ниже ручки выделения
  const mid = await measure('mid');
  assert(mid.fTop >= mid.sBottom + 72 && mid.fTop <= mid.sBottom + 80 && mid.fBottom <= mid.kb, 'панель должна стоять под выделением: ' + JSON.stringify(mid));
  // выделение у самого верха — системное меню уходит вниз, наша панель встаёт ещё ниже
  const top = await measure('top');
  if (top.sTop < 76) assert(top.fTop >= top.sBottom + 72 && top.fTop <= top.sBottom + 80, 'у верха экрана панель должна встать ниже системного меню: ' + JSON.stringify(top));
  // как на iPhone: клавиатура сдвинула видимую область, и «ноль» приклеенных панелей разошёлся с координатами текста
  const ios = await M.evaluate(async () => {
    const prev = window.visualViewport;
    const V = 250;
    const fake = new EventTarget();
    Object.defineProperty(fake, 'height', { get: () => window.innerHeight - 300 });
    Object.defineProperty(fake, 'width', { get: () => window.innerWidth });
    Object.defineProperty(fake, 'offsetTop', { get: () => V });
    Object.defineProperty(fake, 'offsetLeft', { get: () => 0 });
    Object.defineProperty(fake, 'scale', { get: () => 1 });
    Object.defineProperty(window, 'visualViewport', { configurable: true, get: () => fake });
    document.body.style.transform = `translateY(-${V}px)`;
    const wait = () => new Promise((res) => setTimeout(res, 250));
    const t = [...document.querySelectorAll('.page-editor .blk .blk-text')].filter((x) => x.textContent.trim()).pop();
    const sc = t.closest('.scroller');
    sc.style.paddingBottom = '900px';
    sc.scrollTop += t.getBoundingClientRect().top - 150;
    const r = document.createRange();
    const tn = document.createTreeWalker(t, NodeFilter.SHOW_TEXT).nextNode();
    r.setStart(tn, 0);
    r.setEnd(tn, Math.min(4, tn.length));
    getSelection().removeAllRanges();
    getSelection().addRange(r);
    await wait();
    const f = document.querySelector('.fmt-bar').getBoundingClientRect();
    const s = r.getBoundingClientRect();
    const out = { vh: window.innerHeight - 300, fTop: f.top, fBottom: f.bottom, sTop: s.top, sBottom: s.bottom };
    const c = document.createRange();
    c.setStart(tn, 0);
    c.collapse(true);
    getSelection().removeAllRanges();
    getSelection().addRange(c);
    await wait();
    const mb = document.querySelector('.mobilebar.is-visible.is-floating:not(.is-suppressed)');
    if (mb) {
      const b = mb.getBoundingClientRect();
      const cr = c.getClientRects()[0] || t.getBoundingClientRect();
      out.mGap = b.top - cr.bottom;
      out.mAbove = cr.top - b.bottom;
    }
    document.body.style.transform = '';
    Object.defineProperty(window, 'visualViewport', { configurable: true, get: () => prev });
    return out;
  });
  assert(ios.fTop >= ios.sBottom + 72 && ios.fTop <= ios.sBottom + 80 && ios.fTop >= 0 && ios.fBottom <= ios.vh, 'iPhone со сдвигом экрана: панель текста должна стоять сразу под выделением: ' + JSON.stringify(ios));
  if ('mGap' in ios) assert((ios.mGap >= 0 && ios.mGap <= 12) || (ios.mAbove >= 0 && ios.mAbove <= 12), 'iPhone со сдвигом экрана: панель строки должна стоять у строки с курсором: ' + JSON.stringify(ios));
  await M.evaluate(() => {
    getSelection().removeAllRanges();
    window.__kb && window.__kb(0);
  });
}, M);

await step('Обложка на телефоне: кнопка «Сменить обложку» нажимается', async () => {
  const id = await M.evaluate(async () => {
    const csrf = (await (await fetch('api.php?a=auth.status')).json()).csrf;
    return (await (await fetch('api.php?a=page.create', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf }, body: JSON.stringify({ title: 'С обложкой', icon: '📒', cover: 'preset:3' }) })).json()).id;
  });
  await M.goto(`${inst.base}/#/p/${id}`);
  await M.waitForSelector('.page-cover .cover-btn');
  const top = await M.$eval('.cover-btn', (b) => {
    const r = b.getBoundingClientRect();
    const e = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    return b.contains(e);
  });
  assert(top, 'кнопку «Сменить обложку» что-то перекрывает');
  await M.tap('.cover-btn');
  await M.waitForSelector('.menu .menu-item');
  await M.tap('.menu .menu-item >> nth=1');
  await M.waitForTimeout(300);
  assert((await M.$eval('.page-cover', (c) => c.className)) !== 'page-cover cover-preset-3', 'обложка не сменилась');
  await M.goBack();
}, M);

await step('Мобильная вёрстка: приложение сверху экрана, панель выезжает поверх', async () => {
  const r = await M.evaluate(() => ({ top: document.querySelector('.topbar').getBoundingClientRect().top, pos: getComputedStyle(document.querySelector('.sidebar')).position, x: document.querySelector('.sidebar').getBoundingClientRect().right }));
  assert(Math.abs(r.top) < 1 && r.pos === 'fixed' && r.x <= 1, 'пустота сверху или панель в потоке страницы: ' + JSON.stringify(r));
}, M);

await step('Мобильная вёрстка без горизонтальной прокрутки', async () => {
  const overflow = await M.evaluate(() => document.querySelector('.scroller').scrollWidth - document.querySelector('.scroller').clientWidth);
  assert(overflow <= 1, 'горизонтальное переполнение: ' + overflow);
  await M.screenshot({ path: path.join(SHOTS, 'mobile.png') });
}, M);

await A.screenshot({ path: path.join(SHOTS, 'desktop.png') });
console.log(`\nОшибки JavaScript в браузере: ${errors.length ? '\n  ' + errors.join('\n  ') : 'нет'}`);
console.log(`Итог: ${passed} пройдено, ${failed} с ошибками. Скриншоты: ${SHOTS}`);
await browser.close();
await inst.stop();
process.exit(failed || errors.length ? 1 : 0);
