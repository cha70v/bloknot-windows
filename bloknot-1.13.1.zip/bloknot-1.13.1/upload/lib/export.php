<?php
/** Экспорт в Markdown, полный бэкап и восстановление. */

require_once __DIR__ . '/zip.php';

// ---------- Markdown ----------

function md_escape_text($s)
{
    return preg_replace('/([\\\\`*_\[\]#|<>])/u', '\\\\$1', $s);
}

/** Конвертирует встроенный HTML блока (b, i, u, s, code, a, br) в Markdown. */
function inline_html_to_md($html, $ctx)
{
    if ($html === '' || $html === null) return '';
    if (!class_exists('DOMDocument')) {
        return md_escape_text(html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }
    $doc = new DOMDocument();
    libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="utf-8"?><div id="r">' . $html . '</div>', LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors();
    $root = $doc->getElementById('r');
    if (!$root) return md_escape_text(strip_tags($html));
    return md_walk($root, $ctx);
}

function md_walk($node, $ctx)
{
    $out = '';
    foreach ($node->childNodes as $c) {
        if ($c->nodeType === XML_TEXT_NODE) {
            $out .= md_escape_text($c->nodeValue);
            continue;
        }
        if ($c->nodeType !== XML_ELEMENT_NODE) continue;
        $tag = strtolower($c->nodeName);
        if ($tag === 'br') { $out .= "  \n"; continue; }
        if ($tag === 'code') { $out .= '`' . str_replace('`', 'ˋ', $c->textContent) . '`'; continue; }
        $inner = md_walk($c, $ctx);
        if (trim($inner) === '') { $out .= $inner; continue; }
        // пробелы выносим за пределы разметки, иначе Markdown её не распознает
        preg_match('/^(\s*)(.*?)(\s*)$/su', $inner, $m);
        list(, $l, $core, $r) = $m;
        switch ($tag) {
            case 'b': case 'strong': $out .= $l . '**' . $core . '**' . $r; break;
            case 'i': case 'em': $out .= $l . '*' . $core . '*' . $r; break;
            case 's': case 'del': case 'strike': $out .= $l . '~~' . $core . '~~' . $r; break;
            case 'u': $out .= $l . '<u>' . $core . '</u>' . $r; break;
            case 'a':
                $href = $c->getAttribute('href');
                if (preg_match('~^#/p/(\d+)~', $href, $mm) && isset($ctx['links'][(int) $mm[1]])) {
                    $href = $ctx['links'][(int) $mm[1]];
                }
                $out .= $l . '[' . $core . '](' . str_replace(array(' ', ')'), array('%20', '%29'), $href) . ')' . $r;
                break;
            default: $out .= $inner;
        }
    }
    return $out;
}

function blocks_to_markdown($blocks, $ctx)
{
    $lines = array();
    $prevType = null;
    $olCounters = array();
    foreach ((array) $blocks as $b) {
        if (!is_array($b) || empty($b['type'])) continue;
        $type = $b['type'];
        $indent = isset($b['indent']) ? max(0, min(8, (int) $b['indent'])) : 0;
        $pad = str_repeat('    ', $indent);
        $html = isset($b['html']) ? $b['html'] : '';
        $text = inline_html_to_md($html, $ctx);
        $isList = in_array($type, array('ul', 'ol', 'todo', 'toggle'), true);
        if ($type !== 'ol') {
            foreach (array_keys($olCounters) as $k) if ($k >= $indent) unset($olCounters[$k]);
        }
        // пустая строка между блоками (кроме соседних элементов списка)
        if ($lines && !($isList && in_array($prevType, array('ul', 'ol', 'todo', 'toggle'), true))) $lines[] = '';
        switch ($type) {
            case 'h1': $lines[] = '# ' . $text; break;
            case 'h2': $lines[] = '## ' . $text; break;
            case 'h3': $lines[] = '### ' . $text; break;
            case 'ul': $lines[] = $pad . '- ' . $text; break;
            case 'ol':
                foreach (array_keys($olCounters) as $k) if ($k > $indent) unset($olCounters[$k]);
                $olCounters[$indent] = isset($olCounters[$indent]) ? $olCounters[$indent] + 1 : 1;
                $lines[] = $pad . $olCounters[$indent] . '. ' . $text;
                break;
            case 'todo': $lines[] = $pad . '- [' . (!empty($b['checked']) ? 'x' : ' ') . '] ' . $text; break;
            case 'toggle': $lines[] = $pad . '- ▸ ' . $text; break;
            case 'quote': $lines[] = '> ' . str_replace("\n", "\n> ", $text); break;
            case 'callout': $lines[] = '> ' . (isset($b['icon']) && $b['icon'] !== '' ? $b['icon'] . ' ' : '') . str_replace("\n", "\n> ", $text); break;
            case 'code':
                $code = isset($b['text']) ? (string) $b['text'] : '';
                $fence = str_contains($code, '```') ? '~~~~' : '```';
                $lines[] = $fence . (isset($b['lang']) && $b['lang'] !== 'plain' ? $b['lang'] : '');
                $lines[] = $code;
                $lines[] = $fence;
                break;
            case 'hr': $lines[] = '---'; break;
            case 'image':
                $cap = isset($b['caption']) ? trim(strip_tags($b['caption'])) : '';
                $src = '';
                if (!empty($b['file']) && isset($ctx['files'][$b['file']])) $src = $ctx['files'][$b['file']];
                elseif (!empty($b['src'])) $src = $b['src'];
                $lines[] = '![' . md_escape_text($cap) . '](' . str_replace(' ', '%20', $src) . ')';
                if ($cap !== '') $lines[] = '*' . md_escape_text($cap) . '*';
                break;
            case 'bookmark':
                $url = isset($b['url']) ? $b['url'] : '';
                $title = isset($b['title']) && $b['title'] !== '' ? $b['title'] : $url;
                $lines[] = '[' . md_escape_text($title) . '](' . str_replace(' ', '%20', $url) . ')';
                break;
            case 'page':
                $pid = isset($b['pageId']) ? (int) $b['pageId'] : 0;
                $t = isset($ctx['titles'][$pid]) ? $ctx['titles'][$pid] : 'Страница';
                if (isset($ctx['links'][$pid])) $lines[] = '[' . md_escape_text($t) . '](' . $ctx['links'][$pid] . ')';
                else $lines[] = '📄 ' . md_escape_text($t);
                break;
            case 'table':
                $rows = isset($b['rows']) && is_array($b['rows']) ? $b['rows'] : array();
                if (!$rows) break;
                $cols = 0;
                foreach ($rows as $r) $cols = max($cols, count((array) $r));
                foreach ($rows as $ri => $r) {
                    $cells = array();
                    for ($ci = 0; $ci < $cols; $ci++) {
                        $cells[] = str_replace(array("\n", '|'), array(' ', '\\|'), inline_html_to_md(isset($r[$ci]) ? $r[$ci] : '', $ctx));
                    }
                    $lines[] = '| ' . implode(' | ', $cells) . ' |';
                    if ($ri === 0) $lines[] = '|' . str_repeat(' --- |', $cols);
                }
                break;
            default:
                $lines[] = $text;
        }
        $prevType = $type;
    }
    return implode("\n", $lines) . "\n";
}

function safe_filename($title, $fallback = 'Без названия')
{
    $t = trim(preg_replace('/[\/\\\\:*?"<>|\x00-\x1F]+/u', ' ', (string) $title));
    $t = preg_replace('/\s+/u', ' ', $t);
    $t = trim($t, ' .');
    if ($t === '') $t = $fallback;
    return t_substr($t, 0, 80);
}

function relative_path($fromDir, $to)
{
    $from = $fromDir === '' ? array() : explode('/', $fromDir);
    $toParts = explode('/', $to);
    while ($from && $toParts && $from[0] === $toParts[0]) {
        array_shift($from);
        array_shift($toParts);
    }
    $rel = str_repeat('../', count($from)) . implode('/', $toParts);
    return implode('/', array_map('rawurlencode', explode('/', $rel)));
}

/**
 * Экспортирует страницы (поддерево или всё) в ZIP с Markdown-файлами и изображениями.
 * Если $rootId = null — экспортируются все страницы.
 */
function export_markdown_zip($uid, $rootId, $includeChildren = true)
{
    $name = markdown_zip_name($uid, $rootId);
    header('Content-Type: application/zip');
    header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode($name));
    header('Cache-Control: no-store');
    @set_time_limit(0);
    write_markdown_zip($uid, $rootId, $includeChildren, fopen('php://output', 'wb'));
    exit;
}

function markdown_zip_name($uid, $rootId)
{
    $root = $rootId ? page_get_owned($uid, $rootId) : null;
    return safe_filename($root ? $root['title'] : 'Блокнот — все страницы') . '.zip';
}

/**
 * Пишет ZIP с Markdown-страницами в поток. $withFiles = false — без изображений (для письма).
 * Возвращает количество страниц.
 */
function write_markdown_zip($uid, $rootId, $includeChildren, $out, $withFiles = true, $compress = false)
{
    if ($rootId) {
        $root = page_get_owned($uid, $rootId);
        $ids = $includeChildren ? subtree_ids($uid, $rootId) : array((int) $rootId);
    } else {
        $root = null;
        $ids = array_map('intval', q('SELECT id FROM pages WHERE owner_id = ? AND deleted_at IS NULL', array($uid))->fetchAll(PDO::FETCH_COLUMN));
    }
    $pages = array();
    foreach ($ids as $id) {
        $pages[$id] = q_one('SELECT id, parent_id, position, title, icon, content FROM pages WHERE id = ?', array($id));
    }
    // строим пути: «Название.md» и папка «Название/» для вложенных страниц
    $children = array();
    foreach ($pages as $p) {
        $parent = ($p['parent_id'] !== null && isset($pages[(int) $p['parent_id']]) && (int) $p['id'] !== (int) $rootId) ? (int) $p['parent_id'] : 0;
        $children[$parent][] = $p;
    }
    foreach ($children as &$list) {
        usort($list, function ($a, $b) { return $a['position'] <=> $b['position']; });
    }
    unset($list);
    $paths = array();
    $titles = array();
    $assign = function ($parentKey, $dir) use (&$assign, &$children, &$paths, &$titles) {
        if (empty($children[$parentKey])) return;
        $used = array();
        foreach ($children[$parentKey] as $p) {
            $base = safe_filename($p['title']);
            $name = $base;
            $n = 2;
            while (isset($used[t_lower($name)])) $name = $base . ' (' . $n++ . ')';
            $used[t_lower($name)] = true;
            $paths[(int) $p['id']] = ($dir === '' ? '' : $dir . '/') . $name . '.md';
            $titles[(int) $p['id']] = $p['title'] === '' ? 'Без названия' : $p['title'];
            $assign((int) $p['id'], ($dir === '' ? '' : $dir . '/') . $name);
        }
    };
    $assign(0, '');

    // файлы, на которые ссылаются страницы
    $fileIds = array();
    foreach ($pages as $p) {
        if (preg_match_all('/[a-f0-9]{32}/', $p['content'], $m)) {
            foreach ($m[0] as $fid) $fileIds[$fid] = true;
        }
    }
    $files = array();
    if ($fileIds) {
        $in = implode(',', array_fill(0, count($fileIds), '?'));
        $rows = q('SELECT id, mime FROM files WHERE owner_id = ? AND id IN (' . $in . ')', array_merge(array($uid), array_keys($fileIds)))->fetchAll();
        $ext = array('image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp');
        foreach ($rows as $r) $files[$r['id']] = '_files/' . $r['id'] . '.' . (isset($ext[$r['mime']]) ? $ext[$r['mime']] : 'bin');
    }

    $zip = new StoreZipWriter($out, $compress);
    foreach ($paths as $id => $path) {
        $dir = str_contains($path, '/') ? substr($path, 0, strrpos($path, '/')) : '';
        $links = array();
        foreach ($paths as $oid => $opath) $links[$oid] = relative_path($dir, $opath);
        $flinks = array();
        foreach ($files as $fid => $fpath) $flinks[$fid] = relative_path($dir, $fpath);
        $c = json_decode($pages[$id]['content'], true);
        $md = '# ' . ($pages[$id]['icon'] !== '' ? $pages[$id]['icon'] . ' ' : '') . md_escape_text($titles[$id]) . "\n\n"
            . blocks_to_markdown(isset($c['blocks']) ? $c['blocks'] : array(), array('links' => $links, 'files' => $flinks, 'titles' => $titles));
        $zip->addString($path, $md);
    }
    if ($withFiles) {
        foreach ($files as $fid => $fpath) {
            $src = file_storage_path($fid);
            if (is_file($src)) $zip->addFile($fpath, $src);
        }
    }
    $zip->finish();
    return count($paths);
}

// ---------- Резервное копирование ----------

function db_snapshot($dest)
{
    @unlink($dest);
    try {
        $st = db()->prepare('VACUUM INTO ?');
        $st->execute(array($dest));
        if (is_file($dest)) return;
    } catch (Exception $e) {
        // старая версия SQLite — делаем копию под блокировкой записи
    }
    db()->exec('BEGIN IMMEDIATE');
    try {
        copy(db_path(), $dest);
    } finally {
        db()->exec('COMMIT');
    }
}

function backup_tmp_dir()
{
    $d = TETRAD_DATA . '/tmp';
    if (!is_dir($d)) @mkdir($d, 0750, true);
    return $d;
}

/**
 * Пишет полный бэкап (база + файлы + конфигурация) в поток.
 * Сжатие без потерь: база и текст — deflate (уровень 9), одинаковые изображения хранятся один раз
 * (список копий — в manifest.json → duplicates, при восстановлении они создаются заново).
 */
function write_backup($out)
{
    $snap = backup_tmp_dir() . '/snapshot-' . random_token(6) . '.sqlite';
    db_snapshot($snap);
    try {
        $dir = uploads_dir();
        $unique = array();
        $dups = array();
        if (is_dir($dir)) {
            $list = array();
            $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS));
            foreach ($it as $f) {
                if ($f->isFile() && $f->getFilename() !== '_duplicates.json') $list[] = array(str_replace('\\', '/', substr($f->getPathname(), strlen($dir) + 1)), $f->getPathname(), $f->getSize());
            }
            usort($list, function ($a, $b) { return strcmp($a[0], $b[0]); });
            $byHash = array();
            foreach ($list as $e) {
                $key = $e[2] . ':' . hash_file('sha256', $e[1]);
                if (isset($byHash[$key])) $dups[$e[0]] = $byHash[$key];
                else {
                    $byHash[$key] = $e[0];
                    $unique[] = $e;
                }
            }
        }
        $zip = new StoreZipWriter($out, true, backup_tmp_dir());
        $zip->addString('manifest.json', json_encode(array(
            'app' => 'tetrad',
            'version' => TETRAD_VERSION,
            'schema' => TETRAD_SCHEMA,
            'created_at' => gmdate('c'),
            'db_file' => config('db_file'),
            'duplicates' => (object) $dups,
        ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $zip->addFile('data/' . config('db_file'), $snap);
        $zip->addFile('data/config.php', config_path());
        foreach ($unique as $e) $zip->addFile('data/uploads/' . $e[0], $e[1]);
        // для ручной распаковки по FTP: недостающие копии Блокнот создаст сам при первом обращении
        if ($dups) $zip->addString('data/uploads/_duplicates.json', json_encode($dups, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        $zip->finish();
    } finally {
        @unlink($snap);
    }
}

function backup_download()
{
    @set_time_limit(0);
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="bloknot-backup-' . date('Y-m-d-His') . '.zip"');
    header('Cache-Control: no-store');
    write_backup(fopen('php://output', 'wb'));
    exit;
}

function backup_to_file($keep = 7)
{
    $dir = TETRAD_DATA . '/backups';
    if (!is_dir($dir)) mkdir($dir, 0750, true);
    $path = $dir . '/bloknot-backup-' . date('Y-m-d-His') . '.zip';
    $fh = fopen($path . '.part', 'wb');
    write_backup($fh);
    fclose($fh);
    rename($path . '.part', $path);
    $all = glob($dir . '/bloknot-backup-*.zip');
    sort($all);
    while (count($all) > max(1, (int) $keep)) @unlink(array_shift($all));
    return $path;
}

function rrmdir($dir)
{
    if (!is_dir($dir)) return;
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) {
        if ($f->isDir()) @rmdir($f->getPathname());
        else @unlink($f->getPathname());
    }
    @rmdir($dir);
}

/** Восстанавливает данные из архива бэкапа. Текущие данные переносятся в data/pre-restore-*. */
function backup_restore_from($zipPath)
{
    $tmp = backup_tmp_dir() . '/restore-' . random_token(6);
    try {
        zip_extract_safe($zipPath, $tmp);
        $dbFiles = glob($tmp . '/data/*.sqlite');
        if (!$dbFiles) throw new HttpError(422, 'В архиве нет базы данных Блокнота');
        $newDb = $dbFiles[0];
        // одинаковые изображения в архиве хранятся один раз — восстанавливаем копии
        $manifest = is_file($tmp . '/manifest.json') ? json_decode((string) file_get_contents($tmp . '/manifest.json'), true) : null;
        if (is_array($manifest) && !empty($manifest['duplicates']) && is_array($manifest['duplicates'])) {
            $up = $tmp . '/data/uploads';
            foreach ($manifest['duplicates'] as $copy => $orig) {
                $copy = (string) $copy;
                $orig = (string) $orig;
                foreach (array($copy, $orig) as $rel) {
                    if (!preg_match('#^[A-Za-z0-9._-]+(/[A-Za-z0-9._-]+)*$#', $rel) || preg_match('#(^|/)\.\.(/|$)#', $rel)) {
                        throw new HttpError(422, 'Архив содержит недопустимый путь: ' . $rel);
                    }
                }
                if (!is_file($up . '/' . $orig)) throw new HttpError(422, 'В архиве не хватает файла ' . $orig);
                if (!is_dir(dirname($up . '/' . $copy))) mkdir(dirname($up . '/' . $copy), 0750, true);
                copy($up . '/' . $orig, $up . '/' . $copy);
            }
        }
        @unlink($tmp . '/data/uploads/_duplicates.json');
        // проверяем, что это наша база
        $test = new PDO('sqlite:' . $newDb, null, null, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
        $tables = $test->query("SELECT name FROM sqlite_master WHERE type='table'")->fetchAll(PDO::FETCH_COLUMN);
        $users = in_array('users', $tables, true) ? (int) $test->query('SELECT COUNT(*) FROM users')->fetchColumn() : 0;
        $test = null;
        if (!in_array('pages', $tables, true) || $users < 1) throw new HttpError(422, 'Архив не похож на бэкап Блокнота');

        $keep = TETRAD_DATA . '/pre-restore-' . date('Y-m-d-His');
        for ($n = 2; file_exists($keep); $n++) $keep = TETRAD_DATA . '/pre-restore-' . date('Y-m-d-His') . '-' . $n;
        if (!mkdir($keep, 0750, true)) throw new RuntimeException('Не удалось создать папку для текущих данных');
        db_close();
        try {
        if (is_file(db_path()) && !rename(db_path(), $keep . '/' . config('db_file'))) throw new RuntimeException('Не удалось сохранить текущую базу');
        if (is_dir(uploads_dir()) && !rename(uploads_dir(), $keep . '/uploads')) throw new RuntimeException('Не удалось сохранить текущие изображения');
        if (!rename($newDb, db_path())) throw new RuntimeException('Не удалось заменить базу');
        if (is_dir($tmp . '/data/uploads')) {
            if (!rename($tmp . '/data/uploads', uploads_dir())) throw new RuntimeException('Не удалось перенести изображения из архива');
        } else {
            mkdir(uploads_dir(), 0750, true);
        }
        } catch (Throwable $e) {
            // откат: возвращаем прежние данные на место
            if (is_file($keep . '/' . config('db_file'))) { @unlink(db_path()); @rename($keep . '/' . config('db_file'), db_path()); }
            if (is_dir($keep . '/uploads')) { if (is_dir(uploads_dir())) rrmdir(uploads_dir()); @rename($keep . '/uploads', uploads_dir()); }
            throw $e;
        }
        // применяем миграции, если бэкап сделан в старой версии
        db();
        touch_tree();
        return array('ok' => true, 'previous_saved_to' => basename($keep));
    } finally {
        rrmdir($tmp);
    }
}

/** Делит архив на части name.zip.001, .002… (простое разрезание — формат, который понимают 7-Zip и WinRAR). */
function backup_split($path, $partSize)
{
    $dir = backup_tmp_dir() . '/parts-' . random_token(6);
    mkdir($dir, 0750, true);
    $in = fopen($path, 'rb');
    $parts = array();
    $n = 0;
    while (!feof($in)) {
        $target = $dir . '/' . basename($path) . '.' . sprintf('%03d', ++$n);
        $out = fopen($target, 'wb');
        $left = $partSize;
        while ($left > 0 && !feof($in)) {
            $chunk = fread($in, min(1048576, $left));
            if ($chunk === false || $chunk === '') break;
            fwrite($out, $chunk);
            $left -= strlen($chunk);
        }
        fclose($out);
        if (filesize($target) === 0) {
            unlink($target);
            break;
        }
        $parts[] = $target;
    }
    fclose($in);
    return $parts;
}

function plural_ru($n, $one, $few, $many)
{
    $n = abs((int) $n) % 100;
    if ($n >= 11 && $n <= 19) return $many;
    $n %= 10;
    if ($n === 1) return $one;
    if ($n >= 2 && $n <= 4) return $few;
    return $many;
}

function backup_upload_path($token)
{
    if (!preg_match('/^[a-f0-9]{16,40}$/', $token)) throw new HttpError(422, 'Неверный идентификатор загрузки');
    return backup_tmp_dir() . '/restore-up-' . $token . '.zip';
}

/** Принимает очередной кусок архива для восстановления и дописывает его в конец временного файла. */
function backup_upload_chunk($token, $offset, $file)
{
    $path = backup_upload_path($token);
    if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
        throw new HttpError(422, 'Часть архива не получена (лимит загрузки хостинга — ' . round(upload_limit_bytes() / 1048576) . ' МБ)');
    }
    if ($offset === 0) {
        // старые незавершённые загрузки больше суток — удаляем
        foreach (glob(backup_tmp_dir() . '/restore-up-*.zip') ?: array() as $old) {
            if (filemtime($old) < time() - 86400) @unlink($old);
        }
        $free = function_exists('disk_free_space') ? @disk_free_space(TETRAD_DATA) : false;
        if ($free !== false && $free < 64 * 1048576) throw new HttpError(507, 'На хостинге почти не осталось места');
        $fh = fopen($path, 'wb');
    } else {
        clearstatcache(true, $path);
        $have = is_file($path) ? filesize($path) : -1;
        if ($have !== $offset) throw new HttpError(409, 'Загрузка прервалась — начните восстановление заново', array('have' => $have));
        $fh = fopen($path, 'ab');
    }
    if ($offset + (int) $file['size'] > 4294967295) throw new HttpError(413, 'Архив слишком большой');
    $in = fopen($file['tmp_name'], 'rb');
    stream_copy_to_stream($in, $fh);
    fclose($in);
    fclose($fh);
    clearstatcache(true, $path);
    return array('ok' => true, 'size' => filesize($path));
}
