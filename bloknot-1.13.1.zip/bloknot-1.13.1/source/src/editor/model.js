// Типы блоков и их свойства
import { uid } from '../util.js';

export const TEXT_TYPES = new Set(['p', 'h1', 'h2', 'h3', 'ul', 'ol', 'todo', 'toggle', 'quote', 'callout']);
export const LIST_TYPES = new Set(['ul', 'ol', 'todo', 'toggle']);
export const ATOM_TYPES = new Set(['hr', 'image', 'bookmark', 'page', 'table']);
export const MAX_INDENT = 6;

export const TYPE_LABELS = {
  p: 'Текст',
  h1: 'Заголовок 1',
  h2: 'Заголовок 2',
  h3: 'Заголовок 3',
  ul: 'Маркированный список',
  ol: 'Нумерованный список',
  todo: 'Чек-лист',
  toggle: 'Раскрывающийся блок',
  quote: 'Цитата',
  callout: 'Выноска',
  code: 'Код',
  hr: 'Разделитель',
  image: 'Изображение',
  bookmark: 'Ссылка-закладка',
  page: 'Страница',
  table: 'Таблица',
};

export const TYPE_ICONS = {
  p: 'text', h1: 'h1', h2: 'h2', h3: 'h3', ul: 'list', ol: 'olist', todo: 'todo', toggle: 'toggle', quote: 'quote', callout: 'callout',
  code: 'code', hr: 'divider', image: 'image', bookmark: 'bookmark', page: 'page', table: 'table',
};

export const PLACEHOLDERS = {
  p: 'Введите текст или / для выбора блока',
  h1: 'Заголовок 1',
  h2: 'Заголовок 2',
  h3: 'Заголовок 3',
  ul: 'Пункт списка',
  ol: 'Пункт списка',
  todo: 'Задача',
  toggle: 'Заголовок раскрывающегося блока',
  quote: 'Цитата',
  callout: 'Текст выноски',
};

export const isText = (b) => b && TEXT_TYPES.has(b.type);
export const isEditable = (b) => b && (TEXT_TYPES.has(b.type) || b.type === 'code');
export const isAtom = (b) => b && ATOM_TYPES.has(b.type);

export function newBlock(type = 'p', props = {}) {
  const b = { id: uid(), type };
  if (TEXT_TYPES.has(type)) b.html = '';
  if (type === 'todo') b.checked = false;
  if (type === 'toggle') b.open = true;
  if (type === 'callout') b.icon = '💡';
  if (type === 'code') {
    b.text = '';
    b.lang = 'plain';
  }
  if (type === 'table') b.rows = [['', '', ''], ['', '', '']];
  return Object.assign(b, props);
}

/** Приводит блоки, пришедшие с сервера или из буфера, к ожидаемому виду. */
export function normalizeBlocks(blocks) {
  const seen = new Set();
  const out = [];
  for (const raw of Array.isArray(blocks) ? blocks : []) {
    if (!raw || typeof raw !== 'object' || !TYPE_LABELS[raw.type]) continue;
    const b = Object.assign({}, raw);
    if (!b.id || seen.has(b.id)) b.id = uid();
    seen.add(b.id);
    if (TEXT_TYPES.has(b.type) && typeof b.html !== 'string') b.html = '';
    if (b.type === 'code') {
      if (typeof b.text !== 'string') b.text = '';
      if (!b.lang) b.lang = 'plain';
    }
    if (b.type === 'table' && !Array.isArray(b.rows)) b.rows = [['']];
    if (b.widths !== undefined) {
      const ok = b.type === 'table' && Array.isArray(b.widths) && b.widths.length && b.widths.every((x) => Number.isFinite(+x) && +x > 0);
      if (ok) b.widths = b.widths.map((x) => Math.round(+x));
      else delete b.widths;
    }
    if (b.color !== undefined) {
      const c = validColor(b.color);
      if (c) b.color = c;
      else delete b.color;
    }
    if (b.collapsed !== true) delete b.collapsed;
    b.indent = Math.max(0, Math.min(MAX_INDENT, parseInt(b.indent, 10) || 0));
    if (!b.indent) delete b.indent;
    out.push(b);
  }
  return out;
}

export function cloneBlocks(blocks) {
  return JSON.parse(JSON.stringify(blocks)).map((b) => Object.assign(b, { id: uid() }));
}

// Цвета блоков (как в Notion): цвет текста или цвет фона
export const COLORS = [
  ['gray', 'Серый'],
  ['brown', 'Коричневый'],
  ['orange', 'Оранжевый'],
  ['yellow', 'Жёлтый'],
  ['green', 'Зелёный'],
  ['blue', 'Синий'],
  ['purple', 'Фиолетовый'],
  ['pink', 'Розовый'],
  ['red', 'Красный'],
];
const COLOR_SET = new Set(COLORS.map((c) => c[0]));

/** Проверяет значение цвета: 'red' (текст) или 'red_background' (фон). */
export function validColor(c) {
  if (!c || typeof c !== 'string') return null;
  const base = c.replace(/_background$/, '');
  return COLOR_SET.has(base) ? c : null;
}

export function colorLabel(c) {
  const base = c.replace(/_background$/, '');
  const name = (COLORS.find((x) => x[0] === base) || [, ''])[1];
  return c.endsWith('_background') ? `${name} фон` : `${name} текст`;
}
