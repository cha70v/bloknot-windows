<?php
/** Страницы: дерево, содержимое, версии, корзина, поиск. */

function empty_content()
{
    return '{"v":1,"blocks":[]}';
}

function page_row_public($p, $withContent = false)
{
    $out = array(
        'id' => (int) $p['id'],
        'parent_id' => $p['parent_id'] === null ? null : (int) $p['parent_id'],
        'position' => (float) $p['position'],
        'title' => $p['title'],
        'icon' => $p['icon'],
        'cover' => $p['cover'],
        'version' => (int) $p['version'],
        'created_at' => (int) $p['created_at'],
        'updated_at' => (int) $p['updated_at'],
        'last_opened_at' => $p['last_opened_at'] === null ? null : (int) $p['last_opened_at'],
        'favorite_at' => isset($p['favorite_at']) && $p['favorite_at'] !== null ? (int) $p['favorite_at'] : null,
    );
    if (isset($p['deleted_at']) && $p['deleted_at'] !== null) {
        $out['deleted_at'] = (int) $p['deleted_at'];
    }
    if ($withContent) {
        $c = json_decode($p['content'], true);
        $out['content'] = is_array($c) ? $c : array('v' => 1, 'blocks' => array());
    }
    return $out;
}

function page_get_owned($uid, $id, $allowDeleted = false)
{
    $p = q_one('SELECT * FROM pages WHERE id = ? AND owner_id = ?', array((int) $id, (int) $uid));
    if (!$p) throw new HttpError(404, 'Страница не найдена');
    if (!$allowDeleted && $p['deleted_at'] !== null) throw new HttpError(410, 'Страница находится в корзине', array('deleted' => true));
    return $p;
}

function pages_tree($uid)
{
    $rows = q('SELECT id, parent_id, position, title, icon, cover, version, created_at, updated_at, last_opened_at, deleted_at, favorite_at
               FROM pages WHERE owner_id = ? AND deleted_at IS NULL ORDER BY position', array($uid))->fetchAll();
    $out = array();
    foreach ($rows as $r) $out[] = page_row_public($r);
    return array('pages' => $out, 'tree_stamp' => meta_get('tree_stamp', '0'));
}

/** Извлекает текст из блоков для поиска. */
function blocks_plain_text($blocks, $limit = 400000)
{
    $parts = array();
    $len = 0;
    foreach ((array) $blocks as $b) {
        if (!is_array($b)) continue;
        foreach (array('html', 'caption', 'title', 'url') as $k) {
            if (isset($b[$k]) && is_string($b[$k]) && $b[$k] !== '') {
                $txt = html_entity_decode(strip_tags(str_replace(array('<br>', '<br/>', '</p>'), ' ', $b[$k])), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $parts[] = $txt;
                $len += strlen($txt);
            }
        }
        if (isset($b['text']) && is_string($b['text'])) {
            $parts[] = $b['text'];
            $len += strlen($b['text']);
        }
        if (isset($b['rows']) && is_array($b['rows'])) {
            foreach ($b['rows'] as $row) {
                foreach ((array) $row as $cell) {
                    if (is_string($cell)) {
                        $t = html_entity_decode(strip_tags($cell), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                        $parts[] = $t;
                        $len += strlen($t);
                    }
                }
            }
        }
        if ($len > $limit) break;
    }
    return preg_replace('/\s+/u', ' ', implode("\n", $parts));
}

function normalize_content($content)
{
    if (is_string($content)) {
        if (strlen($content) > MAX_PAGE_BYTES) throw new HttpError(413, 'Страница слишком большая (больше 8 МБ)');
        $content = json_decode($content, true);
    }
    if (!is_array($content)) throw new HttpError(422, 'Некорректное содержимое страницы');
    $blocks = isset($content['blocks']) && is_array($content['blocks']) ? array_values($content['blocks']) : array();
    $doc = array('v' => 1, 'blocks' => $blocks);
    $json = json_encode($doc, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) throw new HttpError(422, 'Не удалось обработать содержимое страницы');
    if (strlen($json) > MAX_PAGE_BYTES) throw new HttpError(413, 'Страница слишком большая (больше 8 МБ)');
    return array($json, $blocks);
}

function clean_title($t)
{
    $t = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string) $t));
    return t_substr($t, 0, 500);
}

function clean_icon($i)
{
    $i = trim((string) $i);
    return t_substr($i, 0, 16);
}

function clean_cover($c)
{
    $c = trim((string) $c);
    if ($c === '') return '';
    // обложка: идентификатор файла (file:xxxx) или цвет/градиент из встроенного набора (preset:имя)
    if (preg_match('/^file:[a-f0-9]{32}$/', $c) || preg_match('/^preset:[a-z0-9-]{1,32}$/', $c)) return $c;
    return '';
}

function next_position($uid, $parentId)
{
    if ($parentId === null) {
        $max = q_val('SELECT MAX(position) FROM pages WHERE owner_id = ? AND parent_id IS NULL AND deleted_at IS NULL', array($uid));
    } else {
        $max = q_val('SELECT MAX(position) FROM pages WHERE owner_id = ? AND parent_id = ? AND deleted_at IS NULL', array($uid, $parentId));
    }
    return $max === null ? 1024.0 : ((float) $max + 1024.0);
}

function check_parent($uid, $parentId, $selfId = null)
{
    if ($parentId === null || $parentId === '' || $parentId === 0) return null;
    $parentId = (int) $parentId;
    $p = q_one('SELECT id, deleted_at FROM pages WHERE id = ? AND owner_id = ?', array($parentId, $uid));
    if (!$p || $p['deleted_at'] !== null) throw new HttpError(422, 'Родительская страница не найдена');
    if ($selfId !== null) {
        // запрет циклов: родитель не может быть потомком перемещаемой страницы
        $ids = subtree_ids($uid, $selfId, true);
        if (in_array($parentId, $ids, true)) throw new HttpError(422, 'Нельзя переместить страницу внутрь самой себя');
    }
    return $parentId;
}

function page_create($uid, $data)
{
    $parentId = check_parent($uid, isset($data['parent_id']) ? $data['parent_id'] : null);
    $title = clean_title(isset($data['title']) ? $data['title'] : '');
    $icon = clean_icon(isset($data['icon']) ? $data['icon'] : '');
    $cover = clean_cover(isset($data['cover']) ? $data['cover'] : '');
    $contentJson = empty_content();
    $blocks = array();
    if (isset($data['content'])) {
        list($contentJson, $blocks) = normalize_content($data['content']);
    }
    $position = isset($data['after_id']) && $data['after_id']
        ? position_after($uid, $parentId, (int) $data['after_id'])
        : next_position($uid, $parentId);
    $now = now_ms();
    q('INSERT INTO pages(owner_id, parent_id, position, title, icon, cover, content, search_text, version, created_at, updated_at)
       VALUES(?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)',
        array($uid, $parentId, $position, $title, $icon, $cover, $contentJson,
            t_lower($title . "\n" . blocks_plain_text($blocks)), $now, $now));
    $id = (int) db()->lastInsertId();
    touch_tree();
    return page_row_public(page_get_owned($uid, $id), true);
}

function position_after($uid, $parentId, $afterId)
{
    $after = q_one('SELECT position FROM pages WHERE id = ? AND owner_id = ?', array($afterId, $uid));
    if (!$after) return next_position($uid, $parentId);
    $sql = 'SELECT MIN(position) FROM pages WHERE owner_id = ? AND deleted_at IS NULL AND position > ? AND ' . ($parentId === null ? 'parent_id IS NULL' : 'parent_id = ?');
    $params = $parentId === null ? array($uid, $after['position']) : array($uid, $after['position'], $parentId);
    $next = q_val($sql, $params);
    if ($next === null) return (float) $after['position'] + 1024.0;
    return ((float) $after['position'] + (float) $next) / 2;
}

function maybe_snapshot($page, $reason, $forceSnapshot = false)
{
    $last = q_val('SELECT MAX(created_at) FROM revisions WHERE page_id = ?', array($page['id']));
    $lastContent = q_val('SELECT content FROM revisions WHERE page_id = ? ORDER BY id DESC LIMIT 1', array($page['id']));
    if ($lastContent !== null && $lastContent === $page['content']) return;
    if ($page['content'] === empty_content() && $page['title'] === '') return;
    if ($forceSnapshot || $last === null || (int) $last < now_ms() - REVISION_INTERVAL * 1000) {
        q('INSERT INTO revisions(page_id, version, title, content, reason, created_at) VALUES(?, ?, ?, ?, ?, ?)',
            array($page['id'], $page['version'], $page['title'], $page['content'], $reason, now_ms()));
        // ограничиваем количество снимков
        q('DELETE FROM revisions WHERE page_id = ? AND id NOT IN (SELECT id FROM revisions WHERE page_id = ? ORDER BY id DESC LIMIT ' . (int) REVISIONS_KEEP . ')',
            array($page['id'], $page['id']));
    }
}

/**
 * Сохранение с оптимистичной блокировкой: клиент присылает версию, на которой основаны изменения.
 * Если на сервере уже более новая версия — ответ 409 и копия отклонённого содержимого в истории.
 */
function page_save($uid, $data)
{
    $id = isset($data['id']) ? (int) $data['id'] : 0;
    $base = isset($data['base_version']) ? (int) $data['base_version'] : -1;
    $force = !empty($data['force']);

    db()->beginTransaction();
    try {
        // BEGIN IMMEDIATE в PDO недоступен напрямую — сериализуем через запись-заглушку
        q("UPDATE meta SET value = value WHERE key = 'schema_version'");
        $page = page_get_owned($uid, $id, true);
        if ($page['deleted_at'] !== null) {
            throw new HttpError(410, 'Страница находится в корзине', array('deleted' => true));
        }
        $title = array_key_exists('title', $data) ? clean_title($data['title']) : $page['title'];
        $icon = array_key_exists('icon', $data) ? clean_icon($data['icon']) : $page['icon'];
        $cover = array_key_exists('cover', $data) ? clean_cover($data['cover']) : $page['cover'];
        if (array_key_exists('content', $data)) {
            list($contentJson, $blocks) = normalize_content($data['content']);
        } else {
            $contentJson = $page['content'];
            $decoded = json_decode($contentJson, true);
            $blocks = isset($decoded['blocks']) ? $decoded['blocks'] : array();
        }

        if (!$force && $base !== (int) $page['version']) {
            if ($contentJson !== $page['content'] || $title !== $page['title']) {
                q('INSERT INTO revisions(page_id, version, title, content, reason, created_at) VALUES(?, ?, ?, ?, ?, ?)',
                    array($page['id'], $base, $title, $contentJson, 'conflict', now_ms()));
            }
            db()->commit();
            throw new HttpError(409, 'Страница изменена на другом устройстве', array('server' => page_row_public($page, true)));
        }

        $unchanged = $contentJson === $page['content'] && $title === $page['title'] && $icon === $page['icon'] && $cover === $page['cover'];
        if ($unchanged) {
            db()->commit();
            return array('version' => (int) $page['version'], 'updated_at' => (int) $page['updated_at'], 'unchanged' => true);
        }

        maybe_snapshot($page, $force && $base !== (int) $page['version'] ? 'overwrite' : 'auto', $force && $base !== (int) $page['version']);

        $now = now_ms();
        $newVersion = (int) $page['version'] + 1;
        q('UPDATE pages SET title = ?, icon = ?, cover = ?, content = ?, search_text = ?, version = ?, updated_at = ? WHERE id = ?',
            array($title, $icon, $cover, $contentJson, t_lower($title . "\n" . blocks_plain_text($blocks)), $newVersion, $now, $page['id']));
        if ($title !== $page['title'] || $icon !== $page['icon'] || $cover !== $page['cover']) touch_tree();
        db()->commit();
        return array('version' => $newVersion, 'updated_at' => $now);
    } catch (Exception $e) {
        if (db()->inTransaction()) db()->rollBack();
        throw $e;
    }
}

function subtree_ids($uid, $rootId, $includeDeleted = false)
{
    // обход в ширину вместо рекурсивного CTE — работает и со старыми версиями SQLite
    $root = q_val('SELECT id FROM pages WHERE id = ? AND owner_id = ?', array((int) $rootId, $uid));
    if ($root === null) return array();
    $all = q('SELECT id, parent_id FROM pages WHERE owner_id = ?' . ($includeDeleted ? '' : ' AND deleted_at IS NULL'), array($uid))->fetchAll();
    $kids = array();
    foreach ($all as $r) {
        if ($r['parent_id'] !== null) $kids[(int) $r['parent_id']][] = (int) $r['id'];
    }
    $out = array((int) $root);
    for ($i = 0; $i < count($out); $i++) {
        if (isset($kids[$out[$i]])) {
            foreach ($kids[$out[$i]] as $k) $out[] = $k;
        }
    }
    return $out;
}

function page_move($uid, $data)
{
    $id = (int) $data['id'];
    $page = page_get_owned($uid, $id);
    $parentId = check_parent($uid, isset($data['parent_id']) ? $data['parent_id'] : null, $id);
    $beforeId = isset($data['before_id']) ? (int) $data['before_id'] : 0;
    $afterId = isset($data['after_id']) ? (int) $data['after_id'] : 0;

    $siblingsSql = 'SELECT id, position FROM pages WHERE owner_id = ? AND deleted_at IS NULL AND id != ? AND '
        . ($parentId === null ? 'parent_id IS NULL' : 'parent_id = ?') . ' ORDER BY position';
    $params = $parentId === null ? array($uid, $id) : array($uid, $id, $parentId);
    $sibs = q($siblingsSql, $params)->fetchAll();

    $index = count($sibs);
    foreach ($sibs as $i => $s) {
        if ($beforeId && (int) $s['id'] === $beforeId) { $index = $i; break; }
        if ($afterId && (int) $s['id'] === $afterId) { $index = $i + 1; break; }
    }
    $prev = $index > 0 ? (float) $sibs[$index - 1]['position'] : null;
    $next = $index < count($sibs) ? (float) $sibs[$index]['position'] : null;
    if ($prev === null && $next === null) $pos = 1024.0;
    elseif ($prev === null) $pos = $next - 1024.0;
    elseif ($next === null) $pos = $prev + 1024.0;
    else $pos = ($prev + $next) / 2;

    // слишком маленький зазор — перенумеровываем соседей
    if ($prev !== null && $next !== null && abs($next - $prev) < 1e-6) {
        db()->beginTransaction();
        $n = 0;
        foreach ($sibs as $i => $s) {
            if ($i === $index) $n++;
            q('UPDATE pages SET position = ? WHERE id = ?', array(($n + 1) * 1024.0, $s['id']));
            $n++;
        }
        db()->commit();
        $pos = ($index + 1) * 1024.0;
    }
    q('UPDATE pages SET parent_id = ?, position = ? WHERE id = ?', array($parentId, $pos, $id));
    touch_tree();
    return page_row_public(page_get_owned($uid, $id));
}

function page_duplicate($uid, $id)
{
    $root = page_get_owned($uid, $id);
    $ids = subtree_ids($uid, $id);
    if (count($ids) > 2000) throw new HttpError(422, 'Слишком большое дерево для копирования');
    $map = array();
    $now = now_ms();
    db()->beginTransaction();
    try {
        $rows = array();
        foreach ($ids as $pid) $rows[$pid] = q_one('SELECT * FROM pages WHERE id = ?', array($pid));
        foreach ($ids as $pid) {
            $p = $rows[$pid];
            $isRoot = $pid === (int) $root['id'];
            $parent = $isRoot ? ($p['parent_id'] === null ? null : (int) $p['parent_id']) : $map[(int) $p['parent_id']];
            $position = $isRoot ? position_after($uid, $parent, (int) $p['id']) : (float) $p['position'];
            $title = $isRoot ? clean_title(($p['title'] === '' ? 'Без названия' : $p['title']) . ' (копия)') : $p['title'];
            q('INSERT INTO pages(owner_id, parent_id, position, title, icon, cover, content, search_text, version, created_at, updated_at)
               VALUES(?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)',
                array($uid, $parent, $position, $title, $p['icon'], $p['cover'], $p['content'], $p['search_text'], $now, $now));
            $map[$pid] = (int) db()->lastInsertId();
        }
        // переназначаем ссылки на вложенные страницы внутри скопированного содержимого
        foreach ($map as $old => $new) {
            $c = json_decode($rows[$old]['content'], true);
            if (!is_array($c) || empty($c['blocks'])) continue;
            $changed = false;
            foreach ($c['blocks'] as &$b) {
                if (isset($b['type'], $b['pageId']) && $b['type'] === 'page' && isset($map[(int) $b['pageId']])) {
                    $b['pageId'] = $map[(int) $b['pageId']];
                    $changed = true;
                }
            }
            unset($b);
            if ($changed) {
                q('UPDATE pages SET content = ? WHERE id = ?', array(json_encode($c, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $new));
            }
        }
        db()->commit();
    } catch (Exception $e) {
        db()->rollBack();
        throw $e;
    }
    touch_tree();
    return page_row_public(page_get_owned($uid, $map[(int) $root['id']]));
}

function page_trash($uid, $id)
{
    page_get_owned($uid, $id);
    $ids = subtree_ids($uid, $id);
    $now = now_ms();
    db()->beginTransaction();
    q('UPDATE pages SET deleted_at = ?, trash_root = 0 WHERE id IN (' . implode(',', $ids) . ')', array($now));
    q('UPDATE pages SET trash_root = 1 WHERE id = ?', array((int) $id));
    db()->commit();
    touch_tree();
    return array('trashed' => count($ids));
}

function trash_list($uid)
{
    $rows = q('SELECT * FROM pages WHERE owner_id = ? AND deleted_at IS NOT NULL AND trash_root = 1 ORDER BY deleted_at DESC', array($uid))->fetchAll();
    $out = array();
    foreach ($rows as $r) {
        $item = page_row_public($r);
        $item['children_count'] = count(subtree_ids($uid, $r['id'], true)) - 1;
        $out[] = $item;
    }
    return $out;
}

function page_restore($uid, $id)
{
    $p = page_get_owned($uid, $id, true);
    if ($p['deleted_at'] === null) return page_row_public($p);
    $deletedAt = (int) $p['deleted_at'];
    $all = subtree_ids($uid, $id, true);
    db()->beginTransaction();
    q('UPDATE pages SET deleted_at = NULL, trash_root = 0 WHERE id IN (' . implode(',', $all) . ') AND deleted_at = ?', array($deletedAt));
    // если родитель удалён или отсутствует — восстанавливаем в корень
    if ($p['parent_id'] !== null) {
        $parent = q_one('SELECT deleted_at FROM pages WHERE id = ? AND owner_id = ?', array($p['parent_id'], $uid));
        if (!$parent || $parent['deleted_at'] !== null) {
            q('UPDATE pages SET parent_id = NULL, position = ? WHERE id = ?', array(next_position($uid, null), (int) $id));
        }
    }
    db()->commit();
    touch_tree();
    return page_row_public(page_get_owned($uid, $id));
}

function page_purge($uid, $id)
{
    $p = page_get_owned($uid, $id, true);
    if ($p['deleted_at'] === null) throw new HttpError(422, 'Сначала переместите страницу в корзину');
    $ids = subtree_ids($uid, $id, true);
    $fileIds = q('SELECT id FROM files WHERE owner_id = ? AND page_id IN (' . implode(',', $ids) . ')', array($uid))->fetchAll(PDO::FETCH_COLUMN);
    db()->beginTransaction();
    q('DELETE FROM revisions WHERE page_id IN (' . implode(',', $ids) . ')');
    q('DELETE FROM pages WHERE id IN (' . implode(',', $ids) . ')');
    db()->commit();
    files_delete_if_unreferenced($uid, $fileIds);
    touch_tree();
    return array('deleted' => count($ids));
}

function trash_empty($uid)
{
    $roots = q('SELECT id FROM pages WHERE owner_id = ? AND deleted_at IS NOT NULL AND trash_root = 1', array($uid))->fetchAll(PDO::FETCH_COLUMN);
    $n = 0;
    foreach ($roots as $r) {
        if (q_val('SELECT id FROM pages WHERE id = ?', array($r)) === null) continue;
        $res = page_purge($uid, $r);
        $n += $res['deleted'];
    }
    return array('deleted' => $n);
}

function like_escape($s)
{
    return str_replace(array('\\', '%', '_'), array('\\\\', '\\%', '\\_'), $s);
}

function pages_search($uid, $query)
{
    $query = trim(t_lower((string) $query));
    if ($query === '') return array();
    $query = t_substr($query, 0, 200);
    $like = '%' . like_escape($query) . '%';
    $rows = q("SELECT id, parent_id, title, icon, updated_at, search_text,
                 CASE WHEN lower(title) LIKE ? ESCAPE '\\' THEN 0 ELSE 1 END AS rank
               FROM pages WHERE owner_id = ? AND deleted_at IS NULL AND search_text LIKE ? ESCAPE '\\'
               ORDER BY rank, updated_at DESC LIMIT 60", array($like, $uid, $like))->fetchAll();
    $out = array();
    foreach ($rows as $r) {
        // повторная проверка совпадения в заголовке с учётом кириллицы (lower() SQLite — только ASCII)
        $titleHit = t_strpos(t_lower($r['title']), $query) !== false;
        $text = $r['search_text'];
        $nl = strpos($text, "\n");
        $body = $nl === false ? '' : substr($text, $nl + 1);
        $snippet = '';
        $pos = t_strpos($body, $query);
        if ($pos !== false) {
            $start = max(0, $pos - 50);
            $snippet = ($start > 0 ? '…' : '') . t_substr($body, $start, 160) . (t_strlen($body) > $start + 160 ? '…' : '');
        }
        $out[] = array(
            'id' => (int) $r['id'],
            'parent_id' => $r['parent_id'] === null ? null : (int) $r['parent_id'],
            'title' => $r['title'],
            'icon' => $r['icon'],
            'updated_at' => (int) $r['updated_at'],
            'snippet' => $snippet,
            'title_hit' => $titleHit,
        );
    }
    usort($out, function ($a, $b) {
        if ($a['title_hit'] !== $b['title_hit']) return $a['title_hit'] ? -1 : 1;
        return $b['updated_at'] - $a['updated_at'];
    });
    return array_slice($out, 0, 40);
}

function pages_recent($uid)
{
    $rows = q('SELECT id, parent_id, position, title, icon, cover, version, created_at, updated_at, last_opened_at, deleted_at, favorite_at FROM pages
               WHERE owner_id = ? AND deleted_at IS NULL AND last_opened_at IS NOT NULL ORDER BY last_opened_at DESC LIMIT 12', array($uid))->fetchAll();
    return array_map('page_row_public', $rows);
}

function page_open($uid, $id)
{
    $p = page_get_owned($uid, $id);
    q('UPDATE pages SET last_opened_at = ? WHERE id = ?', array(now_ms(), $p['id']));
    $p['last_opened_at'] = now_ms();
    return page_row_public($p, true);
}

function page_revisions($uid, $id)
{
    page_get_owned($uid, $id, true);
    $rows = q('SELECT id, version, title, reason, created_at, length(content) AS size FROM revisions WHERE page_id = ? ORDER BY id DESC', array((int) $id))->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int) $r['id'];
        $r['version'] = (int) $r['version'];
        $r['created_at'] = (int) $r['created_at'];
        $r['size'] = (int) $r['size'];
    }
    return $rows;
}

function revision_get($uid, $revId)
{
    $r = q_one('SELECT r.* FROM revisions r JOIN pages p ON p.id = r.page_id WHERE r.id = ? AND p.owner_id = ?', array((int) $revId, $uid));
    if (!$r) throw new HttpError(404, 'Версия не найдена');
    return array(
        'id' => (int) $r['id'],
        'page_id' => (int) $r['page_id'],
        'version' => (int) $r['version'],
        'title' => $r['title'],
        'reason' => $r['reason'],
        'created_at' => (int) $r['created_at'],
        'content' => json_decode($r['content'], true),
    );
}

function page_favorite($uid, $id, $on)
{
    page_get_owned($uid, $id);
    q('UPDATE pages SET favorite_at = ? WHERE id = ?', array($on ? now_ms() : null, (int) $id));
    touch_tree();
    return page_row_public(page_get_owned($uid, $id));
}

function poll_state($uid, $pageId)
{
    $out = array('tree_stamp' => meta_get('tree_stamp', '0'), 'server_time' => now_ms());
    if ($pageId) {
        $p = q_one('SELECT id, version, updated_at, deleted_at FROM pages WHERE id = ? AND owner_id = ?', array((int) $pageId, $uid));
        $out['page'] = $p ? array(
            'id' => (int) $p['id'],
            'version' => (int) $p['version'],
            'updated_at' => (int) $p['updated_at'],
            'deleted' => $p['deleted_at'] !== null,
        ) : array('id' => (int) $pageId, 'missing' => true);
    }
    return $out;
}
