<?php
/**
 * Блокнот — общий загрузчик: конфигурация, база данных, сессии, вспомогательные функции.
 * Совместимо с PHP 7.4+.
 */

if (!defined('TETRAD')) {
    define('TETRAD', 1);
}
define('TETRAD_VERSION', '1.13.1');
define('TETRAD_ROOT', dirname(__DIR__));
define('TETRAD_DATA', rtrim(getenv('TETRAD_DATA_DIR') ?: (TETRAD_ROOT . '/data'), '/'));
define('TETRAD_SCHEMA', 4);

// Лимиты
define('MAX_IMAGE_BYTES', 15 * 1024 * 1024);   // 15 МБ на изображение
define('MAX_PAGE_BYTES', 8 * 1024 * 1024);     // 8 МБ JSON содержимого страницы
define('REVISION_INTERVAL', 600);              // снимок истории не чаще, чем раз в 10 минут
define('REVISIONS_KEEP', 60);                  // сколько снимков хранить на страницу

error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
ini_set('default_charset', 'UTF-8');
if (function_exists('mb_internal_encoding')) {
    mb_internal_encoding('UTF-8');
}
date_default_timezone_set('UTC');

// ---- Полифилы для PHP 7.4 ----
if (!function_exists('str_starts_with')) {
    function str_starts_with($h, $n) { return $n === '' || strncmp($h, $n, strlen($n)) === 0; }
}
if (!function_exists('str_ends_with')) {
    function str_ends_with($h, $n) { return $n === '' || substr($h, -strlen($n)) === $n; }
}
if (!function_exists('str_contains')) {
    function str_contains($h, $n) { return $n === '' || strpos($h, $n) !== false; }
}

class HttpError extends Exception
{
    public $status;
    public $extra;
    public function __construct($status, $message, $extra = array())
    {
        parent::__construct($message);
        $this->status = $status;
        $this->extra = $extra;
    }
}

function t_lower($s)
{
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function t_substr($s, $start, $len = null)
{
    if (function_exists('mb_substr')) {
        return $len === null ? mb_substr($s, $start, null, 'UTF-8') : mb_substr($s, $start, $len, 'UTF-8');
    }
    return $len === null ? substr($s, $start) : substr($s, $start, $len);
}

function t_strlen($s)
{
    return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s);
}

function t_strpos($h, $n)
{
    return function_exists('mb_strpos') ? mb_strpos($h, $n, 0, 'UTF-8') : strpos($h, $n);
}

function now_ms()
{
    return (int) round(microtime(true) * 1000);
}

function random_token($bytes = 16)
{
    return bin2hex(random_bytes($bytes));
}

function is_https()
{
    if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') return true;
    if (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) return true;
    if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') return true;
    if (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && strtolower($_SERVER['HTTP_X_FORWARDED_SSL']) === 'on') return true;
    if (!empty($_SERVER['HTTP_CF_VISITOR']) && str_contains($_SERVER['HTTP_CF_VISITOR'], 'https')) return true;
    if (!empty($_SERVER['REQUEST_SCHEME']) && strtolower($_SERVER['REQUEST_SCHEME']) === 'https') return true;
    if (!empty($_SERVER['HTTP_X_FORWARDED_SCHEME']) && strtolower($_SERVER['HTTP_X_FORWARDED_SCHEME']) === 'https') return true;
    if (!empty($_SERVER['HTTP_FRONT_END_HTTPS']) && strtolower($_SERVER['HTTP_FRONT_END_HTTPS']) !== 'off') return true;
    if (!empty($_SERVER['HTTP_X_HTTPS']) && $_SERVER['HTTP_X_HTTPS'] !== '0') return true;
    return false;
}

// ---- Автоматический переход на HTTPS ----
define('HTTPS_PROBE_TOKEN', 'bloknot-https-ok');

function request_host()
{
    $host = isset($_SERVER['HTTP_HOST']) ? strtolower((string) $_SERVER['HTTP_HOST']) : '';
    $host = preg_replace('/:\d+$/', '', $host);
    if (!preg_match('/^[a-z0-9.-]{1,253}$/', $host) || strpos($host, '.') === false) return null;
    return $host;
}

/** Адреса, для которых HTTPS не нужен или невозможен: localhost, IP-адреса, локальные имена. */
function https_exempt_host($host)
{
    if ($host === null) return true;
    if (filter_var($host, FILTER_VALIDATE_IP)) return true;
    return (bool) preg_match('/(^localhost$|\.localhost$|\.local$|\.test$|\.lan$)/', $host);
}

function base_path()
{
    $dir = str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '/'));
    return rtrim($dir === '.' ? '' : $dir, '/') . '/';
}

function https_cache_path()
{
    return TETRAD_DATA . '/https-check.json';
}

/** Проверяет (с кэшированием), что сайт действительно открывается по HTTPS с действующим сертификатом. */
function https_available($host)
{
    $cache = array();
    if (is_file(https_cache_path())) {
        $cache = json_decode((string) @file_get_contents(https_cache_path()), true);
        if (!is_array($cache)) $cache = array();
    }
    $now = time();
    if (isset($cache[$host])) {
        $c = $cache[$host];
        $ttl = !empty($c['ok']) ? 7 * 86400 : 600;
        if ($now - (int) $c['at'] < $ttl) return !empty($c['ok']);
    }
    $url = 'https://' . $host . base_path() . '?__probe=https';
    $body = false;
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_PROTOCOLS => CURLPROTO_HTTPS,
            CURLOPT_USERAGENT => 'Bloknot-HTTPS-check',
        ));
        $body = curl_exec($ch);
        if ((int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE) !== 200) $body = false;
        curl_close($ch);
    } elseif (ini_get('allow_url_fopen')) {
        $ctx = stream_context_create(array(
            'http' => array('timeout' => 5, 'follow_location' => 0, 'ignore_errors' => false),
            'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
        ));
        $body = @file_get_contents($url, false, $ctx);
    }
    $ok = is_string($body) && strpos($body, HTTPS_PROBE_TOKEN) !== false;
    if (count($cache) > 20) $cache = array();
    $cache[$host] = array('ok' => $ok, 'at' => $now);
    if (is_dir(TETRAD_DATA) && is_writable(TETRAD_DATA)) @file_put_contents(https_cache_path(), json_encode($cache), LOCK_EX);
    return $ok;
}

/**
 * Перенаправляет на HTTPS, если сайт открыт по HTTP и сертификат работает.
 * Защита от зацикливания: если после перенаправления запрос всё равно пришёл как HTTP
 * (прокси хостинга скрывает HTTPS), страница отдаётся без повторного перенаправления.
 * Отключить: создать файл data/NO-HTTPS-REDIRECT.
 */
function enforce_https()
{
    if (PHP_SAPI === 'cli') return;
    $method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : 'GET';
    if (isset($_GET['__probe']) && $_GET['__probe'] === 'https') {
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: no-store');
        echo HTTPS_PROBE_TOKEN;
        exit;
    }
    $uri = isset($_SERVER['REQUEST_URI']) ? (string) $_SERVER['REQUEST_URI'] : '/';
    if (is_https()) {
        // убираем служебный параметр после успешного перехода
        if (isset($_GET['_https']) && ($method === 'GET' || $method === 'HEAD')) {
            $clean = preg_replace('/([?&])_https=1(&|$)/', '$1', $uri);
            $clean = rtrim($clean, '?&');
            header('Location: ' . $clean, true, 302);
            exit;
        }
        return;
    }
    if ($method !== 'GET' && $method !== 'HEAD') return;
    if (isset($_GET['_https'])) return; // уже перенаправляли — HTTPS не виден за прокси
    if (is_file(TETRAD_DATA . '/NO-HTTPS-REDIRECT')) return;
    $host = request_host();
    if (https_exempt_host($host)) return;
    if (!https_available($host)) return;
    $target = 'https://' . $host . $uri . (strpos($uri, '?') === false ? '?' : '&') . '_https=1';
    header('Cache-Control: no-store');
    header('Location: ' . $target, true, 301);
    exit;
}

function client_ip()
{
    return isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}

function security_headers()
{
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('X-Frame-Options: DENY');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    if (is_https()) {
        header('Strict-Transport-Security: max-age=31536000');
    }
}

// ---- Конфигурация ----
function config_path()
{
    return TETRAD_DATA . '/config.php';
}

function is_installed()
{
    return is_file(config_path());
}

function config($key = null, $default = null)
{
    static $cfg = null;
    if ($cfg === null || !empty($GLOBALS['__tetrad_cfg_reload'])) {
        $GLOBALS['__tetrad_cfg_reload'] = false;
        $cfg = is_installed() ? (include config_path()) : array();
        if (!is_array($cfg)) $cfg = array();
    }
    if ($key === null) return $cfg;
    return array_key_exists($key, $cfg) ? $cfg[$key] : $default;
}

function write_php_config($path, array $cfg)
{
    $php = "<?php\n// Сгенерировано установщиком Блокнота. Не публикуйте этот файл.\n"
        . "if (!defined('TETRAD')) { http_response_code(403); exit; }\n"
        . 'return ' . var_export($cfg, true) . ";\n";
    $tmp = $path . '.tmp' . random_token(4);
    if (file_put_contents($tmp, $php, LOCK_EX) === false) {
        throw new HttpError(500, 'Не удалось записать конфигурацию');
    }
    rename($tmp, $path);
    @chmod($path, 0640);
    if (function_exists('opcache_invalidate')) @opcache_invalidate($path, true);
}

function db_path()
{
    return TETRAD_DATA . '/' . config('db_file', 'tetrad.sqlite');
}

function uploads_dir()
{
    return TETRAD_DATA . '/uploads';
}

/**
 * Защитные файлы для каталога данных (Apache 2.2/2.4, LiteSpeed). На nginx нужна отдельная проверка —
 * её выполняет установщик и страница настроек.
 */
function ensure_data_protection($dir)
{
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    $ht = "# Запрет прямого доступа к данным Блокнота\n"
        . "<IfModule mod_authz_core.c>\n  Require all denied\n</IfModule>\n"
        . "<IfModule !mod_authz_core.c>\n  Order allow,deny\n  Deny from all\n</IfModule>\n"
        . "Options -Indexes\n";
    if (!is_file($dir . '/.htaccess')) @file_put_contents($dir . '/.htaccess', $ht);
    if (!is_file($dir . '/index.html')) @file_put_contents($dir . '/index.html', '');
    if (!is_file($dir . '/web.config')) {
        @file_put_contents($dir . '/web.config', '<?xml version="1.0" encoding="UTF-8"?><configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>');
    }
}

// ---- База данных ----
function db()
{
    if (!empty($GLOBALS['__tetrad_pdo'])) return $GLOBALS['__tetrad_pdo'];
    $pdo = new PDO('sqlite:' . db_path(), null, null, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 10,
    ));
    $pdo->exec('PRAGMA busy_timeout = 10000');
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec('PRAGMA synchronous = FULL');
    $GLOBALS['__tetrad_pdo'] = $pdo;
    migrate($pdo);
    return $pdo;
}

function db_close()
{
    $GLOBALS['__tetrad_pdo'] = null;
}

function q($sql, $params = array())
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st;
}

function q_one($sql, $params = array())
{
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}

function q_val($sql, $params = array())
{
    $v = q($sql, $params)->fetchColumn();
    return $v === false ? null : $v;
}

function meta_get($key, $default = null)
{
    $v = q_val('SELECT value FROM meta WHERE key = ?', array($key));
    return $v === null ? $default : $v;
}

function meta_set($key, $value)
{
    q('INSERT OR REPLACE INTO meta(key, value) VALUES(?, ?)', array($key, (string) $value));
}

/** Миграции схемы. Каждая миграция выполняется один раз в транзакции. */
function migrate(PDO $pdo)
{
    $pdo->exec('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT)');
    $cur = (int) $pdo->query("SELECT value FROM meta WHERE key = 'schema_version'")->fetchColumn();
    if ($cur >= TETRAD_SCHEMA) return;

    $migrations = array(
        1 => array(
            'CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL DEFAULT \'\',
                password_hash TEXT NOT NULL,
                is_admin INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL,
                password_changed_at INTEGER NOT NULL DEFAULT 0
            )',
            'CREATE TABLE pages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                owner_id INTEGER NOT NULL REFERENCES users(id),
                parent_id INTEGER NULL,
                position REAL NOT NULL DEFAULT 0,
                title TEXT NOT NULL DEFAULT \'\',
                icon TEXT NOT NULL DEFAULT \'\',
                cover TEXT NOT NULL DEFAULT \'\',
                content TEXT NOT NULL DEFAULT \'{"v":1,"blocks":[]}\',
                search_text TEXT NOT NULL DEFAULT \'\',
                version INTEGER NOT NULL DEFAULT 1,
                created_at INTEGER NOT NULL,
                updated_at INTEGER NOT NULL,
                last_opened_at INTEGER NULL,
                deleted_at INTEGER NULL,
                trash_root INTEGER NOT NULL DEFAULT 0
            )',
            'CREATE INDEX idx_pages_owner_parent ON pages(owner_id, parent_id, position)',
            'CREATE INDEX idx_pages_owner_deleted ON pages(owner_id, deleted_at)',
            'CREATE INDEX idx_pages_opened ON pages(owner_id, last_opened_at)',
            'CREATE TABLE revisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                page_id INTEGER NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
                version INTEGER NOT NULL,
                title TEXT NOT NULL DEFAULT \'\',
                content TEXT NOT NULL,
                reason TEXT NOT NULL DEFAULT \'auto\',
                created_at INTEGER NOT NULL
            )',
            'CREATE INDEX idx_revisions_page ON revisions(page_id, created_at)',
            'CREATE TABLE files (
                id TEXT PRIMARY KEY,
                owner_id INTEGER NOT NULL REFERENCES users(id),
                page_id INTEGER NULL,
                mime TEXT NOT NULL,
                size INTEGER NOT NULL,
                width INTEGER NOT NULL DEFAULT 0,
                height INTEGER NOT NULL DEFAULT 0,
                original_name TEXT NOT NULL DEFAULT \'\',
                created_at INTEGER NOT NULL
            )',
            'CREATE TABLE login_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip TEXT NOT NULL,
                ok INTEGER NOT NULL,
                created_at INTEGER NOT NULL
            )',
            'CREATE INDEX idx_login_attempts ON login_attempts(ip, created_at)',
        ),
        2 => array(
            // отметка изменения дерева (для быстрой синхронизации боковой панели)
            "INSERT OR IGNORE INTO meta(key, value) VALUES('tree_stamp', '0')",
        ),
        3 => array(
            // избранные страницы
            'ALTER TABLE pages ADD COLUMN favorite_at INTEGER NULL',
        ),
        4 => array(
            // двухфакторный вход (одноразовые коды из приложения, RFC 6238)
            'ALTER TABLE users ADD COLUMN totp_secret TEXT NULL',
            'ALTER TABLE users ADD COLUMN totp_enabled_at INTEGER NULL',
            'ALTER TABLE users ADD COLUMN totp_last_step INTEGER NOT NULL DEFAULT 0',
            "ALTER TABLE users ADD COLUMN recovery_codes TEXT NOT NULL DEFAULT '[]'",
            'CREATE TABLE trusted_devices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                token_hash TEXT NOT NULL UNIQUE,
                label TEXT NOT NULL DEFAULT \'\',
                created_at INTEGER NOT NULL,
                expires_at INTEGER NOT NULL
            )',
        ),
    );

    foreach ($migrations as $ver => $stmts) {
        if ($ver <= $cur) continue;
        $pdo->beginTransaction();
        try {
            foreach ($stmts as $sql) $pdo->exec($sql);
            $st = $pdo->prepare("INSERT OR REPLACE INTO meta(key, value) VALUES('schema_version', ?)");
            $st->execute(array((string) $ver));
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }
}

function touch_tree()
{
    meta_set('tree_stamp', (string) now_ms());
}

// ---- Сессии ----
function start_session()
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $dir = TETRAD_DATA . '/sessions';
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    if (is_dir($dir) && is_writable($dir)) session_save_path($dir);
    $lifetime = 60 * 60 * 24 * 30;
    ini_set('session.gc_maxlifetime', (string) $lifetime);
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    ini_set('session.gc_probability', '1');
    ini_set('session.gc_divisor', '200');
    session_name(is_https() ? '__Host-tetrad' : 'tetrad_sid');
    $params = array(
        'lifetime' => $lifetime,
        'path' => '/',
        'secure' => is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    );
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params($params);
    } else {
        session_set_cookie_params($lifetime, '/; samesite=Lax', '', is_https(), true);
    }
    session_start();
    // продлеваем cookie при активности
    if (!empty($_SESSION['uid']) && (empty($_SESSION['renewed']) || $_SESSION['renewed'] < time() - 86400)) {
        $_SESSION['renewed'] = time();
        setcookie(session_name(), session_id(), array(
            'expires' => time() + $lifetime, 'path' => '/', 'secure' => is_https(), 'httponly' => true, 'samesite' => 'Lax',
        ));
    }
}

function current_user()
{
    static $user = false;
    if ($user !== false) return $user;
    start_session();
    $user = null;
    if (!empty($_SESSION['uid'])) {
        $row = q_one('SELECT id, email, name, is_admin, password_changed_at FROM users WHERE id = ?', array((int) $_SESSION['uid']));
        // если пароль сменили после входа — сессия недействительна
        if ($row && (int) $row['password_changed_at'] <= (int) (isset($_SESSION['login_at']) ? $_SESSION['login_at'] : 0)) {
            $user = $row;
        } else {
            $_SESSION = array();
        }
    }
    return $user;
}

function csrf_token()
{
    start_session();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = random_token(24);
    return $_SESSION['csrf'];
}
